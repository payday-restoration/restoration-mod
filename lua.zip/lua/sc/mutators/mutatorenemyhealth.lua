if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then

	MutatorEnemyHealth.reductions = {money = 0, exp = 0}
	MutatorEnemyHealth.disables_achievements = false

end