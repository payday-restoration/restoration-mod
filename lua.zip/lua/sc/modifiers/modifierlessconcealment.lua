function ModifierLessConcealment:modify_value(id, value)
	--Wiping to be safe
end