if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then

	function ModifierLessConcealment:modify_value(id, value)
		--Wiping to be safe
	end

end