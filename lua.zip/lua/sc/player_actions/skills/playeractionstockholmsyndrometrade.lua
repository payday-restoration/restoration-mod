function PlayerAction.StockholmSyndromeTrade.Function(pos, peer_id)
	--Fug u :DDDDDD
end