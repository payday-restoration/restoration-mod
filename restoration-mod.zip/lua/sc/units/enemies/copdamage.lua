local math_random = math.random

local mvec_1 = Vector3()
local mvec_2 = Vector3()
local ids_func = Idstring
local table_contains = table.contains

local enemies_visor = {
	ids_func("units/pd2_mod_halloween/characters/ene_swat_heavy_1_sc/ene_swat_heavy_1_sc"),
	ids_func("units/pd2_mod_halloween/characters/ene_swat_heavy_1_sc/ene_swat_heavy_1_sc_husk"),
	ids_func("units/pd2_mod_halloween/characters/ene_swat_heavy_r870_sc/ene_swat_heavy_r870_sc"),
	ids_func("units/pd2_mod_halloween/characters/ene_swat_heavy_r870_sc/ene_swat_heavy_r870_sc_husk"),
	ids_func("units/pd2_mod_halloween/characters/ene_fbi_heavy_1_sc/ene_fbi_heavy_1_sc"),
	ids_func("units/pd2_mod_halloween/characters/ene_fbi_heavy_1_sc/ene_fbi_heavy_1_sc_husk"),
	ids_func("units/pd2_mod_halloween/characters/ene_tazer_1/ene_tazer_1"),
	ids_func("units/pd2_mod_halloween/characters/ene_tazer_1/ene_tazer_1_husk"),     
	ids_func("units/pd2_mod_halloween/characters/ene_shield_2/ene_shield_2"),
	ids_func("units/pd2_mod_halloween/characters/ene_shield_2/ene_shield_2_husk"),     	
	ids_func("units/pd2_mod_halloween/characters/ene_zeal_swat_heavy_sc/ene_zeal_swat_heavy_sc"),
	ids_func("units/pd2_mod_halloween/characters/ene_zeal_swat_heavy_sc/ene_zeal_swat_heavy_sc_husk"),                 	
	ids_func("units/pd2_mod_halloween/characters/ene_zeal_tazer/ene_zeal_tazer"),
	ids_func("units/pd2_mod_halloween/characters/ene_zeal_tazer/ene_zeal_tazer_husk"),                 	
	ids_func("units/pd2_mod_halloween/characters/ene_city_heavy_g36/ene_city_heavy_g36"),
	ids_func("units/pd2_mod_halloween/characters/ene_city_heavy_g36/ene_city_heavy_g36_husk"),                 	
	ids_func("units/pd2_dlc_bex/characters/ene_tazer_1/ene_tazer_1"),
	ids_func("units/pd2_dlc_bex/characters/ene_tazer_1/ene_tazer_1_husk"),                 
	ids_func("units/pd2_dlc_bex/characters/ene_zeal_swat_heavy_sc/ene_zeal_swat_heavy_sc"),
	ids_func("units/pd2_dlc_bex/characters/ene_zeal_swat_heavy_sc/ene_zeal_swat_heavy_sc_husk"),                 
	ids_func("units/pd2_dlc_bex/characters/ene_city_heavy_g36/ene_city_heavy_g36"),
	ids_func("units/pd2_dlc_bex/characters/ene_city_heavy_g36/ene_city_heavy_g36_husk"),                 
	ids_func("units/pd2_dlc_bex/characters/ene_swat_heavy_r870/ene_swat_heavy_r870"),
	ids_func("units/pd2_dlc_bex/characters/ene_swat_heavy_r870/ene_swat_heavy_r870_husk"),                 
	ids_func("units/pd2_dlc_bex/characters/ene_swat_heavy_1/ene_swat_heavy_1"),
	ids_func("units/pd2_dlc_bex/characters/ene_swat_heavy_1/ene_swat_heavy_1_husk"),                 
	ids_func("units/pd2_dlc_gitgud/characters/ene_zeal_tazer_sc/ene_zeal_tazer_sc"),
	ids_func("units/pd2_dlc_gitgud/characters/ene_zeal_tazer_sc/ene_zeal_tazer_sc_husk"),                 
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_1/ene_fbi_heavy_1"),
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_1/ene_fbi_heavy_1_husk"),
	ids_func("units/pd2_mod_reapers/characters/ene_swat_heavy_1/ene_swat_heavy_1"),
	ids_func("units/pd2_mod_reapers/characters/ene_swat_heavy_1/ene_swat_heavy_1_husk"),
	ids_func("units/pd2_mod_reapers/characters/ene_shield_2/ene_shield_2"),
	ids_func("units/pd2_mod_reapers/characters/ene_shield_2/ene_shield_2_husk"),
	ids_func("units/pd2_mod_reapers/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy"),
	ids_func("units/pd2_mod_reapers/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy_husk"),	
	ids_func("units/pd2_mod_reapers/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870"),
	ids_func("units/pd2_mod_reapers/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870_husk"),	
	ids_func("units/pd2_mod_reapers/characters/ene_city_heavy_g36/ene_city_heavy_g36"),
	ids_func("units/pd2_mod_reapers/characters/ene_city_heavy_g36/ene_city_heavy_g36_husk"),	
	ids_func("units/pd2_mod_lapd/characters/ene_swat_heavy_1/ene_swat_heavy_1"),
	ids_func("units/pd2_mod_lapd/characters/ene_swat_heavy_1/ene_swat_heavy_1_husk"),                 
	ids_func("units/pd2_mod_lapd/characters/ene_shield_2/ene_shield_2"),
	ids_func("units/pd2_mod_lapd/characters/ene_shield_2/ene_shield_2_husk"),                 
	ids_func("units/pd2_mod_lapd/characters/ene_swat_heavy_r870/ene_swat_heavy_r870"),
	ids_func("units/pd2_mod_lapd/characters/ene_swat_heavy_r870/ene_swat_heavy_r870_husk"),                 
	ids_func("units/pd2_mod_lapd/characters/ene_fbi_heavy_1/ene_fbi_heavy_1"),
	ids_func("units/pd2_mod_lapd/characters/ene_fbi_heavy_1/ene_fbi_heavy_1_husk"),                             
	ids_func("units/pd2_mod_sharks/characters/ene_fbi_heavy_1/ene_fbi_heavy_1"),
	ids_func("units/pd2_mod_sharks/characters/ene_fbi_heavy_1/ene_fbi_heavy_1_husk"),                 
	ids_func("units/pd2_mod_sharks/characters/ene_murky_tazer/ene_murky_tazer"),
	ids_func("units/pd2_mod_sharks/characters/ene_murky_tazer/ene_murky_tazer_husk"),                 
	ids_func("units/pd2_mod_sharks/characters/ene_swat_heavy_1/ene_swat_heavy_1"),                 
	ids_func("units/pd2_mod_sharks/characters/ene_swat_heavy_1/ene_swat_heavy_1_husk"),               
	ids_func("units/pd2_mod_sharks/characters/ene_swat_heavy_r870/ene_swat_heavy_r870"),                 
	ids_func("units/pd2_mod_sharks/characters/ene_swat_heavy_r870/ene_swat_heavy_r870_husk"),
	ids_func("units/pd2_mod_sharks/characters/ene_murky_shield_yellow/ene_murky_shield_yellow"),
	ids_func("units/pd2_mod_sharks/characters/ene_murky_shield_yellow/ene_murky_shield_yellow_husk"),
	ids_func("units/pd2_mod_sharks/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy"),
	ids_func("units/pd2_mod_sharks/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy_husk"),
	ids_func("units/pd2_mod_omnia/characters/ene_omnia_heavy/ene_omnia_heavy"),
	ids_func("units/pd2_mod_omnia/characters/ene_omnia_heavy/ene_omnia_heavy_husk"),	
	ids_func("units/pd2_mod_omnia/characters/ene_grenadier_1/ene_grenadier_1"),
	ids_func("units/pd2_mod_omnia/characters/ene_grenadier_1/ene_grenadier_1_husk")             	
}

local enemies_plink = {	  
	ids_func("units/pd2_mod_lapd/characters/ene_fbi_heavy_r870_sc/ene_fbi_heavy_r870_sc"),
	ids_func("units/pd2_mod_lapd/characters/ene_fbi_heavy_r870_sc/ene_fbi_heavy_r870_sc_husk"),                     
	ids_func("units/pd2_mod_lapd/characters/ene_city_heavy_r870_sc/ene_city_heavy_r870_sc"),
	ids_func("units/pd2_mod_lapd/characters/ene_city_heavy_r870_sc/ene_city_heavy_r870_sc_husk"),

	ids_func("units/pd2_mod_reapers/characters/ene_city_heavy_r870/ene_city_heavy_r870"),
	ids_func("units/pd2_mod_reapers/characters/ene_city_heavy_r870/ene_city_heavy_r870_husk"),   
	
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870"),
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870_husk"),   
	
	ids_func("units/pd2_dlc_vip/characters/ene_phalanx_1_new/ene_phalanx_1_new"),
	ids_func("units/pd2_dlc_vip/characters/ene_phalanx_1_new/ene_phalanx_1_new_husk"),   
	
	ids_func("units/pd2_mod_omnia/characters/ene_omnia_heavy_r870/ene_omnia_heavy_r870"),
	ids_func("units/pd2_mod_omnia/characters/ene_omnia_heavy_r870/ene_omnia_heavy_r870_husk"),
	
	ids_func("units/pd2_mod_halloween/characters/ene_skele_swat/ene_skele_swat"),
	ids_func("units/pd2_mod_halloween/characters/ene_skele_swat/ene_skele_swat_husk"),
	ids_func("units/pd2_mod_halloween/characters/ene_skele_swat_2/ene_skele_swat_2"),
	ids_func("units/pd2_mod_halloween/characters/ene_skele_swat_2/ene_skele_swat_2_husk"),
	ids_func("units/pd2_mod_halloween/characters/ene_zeal_swat_heavy_r870_sc/ene_zeal_swat_heavy_r870_sc"),
	ids_func("units/pd2_mod_halloween/characters/ene_zeal_swat_heavy_r870_sc/ene_zeal_swat_heavy_r870_sc_husk"),                 	
	ids_func("units/pd2_mod_halloween/characters/ene_city_heavy_r870_sc/ene_city_heavy_r870_sc"),
	ids_func("units/pd2_mod_halloween/characters/ene_city_heavy_r870_sc/ene_city_heavy_r870_sc_husk"),
	
	ids_func("units/pd2_mod_sharks/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870"),
	ids_func("units/pd2_mod_sharks/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870_husk"),   	
	ids_func("units/pd2_mod_sharks/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870"),
	ids_func("units/pd2_mod_sharks/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870_husk"),
	
	ids_func("units/pd2_dlc_bex/characters/ene_fbi_heavy_1/ene_fbi_heavy_1"),
	ids_func("units/pd2_dlc_bex/characters/ene_fbi_heavy_1/ene_fbi_heavy_1_husk"),
	ids_func("units/pd2_dlc_bex/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870"),
	ids_func("units/pd2_dlc_bex/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870_husk"),
	ids_func("units/pd2_dlc_bex/characters/ene_city_heavy_r870/ene_city_heavy_r870"),
	ids_func("units/pd2_dlc_bex/characters/ene_city_heavy_r870/ene_city_heavy_r870_husk"),
	ids_func("units/pd2_dlc_bex/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870"),
	ids_func("units/pd2_dlc_bex/characters/ene_zeal_swat_heavy_r870/ene_zeal_swat_heavy_r870_husk"),

	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_1/ene_fbi_heavy_1"),
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_1/ene_fbi_heavy_1_husk"),
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870"),
	ids_func("units/pd2_mod_reapers/characters/ene_fbi_heavy_r870/ene_fbi_heavy_r870_husk"),
	
}

local grenadier_smash = {
	ids_func("units/pd2_mod_reapers/characters/ene_titan_taser/ene_titan_taser"),
	ids_func("units/pd2_mod_reapers/characters/ene_titan_taser/ene_titan_taser_husk"),
	ids_func("units/pd2_dlc_bex/characters/ene_grenadier_1/ene_grenadier_1"),
	ids_func("units/pd2_dlc_bex/characters/ene_grenadier_1/ene_grenadier_1_husk"),   
	ids_func("units/pd2_mod_sharks/characters/ene_grenadier_1/ene_grenadier_1"),
	ids_func("units/pd2_mod_sharks/characters/ene_grenadier_1/ene_grenadier_1_husk")    	
}

local armour = {
	-- Tans
	[Idstring("body_plate"):key()] = true,
	-- Dozer
	[Idstring("body_helmet"):key()] = true,
	[Idstring("body_helmet_ben"):key()] = true,
	[Idstring("body_helmet_black"):key()] = true,
	[Idstring("body_helmet_plate"):key()] = true,
	[Idstring("body_helmet_plate_black"):key()] = true,
	[Idstring("body_helmet_glass"):key()] = true,
	[Idstring("body_helmet_glass_ben"):key()] = true,
	[Idstring("body_helmet_glass_black"):key()] = true,
	[Idstring("body_armor_chest"):key()] = true,
	[Idstring("body_armor_stomache"):key()] = true,
	[Idstring("body_armor_back"):key()] = true,
	[Idstring("body_armor_throat"):key()] = true,
	[Idstring("body_armor_neck"):key()] = true,
	-- Sosa
	[Idstring("body_vest"):key()] = true,
	[Idstring("body_ammo"):key()] = true,
}

local impenetrable_armour = {
	[Idstring("acc_helmet"):key()] = true,
	[Idstring("acc_hat"):key()] = true,
	[Idstring("bag"):key()] = true,
	[Idstring("bag_gren"):key()] = true,
	[Idstring("antenna"):key()] = true,
}

local limbs = {
	[Idstring("rag_LeftUpLeg"):key()] = true,
	[Idstring("rag_LeftLeg"):key()] = true,
	[Idstring("rag_LeftFoot"):key()] = true,
	[Idstring("rag_RightUpLeg"):key()] = true,
	[Idstring("rag_RightLeg"):key()] = true,
	[Idstring("rag_RightFoot"):key()] = true
}

local damage_type_mult = {
	machine_gun = 0.6,
	pistol = 0.7,
	heavy_pistol = 0.6,
	handcannon = 0.8,
	assault_rifle = 0.6,
	sniper = 0.8
}

local head_hitboxes = {
	[Idstring("glass_shield"):key()] = true,
	[Idstring("glass_swat"):key()] = true,
	[Idstring("glass_c"):key()] = true,
	[Idstring("glass_d"):key()] = true,
	[Idstring("glass_l"):key()] = true,
	[Idstring("glass_r"):key()] = true,
	[Idstring("visor"):key()] = true,
	[Idstring("sg_mask"):key()] = true,
	[Idstring("glass_altyn"):key()] = true,
	[Idstring("altyn_visor"):key()] = true,
	[Idstring("glass_visor"):key()] = true
}

local bodies_tmp = {
	[Idstring("glass_shield"):key()] = 1,
	[Idstring("glass_swat"):key()] = 1,
	[Idstring("glass_c"):key()] = 1,
	[Idstring("glass_d"):key()] = 1,
	[Idstring("glass_l"):key()] = 1,
	[Idstring("glass_r"):key()] = 1,
	[Idstring("visor"):key()] = 1,
	[Idstring("sg_mask"):key()] = 1,
	[Idstring("glass_altyn"):key()] = 1,
	[Idstring("altyn_visor"):key()] = 1,
	[Idstring("glass_visor"):key()] = 1,
	[Idstring("body_helmet_plate"):key()] = 1,
	[Idstring("body_helmet_plate_black"):key()] = 1,
	[Idstring("body_helmet_glass"):key()] = 1,
	[Idstring("body_helmet_glass_ben"):key()] = 1,
	[Idstring("body_helmet_glass_black"):key()] = 1,
	[Idstring("bag"):key()] = 2,
	[Idstring("bag_gren"):key()] = 2,
	[Idstring("antenna"):key()] = 2,
	[Idstring("body_armor_chest"):key()] = 3,
	[Idstring("body_armor_stomache"):key()] = 3,
	[Idstring("body_armor_back"):key()] = 3,
	[Idstring("body_armor_throat"):key()] = 3,
	[Idstring("body_armor_neck"):key()] = 3,
}
CopDamage._priority_bodies_ids = bodies_tmp

--CopDamage._ON_STUN_ACCURACY_DECREASE = 0.5
--CopDamage._ON_STUN_ACCURACY_DECREASE_TIME = 5

local is_pro = Global.game_settings and Global.game_settings.one_down

Hooks:PostHook(CopDamage, "init", "res_init", function(self, unit)
	self._player_damage_ratio = 0 --Damage dealt to this enemy by players that contributed to the kill.
	self._last_overheal_t = 0 --- The last time the enemy has been near an LPF.
	self._decay_start_t = 0 --- When the overheal decay last started.

	--- I've been running into issues where CopMovement doesn't recognise decay_buffs().
	--- So one way I thought I could force the issue was by setting a "flag" to signal
	--- we're ready.
	self._may_decay_buffs = true
	
	-- i don't want to sift through every single .object file in the game to do this so
	if self._head_gear_decal_mesh then
		local mesh_name_idstr = Idstring(self._head_gear_decal_mesh)

		self._unit:decal_surface(mesh_name_idstr):set_mesh_material(mesh_name_idstr, Idstring("helmet"))
	end	
end)

Hooks:PostHook(CopDamage, "convert_to_criminal", "convert_to_criminal_mutator_no_outlines", function(self, health_multiplier)
	--Disable LPF overheal effect for jokers
	self._unit:base():disable_lpf_buff()
	--Special effect for jokers with No Outlines mutator
	if managers.mutators:modify_value("CopDamage:DisableEnemyOutlines", false) then
		self._unit:base():converted_enemy_effect(true)
	end
end)

Hooks:PostHook(CopDamage, "_apply_damage_to_health", "res_apply_damage_to_health", function(self, damage)

	if self._health > self._HEALTH_INIT then
		self._unit:base():enable_lpf_buff(true)
	else
		self._unit:base():disable_lpf_buff()
	end
end)

function CopDamage:is_head(body)
	local head = self._head_body_name and body and (body:name() == self._ids_head_body_name or head_hitboxes[body:name():key()])

	return head
end

function CopDamage:decay_buffs(t)
	local decay_delay_t = tweak_data.medic.overheal_decay_delay_t or 5
	
	if self._last_overheal_t + decay_delay_t < t then
		-- It's been enough time to start decaying overheal if we have any.
		local decay_t = tweak_data.medic.overheal_decay_t or 1
		if not self._decay_start_t then
			self._decay_start_t = self._last_overheal_t + decay_delay_t
		end

		if self._health > self._HEALTH_INIT and self._decay_start_t + decay_t < t then
			-- Since this only gets run when CopMovement runs _upd_actions, there can be a situation where
			-- we're lagging behind several decay_t amount of seconds.
			-- So, we'll "catch up" to where our overheal decay should be in that case.
			-- ...There's probably a smarter way of doing this.
			local times_happened = math.floor((t - self._decay_start_t)/decay_t)

			local self_tweak_data = tweak_data.character[self._unit:base()._tweak_table]
			local overheal_mult = self_tweak_data.overheal_mult or 1
			local overheal_full = self._HEALTH_INIT * overheal_mult - self._HEALTH_INIT -- Difference of max heal WITH overheal and just normal max health.
			local decay_percent_loss = tweak_data.medic.overheal_decay_percent or 0.1

			local final_damage = math.max(0,math.min(overheal_full * decay_percent_loss * times_happened, self._health - self._HEALTH_INIT))
			self:_apply_damage_to_health(final_damage)	

			self._decay_start_t = self._decay_start_t + times_happened * decay_t
		end
	end
end

function CopDamage:refresh_overheal_decay_timer(t)
	self._last_overheal_t = t
	self._decay_start_t = nil -- To enforce a recalculation in decay_buffs()
end

function CopDamage:_spawn_head_gadget(params)
	local unit_name = self._unit:name()
	local my_unit = self._unit

	if not self._head_gear or not params then
		return
	end

	if not params.position or not params.rotation then
		return
	end

	if self._head_gear_object then
		if self._nr_head_gear_objects then
			for i = 1, self._nr_head_gear_objects do
				local head_gear_obj_name = self._head_gear_object .. tostring(i)

				self._unit:get_object(Idstring(head_gear_obj_name)):set_visibility(false)
			end
		else
			self._unit:get_object(Idstring(self._head_gear_object)):set_visibility(false)
		end

		if self._head_gear_decal_mesh then
			local mesh_name_idstr = Idstring(self._head_gear_decal_mesh)

			self._unit:decal_surface(mesh_name_idstr):set_mesh_material(mesh_name_idstr, Idstring("flesh"))
		end
	end

	local unit = World:spawn_unit(Idstring(self._head_gear), params.position, params.rotation)

	if not params.skip_push then
		local true_dir = params.dir
		local spread = math.random(6, 9)
		mvector3.spread(true_dir, spread)
		local dir = math.UP + true_dir
		local body = unit:body(0)

		body:push_at(body:mass(), dir * math.lerp(450, 650, math.random()), unit:position() + Vector3(math.rand(1), math.rand(1), math.rand(1)))
	end
	
	local smashablefuckers = table_contains(enemies_visor, unit_name)
	local smashablefuckers_hsg = table_contains(enemies_plink, unit_name)
	
	local head_obj = ids_func("Head")
	local head_object_get = my_unit:get_object(head_obj)
	
	if not head_object_get then
		return
	end
	
	local world_g = World		
	local sound_ext = my_unit:sound()	
	  
	if smashablefuckers then
		world_g:effect_manager():spawn({
			effect = ids_func("effects/particles/bullet_hit/glass_breakable/bullet_hit_glass_breakable"),
			parent = head_object_get		
		})
		sound_ext:play("swat_heavy_visor_shatter", nil, nil)
		sound_ext:play("swat_heavy_visor_shatter", nil, nil)
	elseif smashablefuckers_hsg then
		world_g:effect_manager():spawn({
			effect = ids_func("effects/payday2/particles/impacts/metal_impact_pd2"),
			parent = head_object_get		
		})
		sound_ext:play("swatturret_weakspot_hit", nil, nil)
	end

	self._head_gear = false
end

--Enemy scaling health with number of players
function CopDamage:chk_has_player_health_scaling(char_tweak)
	local mul = char_tweak.player_health_scaling_mul

	if not mul then
		return
	end

	local session = managers.network:session()

	if not session then
		return
	end
	
	--Just so math looks way cleaner, player 1 will always count
	local nr_other_players = 1
	local local_peer_id = session:local_peer():id()

	for peer_id, peer in pairs(session:all_peers()) do
		if peer_id ~= local_peer_id then
			nr_other_players = nr_other_players + 1
		end
	end

	mul = 1 + (mul - 1) * nr_other_players
	self._HEALTH_INIT = self._HEALTH_INIT * mul
end

function CopDamage:damage_fire(attack_data)
	if self._dead or self._invulnerable then
		return
	end

	if self:chk_immune_to_attacker(attacker_unit) then
		return
	end
	
	local hit_body = attack_data and attack_data.col_ray and attack_data.col_ray.body

	if hit_body and impenetrable_armour[hit_body:name():key()] then -- nothing
		return
	end

	local attacker_unit = attack_data.attacker_unit
	local attacker_unit_base = attacker_unit and alive(attacker_unit) and attacker_unit:base()
	local attacker_unit_char_tweak = attacker_unit_base and attacker_unit_base.char_tweak and attacker_unit_base:char_tweak()
	local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)
	local cannot_be_ff = not is_civilian and self._char_tweak.immune_to_ff_fire
	local allow_ff = not cannot_be_ff and attacker_unit_char_tweak and attacker_unit_char_tweak.can_ff_fire
	local weap_unit = attack_data.weapon_unit
	
	if not allow_ff and self:is_friendly_fire(attacker_unit) then
		return "friendly_fire"
	end	
	
	if attacker_unit and alive(attacker_unit) then
		if attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			weap_unit = attack_data.attacker_unit
		end

		if not allow_ff and self:is_friendly_fire(attacker_unit) then
			return "friendly_fire"
		end
	end

	if not self._unit:movement():cloaked() and math_random() < (self._char_tweak.cloak_on_fire_damage_chance or 0.5) then
		self._unit:movement():set_cloaked(true, true)
	end

	local head = attack_data.variant ~= "stun" and self._head_body_name and attack_data.col_ray.body and attack_data.col_ray.body:name() == self._ids_head_body_name or attack_data.variant ~= "stun" and self._head_body_name and attack_data.col_ray.body and attack_data.col_ray.body:name() == self._ids_head_body_name and head_hitboxes[attack_data.col_ray.body:name():key()]

	if head and weap_unit and alive(weap_unit) and weap_unit:base() and not weap_unit:base().thrower_unit and attack_data.col_ray and attack_data.col_ray.ray and self._unit:base():has_tag("tank") then
		--mvector3.set(mvec_1, attack_data.col_ray.ray)
		--mrotation.z(self._unit:movement():m_head_rot(), mvec_2)

		--local not_from_the_front = mvector3.dot(mvec_1, mvec_2) >= 0
		mvector3.set(mvec_1, attack_data.col_ray.ray)
		mvector3.set_z(mvec_1, 0)
		mvector3.normalize(mvec_1)

		mrotation.y(self._unit:rotation(), mvec_2)
		mvector3.set_z(mvec_2, 0)
		mvector3.normalize(mvec_2)

		local not_from_the_front = mvector3.dot(mvec_1, mvec_2) + (mvec_1.x * mvec_2.y - mvec_1.y * mvec_2.x) * 0.35 >= 0.3

		if not_from_the_front then
			head = false
		end
	end

	local headshot_multiplier = 1
	local damage = attack_data.damage
	local distance = 1000
	local hit_pos = attack_data.col_ray.hit_position
	local is_player = attack_data.attacker_unit == managers.player:player_unit()
	local damage_clamp = self._char_tweak.DAMAGE_CLAMP_FIRE

	if allow_ff then
		damage = damage * 0.5
	end

	if is_player then
		if self._char_tweak.priority_shout then
			damage = damage * managers.player:upgrade_value("weapon", "special_damage_taken_multiplier", 1)
		end

		if head then
			headshot_multiplier = managers.player:upgrade_value("weapon", "passive_headshot_damage_multiplier", 1)
			managers.player:on_headshot_dealt(self._unit, attack_data)
		end
	end

	if head and not self._damage_reduction_multiplier then
		if self._char_tweak.headshot_dmg_mul then
			damage = damage * self._char_tweak.headshot_dmg_mul * headshot_multiplier
		else
			damage = self._health * 10
		end
	end

	--Allows seperate damage mults for fire pools and fire damage.
	if alive(weap_unit) then
		local weap_base = weap_unit:base()
		if weap_base.thrower_unit or weap_base.get_name_id and weap_base:get_name_id() == "environment_fire" then
			attack_data.is_fire_pool_damage = true
			if self._char_tweak.damage.fire_pool_damage_mul then
				damage = damage * self._char_tweak.damage.fire_pool_damage_mul
			end
		else
			if self._char_tweak.damage.fire_damage_mul then
				damage = damage * self._char_tweak.damage.fire_damage_mul
			end	
		end	

		local damage_type = (attack_data.variant == "fire_bullet" and weap_base and weap_base.get_damage_type and weap_base:get_damage_type()) or "normal"
		if hit_body and limbs[hit_body:name():key()] then
			if damage_type_mult[damage_type] then
				damage = damage * damage_type_mult[damage_type]
			end
			if is_pro and damage_type ~= "flamethrower" then
				damage = damage * 0.75
			end
		end
	end
		
	-- Separated the two damage boosts from marking.
	-- Could have just swapped their order, but honestly, there's no reason why one should depend on the other anyway.
	if self._marked_dmg_mul then
		damage = damage * self._marked_dmg_mul
	end

	if not attack_data.is_fire_dot_damage and self._marked_dmg_dist_mul and alive(attacker_unit) then
		local dst = mvector3.distance(attacker_unit:position(), self._unit:position())
		local spott_dst = tweak_data.upgrades.values.player.marked_inc_dmg_distance[self._marked_dmg_dist_mul]

		if spott_dst[1] < dst then
			damage = damage * spott_dst[2]
		end
	end

	damage = self:_apply_damage_reduction(damage)

	if damage_clamp then
		damage = math.min(damage, damage_clamp)
	end

	if is_player then
		if hit_pos then
			distance = mvector3.distance(hit_pos, attack_data.attacker_unit:position())
		end

		if weap_unit and alive(weap_unit) and attack_data.variant ~= "stun" then
			local weap_base = weap_unit:base()
			local is_grenade_or_ground_fire = nil

			if weap_base then
				if weap_base.thrower_unit or weap_base.get_name_id and weap_base:get_name_id() == "environment_fire" then
					is_grenade_or_ground_fire = true
				end
			end

			if is_grenade_or_ground_fire then
				if attack_data.is_fire_dot_damage and self._char_tweak.priority_shout then
					damage = damage * managers.player:upgrade_value("weapon", "special_damage_taken_multiplier", 1)
				end
			else
				local critical_hit, crit_damage = self:roll_critical_hit(attack_data, damage, damage_clamp)

				if critical_hit then
					damage = crit_damage
				end

				local damage_scale = nil
				if weap_base.near_falloff_distance and weap_base.far_falloff_distance then
					damage_scale = distance >= weap_base.far_falloff_distance + weap_base.near_falloff_distance and 0 or distance >= weap_base.near_falloff_distance and 0.5 or 1
				end		

				if not attack_data.is_fire_dot_damage and damage > 0 then
					if critical_hit then
						managers.hud:on_crit_confirmed(damage_scale)
					else
						managers.hud:on_hit_confirmed(damage_scale)
					end
				end
			end
		end
	end

	attack_data.raw_damage = damage

	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)

	if self._immortal then
		damage = math.min(damage, self._health - 1)
	end

	local result = nil

	if self._health <= damage then
		attack_data.damage = self._health

		if self:check_medic_heal() then
			result = {
				type = "healed",
				variant = attack_data.variant
			}
			self._player_damage_ratio = 0
		else
			if head then
				-- This feels... weird, but flames can technically headshot, I guess!
				managers.player:on_lethal_headshot_dealt(attack_data.attacker_unit, attack_data)
			end

			result = {
				type = "death",
				variant = attack_data.variant
			}

			if is_player and (attack_data.backstab or head) and not attack_data.is_fire_dot_damage then
				managers.player:add_backstab_dodge(attack_data.backstab, head)
			end

			local orig_variant = attack_data.variant
			self:die(attack_data)
			self:chk_killshot(attack_data.attacker_unit, orig_variant or "fire", head, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())
		end
	else
		attack_data.damage = damage

		local result_type = "dmg_rcv"

		if not attack_data.is_fire_dot_damage then
			result_type = self:get_damage_type(damage_percent, "fire")
		end

		result = {
			type = result_type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position

	if result.type == "death" then
		if attack_data.variant ~= "stun" then
			if table_contains(grenadier_smash, self._unit:name()) then
				self._unit:damage():run_sequence_simple("grenadier_glass_break")
			elseif self._head_body_name then
				local body = self._unit:body(self._head_body_name)


				if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
					self._unit:damage():run_sequence_simple("spawn_helmet")
				end

				self:_spawn_head_gadget({
					skip_push = true,
					position = body:position(),
					rotation = body:rotation()
				})
			end
		end

		if Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
			managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)
		end
		
		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			owner = attack_data.owner,
			weapon_unit = weap_unit,
			variant = attack_data.variant,
			is_molotov = attack_data.is_molotov
		}

		managers.statistics:killed_by_anyone(data)

		local weap_base = weap_unit and weap_unit:base()
		local close_range = weap_base and ((weap_base.is_category and weap_base:is_category("saw")) or (distance <= (weap_base.near_falloff_distance or 100)))
		if weap_base and not is_civilian and managers.player:has_category_upgrade("temporary", "overkill_damage_multiplier") and attacker_unit == managers.player:player_unit() and alive(attack_data.weapon_unit) and not weap_base.thrower_unit and (close_range or head) and weap_base.is_category and weap_base:is_category("shotgun", "saw") then
			managers.player:activate_temporary_upgrade("temporary", "overkill_damage_multiplier")
		end

		if attacker_unit == managers.player:player_unit() then
			if alive(attacker_unit) then
				self:_comment_death(attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if is_civilian then
				managers.money:civilian_killed()
			end

			self:_check_damage_achievements(attack_data, false)
		else
			if attacker_unit and alive(attacker_unit) and managers.groupai:state():is_unit_team_AI(attacker_unit) then
				self:_AI_comment_death(attacker_unit, self._unit)
			end
		end
		
		local weapon_unit = attack_data.weapon_unit
		local weapon_id = alive(weapon_unit) and weapon_unit:base().name_id

		if self._unit:base()._tweak_table == "summers" and weapon_id == "flamethrower_mk2" then
			managers.challenges_res:set_flag("summers_test")
		end
	end

	local weapon_unit = weap_unit
	local weap_base = nil
	
	if alive(weapon_unit) and weapon_unit.base then
		weap_base = weapon_unit:base() 
		if weap_base and weap_base.add_damage_result then
			weapon_unit:base():add_damage_result(self._unit, result.type == "death", damage_percent)
		end
	end

	if not attack_data.is_fire_dot_damage and attack_data.fire_dot_data and result.type ~= "death" then --DoT never triggers an animation so it shouldn't constantly micro-stun enemies that are vulnerable to fire
		local fire_dot_data = attack_data.fire_dot_data
		local flammable, start_dot_dance_antimation = nil

		if self._char_tweak.flammable == nil then
			flammable = true
		else
			flammable = self._char_tweak.flammable
		end

		if flammable then
			local fire_dot_max_distance = weap_base and weap_base.far_falloff_distance and weap_base.far_falloff_distance + weap_base.near_falloff_distance or 3000
			local fire_dot_panic_max_distance = weap_base and weap_base.near_falloff_distance or 500

			if distance < fire_dot_max_distance then
				local start_dot_damage_roll = math.random(1, 100)
				local fire_dot_trigger_chance = tonumber(fire_dot_data.dot_trigger_chance) or 30

				--Dragon's breath trigger chance scales with range.
				if weap_base and weap_base.far_falloff_distance then
					fire_dot_trigger_chance = (1 - math.min(1, math.max(0, distance - weap_base.near_falloff_distance) / weap_base.far_falloff_distance)) * fire_dot_trigger_chance
				end

				if start_dot_damage_roll <= fire_dot_trigger_chance then
					local dot_damage = fire_dot_data.dot_damage or 25
					local t = TimerManager:game():time()

					managers.fire:add_doted_enemy(self._unit, t, weap_unit, fire_dot_data.dot_length, dot_damage, attacker_unit, attack_data.is_molotov)

					local use_animation_on_fire_damage = nil

					if self._char_tweak.use_animation_on_fire_damage == nil then
						use_animation_on_fire_damage = true
					else
						use_animation_on_fire_damage = self._char_tweak.use_animation_on_fire_damage
					end
					
					if not (attack_data.is_fire_pool_damage or attack_data.is_molotov) and distance > fire_dot_panic_max_distance then
						use_animation_on_fire_damage = nil
					end

					if use_animation_on_fire_damage then
						if self.get_last_time_unit_got_fire_damage then
							local last_time_received = self:get_last_time_unit_got_fire_damage()

							if last_time_received == nil or t - last_time_received > 2 then
								start_dot_dance_antimation = true
							end
						else
							start_dot_dance_antimation = true
						end
					end
				end
			end

			fire_dot_data.start_dot_dance_antimation = start_dot_dance_antimation
			attack_data.fire_dot_data = fire_dot_data
		end

		if not start_dot_dance_antimation then --prevent fire_hurt from micro-stunning enemies when the dance animation isn't proced
			result.type = "dmg_rcv"
			attack_data.result.type = "dmg_rcv"
		else
			result.type = "fire_hurt"
			attack_data.result.type = "fire_hurt"
		end
	end

	local attacker = attack_data.attacker_unit

	if not attacker or not alive(attacker) or attacker:id() == -1 then
		attacker = self._unit
	end

	self:_send_fire_attack_result(attack_data, attacker, damage_percent, attack_data.is_fire_dot_damage, attack_data.col_ray.ray, attack_data.result.type == "healed")
	self:_on_damage_received(attack_data)

	if not attack_data.is_fire_dot_damage and not is_civilian and attacker_unit and alive(attacker_unit) then
		managers.player:send_message(Message.OnEnemyShot, nil, self._unit, attack_data)
	end

	return result
end

function CopDamage:sync_damage_fire(attacker_unit, damage_percent, death, direction, i_result, is_molotov)
	if self._dead then
		return
	end

	local variant = "fire"
	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	local attack_data = {
		variant = variant,
		attacker_unit = attacker_unit,
		weapon_unit = attacker_unit and attacker_unit:inventory() and attacker_unit:inventory():equipped_unit()
	}
	local result = nil

	if death then
		result = {
			type = "death",
			variant = variant
		}

		self:die(attack_data)
		self:chk_killshot(attacker_unit, (attack_data.variant == "fire_bullet" and "fire_bullet") or "fire", false, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())

		local data = {
			variant = "fire",
			head_shot = false,
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			weapon_unit = attack_data.weapon_unit,
			is_molotov = is_molotov
		}

		managers.statistics:killed_by_anyone(data)
	else
		local result_type = table.get_key(self._result_type_to_idx.fire, i_result) or "dmg_rcv"
		result = {
			type = result_type,
			variant = variant
		}

		if result_type ~= "healed" then
			self:_apply_damage_to_health(damage)
		else
			self:do_medic_heal()
		end
	end

	attack_data.result = result
	attack_data.damage = damage
	attack_data.is_synced = true
	local attack_dir = nil

	if direction then
		attack_dir = direction
	elseif attacker_unit then
		attack_dir = self._unit:position() - attacker_unit:position()

		mvector3.normalize(attack_dir)
	else
		attack_dir = self._unit:rotation():y()
	end

	attack_data.attack_dir = attack_dir

	if death and self._head_body_name then
		local body = self._unit:body(self._head_body_name)

		self:_spawn_head_gadget({
			skip_push = true,
			position = body:position(),
			rotation = body:rotation(),
			dir = Vector3()
		})
	end

	if result.type == "death" then
		local data = {
			variant = "fire",
			head_shot = false,
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			weapon_unit = attacker_unit and attacker_unit:inventory() and attacker_unit:inventory():equipped_unit()
		}
		local attacker_unit = attack_data.attacker_unit

		if attacker_unit and attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			data.weapon_unit = attack_data.attacker_unit
		end
		
		if table_contains(grenadier_smash, self._unit:name()) then
			self._unit:damage():run_sequence_simple("grenadier_glass_break")
		elseif self._head_body_name then
			local body = self._unit:body(self._head_body_name)

			if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
				self._unit:damage():run_sequence_simple("spawn_helmet")
			end

			self:_spawn_head_gadget({
				skip_push = true,
				position = body:position(),
				rotation = body:rotation()
			})
		end

		if Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
			managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)
		end		

		if attacker_unit == managers.player:player_unit() then
			if alive(attacker_unit) then
				self:_comment_death(attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if CopDamage.is_civilian(self._unit:base()._tweak_table) then
				managers.money:civilian_killed()
			end
		end
	end

	local weapon_unit = attack_data.weapon_unit

	if alive(weapon_unit) and weapon_unit:base() and weapon_unit:base().add_damage_result then
		weapon_unit:base():add_damage_result(self._unit, result.type == "death", damage_percent)
	end

	attack_data.pos = self._unit:position()

	mvector3.set_z(attack_data.pos, attack_data.pos.z + math.random() * 180)
	self:_send_sync_fire_attack_result(attack_data)
	self:_on_damage_received(attack_data)
end

function CopDamage:damage_bullet(attack_data)
	if self._dead or self._invulnerable then
		return
	end

	if self:is_friendly_fire(attack_data.attacker_unit) then
		return "friendly_fire"
	end
	
	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end

	if self._char_tweak.bullet_damage_only_from_front then
		mvector3.set(mvec_1, attack_data.col_ray.ray)
		mvector3.set_z(mvec_1, 0)
		mrotation.y(self._unit:rotation(), mvec_2)
		mvector3.set_z(mvec_2, 0)

		local not_from_the_front = mvector3.dot(mvec_1, mvec_2) > 0.3

		if not_from_the_front then
			return
		end
	end	

	if alive(attack_data.attacker_unit) and attack_data.attacker_unit:in_slot(16) then
		local has_surrendered = self._unit:brain().surrendered and self._unit:brain():surrendered() or self._unit:anim_data().surrender or self._unit:anim_data().hands_back or self._unit:anim_data().hands_tied

		if has_surrendered then
			return
		end
	end

	local weap_base = attack_data.weapon_unit:base()
	if self._char_tweak.damage.bullet_dodge_chance then
		local dodge_chance = self._char_tweak.damage.bullet_dodge_chance
		if weap_base.thrower_unit or weap_base.is_category and weap_base:is_category("saw") then
			dodge_chance = 0
		end

		if dodge_chance > 0 then
			local roll = math.rand(1, 100)

			if roll <= dodge_chance then
				self._unit:sound():play("bullet_whizby_medium", nil, nil)

				return
			end
		end
	end

	local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)
	local damage = attack_data.damage
	
	local ignore = self._char_tweak.no_dozer_armor_resistance
	
	local hit_body = attack_data and attack_data.col_ray and attack_data.col_ray.body
	
	if hit_body and impenetrable_armour[hit_body:name():key()] then -- nothing
		return
	end

	if armour[hit_body:name():key()] and not ignore then -- dozer armour negates damage
		local pierce_armor = nil
		
		--Just as a fallback, ugly as sin but whatever
		if attack_data.attacker_unit:base() and --[[not attack_data.attacker_unit:base().sentry_gun and]] not weap_base.thrower_unit then
			local weapon_ap = attack_data.weapon_unit:base().armor_piercing_chance and attack_data.weapon_unit:base():armor_piercing_chance()
			if weapon_ap and weapon_ap > 0 then
				pierce_armor = true
				damage = damage * weapon_ap or 1
			end
		end		

		if attack_data.armor_piercing or weap_base.thrower_unit then
			pierce_armor = true
		end

		if pierce_armor then
			World:effect_manager():spawn({
				effect = Idstring("effects/payday2/particles/impacts/blood/blood_impact_a"),
				position = attack_data.col_ray.position,
				normal = attack_data.col_ray.ray
			})
		else
			if attack_data.attacker_unit == managers.player:player_unit() and hit_body:extension() and hit_body:extension().damage then
				managers.hud:on_hit_confirmed() -- no damage to the unit, but it did damage the body
			end

			World:effect_manager():spawn({
				effect = Idstring("effects/payday2/particles/impacts/steel_no_decal_impact_pd2"),
				position = attack_data.col_ray.position,
				normal = attack_data.col_ray.ray
			})			
			--new sound below
			self._unit:sound():play("knuckles_hit_gen", nil, nil)
			self._unit:sound():play("knife_equip", nil, nil)
		
			return
		end
	end
	
	if not self._unit:movement():cloaked() and math_random() < (self._char_tweak.cloak_on_bullet_damage_chance or 0.5) then
		self._unit:movement():set_cloaked(true, true)
	end

	local result = nil
	local body_index = self._unit:get_body_index(attack_data.col_ray.body:name())
	local head = self._head_body_name and not self._unit:in_slot(16) and not self._char_tweak.ignore_headshot and attack_data.col_ray.body and attack_data.col_ray.body:name() == self._ids_head_body_name or head_hitboxes[hit_body:name():key()]

	if head and not weap_base.thrower_unit and self._unit:base():has_tag("tank") then
		--mvector3.set(mvec_1, attack_data.col_ray.ray)
		--mrotation.z(self._unit:movement():m_head_rot(), mvec_2)

		--local not_from_the_front = mvector3.dot(mvec_1, mvec_2) >= 0
		mvector3.set(mvec_1, attack_data.col_ray.ray)
		mvector3.set_z(mvec_1, 0)
		mvector3.normalize(mvec_1)

		mrotation.y(self._unit:rotation(), mvec_2)
		mvector3.set_z(mvec_2, 0)
		mvector3.normalize(mvec_2)

		local not_from_the_front = mvector3.dot(mvec_1, mvec_2) + (mvec_1.x * mvec_2.y - mvec_1.y * mvec_2.x) * 0.35 >= 0.3

		if not_from_the_front then
			head = false
		end
	end

	attack_data.headshot = head

	local headshot_by_player = false
	local headshot_multiplier = 1
	local distance = attack_data.col_ray and attack_data.col_ray.distance or mvector3.distance(attack_data.origin, self._unit:position()) or 0

	if self._char_tweak.damage.bullet_damage_mul then
		damage = damage * self._char_tweak.damage.bullet_damage_mul
	end	
	
	local damage_type = "normal"
	local ineffective_damage = false
	local effective_damage = false
	local is_player = attack_data.attacker_unit == managers.player:player_unit() and true
	local damage_clamp = self._char_tweak.DAMAGE_CLAMP_BULLET
	
	if is_player then
		if  self._char_tweak.priority_shout then
			damage = damage * managers.player:upgrade_value("weapon", "special_damage_taken_multiplier", 1)
			
			if attack_data.weapon_unit:base().weapon_tweak_data then
				damage = damage * (attack_data.weapon_unit:base():weapon_tweak_data().special_damage_multiplier or 1)
			end			
		end
	
		if head then
			managers.player:on_headshot_dealt(self._unit, attack_data)
			headshot_by_player = true
			headshot_multiplier = managers.player:upgrade_value("weapon", "passive_headshot_damage_multiplier", 1)
		end
	end

	if not weap_base.thrower_unit then
		--Sentries should do machine gun damage
		if attack_data.attacker_unit:base() and attack_data.attacker_unit:base().sentry_gun then
			damage_type = "machine_gun"
		else 
			damage_type = attack_data.weapon_unit:base():get_damage_type() 
		end
			
		--Damage multipliers for specific damage types come into play *after* the base damage type multiplier above
		if self._char_tweak.damage_resistance and damage_type then
			damage = damage * (self._char_tweak.damage_resistance[damage_type] or 1)
			
			--Let the player know to try something different
			if self._char_tweak.damage_resistance[damage_type] and self._char_tweak.damage_resistance[damage_type] < 1 then
				ineffective_damage = true
			elseif self._char_tweak.damage_resistance[damage_type] and self._char_tweak.damage_resistance[damage_type] > 1 then
				effective_damage = true
			end		
		end		
	end	

	if limbs[hit_body:name():key()] then
		if damage_type_mult[damage_type] then
			damage = damage * damage_type_mult[damage_type]
		end
		if is_pro then
			damage = damage * 0.75
		end
	end

	if not self._damage_reduction_multiplier and head then
		local is_captain = (self._unit:base():has_tag("captain") or self._unit:base():has_tag("boss"))
		local weapon_hs_mult = (is_captain and 1) or attack_data.weapon_unit:base()._hs_mult or 1
		local weapon_ene_hs_mult = attack_data.weapon_unit:base()._ene_hs_mult or 1
		if self._char_tweak.headshot_dmg_mul then
			damage = math.max( damage, damage * ((((self._char_tweak.headshot_dmg_mul - 1) * weapon_ene_hs_mult) + 1) * headshot_multiplier) * weapon_hs_mult)
		else
			damage = self._health * 10
		end
	end

	-- Separated the two damage boosts from marking.
	-- Could have just swapped their order, but honestly, there's no reason why one should depend on the other anyway.
	if self._marked_dmg_mul then
		damage = damage * self._marked_dmg_mul
	end

	if self._marked_dmg_dist_mul then
		local spott_dst = tweak_data.upgrades.values.player.marked_inc_dmg_distance[self._marked_dmg_dist_mul]

		if spott_dst[1] < distance then
			damage = damage * spott_dst[2]
		end
	end

	if not head and attack_data.attacker_unit == managers.player:player_unit() and not self._char_tweak.must_headshot and not self._char_tweak.priority_shout and self._char_tweak.headshot_dmg_mul then
		if (weap_base.fire_mode and weap_base:fire_mode() == "auto") and weap_base.is_category and (weap_base:is_category("smg", "lmg", "minigun") and managers.player:has_category_upgrade("weapon", "automatic_head_shot_add") or managers.player:has_category_upgrade("player", "universal_body_expertise")) then
			attack_data.add_head_shot_mul = managers.player:upgrade_value("weapon", "automatic_head_shot_add", nil)
		end

		if attack_data.add_head_shot_mul then
			local tweak_headshot_mul = math.max(0, self._char_tweak.headshot_dmg_mul - 1)
			local mul = tweak_headshot_mul * attack_data.add_head_shot_mul + 1
			damage = damage * mul
		end
	end

	damage = self:_apply_damage_reduction(damage)

	--Saw+Throwables ignore clamps
	if damage_clamp then
		if weap_base.thrower_unit or weap_base.is_category and weap_base:is_category("saw") then
			damage_clamp = nil
		else
			damage = math.min(damage, damage_clamp)
			--Cease
			ineffective_damage = true			
		end
	end	

	--Crits need to be the last calcuation to alter damage else Pocohud's crit damage pop-ups print wrong
	if is_player then
		attack_data.backstab = self:check_backstab(attack_data)

		if attack_data.backstab == true and weap_base._autograph_multiplier then
			damage = damage * weap_base._autograph_multiplier
		end

		local damage_scale = nil

		if weap_base.near_falloff_distance and weap_base.far_falloff_distance then
			damage_scale = distance >= weap_base.far_falloff_distance + weap_base.near_falloff_distance and 0 or distance >= weap_base.near_falloff_distance and 0.5 or 1
		end		
		
		local critical_hit, crit_damage = self:roll_critical_hit(attack_data, damage, damage_clamp)

		if critical_hit then
			damage = crit_damage
			attack_data.critical_hit = true

			if damage > 0 then
				managers.hud:on_crit_confirmed(damage_scale)
			end
		elseif ineffective_damage then
			if damage > 0 then
				managers.hud:on_ineffective_hit_confirmed(damage_scale)
			end		
		elseif effective_damage then
			if damage > 0 then
				managers.hud:on_effective_hit_confirmed(damage_scale)
			end				
		else
			if damage > 0 then
				managers.hud:on_hit_confirmed(damage_scale)
			end
		end

	end

	attack_data.raw_damage = damage

	if attack_data.weapon_unit and weap_base.is_category and weap_base:is_category("saw") then
		managers.groupai:state():_voice_saw() --THAT MADMAN HAS A FUCKIN' SAW
	end

	if attack_data.attacker_unit:base().sentry_gun and not self:is_friendly_fire(attack_data.attacker_unit) then
		managers.groupai:state():_voice_sentry() --FUCKING SCI-FI ROBOT GUNS
	end
	
	local summers_dr = managers.groupai:state():_get_summers_dr()
	if self._unit:base()._tweak_table == "summers" then
		damage = damage * summers_dr
	end

	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)

	if self._immortal then
		damage = math.min(damage, self._health - 1)
	end

	if self._health <= damage then
		attack_data.damage = self._health
		
		if self:check_medic_heal() then
			result = {
				type = "healed",
				variant = attack_data.variant
			}
			self._player_damage_ratio = 0
		else
			if head then
				managers.player:on_lethal_headshot_dealt(attack_data.attacker_unit, attack_data)
				
				if table_contains(grenadier_smash, self._unit:name()) then
					self._unit:damage():run_sequence_simple("grenadier_glass_break")
				else

					if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
						self._unit:damage():run_sequence_simple("spawn_helmet")
					end
				
					self:_spawn_head_gadget({
						position = attack_data.col_ray.body:position(),
						rotation = attack_data.col_ray.body:rotation(),
						dir = attack_data.col_ray.ray
					})
				end
			
				local my_unit = self._unit	
				local sound_ext = my_unit:sound()	
				sound_ext:play("expl_gen_head", nil, nil)	

				local head_obj = ids_func("Head")
				local head_object_get = my_unit:get_object(head_obj)

				local is_spring = my_unit:base()._tweak_table == "spring"
				local accelerated_training_program = self._char_tweak.yellow_blood

				if head_object_get and not is_spring then
					local world_g = World
					local head_pop = damage_type and damage_type == "sniper" or damage_type == "anti_materiel" or damage_type == "heavy_pistol" or damage_type == "handcannon" 
					if accelerated_training_program then
						world_g:effect_manager():spawn({
							effect = ids_func("effects/payday2/particles/impacts/blood/yellow/explosions/yellow_mist"), --need yellow brains
							parent = head_object_get		
						})
						if head_pop then
							world_g:effect_manager():spawn({
								effect = ids_func("effects/payday2/particles/impacts/blood/yellow/explosions/yellow_mist"),
								parent = head_object_get		
							})
							world_g:effect_manager():spawn({
								effect = ids_func("effects/payday2/particles/impacts/blood/yellow/explosions/yellow_mist"),
								parent = head_object_get		
							})
						end

					else
						world_g:effect_manager():spawn({
							effect = ids_func("effects/payday2/particles/impacts/blood/brain_splat"),
							parent = head_object_get		
						})
						if head_pop then
							world_g:effect_manager():spawn({
								effect = ids_func("effects/payday2/particles/explosions/red_mist"),
								parent = head_object_get		
							})
							world_g:effect_manager():spawn({
								effect = ids_func("effects/payday2/particles/explosions/red_mist"),
								parent = head_object_get		
							})
						end
					end
				end
			elseif Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
				managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)			
			end


			result = {
				type = "death",
				variant = attack_data.variant
			}
			
			if is_player and (attack_data.backstab or head) then
				managers.player:add_backstab_dodge(attack_data.backstab, head)
			end
			
			self:die(attack_data)
			self:chk_killshot(attack_data.attacker_unit, "bullet", headshot_by_player, attack_data.weapon_unit:base():get_name_id())
		end
	else
		attack_data.damage = damage

		local result_type = nil

		if not self._char_tweak.immune_to_knock_down then
			if attack_data.knock_down then
				result_type = "knock_down"
			elseif attack_data.stagger and not self._has_been_staggered then
				result_type = "stagger"
				self._has_been_staggered = true
			end
		end

		if not result_type then
			result_type = self:get_damage_type(damage_percent, "bullet")
		end

		result = {
			type = result_type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position

	if result.type == "death" then
		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			head_shot = head,
			weapon_unit = attack_data.weapon_unit,
			variant = attack_data.variant
		}		

		managers.statistics:killed_by_anyone(data)

		if attack_data.attacker_unit == managers.player:player_unit() then
			local special_comment = self:_check_special_death_conditions(attack_data.variant, attack_data.col_ray.body, attack_data.attacker_unit, attack_data.weapon_unit)

			self:_comment_death(attack_data.attacker_unit, self._unit, special_comment)
			self:_show_death_hint(self._unit:base()._tweak_table)

			local attacker_state = managers.player:current_state()
			data.attacker_state = attacker_state

			managers.statistics:killed(data)
			self:_check_damage_achievements(attack_data, head)


			local close_range = weap_base and ((weap_base.is_category and weap_base:is_category("saw")) or (distance <= (weap_base.near_falloff_distance or 100)))
			if not is_civilian and managers.player:has_category_upgrade("temporary", "overkill_damage_multiplier") and not weap_base.thrower_unit and (close_range or head) and weap_base:is_category("shotgun", "saw") then
				managers.player:activate_temporary_upgrade("temporary", "overkill_damage_multiplier")
			end

			if is_civilian then
				managers.money:civilian_killed()
			end
			
			local weapon_unit = attack_data.weapon_unit
			local weapon_id = alive(weapon_unit) and weapon_unit:base().name_id

			if self._unit:base()._tweak_table == "spring" and (weapon_id == "m134" or weapon_id == "shuno") then
				managers.challenges_res:set_flag("spring_test")
			end
		elseif attack_data.attacker_unit:base().sentry_gun then
			if Network:is_server() then
				local server_info = weap_base:server_information()

				if server_info and server_info.owner_peer_id ~= managers.network:session():local_peer():id() then
					local owner_peer = managers.network:session():peer(server_info.owner_peer_id)

					if owner_peer then
						owner_peer:send_queued_sync("sync_player_kill_statistic", data.name, data.head_shot and true or false, data.weapon_unit, data.variant, data.stats_name)
					end
				else
					data.attacker_state = managers.player:current_state()

					managers.statistics:killed(data)
				end
			end

			local sentry_attack_data = deep_clone(attack_data)
			sentry_attack_data.attacker_unit = attack_data.attacker_unit:base():get_owner()

			if sentry_attack_data.attacker_unit == managers.player:player_unit() then
				self:_check_damage_achievements(sentry_attack_data, head)
			else
				self._unit:network():send("sync_damage_achievements", sentry_attack_data.weapon_unit, sentry_attack_data.attacker_unit, sentry_attack_data.damage, sentry_attack_data.col_ray and sentry_attack_data.col_ray.distance, head)
			end
		else
			if managers.groupai:state():is_unit_team_AI(attack_data.attacker_unit) then
				local special_comment = self:_check_special_death_conditions(attack_data.variant, attack_data.col_ray.body, attack_data.attacker_unit, attack_data.weapon_unit)

				self:_AI_comment_death(attack_data.attacker_unit, self._unit, special_comment)
			end
		end
	end

	local hit_offset_height = math.clamp(attack_data.col_ray.position.z - self._unit:position().z, 0, 300)
	local attacker = attack_data.attacker_unit

	if not attacker or not alive(attacker) or attacker:id() == -1 then
		attacker = self._unit
	end

	if weap_base.add_damage_result then
		weap_base:add_damage_result(self._unit, result.type == "death", attacker, damage_percent) --add bow and arrow base checks
	end

	local i_result = nil

	if result.type == "healed" then
		i_result = 1
	else
		i_result = 0
	end

	self:_send_bullet_attack_result(attack_data, attacker, damage_percent, body_index, hit_offset_height, i_result)
	self:_on_damage_received(attack_data)

	if not is_civilian then
		managers.player:send_message(Message.OnEnemyShot, nil, self._unit, attack_data)
	end

	result.attack_data = attack_data

	return result
end

function CopDamage:sync_damage_bullet(attacker_unit, damage_percent, i_body, hit_offset_height, variant, death)
	if self._dead then
		return
	end

	local body = self._unit:body(i_body)
	local head = self._head_body_name and body and body:name() == self._ids_head_body_name
	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	local attack_data = {}
	local hit_pos = mvector3.copy(self._unit:movement():m_pos())

	mvector3.set_z(hit_pos, hit_pos.z + hit_offset_height)

	attack_data.pos = hit_pos
	attack_data.attacker_unit = attacker_unit
	attack_data.variant = "bullet"
	attack_data.headshot = head
	attack_data.weapon_unit = attacker_unit and attacker_unit:inventory() and attacker_unit:inventory():equipped_unit()
	local attack_dir, distance = nil

	if attacker_unit then
		attack_dir = hit_pos - attacker_unit:movement():m_head_pos()
		distance = mvector3.normalize(attack_dir)
	else
		attack_dir = self._unit:rotation():y()
	end

	attack_data.attack_dir = attack_dir
	local shotgun_push, result = nil

	if death then
		if head then
			if table_contains(grenadier_smash, self._unit:name()) then
				self._unit:damage():run_sequence_simple("grenadier_glass_break")
			else

				if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
					self._unit:damage():run_sequence_simple("spawn_helmet")
				end
			
				self:_spawn_head_gadget({
					position = body:position(),
					rotation = body:rotation(),
					dir = attack_dir
				})
			end
			
			local my_unit = self._unit	
			local sound_ext = my_unit:sound()	
			sound_ext:play("expl_gen_head", nil, nil)	

			local head_obj = ids_func("Head")
			local head_object_get = my_unit:get_object(head_obj)

			local is_spring = my_unit:base()._tweak_table == "spring"
			local accelerated_training_program = self._char_tweak.yellow_blood

			local damage_type = (alive(attack_data.weapon_unit) and attack_data.weapon_unit.base and attack_data.weapon_unit:base():get_damage_type()) or "normal"
			if head_object_get and not is_spring then
				local world_g = World
				local head_pop = damage_type and damage_type == "sniper" or damage_type == "anti_materiel" or damage_type == "heavy_pistol" or damage_type == "handcannon" 
				if accelerated_training_program then
					world_g:effect_manager():spawn({
						effect = ids_func("effects/payday2/particles/impacts/blood/yellow/explosions/yellow_mist"), --need yellow brains
						parent = head_object_get		
					})
					if head_pop then
						world_g:effect_manager():spawn({
							effect = ids_func("effects/payday2/particles/impacts/blood/yellow/explosions/yellow_mist"),
							parent = head_object_get		
						})
						world_g:effect_manager():spawn({
							effect = ids_func("effects/payday2/particles/impacts/blood/yellow/explosions/yellow_mist"),
							parent = head_object_get		
						})
					end

				else
					world_g:effect_manager():spawn({
						effect = ids_func("effects/payday2/particles/impacts/blood/brain_splat"),
						parent = head_object_get		
					})
					if head_pop then
						world_g:effect_manager():spawn({
							effect = ids_func("effects/payday2/particles/explosions/red_mist"),
							parent = head_object_get		
						})
						world_g:effect_manager():spawn({
							effect = ids_func("effects/payday2/particles/explosions/red_mist"),
							parent = head_object_get		
						})
					end
				end
			end
		elseif Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
			managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)		
		end

		result = {
			variant = "bullet",
			type = "death"
		}

		self:die(attack_data)
		self:chk_killshot(attacker_unit, "bullet", head, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())

		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			head_shot = head,
			weapon_unit = attack_data.weapon_unit,
			variant = attack_data.variant
		}

		if data.weapon_unit then
			self:_check_special_death_conditions("bullet", body, attacker_unit, data.weapon_unit)
			managers.statistics:killed_by_anyone(data)

			if managers.enemy:is_corpse_disposal_enabled() and data.weapon_unit:base()._do_shotgun_push and distance then
				shotgun_push = distance <= managers.game_play_central:get_shotgun_push_range(attacker_unit)
			end
		end
	else
		local result_type = variant == 1 and "knock_down" or variant == 2 and "stagger" or self:get_damage_type(damage_percent, "bullet")

		if variant == 3 then
			result_type = "healed"
		end

		result = {
			variant = "bullet",
			type = result_type
		}

		if result_type ~= "healed" then
			self:_apply_damage_to_health(damage)
		else
			self:do_medic_heal()
		end
	end

	attack_data.variant = "bullet"
	attack_data.attacker_unit = attacker_unit
	attack_data.result = result
	attack_data.damage = damage
	attack_data.is_synced = true

	if not self._no_blood then
		managers.game_play_central:sync_play_impact_flesh(hit_pos, attack_dir)
	end

	self:_send_sync_bullet_attack_result(attack_data, hit_offset_height)
	self:_on_damage_received(attack_data)

	if shotgun_push then
		--managers.game_play_central:_do_shotgun_push(self._unit, hit_pos, attack_dir, distance)
	end
end

function CopDamage:damage_melee(attack_data)
	if self._dead or self._invulnerable then
		return
	end
	
	if self:is_friendly_fire(attack_data.attacker_unit) and not attack_data.attacker_unit == self._unit then
		return "friendly_fire"
	end
	
	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end	

	if alive(attack_data.attacker_unit) and attack_data.attacker_unit:in_slot(16) then
		local has_surrendered = self._unit:brain().surrendered and self._unit:brain():surrendered() or self._unit:anim_data().surrender or self._unit:anim_data().hands_back or self._unit:anim_data().hands_tied

		if has_surrendered then
			return
		end
	end

	local result = nil
	local is_civlian = CopDamage.is_civilian(self._unit:base()._tweak_table)
	local is_gangster = CopDamage.is_gangster(self._unit:base()._tweak_table)
	local is_cop = not is_civlian and not is_gangster
	local hit_body = attack_data and attack_data.col_ray and attack_data.col_ray.body
	local head = hit_body and self._head_body_name and not self._unit:in_slot(16) and not self._char_tweak.ignore_headshot and (hit_body:name() == self._ids_head_body_name or head_hitboxes[hit_body:name():key()])
	local headshot_multiplier = attack_data.headshot_multiplier or 1
	local damage = attack_data.damage
	local damage_effect = attack_data.damage_effect or attack_data.damage
	local is_player = attack_data.attacker_unit == managers.player:player_unit() and true
	local damage_clamp = self._char_tweak.DAMAGE_CLAMP_MELEE
	
	if hit_body and impenetrable_armour[hit_body:name():key()] then
		--return
	end

	if is_player then
		if self._char_tweak.priority_shout then
			damage = damage * managers.player:upgrade_value("weapon", "special_damage_taken_multiplier", 1)
		end

		if head then
			headshot_multiplier = headshot_multiplier * managers.player:upgrade_value("weapon", "passive_headshot_damage_multiplier", 1)
			managers.player:on_headshot_dealt(self._unit, attack_data)
		end

		attack_data.backstab = self:check_backstab(attack_data)

		if attack_data.backstab and attack_data.backstab_multiplier then
			damage = damage * attack_data.backstab_multiplier
			damage_effect = damage_effect * attack_data.backstab_multiplier
		end
	end

	if self._char_tweak.damage.melee_damage_mul then
		damage = damage * self._char_tweak.damage.melee_damage_mul
	end		

	if self._marked_dmg_mul then
		damage = damage * self._marked_dmg_mul
		damage_effect = damage_effect * self._marked_dmg_mul
	end

	if head and not self._damage_reduction_multiplier then
		if self._char_tweak.headshot_dmg_mul then
			--Use math.max to cover edge cases (mostly Capt. Summers) where cleaver type weapons would deal *less* damage on a headshot than a bodyshot.
			headshot_multiplier = math.max(self._char_tweak.headshot_dmg_mul * headshot_multiplier, 1)
			damage = damage * headshot_multiplier
			damage_effect = damage_effect * headshot_multiplier
		else
			damage = self._health * 10
			damage_effect = self._health * 10
		end
	end

	local melee_tweak_data = tweak_data.blackmarket.melee_weapons[attack_data.name_id]
	local ineffective_damage = false
	local effective_damage = false
	local damage_type = melee_tweak_data and melee_tweak_data.stats.weapon_type or "blunt"
	
	--Damage multipliers for specific damage types come into play *after* the base damage type multiplier above
	if self._char_tweak.damage_resistance and damage_type then
		damage = damage * (self._char_tweak.damage_resistance[damage_type] or 1)
		
		--Let the player know to try something different
		if self._char_tweak.damage_resistance[damage_type] and self._char_tweak.damage_resistance[damage_type] < 1 then
			ineffective_damage = true
		elseif self._char_tweak.damage_resistance[damage_type] and self._char_tweak.damage_resistance[damage_type] > 1 then
			effective_damage = true
		end		
	end		

	damage = self:_apply_damage_reduction(damage)
	damage_effect = self:_apply_damage_reduction(damage_effect)

	if damage_clamp then
		damage = math.min(damage, damage_clamp)
		damage_effect = math.min(damage_effect, damage_clamp)
	end
	
	if is_player then
		local critical_hit, crit_damage = self:roll_critical_hit(attack_data, damage, damage_clamp)
		
		if critical_hit then
			damage = crit_damage

			local critical_hits = self._char_tweak.critical_hits or {}
			local critical_damage_mul = critical_hits.damage_mul or self._char_tweak.headshot_dmg_mul

			if critical_damage_mul then
				damage_effect = damage_effect * critical_damage_mul				
			else
				damage_effect = self._health * 10
			end

			attack_data.critical_hit = true

			if damage > 0 then
				managers.hud:on_crit_confirmed()
			end
		elseif ineffective_damage then
			if damage > 0 then
				managers.hud:on_ineffective_hit_confirmed(damage_scale)
			end		
		elseif effective_damage then
			if damage > 0 then
				managers.hud:on_effective_hit_confirmed(damage_scale)
			end					
		else
			if damage > 0 then
				managers.hud:on_hit_confirmed()
			end
		end

		if tweak_data.achievement.cavity.melee_type == attack_data.name_id and not is_civilian then
			managers.achievment:award(tweak_data.achievement.cavity.award)
		end
	end

	local summers_dr = managers.groupai:state():_get_summers_dr()
	if self._unit:base()._tweak_table == "summers" then
		damage = damage * summers_dr
	end

	attack_data.raw_damage = damage

	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	damage_effect = math.clamp(damage_effect, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	local damage_effect_percent = math.ceil(damage_effect / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)
	damage_effect, damage_effect_percent = self:_apply_min_health_limit(damage_effect, damage_effect_percent)

	if self._immortal then
		damage = math.min(damage, self._health - 1)
		damage_effect = math.min(damage_effect, self._health - 1)
	end

	if self._health <= damage then
		if self:check_medic_heal() then
			result = {
				type = "healed",
				variant = "melee"
			}
		else
			damage_effect_percent = 1
			attack_data.damage = self._health
			attack_data.damage_effect = self._health

			if head then
				managers.player:on_lethal_headshot_dealt(attack_data.attacker_unit, attack_data)

				if table_contains(grenadier_smash, self._unit:name()) then
					self._unit:damage():run_sequence_simple("grenadier_glass_break")
				else

					if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
						self._unit:damage():run_sequence_simple("spawn_helmet")
					end
				
					self:_spawn_head_gadget({
						position = attack_data.col_ray.body:position(),
						rotation = attack_data.col_ray.body:rotation(),
						dir = attack_data.col_ray.ray
					})
				end
			end

			result = {
				type = "death",
				variant = attack_data.variant,
				head_shot = head
			}

			if is_player and (attack_data.backstab or head) then
				managers.player:add_backstab_dodge(attack_data.backstab, head)
			end

			self:die(attack_data)
			self:chk_killshot(attack_data.attacker_unit, "melee", false, attack_data.name_id)
		end
	else
		attack_data.damage = damage
		attack_data.damage_effect = damage_effect
		damage_effect = math.clamp(damage_effect, self._HEALTH_INIT_PRECENT, self._HEALTH_INIT)
		damage_effect_percent = math.ceil(damage_effect / self._HEALTH_INIT_PRECENT)
		damage_effect_percent = math.clamp(damage_effect_percent, 1, self._HEALTH_GRANULARITY)
		local result_type = attack_data.shield_knock and self._char_tweak.damage.shield_knocked and "shield_knock" or attack_data.variant == "counter_tased" and "counter_tased" or attack_data.variant == "taser_tased" and self._char_tweak.can_be_tased ~= false and "taser_tased" or attack_data.variant == "counter_spooc" and "expl_hurt" or self:get_damage_type(damage_effect_percent, "melee") or "fire_hurt"

		if attack_data.variant == "taser_tased" and self._char_tweak.autumn_tase then		
			if self._unit:movement():cloaked() and math_random() < (self._char_tweak.uncloak_on_tase_damage_chance or 0.5) then
				self._unit:movement():set_cloaked(false, true)
				
				result_type = "hurt"
			else
				result_type = "light_hurt"
			end												
		end

		result = {
			type = result_type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position

	local dismember_victim = false
	local snatch_pager, from_behind = nil

	if result.type == "death" then
		if self:_dismember_condition(attack_data) then
			self:_dismember_body_part(attack_data)

			dismember_victim = true
		end

		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			head_shot = head,
			weapon_unit = attack_data.weapon_unit,
			name_id = attack_data.name_id,
			variant = attack_data.variant
		}

		managers.statistics:killed_by_anyone(data)

		if attack_data.attacker_unit == managers.player:player_unit() then
			local special_comment = self:_check_special_death_conditions("melee", attack_data.col_ray.body, attack_data.attacker_unit, attack_data.name_id)

			self:_comment_death(attack_data.attacker_unit, self._unit, special_comment)
			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if not is_civlian and managers.groupai:state():whisper_mode() and managers.blackmarket:equipped_mask().mask_id == tweak_data.achievement.cant_hear_you_scream.mask then
				managers.achievment:award_progress(tweak_data.achievement.cant_hear_you_scream.stat)
			end

			mvector3.set(mvec_1, self._unit:position())
			mvector3.subtract(mvec_1, attack_data.attacker_unit:position())
			mvector3.normalize(mvec_1)
			mvector3.set(mvec_2, self._unit:rotation():y())

			local from_behind = mvector3.dot(mvec_1, mvec_2) >= 0

			if is_cop and Global.game_settings.level_id == "nightclub" and attack_data.name_id and attack_data.name_id == "fists" then
				managers.achievment:award_progress(tweak_data.achievement.final_rule.stat)
			end

			if self._unit:base()._tweak_table == "autumn" and attack_data.name_id and attack_data.name_id == "fists" then
				managers.challenges_res:set_flag("melee_test")
			end
			
			if self._unit:base()._tweak_table == "phalanx_vip" and attack_data.name_id and (attack_data.name_id == "wing" or attack_data.name_id == "switchblade") then
				managers.challenges_res:set_flag("winters_test")
			end

			if is_civilian then
				managers.money:civilian_killed()
			else
				local job = Global.level_data and Global.level_data.level_id

				if job == "short1_stage1" or job == "short1_stage2" then
					--Just in case, cause otherwise it apparently screws everything up
					snatch_pager = false
				else
					if managers.player:upgrade_value("player", "melee_kill_snatch_pager_chance", 0) > math.rand(1) then
						if self._unit:movement():cool() then
							snatch_pager = true
							self._unit:unit_data().has_alarm_pager = false
						else
							local not_cool_t = self._unit:movement().not_cool_t and self._unit:movement():not_cool_t()
							local t = TimerManager:game():time()

							if not not_cool_t or t - not_cool_t < 0.75 then
								snatch_pager = true
								self._unit:unit_data().has_alarm_pager = false
							end
						end
					end
				end
			end


		elseif managers.groupai:state():is_unit_team_AI(attack_data.attacker_unit) then
			local special_comment = self:_check_special_death_conditions("melee", attack_data.col_ray.body, attack_data.attacker_unit, attack_data.name_id)

			self:_AI_comment_death(attack_data.attacker_unit, self._unit, special_comment)
		end
	end

	if is_player then
		self:_check_melee_achievements(attack_data)
	end

	local hit_offset_height = math.clamp(attack_data.col_ray.position.z - self._unit:movement():m_pos().z, 0, 300)
	local variant = nil

	if result.type == "shield_knock" then
		variant = 1
	elseif result.type == "counter_tased" then
		variant = 2
	elseif result.type == "expl_hurt" then
		variant = 4
	elseif snatch_pager then
		variant = 3
	elseif result.type == "taser_tased" then
		variant = 5
	elseif dismember_victim then
		variant = 6
	elseif result.type == "healed" then
		variant = 7
	else
		variant = 0
	end
	
	if attack_data.charge_lerp_value then
		result.charge_lerp_value = attack_data.charge_lerp_value
	end

	local body_index = self._unit:get_body_index(attack_data.col_ray.body:name())

	self:_send_melee_attack_result(attack_data, damage_percent, damage_effect_percent, hit_offset_height, variant, body_index)
	self:_on_damage_received(attack_data)

	return result
end

function CopDamage:sync_damage_melee(attacker_unit, damage_percent, damage_effect_percent, i_body, hit_offset_height, variant, death)
	local attack_data = {
		variant = "melee",
		attacker_unit = attacker_unit
	}
	local body = self._unit:body(i_body)
	local head = self._head_body_name and not self._unit:in_slot(16) and not self._char_tweak.ignore_headshot and body and body:name() == self._ids_head_body_name
	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	local damage_effect = damage_effect_percent * self._HEALTH_INIT_PRECENT
	local result = nil

	local attack_dir = nil

	if attacker_unit then --attack_dir needs to be defined before "if death"
		attack_dir = self._unit:position() - attacker_unit:position()

		mvector3.normalize(attack_dir)
	else
		attack_dir = -self._unit:rotation():y()
	end
	attack_data.attack_dir = attack_dir

	if death then
		--[[
		if self:_sync_dismember(attacker_unit) and variant == 6 then
			attack_data.body_name = body:name()

			self:_dismember_body_part(attack_data)
		end
		]]

		if head then
			if table_contains(grenadier_smash, self._unit:name()) then
				self._unit:damage():run_sequence_simple("grenadier_glass_break")
			else


				if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
					self._unit:damage():run_sequence_simple("spawn_helmet")
				end
			
				self:_spawn_head_gadget({
					position = body:position(),
					rotation = body:rotation(),
					dir = attack_dir
				})
			end
		end

		result = {
			variant = "melee",
			type = "death"
		}

		self:die(attack_data)
		self:chk_killshot(attacker_unit, "melee", false, nil)

		local data = {
			variant = "melee",
			head_shot = false,
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name
		}

		managers.statistics:killed_by_anyone(data)
	else
		local result_type = variant == 1 and "shield_knock" or variant == 2 and "counter_tased" or variant == 5 and "taser_tased" or variant == 4 and "expl_hurt" or self:get_damage_type(damage_effect_percent, "bullet") or "fire_hurt"

		if attack_data.variant == "taser_tased" and self._char_tweak.autumn_tase then		
			if self._unit:movement():cloaked() then				
				result_type = "hurt"
			else
				result_type = "light_hurt"
			end												
		end

		result = {
			variant = "melee",
			type = result_type
		}

		self:_apply_damage_to_health(damage)

		attack_data.variant = result_type
	end

	attack_data.result = result
	attack_data.damage = damage
	attack_data.damage_effect = self._health
	attack_data.is_synced = true
	attack_data.name_id = attacker_unit and attacker_unit:inventory() and attacker_unit:inventory():get_melee_weapon_id()

	if variant == 3 then
		self._unit:unit_data().has_alarm_pager = false
	end

	attack_data.pos = self._unit:position()

	mvector3.set_z(attack_data.pos, attack_data.pos.z + math.random() * 180)

	if not self._no_blood then
		managers.game_play_central:sync_play_impact_flesh(self._unit:movement():m_pos() + Vector3(0, 0, hit_offset_height), attack_dir)
	end

	self:_send_sync_melee_attack_result(attack_data, hit_offset_height)
	self:_on_damage_received(attack_data)
end

local old_death = CopDamage.die
function CopDamage:die(attack_data)
	local job = Global.level_data and Global.level_data.level_id
	--Increment skirmish kill counter.
	if managers.skirmish:is_skirmish() then
		managers.skirmish:do_kill()
	end
	
	local mutator_ammo_drop_chance = managers.mutators:modify_value("CopDamage:NoAmmoDropChance", 1)
	local mutator_ammo_drop_chance_bot_kill = 1 - mutator_ammo_drop_chance

	if not self._char_tweak.always_drop and self._pickup == "ammo" then
		local attacker_unit = attack_data.attacker_unit

		if attacker_unit and alive(attacker_unit) then
			if attacker_unit:in_slot(16) then
				local roll = math.random() + mutator_ammo_drop_chance_bot_kill
				local ammo_chance = 0.2 + self._player_damage_ratio --Enemy bot ammo drop chance increases based on the amount of damage dealy by a player.
				--80% of health damage leading to kill dealt by a player == 100% chance to drop ammo.
				--0% of health damage leading to kill dealt by a player == 20% chance to drop ammo.

				if roll >= ammo_chance then
					self:set_pickup()
				end
			end	
			if mutator_ammo_drop_chance ~= 1 then
				local no_ammo_roll = math.random()
				if no_ammo_roll >= mutator_ammo_drop_chance then
					self:set_pickup()
				end
			end	
		end	
	end

	old_death(self, attack_data)

	if self._unit:interaction().tweak_data == "hostage_convert" then
		self._unit:interaction():set_active(false, true, false)
	end

	if self._unit:interaction().tweak_data == "intimidated_guard_checkin" or self._unit:interaction().tweak_data == "intimidated_guard_checkin_pointless" then
		self._unit:interaction():set_active(false, true, false)
	end
	managers.enemy:unregister_intimidated_guard(self._unit:id())
	if Network:is_server() then
		LuaNetworking:SendToPeers("sync_intimidated_guard_data_delete", self._unit:id())
	end

	if self._char_tweak.ends_assault_on_death then
		if job == "crojob3" or job == "crojob3_night" then
			--No assault end, as they're not the assaulting force
		else
			managers.groupai:state():force_end_assault_phase()
		end
		managers.hud:set_buff_enabled("vip", false)
	end

	if self._unit:contour() then
		self._unit:contour():remove("medic_show", false)
	end
	
	if self._unit:base() then
		self._unit:base():disable_lpf_buff()
		self._unit:base():disable_asu_laser()
		self._unit:base():apply_infiltrator_nerf(false)
		self._unit:base():converted_enemy_effect(false)
	end

	if self._unit:base()._tweak_table == "spooc" then
		self._unit:damage():run_sequence_simple("kill_spook_lights")
	end
	
	if self._unit:base()._tweak_table == "phalanx_vip" or self._unit:base()._tweak_table == "phalanx_vip_break" then
		self._unit:damage():run_sequence_simple("kill_smoke_winters")
	end
	
	if self._unit:base()._tweak_table == "summers" or self._unit:base()._tweak_table == "headless_hatman"  then
		self._unit:damage():run_sequence_simple("kill_feet_fire_summers")
		self._unit:base():update_summers_dr_effect(true) -- Kill Summers DR effect
	end

	if self._char_tweak.failure_on_death then
		managers.groupai:state():set_point_of_no_return_timer(5, 0)
	end

	if self._char_tweak.do_autumn_blackout then
		managers.groupai:state():unregister_blackout_source(self._unit)
	end

	if self._char_tweak.die_sound_event_2 then
		self._unit:sound():play(self._char_tweak.die_sound_event_2, nil, true)
	end

	if self._unit:base()._tweak_table == "boom" then
		local boom_boom = false
		boom_boom = managers.modifiers:modify_value("CopDamage:CanBoomBoom", boom_boom)
		boom_boom = managers.mutators:modify_value("CopDamage:CanBoomBoom", boom_boom)
		if boom_boom then
			self:kamikaze_bag_explode()
		end
	end
	
	if self._char_tweak.reduce_summers_dr_on_death then
		managers.groupai:state():_reduce_summers_dr(0.15)
		self._unit:base():find_summers()
	end	
end

function CopDamage:stun_hit(attack_data)
	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end

	local hit_body = attack_data and attack_data.col_ray and attack_data.col_ray.body
	
	if hit_body and impenetrable_armour[hit_body:name():key()] then -- nothing
		return
	end
	
	if self:is_friendly_fire(attack_data.attacker_unit) then
		return "friendly_fire"
	end	

	if self._dead or self._invulnerable or self._unit:in_slot(16, 21, 22) then
		return
	else
		local anim_data = self._unit:anim_data()

		if anim_data and anim_data.act then
			return
		else
			if self._unit:brain().surrendered and self._unit:brain():surrendered() then
				return
			elseif anim_data then
				if anim_data.surrender or anim_data.hands_back or anim_data.hands_tied then
					return
				end
			end
		end
	end

	local attacker_unit = attack_data.attacker_unit

	if attacker_unit and attacker_unit:base() and attacker_unit:base().thrower_unit then
		attacker_unit = attacker_unit:base():thrower_unit()
	end

	local attacker = attack_data.attacker_unit

	if not attacker or not alive(attacker) or attacker:id() == -1 then
		attacker = self._unit
	end

	local result_type = "concussion"

	if self._char_tweak.tank_concussion or self._unit:base():has_tag("shield") then
		result_type = "expl_hurt"
	elseif attack_data.variant == "bullet" then
		result_type = "hurt"
	end

	local result = {
		type = result_type,
		variant = attack_data.variant
	}
	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position
	local damage_percent = 0
	local attacker = attack_data.attacker_unit

	self:_send_stun_attack_result(attacker, damage_percent, self:_get_attack_variant_index(attack_data.result.variant), attack_data.col_ray.ray)
	self:_on_damage_received(attack_data)
	self:_create_stun_exit_clbk()
end

function CopDamage:sync_damage_stun(attacker_unit, damage_percent, i_attack_variant, death, direction)
	if self._dead then
		return
	end

	local variant = CopDamage._ATTACK_VARIANTS[i_attack_variant]
	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	local attack_data = {
		variant = variant,
		attacker_unit = attacker_unit
	}
	local result = nil
	local result_type = "concussion"
	
	if self._char_tweak.tank_concussion or self._unit:base():has_tag("shield") then
		result_type = "expl_hurt"
	elseif attack_data.variant == "bullet" then
		result_type = "hurt"
	end
	
	result = {
		type = result_type,
		variant = variant
	}
	attack_data.result = result
	attack_data.damage = damage
	attack_data.is_synced = true
	local attack_dir = nil

	if direction then
		attack_dir = direction
	elseif attacker_unit then
		attack_dir = self._unit:position() - attacker_unit:position()

		mvector3.normalize(attack_dir)
	else
		attack_dir = self._unit:rotation():y()
	end

	attack_data.attack_dir = attack_dir

	if attack_data.attacker_unit and attack_data.attacker_unit == managers.player:player_unit() then
		managers.hud:on_hit_confirmed()
	end

	attack_data.pos = self._unit:position()

	mvector3.set_z(attack_data.pos, attack_data.pos.z + math.random() * 180)
	self:_on_damage_received(attack_data)
	self:_create_stun_exit_clbk()
end


function CopDamage:damage_explosion(attack_data)
	if self._dead or self._invulnerable then
		return
	end
	
	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end	

	local attacker_unit = attack_data.attacker_unit
	local attacker_unit_base = attacker_unit and alive(attacker_unit) and attacker_unit:base()
	local attacker_unit_char_tweak = attacker_unit_base and attacker_unit_base.char_tweak and attacker_unit_base:char_tweak()
	local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)
	local cannot_be_ff = not is_civilian and self._char_tweak.immune_to_ff_exp
	local allow_ff = not cannot_be_ff and attacker_unit_char_tweak and attacker_unit_char_tweak.can_ff_exp
	local weap_unit = attack_data.weapon_unit

	if not allow_ff and attack_data.weapon_unit and alive(attack_data.weapon_unit) then
		if attack_data.weapon_unit:base() and attack_data.weapon_unit:base()._variant == "explosion" and not attack_data.weapon_unit:base()._thrower_unit then
			-- no friendly fire >:(
			return
		end
	end

	if attacker_unit and alive(attacker_unit) then
		if attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			weap_unit = attack_data.attacker_unit
		end

		if not allow_ff and self:is_friendly_fire(attacker_unit) then
			return "friendly_fire"
		end
	end

	if not self._unit:movement():cloaked() and math_random() < (self._char_tweak.cloak_on_explosive_damage_chance or 0.5) then
		self._unit:movement():set_cloaked(true, true)
	end

	local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)
	local result = nil
	local damage = attack_data.damage

	if allow_ff then
		damage = damage * 0.5
	end
	
	local hit_body = attack_data and attack_data.col_ray and attack_data.col_ray.body
		
	if hit_body and impenetrable_armour[hit_body:name():key()] then -- nothing
		return
	end
		
	--Use a different damage resistance when being hit by a rocket	
	if alive(weap_unit) then
		local weap_base = weap_unit:base()
		if weap_base.thrower_unit or weap_base.get_name_id and weap_base:get_name_id() == "rocket_ray_frag" or weap_base:get_name_id() == "rocket_frag" then
			if self._char_tweak.damage.rocket_damage_mul then
				damage = damage * self._char_tweak.damage.rocket_damage_mul
			end	
		else
			if self._char_tweak.damage.explosion_damage_mul then
				damage = damage * self._char_tweak.damage.explosion_damage_mul
			end	
		end	
	end	

	-- Separated the two damage boosts from marking.
	-- Could have just swapped their order, but honestly, there's no reason why one should depend on the other anyway.
	if self._marked_dmg_mul then
		damage = damage * self._marked_dmg_mul
	end

	if self._marked_dmg_dist_mul and alive(attacker_unit) then
		local dst = mvector3.distance(attacker_unit:position(), self._unit:position())
		local spott_dst = tweak_data.upgrades.values.player.marked_inc_dmg_distance[self._marked_dmg_dist_mul]

		if spott_dst[1] < dst then
			damage = damage * spott_dst[2]
		end
	end

	damage = managers.modifiers:modify_value("CopDamage:DamageExplosion", damage, self._unit)
	damage = self:_apply_damage_reduction(damage)

	if attacker_unit == managers.player:player_unit() and damage > 0 and attack_data.variant ~= "stun" then
		managers.hud:on_hit_confirmed()
	end

	if self._char_tweak.DAMAGE_CLAMP_EXPLOSION then
		damage = math.min(damage, self._char_tweak.DAMAGE_CLAMP_EXPLOSION)
	end

	attack_data.raw_damage = damage

	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)

	if self._immortal then
		damage = math.min(damage, self._health - 1)
	end

	if self._health <= damage then
		attack_data.damage = self._health

		if self:check_medic_heal() then
			result = {
				type = "healed",
				variant = attack_data.variant
			}
			self._player_damage_ratio = 0
		else
			result = {
				type = "death",
				variant = attack_data.variant
			}

			self:die(attack_data)
		end
	else
		attack_data.damage = damage

		local result_type = (allow_ff and "dmg_rcv") or (attack_data.variant == "stun" and "hurt_sick") or self:get_damage_type(damage_percent, "explosion")

		if attack_data.variant == "stun" and self._char_tweak.autumn_tase then
			result_type = "light_hurt"
		
			if self._unit:movement():cloaked() and math_random() < (self._char_tweak.uncloak_on_tase_damage_chance or 0.5) then
				self._unit:movement():set_cloaked(false, true)
			end
			
		end		

		result = {
			type = result_type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position

	result.ignite_character = attack_data.ignite_character

	if result.type == "death" then
		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			owner = attack_data.owner,
			weapon_unit = weap_unit,
			variant = attack_data.variant
		}

		managers.statistics:killed_by_anyone(data)

		if attacker_unit and attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			data.weapon_unit = attack_data.attacker_unit
		end

		if attack_data.variant ~= "stun" then
			if table_contains(grenadier_smash, self._unit:name()) then
				self._unit:damage():run_sequence_simple("grenadier_glass_break")
			elseif self._head_body_name then
				local body = self._unit:body(self._head_body_name)


				if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
					self._unit:damage():run_sequence_simple("spawn_helmet")
				end

				self:_spawn_head_gadget({
					skip_push = true,
					position = body:position(),
					rotation = body:rotation()
				})
			end
		end

		if Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
			managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)
		end
		--[[
		if not is_civilian and managers.player:has_category_upgrade("temporary", "overkill_damage_multiplier") and attacker_unit == managers.player:player_unit() and attack_data.weapon_unit and attack_data.weapon_unit:base().weapon_tweak_data and not attack_data.weapon_unit:base().thrower_unit and attack_data.weapon_unit:base():is_category("shotgun", "saw") then
			managers.player:activate_temporary_upgrade("temporary", "overkill_damage_multiplier")
		end
		]]

		self:chk_killshot(attacker_unit, "explosion", false, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())

		if attacker_unit == managers.player:player_unit() then
			if alive(attacker_unit) then
				self:_comment_death(attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if is_civilian then
				managers.money:civilian_killed()
			end

			self:_check_damage_achievements(attack_data, false)
		else
			if attacker_unit and alive(attacker_unit) and managers.groupai:state():is_unit_team_AI(attacker_unit) then
				self:_AI_comment_death(attacker_unit, self._unit)
			end
		end
	end

	if alive(weap_unit) and weap_unit:base() and weap_unit:base().add_damage_result then
		weap_unit:base():add_damage_result(self._unit, result.type == "death", attacker_unit, damage_percent)
	end

	if attack_data.variant ~= "stun" and not self._no_blood and damage > 0 then
		managers.game_play_central:sync_play_impact_flesh(attack_data.pos, attack_data.col_ray.ray)
	end

	local attacker = attack_data.attacker_unit

	if not attacker or not alive(attacker) or attacker:id() == -1 then
		attacker = self._unit
	end

	local sync_attack_variant = attack_data.variant

	if result.type == "healed" then
		sync_attack_variant = "healed"
	end

	self:_send_explosion_attack_result(attack_data, attacker, damage_percent, self:_get_attack_variant_index(sync_attack_variant), attack_data.col_ray.ray)
	self:_on_damage_received(attack_data)

	if not is_civilian and attacker_unit and alive(attacker_unit) then
		managers.player:send_message(Message.OnEnemyShot, nil, self._unit, attack_data)
	end

	return result
end

function CopDamage:sync_damage_explosion(attacker_unit, damage_percent, i_attack_variant, death, direction, weapon_unit)
	if self._dead then
		return
	end

	local variant = CopDamage._ATTACK_VARIANTS[i_attack_variant]
	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	local attack_data = {
		variant = variant,
		attacker_unit = attacker_unit,
		weapon_unit = weapon_unit or attacker_unit and attacker_unit:inventory() and attacker_unit:inventory():equipped_unit()
	}
	local result = nil

	if death then
		result = {
			type = "death",
			variant = variant
		}
		
		if Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
			managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)
		end				

		self:die(attack_data)

		local data = {
			variant = "explosion",
			head_shot = false,
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			weapon_unit = attack_data.weapon_unit
		}

		managers.statistics:killed_by_anyone(data)
	else
		local result_type = variant == "stun" and "hurt_sick" or variant == "healed" and "healed" or self:get_damage_type(damage_percent, "explosion")

		if attack_data.variant == "stun" and self._char_tweak.autumn_tase then
			result_type = "light_hurt"			
		end		

		result = {
			type = result_type,
			variant = variant
		}

		if variant == "healed" then
			self:do_medic_heal()
		else
			self:_apply_damage_to_health(damage)
		end
	end

	attack_data.result = result
	attack_data.damage = damage
	attack_data.is_synced = true
	local attack_dir = nil

	if direction then
		attack_dir = direction
	elseif attacker_unit then
		attack_dir = self._unit:position() - attacker_unit:position()

		mvector3.normalize(attack_dir)
	else
		attack_dir = self._unit:rotation():y()
	end

	attack_data.attack_dir = attack_dir

	if death and self._head_body_name then
		local body = self._unit:body(self._head_body_name)
		
		if table_contains(grenadier_smash, self._unit:name()) then
			self._unit:damage():run_sequence_simple("grenadier_glass_break")	
		else

			if self._unit:damage() and self._unit:damage():has_sequence("spawn_helmet")  then
				self._unit:damage():run_sequence_simple("spawn_helmet")
			end
		
			self:_spawn_head_gadget({
				skip_push = true,
				position = body:position(),
				rotation = body:rotation(),
				dir = Vector3()
			})
		end
	end

	if attack_data.attacker_unit and attack_data.attacker_unit == managers.player:player_unit() then
		managers.hud:on_hit_confirmed()
		managers.statistics:shot_fired({
			hit = true,
			weapon_unit = attack_data.weapon_unit
		})
	end

	if result.type == "death" then
		local data = {
			variant = "explosion",
			head_shot = false,
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			weapon_unit = attack_data.weapon_unit
		}
		local attacker_unit = attack_data.attacker_unit

		if attacker_unit and attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			data.weapon_unit = attack_data.attacker_unit
		end

		self:chk_killshot(attacker_unit, "explosion", false, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())

		if attacker_unit == managers.player:player_unit() then
			if alive(attacker_unit) then
				self:_comment_death(attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if CopDamage.is_civilian(self._unit:base()._tweak_table) then
				managers.money:civilian_killed()
			end
		end
	end

	if alive(weapon_unit) and weapon_unit:base() and weapon_unit:base().add_damage_result then
		weapon_unit:base():add_damage_result(self._unit, result.type == "death", damage_percent)
	end

	if not self._no_blood then
		local hit_pos = mvector3.copy(self._unit:movement():m_pos())

		mvector3.set_z(hit_pos, hit_pos.z + 100)
		managers.game_play_central:sync_play_impact_flesh(hit_pos, attack_dir)
	end

	attack_data.pos = self._unit:position()

	mvector3.set_z(attack_data.pos, attack_data.pos.z + math.random() * 180)
	self:_send_sync_explosion_attack_result(attack_data)
	self:_on_damage_received(attack_data)
end

function CopDamage:damage_simple(attack_data)
	if self._dead or self._invulnerable then
		return
	end
	
	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end	

	if self._unit:in_slot(16, 21, 22) then
		return
	end

	local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)
	local result = nil
	local damage = attack_data.damage

	damage = self:_apply_damage_reduction(damage)

	if self._char_tweak.DAMAGE_CLAMP_SHOCK then
		damage = math.min(damage, self._char_tweak.DAMAGE_CLAMP_SHOCK)
	elseif self._char_tweak.DAMAGE_CLAMP_BULLET then
		damage = math.min(damage, self._char_tweak.DAMAGE_CLAMP_BULLET)
	end

	attack_data.raw_damage = damage

	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)

	if self._immortal then
		damage = math.min(damage, self._health - 1)
	end

	if self._health <= damage then
		attack_data.damage = self._health

		if self:check_medic_heal() then
			result = {
				type = "healed",
				variant = attack_data.variant
			}
			self._player_damage_ratio = 0
		else
			result = {
				type = "death",
				variant = attack_data.variant
			}

			self:die(attack_data)
		end
	else
		attack_data.damage = damage

		local result_type = nil

		if not self._char_tweak.immune_to_knock_down then
			local weapon_base = attack_data.attacker_unit and attack_data.attacker_unit:inventory() and attack_data.attacker_unit:inventory():equipped_unit() and attack_data.attacker_unit:inventory():equipped_unit():base()

			if weapon_base then
				local knock_down = weapon_base._knock_down and weapon_base._knock_down > 0 and math.random() < weapon_base._knock_down

				if knock_down then
					result_type = "knock_down"
				else
					local stagger = weapon_base._stagger and not self._has_been_staggered

					if stagger then
						result_type = "stagger"
						self._has_been_staggered = true
					end
				end
			end
		end

		if not result_type then
			result_type = self:get_damage_type(damage_percent)
		end

		result = {
			type = result_type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	attack_data.result = result

	local attacker_unit = attack_data.attacker_unit

	if result.type == "death" then
		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			owner = attack_data.owner,
			weapon_unit = attack_data.weapon_unit,
			variant = attack_data.variant
		}

		managers.statistics:killed_by_anyone(data)

		if attacker_unit and attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			data.weapon_unit = attack_data.attacker_unit
		end

		--[[
		if not is_civilian and managers.player:has_category_upgrade("temporary", "overkill_damage_multiplier") and attacker_unit == managers.player:player_unit() and attack_data.weapon_unit and attack_data.weapon_unit:base().weapon_tweak_data and not attack_data.weapon_unit:base().thrower_unit and attack_data.weapon_unit:base():is_category("shotgun", "saw") then
			managers.player:activate_temporary_upgrade("temporary", "overkill_damage_multiplier")
		end
		]]

		self:chk_killshot(attacker_unit, "shock", false, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())

		if attacker_unit == managers.player:player_unit() then
			if alive(attacker_unit) then
				self:_comment_death(attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if is_civilian then
				managers.money:civilian_killed()
			end

			self:_check_damage_achievements(attack_data, false)
		else
			if attacker_unit and alive(attacker_unit) and managers.groupai:state():is_unit_team_AI(attacker_unit) then
				self:_AI_comment_death(attacker_unit, self._unit)
			end
		end
	end

	local attacker = attack_data.attacker_unit

	if not attacker or not alive(attacker) or attacker:id() == -1 then
		attacker = self._unit
	end

	if not self._no_blood and damage > 0 then
		managers.game_play_central:sync_play_impact_flesh(attack_data.pos, attack_data.attack_dir)
	end

	local i_result = nil

	if result.type == "healed" then
		i_result = 1
	else
		i_result = 0
	end

	self:_send_simple_attack_result(attacker, damage_percent, self:_get_attack_variant_index(attack_data.variant), i_result)
	self:_on_damage_received(attack_data)

	if not is_civilian and attacker_unit and alive(attacker_unit) then
		managers.player:send_message(Message.OnEnemyShot, nil, self._unit, attack_data)
	end

	return result
end

function CopDamage:sync_damage_simple(attacker_unit, damage_percent, i_attack_variant, i_result, death)
	if self._dead then
		return
	end

	local variant = CopDamage._ATTACK_VARIANTS[i_attack_variant]
	local attack_data = {
		variant = variant,
		attacker_unit = attacker_unit
	}

	local hit_pos = mvector3.copy(self._unit:position())
	mvector3.set_z(hit_pos, hit_pos.z + 100)

	local attack_dir, result = nil

	if attacker_unit then
		local from_pos = nil

		if attacker_unit:movement() then
			if attacker_unit:movement().m_detect_pos then
				from_pos = attacker_unit:movement():m_detect_pos()
			elseif attacker_unit:movement().m_head_pos then
				from_pos = attacker_unit:movement():m_head_pos()
			else
				from_pos = attacker_unit:position()
			end
		else
			from_pos = attacker_unit:position()
		end

		attack_dir = hit_pos - from_pos
		mvector3.normalize(attack_dir)
	else
		attack_dir = -self._unit:rotation():y()
	end

	attack_data.attack_dir = attack_dir
	hit_pos = hit_pos - attack_dir * 5
	attack_data.pos = hit_pos

	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	attack_data.damage = damage

	if death then
		attack_data.damage = self._health

		result = {
			type = "death",
			variant = variant
		}

		self:die(attack_data)
		self:chk_killshot(attacker_unit, variant, false, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())

		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			weapon_unit = attacker_unit and attacker_unit:inventory() and attacker_unit:inventory():equipped_unit(),
			variant = variant
		}

		local attacker = attacker_unit

		if attacker and attacker:base() and attacker:base().thrower_unit then
			data.weapon_unit = attacker_unit
		end

		if data.weapon_unit then
			managers.statistics:killed_by_anyone(data)
		end
	else
		local result_type = "dmg_rcv"

		if i_result == 1 then
			result_type = "healed"

			attack_data.damage = self._health
		else
			self:_apply_damage_to_health(damage)
		end

		result = {
			type = result_type,
			variant = variant
		}
	end

	attack_data.result = result
	attack_data.is_synced = true

	if not self._no_blood and damage > 0 then
		managers.game_play_central:sync_play_impact_flesh(hit_pos, attack_dir)
	end

	self:_on_damage_received(attack_data)
end

function CopDamage:damage_tase(attack_data)
	if self._dead or self._invulnerable then
		if self._invulnerable then
			print("INVULNERABLE!  Not tasing.")
		end

		return
	end

	if PlayerDamage.is_friendly_fire(self, attack_data.attacker_unit) then
		return "friendly_fire"
	end

	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end

	local result = nil
	local damage = attack_data.damage
	
	if self._char_tweak.damage.tase_damage_mul then
		damage = damage * self._char_tweak.damage.tase_damage_mul
	end	

	if attack_data.attacker_unit == managers.player:player_unit() then
		local critical_hit, crit_damage = self:roll_critical_hit(attack_data, damage)

		if critical_hit then
			damage = crit_damage
		end

		if attack_data.weapon_unit then
			if critical_hit then
				managers.hud:on_crit_confirmed()
			else
				managers.hud:on_hit_confirmed()
			end
		end
	end

	damage = self:_apply_damage_reduction(damage)
	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)	
	
	if self._unit:movement():cloaked() and math_random() < (self._char_tweak.uncloak_on_tase_damage_chance or 0.5) then
		self._unit:movement():set_cloaked(false, true)
	end	

	if self._health <= damage then
		attack_data.damage = self._health
		result = {
			variant = "bullet",
			type = "death"
		}

		self:die(attack_data)
		self:chk_killshot(attack_data.attacker_unit, "tase", false, attack_data.weapon_unit and attack_data.weapon_unit:base():get_name_id())
	else
		attack_data.damage = damage
		local type = (attack_data.forced or self._char_tweak.can_be_tased == nil or self._char_tweak.can_be_tased) and "taser_tased" or "none"
		
		if self._char_tweak.autumn_tase then
			type = "heavy_hurt"
		end
		
		result = {
			type = type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	if (result.type == "taser_tased" or result.type == "heavy_hurt") and (attack_data.forced or not self._unit:anim_data() or not self._unit:anim_data().act) then
		self.is_tased = true

		if self._tase_effect then
			World:effect_manager():fade_kill(self._tase_effect)
		end

		self._tase_effect = World:effect_manager():spawn(self._tase_effect_table)
	end

	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position
	local head = nil

	if result.type == "death" and self._head_body_name then
		head = attack_data.col_ray and attack_data.col_ray.body and self._head_body_key and attack_data.col_ray.body:key() == self._head_body_key
		local body = self._unit:body(self._head_body_name)
		local dir_vec = head and attack_data.col_ray.ray or body:rotation():y()

		self:_spawn_head_gadget({
			position = body:position(),
			rotation = body:rotation(),
			skip_push = not head,
			dir = dir_vec
		})
	end

	local attacker = attack_data.attacker_unit

	if not attacker or attacker:id() == -1 then
		attacker = self._unit
	end

	if result.type == "death" then
		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			owner = attack_data.owner,
			weapon_unit = attack_data.weapon_unit,
			variant = attack_data.variant,
			head_shot = head
		}

		managers.statistics:killed_by_anyone(data)

		local attacker_unit = attack_data.attacker_unit

		if attacker_unit and attacker_unit:base() and attacker_unit:base().thrower_unit then
			attacker_unit = attacker_unit:base():thrower_unit()
			data.weapon_unit = attack_data.attacker_unit
		end

		if attacker_unit == managers.player:player_unit() then
			if alive(attacker_unit) then
				self:_comment_death(attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			if CopDamage.is_civilian(self._unit:base()._tweak_table) then
				managers.money:civilian_killed()
			end

			self:_check_damage_achievements(attack_data, false)
		end
	end

	local weapon_unit = attack_data.weapon_unit

	if alive(weapon_unit) and weapon_unit:base() and weapon_unit:base().add_damage_result then
		weapon_unit:base():add_damage_result(self._unit, result.type == "death", damage_percent)
	end

	local variant = result.variant == "heavy" and 1 or 0

	self:_send_tase_attack_result(attack_data, damage_percent, variant)
	self:_on_damage_received(attack_data)

	return result
end

function CopDamage:sync_damage_tase(attacker_unit, damage_percent, variant, death)
	if self._dead then
		return
	end

	if variant == 1 then
		variant = "heavy"
	else
		variant = "light"
	end

	local damage = damage_percent * self._HEALTH_INIT_PRECENT
	local attack_data = {
		attacker_unit = attacker_unit,
		variant = variant
	}
	local result = nil

	if death then
		result = {
			variant = "bullet",
			type = "death"
		}

		self:die("bullet")
		self:chk_killshot(attacker_unit, "tase", false, attack_data.weapon_unit)

		local data = {
			head_shot = false,
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			variant = variant
		}

		managers.statistics:killed_by_anyone(data)
	else
		local type = (self._char_tweak.can_be_tased == nil or self._char_tweak.can_be_tased) and "taser_tased" or "none"

		if self._char_tweak.autumn_tase then
			type = "heavy_hurt"
		end
		
		result = {
			type = type,
			variant = variant
		}

		self:_apply_damage_to_health(damage)
	end

	if result.type == "taser_tased" then
		if self._tase_effect then
			World:effect_manager():fade_kill(self._tase_effect)
		end

		self._tase_effect = World:effect_manager():spawn(self._tase_effect_table)
	end

	attack_data.result = result
	attack_data.damage = damage
	attack_data.is_synced = true
	local attack_dir = nil

	if attacker_unit then
		attack_dir = self._unit:position() - attacker_unit:position()

		mvector3.normalize(attack_dir)
	else
		attack_dir = -self._unit:rotation():y()
	end

	attack_data.attack_dir = attack_dir

	if death and self._head_body_name then
		local body = self._unit:body(self._head_body_name)

		self:_spawn_head_gadget({
			position = body:position(),
			rotation = body:rotation(),
			dir = attack_dir
		})
	end

	attack_data.pos = self._unit:position()

	mvector3.set_z(attack_data.pos, attack_data.pos.z + math.random() * 180)
	self:_send_sync_tase_attack_result(attack_data)
	self:_on_damage_received(attack_data)
end

function CopDamage:damage_dot(attack_data)
	if self._dead or self._invulnerable then
		return
	end

	local hit_body = attack_data and attack_data.col_ray and attack_data.col_ray.body
	
	if hit_body and impenetrable_armour[hit_body:name():key()] then -- nothing
		return
	end
	
	if self:chk_immune_to_attacker(attack_data.attacker_unit) then
		return
	end	

	if attack_data.attacker_unit and alive(attack_data.attacker_unit) and self:is_friendly_fire(attack_data.attacker_unit) then
		return "friendly_fire"
	end

	local damage = attack_data.damage

	if self._char_tweak.damage.dot_damage_mul then
		damage = damage * self._char_tweak.damage.dot_damage_mul
	end

	if self._marked_dmg_mul then
		damage = damage * self._marked_dmg_mul
	end

	damage = self:_apply_damage_reduction(damage)

	if self._char_tweak.DAMAGE_CLAMP_DOT then
		damage = math.min(damage, self._char_tweak.DAMAGE_CLAMP_DOT)
	end

	attack_data.raw_damage = damage

	damage = math.clamp(damage, 0, self._HEALTH_INIT)
	local damage_percent = math.ceil(damage / self._HEALTH_INIT_PRECENT)
	damage = damage_percent * self._HEALTH_INIT_PRECENT
	damage, damage_percent = self:_apply_min_health_limit(damage, damage_percent)

	if self._immortal then
		damage = math.min(damage, self._health - 1)
	end

	if not attack_data.variant then
		attack_data.variant = "dot"
	end

	local result = nil

	if self._health <= damage then
		attack_data.damage = self._health

		if self:check_medic_heal() then
			result = {
				type = "healed",
				variant = attack_data.variant
			}
			self._player_damage_ratio = 0
		else
			result = {
				type = "death",
				variant = attack_data.variant
			}

			self:die(attack_data)
			self:chk_killshot(attack_data.attacker_unit, attack_data.variant, nil, attack_data.weapon_id)
		end
	else
		attack_data.damage = damage

		local result_type = attack_data.hurt_animation and self:get_damage_type(damage_percent, attack_data.variant) or "dmg_rcv"

		result = {
			type = result_type,
			variant = attack_data.variant
		}

		self:_apply_damage_to_health(damage)
	end

	attack_data.result = result
	attack_data.pos = attack_data.col_ray.position

	if result.type == "death" then
		local variant = attack_data.weapon_id and tweak_data.blackmarket and tweak_data.blackmarket.melee_weapons and tweak_data.blackmarket.melee_weapons[attack_data.weapon_id] and "melee" or attack_data.variant
		local data = {
			name = self._unit:base()._tweak_table,
			stats_name = self._unit:base()._stats_name,
			owner = attack_data.owner,
			weapon_unit = attack_data.weapon_unit,
			variant = variant,
			name_id = attack_data.weapon_id
		}

		managers.statistics:killed_by_anyone(data)

		if attack_data.attacker_unit == managers.player:player_unit() then
			if alive(attack_data.attacker_unit) then
				self:_comment_death(attack_data.attacker_unit, self._unit)
			end

			self:_show_death_hint(self._unit:base()._tweak_table)
			managers.statistics:killed(data)

			local is_civilian = CopDamage.is_civilian(self._unit:base()._tweak_table)

			if is_civilian then
				managers.money:civilian_killed()
			end

			--[[
			if not is_civilian and managers.player:has_category_upgrade("temporary", "overkill_damage_multiplier") and attack_data.weapon_unit and attack_data.weapon_unit:base().weapon_tweak_data and not attack_data.weapon_unit:base().thrower_unit and attack_data.weapon_unit:base():is_category("shotgun", "saw") then
				managers.player:activate_temporary_upgrade("temporary", "overkill_damage_multiplier")
			end
			--]]

			if attack_data and attack_data.weapon_id and not attack_data.weapon_unit then
				attack_data.name_id = attack_data.weapon_id

				self:_check_melee_achievements(attack_data)
			else
				self:_check_damage_achievements(attack_data, false)
			end
		end
	end

	if attack_data.hurt_animation and result.type ~= "poison_hurt" then
		attack_data.hurt_animation = false
	end

	local attacker = attack_data.attacker_unit

	if not attacker or not alive(attacker) or attacker:id() == -1 then
		attacker = self._unit
	end

	local sync_attack_variant = attack_data.variant

	if result.type == "healed" then
		if attack_data.variant == "poison" then
			sync_attack_variant = "poison_healed"
		else
			sync_attack_variant = "dot_healed"
		end
	end

	self:_send_dot_attack_result(attack_data, attacker, damage_percent, sync_attack_variant)
	self:_on_damage_received(attack_data)

	result.attack_data = attack_data
	result.damage_percent = damage_percent
	result.damage = damage
	
	return result
end

Hooks:PreHook(CopDamage, "_chk_unique_death_requirements", "resmod_spoof_fire_bullet", function(self, damage_info, died)
	if damage_info and damage_info.variant and damage_info.variant == "fire_bullet" then
		damage_info.variant = "fire" --changes the "fire_bullet" variant to "fire" so the damage check against the Yufu Wang doesn't fail
	end
end)

function CopDamage:_on_damage_received(damage_info)
	self:chk_health_sequences()
	self:_call_listeners(damage_info)
	CopDamage._notify_listeners("on_damage", damage_info)

	if damage_info.result.type == "death" then
		managers.enemy:on_enemy_died(self._unit, damage_info)
		self:chk_disable_aoe_damage()
	end

	local damage_info_orig_variant = damage_info.variant

	if not self._dead then
		self:_chk_unique_death_requirements(damage_info, false)
	end

	damage_info.variant = damage_info_orig_variant --revert the variant change done in the "_chk_unique_death_requirements" prehook

	local attacker_unit = damage_info and damage_info.attacker_unit

	if alive(attacker_unit) then
		local attacker_base = attacker_unit:base()

		if attacker_base then
			if attacker_unit:base().thrower_unit then
				attacker_unit = attacker_unit:base():thrower_unit()
				attacker_base = alive(attacker_unit) and attacker_unit:base()
			elseif attacker_unit:base().sentry_gun then
				attacker_unit = attacker_unit:base():get_owner()
				attacker_base = alive(attacker_unit) and attacker_unit:base()
			end
		end

		if attacker_base then
			if attacker_base.is_husk_player then
				self._player_damage_ratio = self._player_damage_ratio + ((damage_info.damage or 0) / self._HEALTH_INIT)
			elseif attacker_base.is_local_player then
				managers.player:on_damage_dealt(self._unit, damage_info)
				self._player_damage_ratio = self._player_damage_ratio + ((damage_info.damage or 0) / self._HEALTH_INIT)
			end
		end
	end

	--should prevent countering and shield knock from counting towards this
	if damage_info.variant == "melee" and type(damage_info.damage) == "number" and damage_info.damage > 0 then
		managers.statistics:register_melee_hit()
	end

	self:_update_debug_ws(damage_info) --debug watersports??????????

	if not self._dead and not self._unit:base():has_tag("special") and self._health > 0 then
		local t = TimerManager:game():time()
		if not self._next_allowed_hurt_t or self._next_allowed_hurt_t and self._next_allowed_hurt_t < t then
			if damage_info.damage and damage_info.damage > 0.01 and self._health > damage_info.damage then
				if not damage_info.result_type or damage_info.result_type ~= "healed" or damage_info.variant == "hurt_sick" and damage_info.result_type ~= "death" then
					if damage_info.is_fire_dot_damage or damage_info.variant == "fire" then
						if self._next_allowed_burnhurt_t and self._next_allowed_burnhurt_t < t or not self._next_allowed_burnhurt_t then
							self._unit:sound():say("burnhurt", nil, nil, nil, nil)
							self._next_allowed_burnhurt_t = t + 8
							self._next_allowed_hurt_t = t + math.random(1, 1.28)
						end
					else
						self._unit:sound():say("x01a_any_3p", nil, nil, nil, nil)
					end
				end
			end
		end
	end
	
	--[[if not self._dead and self._unit:base():has_tag("tank") and self._health > 0 then
		self._unit:sound():play("fist_hit_gen", nil, nil)
	else	
		self._unit:sound():play("fist_hit_body", nil, nil)
	end]]--
	
end

function CopDamage:damage_mission(attack_data)
	if self._dead then
		return
	elseif self._invulnerable or self._immortal then
		if not attack_data.forced then
			return
		end
	end

	if self.immortal and self.is_escort then
		if attack_data.backup_so then
			attack_data.backup_so:on_executed(self._unit)
		end

		return
	end

	if self._char_tweak.no_damage_mission then
		return
	end

	local result = nil
	local damage_percent = self._HEALTH_GRANULARITY
	attack_data.damage = self._health
	result = {
		type = "death",
		variant = attack_data.variant
	}

	self:die(attack_data)

	attack_data.result = result
	attack_data.attack_dir = -self._unit:rotation():y()
	attack_data.pos = self._unit:position()

	if attack_data.attacker_unit == managers.player:local_player() then
		if CopDamage.is_civilian(self._unit:base()._tweak_table) then
			managers.money:civilian_killed()
		elseif Network:is_server() and self._char_tweak.gas_on_death and not managers.groupai:state():whisper_mode() then
			managers.groupai:state():detonate_cs_grenade(self._unit:movement():m_pos() + math.UP * 10, mvector3.copy(self._unit:movement():m_head_pos()), 7.5)
		end
	end

	self:_send_explosion_attack_result(attack_data, self._unit, damage_percent, self:_get_attack_variant_index("explosion"), attack_data.col_ray and attack_data.col_ray.ray)
	self:_on_damage_received(attack_data)

	return result
end

function CopDamage:_apply_min_health_limit(damage, damage_percent)
	local lower_health_percentage_limit = self._unit:base():char_tweak().LOWER_HEALTH_PERCENTAGE_LIMIT

	if lower_health_percentage_limit then
		local real_damage_percent = damage_percent / self._HEALTH_GRANULARITY
		local new_health_ratio = self._health_ratio - real_damage_percent

		if lower_health_percentage_limit > new_health_ratio then
			real_damage_percent = self._health_ratio - lower_health_percentage_limit
			damage_percent = real_damage_percent * self._HEALTH_GRANULARITY
			damage = damage_percent * self._HEALTH_INIT_PRECENT
		end
	end

	return damage, damage_percent
end

function CopDamage:build_suppression(amount, panic_chance)
	if self._dead or self._invulnerable or self._unit:in_slot(16) or not self._char_tweak.suppression then
		return
	end

	local t = TimerManager:game():time()
	local sup_tweak = self._char_tweak.suppression

	if panic_chance then
		if panic_chance == -1 or panic_chance > 0 and sup_tweak.panic_chance_mul > 0 and math.random() < panic_chance * sup_tweak.panic_chance_mul then
			amount = "panic"
		end
	end

	local amount_val = nil

	if amount == "max" or amount == "panic" then
		local value = sup_tweak.brown_point or sup_tweak.react_point

		amount_val = value[2]
	elseif Network:is_server() and self._suppression_hardness_t and t < self._suppression_hardness_t then
		amount_val = amount * 0.5
	else
		amount_val = amount
	end

	if not Network:is_server() then
		local sync_amount = nil

		if amount == "panic" then
			sync_amount = 16
		elseif amount == "max" then
			sync_amount = 15
		else
			local sync_amount_ratio = nil

			if sup_tweak.brown_point then
				if sup_tweak.brown_point[2] <= 0 then
					sync_amount_ratio = 1
				else
					sync_amount_ratio = amount_val / sup_tweak.brown_point[2]
				end
			elseif sup_tweak.react_point[2] <= 0 then
				sync_amount_ratio = 1
			else
				sync_amount_ratio = amount_val / sup_tweak.react_point[2]
			end

			sync_amount = math.clamp(math.ceil(sync_amount_ratio * 15), 1, 15)
		end

		managers.network:session():send_to_host("suppression", self._unit, sync_amount)

		return
	end

	if self._suppression_data then
		self._suppression_data.value = math.min(self._suppression_data.brown_point or self._suppression_data.react_point, self._suppression_data.value + amount_val)
		self._suppression_data.last_build_t = t
		self._suppression_data.decay_t = t + self._suppression_data.duration

		managers.enemy:reschedule_delayed_clbk(self._suppression_data.decay_clbk_id, self._suppression_data.decay_t)
	else
		local duration = math.lerp(sup_tweak.duration[1], sup_tweak.duration[2], math.random())
		local decay_t = t + duration
		self._suppression_data = {
			value = amount_val,
			last_build_t = t,
			decay_t = decay_t,
			duration = duration,
			react_point = sup_tweak.react_point and math.lerp(sup_tweak.react_point[1], sup_tweak.react_point[2], math.random()),
			brown_point = sup_tweak.brown_point and math.lerp(sup_tweak.brown_point[1], sup_tweak.brown_point[2], math.random()),
			decay_clbk_id = "CopDamage_suppression" .. tostring(self._unit:key())
		}

		managers.enemy:add_delayed_clbk(self._suppression_data.decay_clbk_id, callback(self, self, "clbk_suppression_decay"), decay_t)
	end

	if not self._suppression_data.brown_zone and self._suppression_data.brown_point and self._suppression_data.brown_point <= self._suppression_data.value then
		self._suppression_data.brown_zone = true

		local state = amount == "panic" and "panic" or true

		self._unit:brain():on_suppressed(state)
	elseif amount == "panic" then
		self._unit:brain():on_suppressed("panic")
	end

	if not self._suppression_data.react_zone and self._suppression_data.react_point and self._suppression_data.react_point <= self._suppression_data.value then
		self._suppression_data.react_zone = true

		local state = amount == "panic" and "panic" or true

		self._unit:movement():on_suppressed(state)
	elseif amount == "panic" then
		self._unit:movement():on_suppressed("panic")
	end
end

function CopDamage:_comment_death(attacker, killed_unit, special_comment)
	local victim_base = killed_unit:base()

	if special_comment then
		PlayerStandard.say_line(attacker:sound(), special_comment)
	elseif victim_base:has_tag("tank") then
		PlayerStandard.say_line(attacker:sound(), "g30x_any")
	elseif victim_base:has_tag("spooc") then
		PlayerStandard.say_line(attacker:sound(), "g33x_any")
	elseif victim_base:has_tag("taser") then
		PlayerStandard.say_line(attacker:sound(), "g32x_any")
	elseif victim_base:has_tag("shield") then
		PlayerStandard.say_line(attacker:sound(), "g31x_any")
	elseif victim_base:has_tag("sniper") then
		PlayerStandard.say_line(attacker:sound(), "g35x_any")
	elseif victim_base:has_tag("medic") or victim_base:has_tag("lpf") then
		PlayerStandard.say_line(attacker:sound(), "g36x_any")
	elseif victim_base:has_tag("custom") then
		local delay = TimerManager:game():time() + 1
		managers.enemy:add_delayed_clbk(clbk_id, callback(self, self, "_comment_custom_death", attacker), delay)
	end
end

function CopDamage:_comment_custom_death(attacker)
	if alive(attacker) then
		PlayerStandard.say_line(attacker:sound(), "g92")
	end
end

function CopDamage:_AI_comment_death(unit, killed_unit, special_comment)
	local victim_base = killed_unit:base()

	if special_comment then
		unit:sound():say(special_comment, true)
	elseif victim_base:has_tag("tank") then
		unit:sound():say("g30x_any", true)
	elseif victim_base:has_tag("spooc") then
		unit:sound():say("g33x_any", true)
	elseif victim_base:has_tag("taser") then
		unit:sound():say("g32x_any", true)
	elseif victim_base:has_tag("shield") then
		unit:sound():say("g31x_any", true)
	elseif victim_base:has_tag("sniper") then
		unit:sound():say("g35x_any", true)
	elseif victim_base:has_tag("medic") or victim_base:has_tag("lpf") then
		unit:sound():say("g36x_any", true)
	elseif victim_base:has_tag("custom") then
		local delay = TimerManager:game():time() + 1
		managers.enemy:add_delayed_clbk(clbk_id, callback(self, self, "_comment_ai_custom_death", unit), delay)		
	end
end

function CopDamage:_comment_ai_custom_death(unit)
	if alive(unit) then
		unit:sound():say("g92", true)
	end
end

function CopDamage:_on_death(variant)
	--Remove Ex-Pres
	managers.player:chk_wild_kill_counter(self._unit, variant)

	if self._char_tweak and self._char_tweak.do_autumn_blackout then --clear all equipment and re-enable them when autumn dies
		managers.enemy:end_autumn_blackout()
	end

	if self._unit:unit_data().is_convert and SC._converts then
		for i, unit in pairs(SC._converts) do
			if unit == self._unit then
				table.remove(SC._converts, i)
			end
		end
	end
end

function CopDamage:roll_critical_hit(attack_data, damage, damage_clamp)
	local damage = damage or attack_data.damage
	if not self:can_be_critical(attack_data) then
		return false, damage
	end
	
	local critical_hits = self._char_tweak.critical_hits or {}
	local critical_hit = false
	local critical_value = critical_hits.base_chance or 0
	local critical_hit_chance_multiplier = critical_hits.player_chance_multiplier or 1
	critical_value = critical_value + managers.player:critical_hit_chance() * critical_hit_chance_multiplier

	if attack_data.backstab then
		critical_value = critical_value + managers.player:upgrade_value("player", "backstab_crits", 0)
	end

	if critical_value > 0 then
		local critical_roll = math.rand(1)
		critical_hit = critical_roll < critical_value
	end

	if critical_hit then
		local critical_damage_mul = critical_hits.damage_mul or self._char_tweak.headshot_dmg_mul

		if critical_damage_mul then
			damage = damage * critical_damage_mul
		else
			damage = self._health * 10
		end
	end

	if damage_clamp then
		damage = math.min(damage, damage_clamp)
	end
	
	return critical_hit, damage
end

function CopDamage:can_be_critical(attack_data)
	local weapon_unit_base = nil

	if alive(attack_data.weapon_unit) then
		weapon_unit_base = attack_data.weapon_unit:base()
	end

	if weapon_unit_base == nil then
		return true
	end

	local weapon_type = nil
	local damage_type = attack_data.variant

	if weapon_unit_base.thrower_unit then
		local unit_base = weapon_unit_base._unit:base()

		if unit_base._tweak_projectile_entry then
			weapon_type = unit_base._tweak_projectile_entry
		elseif unit_base._projectile_entry then
			weapon_type = unit_base._projectile_entry
		end
	elseif weapon_unit_base.weapon_tweak_data then
		local weapon_td = weapon_unit_base:weapon_tweak_data()

		if weapon_td.ignore_crit_damage then
			return false
		end

		weapon_type = weapon_td.categories[1]
	elseif weapon_unit_base.get_name_id then
		weapon_type = weapon_unit_base:get_name_id()
	end

	local damage_crit_data = tweak_data.weapon_disable_crit_for_damage[weapon_type]

	if not damage_crit_data then
		return true
	end

	local is_damage_type_can_crit = damage_crit_data[damage_type]

	if is_damage_type_can_crit or attack_data.is_fire_dot_damage then
		return true
	end

	return false
end

function CopDamage:check_backstab(attack_data)
	if self._unit.movement and self._unit:movement().m_rot then
		local fwd_vec = mvector3.dot(self._unit:movement():m_rot():y(), managers.player:player_unit():movement():m_head_rot():y())

		--# degrees of leeway == (1-(2*number fwd_vec > than))pi radians
		if fwd_vec > 0.15 then
			return true
		end
	end

	return false
end

function CopDamage:bag_explode()	
	local pos = self._unit:get_object(Idstring("Spine2")):position()

	local range = 400
	local damage = 800
	local ply_damage = damage * 0.5
	local normal = math.UP
	local slot_mask = managers.slot:get_mask("explosion_targets")
	local curve_pow = 4
	
	--Kill this dude if he isn't already
	self._unit:character_damage():damage_mission({damage = 9999999})

	--BOOM
	local damage_params = {
		no_raycast_check_characters = false,
		hit_pos = pos,
		range = range,
		collision_slotmask = slot_mask,
		curve_pow = curve_pow,
		damage = damage,
		player_damage = ply_damage,
		ignore_unit = self._unit,
		user = nil
	}
	local effect_params = {
		sound_event = "grenade_explode",
		effect = "effects/payday2/particles/explosions/grenade_explosion",
		camera_shake_max_mul = 4,
		sound_muffle_effect = true,
		feedback_range = range * 2
	}

	managers.explosion:give_local_player_dmg(pos, range, ply_damage)
	managers.explosion:play_sound_and_effects(pos, normal, range, effect_params)
	managers.explosion:detect_and_give_dmg(damage_params)
	managers.network:session():send_to_peers_synched("sync_explosion_to_client", nil, pos, normal, ply_damage, range, curve_pow)	

	--Spawn some fire afterwards too
	local position = self._unit:position()
	local rotation = self._unit:rotation()
	local data = {
		damage = 6,
		player_damage = 3,
		fire_dot_data = {
			dot_damage = 1,
			dot_trigger_max_distance = 3000,
			dot_trigger_chance = 50,
			dot_length = 3.1,
			dot_tick_period = 0.5
		},
		range = 75,
		burn_duration = 12,
		burn_tick_period = 0.5,
		curve_pow = 3,
		sound_event = "white_explosion",
		sound_event_burning = "burn_loop_gen",
		sound_event_impact_duration = 4,
		alert_radius = 15000,
		fire_alert_radius = 15000,
		effect_name = "effects/payday2/particles/explosions/grenade_incendiary_explosion_sc"
	}

	EnvironmentFire.spawn(position, rotation, data, math.UP, nil, nil, 0, 1)			
end

function CopDamage:taser_bag_explode()    
	local pos = self._unit:get_object(Idstring("Spine2")):position()

	local range = 750
	local damage = 300
	local ply_damage = 0
	local normal = math.UP
	local slot_mask = managers.slot:get_mask("explosion_targets") - managers.slot:get_mask("all_criminals")
	local curve_pow = 4
	local custom_params = {
		camera_shake_max_mul = 4,
		effect = "effects/particles/explosions/electric_grenade",
		sound_event = "grenade_electric_explode",
		feedback_range = range * 2
	}
	
	--Do a shit ton of damage to this dude and stun him
	local taser_action_data = {
		variant = "counter_tased",
		damage = self._unit:character_damage()._HEALTH_INIT * 0.2,
		damage_effect = self._unit:character_damage()._HEALTH_INIT * 2,
		attacker_unit = self._unit,
		attack_dir = -self._unit:movement()._action_common_data.fwd,
		col_ray = {
			position = mvector3.copy(self._unit:movement():m_head_pos()),
			body = self._unit:body("body")
		}
	}

	self._unit:character_damage():damage_melee(taser_action_data)	
		
	managers.explosion:play_sound_and_effects(pos, normal, range, custom_params)

	--Taser BOOM
	local hit_units, splinters = managers.explosion:detect_and_tase({
		player_damage = ply_damage,
		tase_strength = "heavy",
		hit_pos = pos,
		range = range,
		collision_slotmask = slot_mask,
		curve_pow = 4,
		damage = 3,
		ignore_unit = self._unit,
		alert_radius = 1
	})
	
	managers.network:session():send_to_peers_synched("sync_explosion_to_client", nil, pos, normal, ply_damage, range, curve_pow)		
end

function CopDamage:grenadier_bag_explode()    
	local pos = self._unit:get_object(Idstring("Spine2")):position()

	local range = 1000
	local damage = 0
	local ply_damage = 0
	local normal = math.UP
	local slot_mask = managers.slot:get_mask("explosion_targets") - managers.slot:get_mask("all_criminals")
	local curve_pow = 0.8
	local custom_params = {
		camera_shake_max_mul = 4,
		effect = "effects/particles/explosions/explosion_flash_grenade",
		sound_event = "flashbang_explosion",
		feedback_range = range * 2
	}
	local tweak_entry = {
		damage = damage,
		player_damage = ply_damage,
		curve_pow = curve_pow,
		range = range,
		name_id = "bm_concussion",
	}
	
	--Do a shit ton of damage to this dude and stun him
	local boom_action_data = {
		variant = "concussion",
		damage = self._unit:character_damage()._HEALTH_INIT * 0.2,
		damage_effect = self._unit:character_damage()._HEALTH_INIT * 2,
		attacker_unit = self._unit,
		attack_dir = -self._unit:movement()._action_common_data.fwd,
		col_ray = {
			position = mvector3.copy(self._unit:movement():m_head_pos()),
			body = self._unit:body("body")
		}
	}

	self._unit:character_damage():damage_melee(boom_action_data)		
	
	managers.explosion:play_sound_and_effects(pos, normal, range, custom_params)	
	
	local hit_units, splinters = managers.explosion:detect_and_stun({
		player_damage = 0,
		hit_pos = pos,
		range = range,
		collision_slotmask = slot_mask,
		curve_pow = curve_pow,
		damage = damage,
		ignore_unit = self._unit,
		alert_radius = 1
	})	
	
	managers.network:session():send_to_peers_synched("sync_explosion_to_client", nil, pos, normal, ply_damage, range, curve_pow)		
end

function CopDamage:kamikaze_bag_explode()    
	local pos = alive(self._unit) and (self._unit:get_object(Idstring("Spine2")):position() or self._unit:position())

	if not pos then
		return
	end

	local range = 400
	local damage = 500
	local ply_damage = 250
	local normal = math.UP
	local slot_mask = managers.slot:get_mask("explosion_targets")
	local curve_pow = 4
	local custom_params = {
		camera_shake_max_mul = 4,
		effect = "effects/payday2/particles/explosions/grenade_explosion",
		sound_event = "grenade_explode",
		feedback_range = range * 2
	}
	local tweak_entry = {
		damage = damage,
		player_damage = ply_damage,
		curve_pow = curve_pow,
		range = range
	}
	
	managers.explosion:give_local_player_dmg(pos, range, ply_damage)
	managers.explosion:play_sound_and_effects(pos, normal, range, custom_params)	
	
	local damage_params = {
		no_raycast_check_characters = true,
		hit_pos = pos,
		range = range,
		collision_slotmask = managers.slot:get_mask("explosion_targets"),
		curve_pow = curve_pow,
		damage = damage,
		player_damage = ply_damage,
		ignore_unit = alive(self._unit) and self._unit or nil
	}

	managers.explosion:detect_and_give_dmg(damage_params)
	managers.network:session():send_to_peers_synched("element_explode_on_client", pos, normal, damage, range, curve_pow)
	
end

function CopDamage:lpf_disable()	
	if not alive(self._unit) then
		return
	end	
	
	if self._unit:base() then
		self._unit:base():change_char_tweak("omnia_lpf_no_heal")
	end
	if self._unit:character_damage() and self._unit:character_damage().force_hurt then
		local attack_data = {
			variant = "bullet",
			type = "hurt",
			position = self._unit:oobb():center(),
			direction = self._unit:rotation():y(),
			col_ray = {
				position = self._unit:oobb():center(),
				ray = self._unit:rotation():y()
			}
		}

		self._unit:character_damage():force_hurt(attack_data)
	end	

	if not self._unit:movement()._buff_targets then
		return
	end

	for _, buffed_target in ipairs(self._unit:movement()._buff_targets) do
		if alive(buffed_target) and buffed_target:character_damage() and buffed_target:character_damage().force_hurt then
			local attack_data = {
				variant = "bullet",
				type = "hurt",
				position = buffed_target:oobb():center(),
				direction = buffed_target:rotation():y(),
				col_ray = {
					position = buffed_target:oobb():center(),
					ray = buffed_target:rotation():y(),
				}
			}

			buffed_target:character_damage():_apply_damage_to_health(math.max(buffed_target:character_damage()._health - buffed_target:character_damage()._HEALTH_INIT, 0)) -- Only take damage equivalent to the overheal, if any.
			buffed_target:character_damage():force_hurt(attack_data)
		end
	end
end

--Added stuff for CG22 mutator
function CopDamage:_apply_damage_reduction(damage)
	local damage_reduction = self._unit:movement():team().damage_reduction or 0

	if damage_reduction > 0 then
		damage = damage * (1 - damage_reduction)
	end

	if self._damage_reduction_multiplier then
		damage = damage * self._damage_reduction_multiplier
	end
	
	--Here!
	if managers.mutators:is_mutator_active(MutatorCG22) then
		local cg22_mutator = managers.mutators:get_mutator(MutatorCG22)

		if cg22_mutator:can_enemy_be_affected_by_buff("blue", self._unit) then
			damage = damage * cg22_mutator:get_enemy_blue_multiplier()
		end
	end

	return damage
end

function CopDamage:can_attach_projectiles()
	return not self._char_tweak.cannot_attach_projectiles
end

function CopDamage:check_medic_heal()
	if self._unit:anim_data().act then
		return false
	end

	local medic = managers.enemy:get_nearby_medic(self._unit)
	
	if medic and medic.anim_data then
		if medic:anim_data().hurt or medic:anim_data().heavy_hurt then
			return false
		end
	end

	return medic and medic:character_damage():heal_unit(self._unit)
end

--Doing this to get rid of unused CrimeSpree stuff just in case
function CopDamage:do_medic_heal()
	self._healed = true
	self._health = self._HEALTH_INIT
	self._health_ratio = 1

	self:_update_debug_ws()
	
	return true
end

function CopDamage:_check_melee_achievements(attack_data)
	local player_unit = managers.player:player_unit()

	if alive(player_unit) and tweak_data.blackmarket.melee_weapons[attack_data.name_id] then
		local is_civlian = CopDamage.is_civilian(self._unit:base()._tweak_table)
		local is_gangster = CopDamage.is_gangster(self._unit:base()._tweak_table)
		local is_cop = not is_civlian and not is_gangster
		local achievements = tweak_data.achievement.enemy_melee_hit_achievements or {}
		local melee_type = tweak_data.blackmarket.melee_weapons[attack_data.name_id].type
		local enemy_base = self._unit:base()
		local enemy_movement = self._unit:movement()
		local enemy_type = enemy_base._tweak_table
		local unit_weapon = enemy_base._default_weapon_id
		local health_ratio = nil

		if alive(player_unit) and player_unit:character_damage() then
			health_ratio = player_unit:character_damage():health_ratio() * 100
		else
			health_ratio = 0
		end
		local melee_pass, melee_weapons_pass, type_pass, enemy_pass, enemy_weapon_pass, diff_pass, health_pass, level_pass, job_pass, jobs_pass, enemy_count_pass, tags_all_pass, tags_any_pass, all_pass, cop_pass, gangster_pass, civilian_pass, stealth_pass, on_fire_pass, behind_pass, result_pass, mutators_pass, critical_pass, action_pass, is_dropin_pass, style_pass = nil

		local function count_enemy_type_kills(enemy_type)
			local rtn = 0
			if type(enemy_type) == "table" then
				for _, enemy in ipairs(enemy_type) do
					rtn = rtn + managers.statistics:session_enemy_killed_by_type(enemy, "melee")
				end
			else
				return managers.statistics:session_enemy_killed_by_type(enemy_type, "melee")
			end
			return rtn
		end
		
		for achievement, achievement_data in pairs(achievements) do
			melee_pass = not achievement_data.melee_id or achievement_data.melee_id == attack_data.name_id
			melee_weapons_pass = not achievement_data.melee_weapons or table.contains(achievement_data.melee_weapons, attack_data.name_id)
			type_pass = not achievement_data.melee_type or melee_type == achievement_data.melee_type
			result_pass = not achievement_data.result or attack_data.result.type == achievement_data.result
			enemy_pass = not achievement_data.enemy or enemy_type == achievement_data.enemy
			enemy_weapon_pass = not achievement_data.enemy_weapon or unit_weapon == achievement_data.enemy_weapon
			behind_pass = not achievement_data.from_behind or from_behind
			diff_pass = not achievement_data.difficulty or table.contains(achievement_data.difficulty, Global.game_settings.difficulty)
			health_pass = not achievement_data.health or health_ratio <= achievement_data.health
			level_pass = not achievement_data.level_id or (managers.job:current_level_id() or "") == achievement_data.level_id
			job_pass = not achievement_data.job or managers.job:current_real_job_id() == achievement_data.job
			jobs_pass = not achievement_data.jobs or table.contains(achievement_data.jobs, managers.job:current_real_job_id())
			enemy_count_pass = not achievement_data.enemy_kills or achievement_data.enemy_kills.count <= count_enemy_type_kills(achievement_data.enemy_kills.enemies or achievement_data.enemy_kills.enemy)
			tags_all_pass = not achievement_data.enemy_tags_all or enemy_base:has_all_tags(achievement_data.enemy_tags_all)
			tags_any_pass = not achievement_data.enemy_tags_any or enemy_base:has_any_tag(achievement_data.enemy_tags_any)
			cop_pass = not achievement_data.is_cop or is_cop
			gangster_pass = not achievement_data.is_gangster or is_gangster
			civilian_pass = not achievement_data.is_not_civilian or not is_civlian
			stealth_pass = not achievement_data.is_stealth or managers.groupai:state():whisper_mode()
			on_fire_pass = not achievement_data.is_on_fire or managers.fire:is_set_on_fire(self._unit)
			is_dropin_pass = achievement_data.is_dropin == nil or achievement_data.is_dropin == managers.statistics:is_dropin()
			style_pass = not achievement_data.player_style or achievement_data.player_style.style == managers.blackmarket:equipped_player_style() and (not achievement_data.player_style.variation or achievement_data.player_style.variation == managers.blackmarket:equipped_suit_variation())

			if achievement_data.enemies then
				enemy_pass = false

				for _, enemy in pairs(achievement_data.enemies) do
					if enemy == enemy_type then
						enemy_pass = true

						break
					end
				end
			end

			mutators_pass = managers.mutators:check_achievements(achievement_data)
			critical_pass = not achievement_data.critical

			if achievement_data.critical then
				critical_pass = attack_data.critical_hit
			end

			action_pass = true

			if achievement_data.action then
				local action = enemy_movement:get_action(achievement_data.action.body_part)
				local action_type = action and action:type()
				action_pass = action_type == achievement_data.action.type
			end

			all_pass = melee_pass and melee_weapons_pass and type_pass and enemy_pass and enemy_weapon_pass and behind_pass and diff_pass and health_pass and level_pass and job_pass and jobs_pass and cop_pass and gangster_pass and civilian_pass and stealth_pass and on_fire_pass and enemy_count_pass and tags_all_pass and tags_any_pass and result_pass and mutators_pass and critical_pass and action_pass and is_dropin_pass and style_pass

			if all_pass then
				if achievement_data.stat then
					managers.achievment:award_progress(achievement_data.stat)
				elseif achievement_data.award then
					managers.achievment:award(achievement_data.award)
				elseif achievement_data.challenge_stat then
					managers.challenge:award_progress(achievement_data.challenge_stat)
				elseif achievement_data.trophy_stat then
					managers.custom_safehouse:award(achievement_data.trophy_stat)
				elseif achievement_data.challenge_award then
					managers.challenge:award(achievement_data.challenge_award)
				end
			end
		end
	end
end

--Add better checks for the Crazy Ivan cheevo so the in-fighting won't cause the cheevo to fail
function CopDamage.MAD_3_ACHIEVEMENT(attack_data)
	local attacker_unit = alive(attack_data.attacker_unit) and attack_data.attacker_unit
	local unit_base = attacker_unit and attacker_unit:base()
	local is_player_or_ally = attacker_unit and ((attacker_unit == managers.player:player_unit()) or (attacker_unit.movement and attacker_unit:movement() and not attacker_unit:movement():team().foes[tweak_data.levels:get_default_team_ID("player")] ))
	if attack_data.variant ~= "melee" and unit_base and not unit_base.tased and is_player_or_ally then
		managers.job:set_memory("mad_3", false)
	end
end
