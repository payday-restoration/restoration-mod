GamemodeCrimeSpree = GamemodeCrimeSpree or class(GamemodeStandard)
GamemodeCrimeSpree.id = "crime_spree"
GamemodeCrimeSpree._NAME = "Crime Spree Gamemode"
Gamemode.register(GamemodeCrimeSpree.id, GamemodeCrimeSpree)

GamemodeHeistWar = GamemodeHeistWar or class(GamemodeStandard)
GamemodeHeistWar.id = "heist_war"
GamemodeHeistWar._NAME = "Heist War Gamemode"
Gamemode.register(GamemodeHeistWar.id, GamemodeHeistWar)