local mvec3_dist_sq = mvector3.distance_sq

function TeamAILogicTravel.check_inspire(data, attention)
	if not attention then
		return
	end

	local range_sq = 810000
	local pos = data.unit:position()
	local target = attention.unit:position()
	local dist = mvec3_dist_sq(pos, target)

	if dist < range_sq and not attention.unit:character_damage():arrested() then
		data.unit:brain():set_objective()
		data.unit:sound():say("f36x_any", true, false)

		local can_play_action = not data.unit:movement():chk_action_forbidden("action") and not data.unit:anim_data().reload and not data.internal_data.firing and not data.internal_data.shooting

		if can_play_action then
			local new_action = {
				variant = "cmd_get_up",
				align_sync = true,
				body_part = 3,
				type = "act"
			}

			if data.unit:brain():action_request(new_action) then
				data.internal_data.gesture_arrest = true
			end
		end

		local cooldown = managers.player:crew_ability_upgrade_value("crew_inspire", 360)

		managers.player:start_custom_cooldown("team", "crew_inspire", cooldown)
		TeamAILogicTravel.actually_revive(data, attention.unit, true)

		local skip_alert = managers.groupai:state():whisper_mode()

		if not skip_alert then
			local alert_rad = 500
			local new_alert = {
				"vo_cbt",
				data.unit:movement():m_head_pos(),
				alert_rad,
				data.SO_access,
				data.unit
			}

			managers.groupai:state():propagate_alert(new_alert)
		end
	end
end

function TeamAILogicTravel._upd_pathing(data, my_data)
if data.pathing_results then
	local pathing_results = data.pathing_results
	data.pathing_results = nil
	local path = pathing_results[my_data.advance_path_search_id]

	if path and my_data.processing_advance_path then
		my_data.processing_advance_path = nil

		if path ~= "failed" then
			my_data.advance_path = path
		else
			data.path_fail_t = data.t

			data.objective_failed_clbk(data.unit, data.objective)

			return
		end
	end

	local path = pathing_results[my_data.coarse_path_search_id]

	if path and my_data.processing_coarse_path then
		my_data.processing_coarse_path = nil

		if path ~= "failed" then
			my_data.coarse_path = path
			my_data.coarse_path_index = 1
		elseif my_data.path_safely then
			my_data.path_safely = nil
		else
			print("[TeamAILogicTravel:_upd_pathing] coarse_path failed unsafe", data.unit, my_data.coarse_path_index)

			data.path_fail_t = data.t

			data.objective_failed_clbk(data.unit, data.objective)

			return
		end
	end
end
end

function TeamAILogicTravel._get_exact_move_pos(data, nav_index)
local my_data = data.internal_data
local objective = data.objective
local to_pos = nil
local coarse_path = my_data.coarse_path
local total_nav_points = #coarse_path
local reservation, wants_reservation = nil

if total_nav_points <= nav_index then
	local new_occupation = data.logic._determine_destination_occupation(data, objective)

	if new_occupation then
		if new_occupation.type == "guard" then
			local guard_door = new_occupation.door
			local guard_pos = CopLogicTravel._get_pos_accross_door(guard_door, objective.nav_seg)

			if guard_pos then
				reservation = CopLogicTravel._reserve_pos_along_vec(guard_door.center, guard_pos)

				if reservation then
					local guard_object = {
						type = "door",
						door = guard_door,
						from_seg = new_occupation.from_seg
					}
					objective.guard_obj = guard_object
					to_pos = reservation.pos
				end
			end
		elseif new_occupation.type == "defend" then
			if new_occupation.cover then
				to_pos = new_occupation.cover[1][1]

				if data.char_tweak.wall_fwd_offset then
					to_pos = CopLogicTravel.apply_wall_offset_to_cover(data, my_data, new_occupation.cover[1], data.char_tweak.wall_fwd_offset)
				end

				local new_cover = new_occupation.cover

				managers.navigation:reserve_cover(new_cover[1], data.pos_rsrv_id)

				my_data.moving_to_cover = new_cover
			elseif new_occupation.pos then
				to_pos = new_occupation.pos
			end

			wants_reservation = true
		elseif new_occupation.type == "act" then
			to_pos = new_occupation.pos
			wants_reservation = true
		elseif new_occupation.type == "revive" then
			to_pos = new_occupation.pos
			objective.rot = new_occupation.rot
			wants_reservation = true
		else
			to_pos = new_occupation.pos
			wants_reservation = true
		end
	end

	if not to_pos then
		to_pos = managers.navigation:find_random_position_in_segment(objective.nav_seg)
		to_pos = CopLogicTravel._get_pos_on_wall(to_pos)
		wants_reservation = true
	end
else
	local nav_seg = coarse_path[nav_index][1]
	local area = managers.groupai:state():get_area_from_nav_seg_id(nav_seg)
	local cover = managers.navigation:find_cover_in_nav_seg_1(area.nav_segs)

	if my_data.moving_to_cover then
		managers.navigation:release_cover(my_data.moving_to_cover[1])

		my_data.moving_to_cover = nil
	end

	if cover then
		managers.navigation:reserve_cover(cover, data.pos_rsrv_id)

		my_data.moving_to_cover = {
			cover
		}
		to_pos = cover[1]
	else
		to_pos = coarse_path[nav_index][2]
	end
end

if not reservation and wants_reservation then
	data.brain:add_pos_rsrv("path", {
		radius = 60,
		position = mvector3.copy(to_pos)
	})
end

return to_pos
end

function TeamAILogicTravel._determine_destination_occupation(data, objective)
local occupation = nil

if objective.type == "defend_area" then
	if objective.cover then
		occupation = {
			type = "defend",
			seg = objective.nav_seg,
			cover = objective.cover,
			radius = objective.radius
		}
	elseif objective.pos then
		occupation = {
			type = "defend",
			seg = objective.nav_seg,
			pos = objective.pos,
			radius = objective.radius
		}
	else
		local near_pos = objective.follow_unit and objective.follow_unit:movement():nav_tracker():field_position()
		local cover = CopLogicTravel._find_cover(data, objective.nav_seg, near_pos)

		if cover then
			local cover_entry = {
				cover
			}
			occupation = {
				type = "defend",
				seg = objective.nav_seg,
				cover = cover_entry,
				radius = objective.radius
			}
		else
			near_pos = CopLogicTravel._get_pos_on_wall(managers.navigation._nav_segments[objective.nav_seg].pos, 700)
			occupation = {
				type = "defend",
				seg = objective.nav_seg,
				pos = near_pos,
				radius = objective.radius
			}
		end
	end
elseif objective.type == "phalanx" then
	local logic = data.unit:brain():get_logic_by_name(objective.type)

	logic.register_in_group_ai(data.unit)

	local phalanx_circle_pos = logic.calc_initial_phalanx_pos(data.m_pos, objective)
	occupation = {
		type = "defend",
		seg = objective.nav_seg,
		pos = phalanx_circle_pos,
		radius = objective.radius
	}
elseif objective.type == "act" then
	occupation = {
		type = "act",
		seg = objective.nav_seg,
		pos = objective.pos
	}
elseif objective.type == "follow" then
	local my_data = data.internal_data
	local follow_tracker = objective.follow_unit:movement():nav_tracker()
	local dest_nav_seg_id = my_data.coarse_path[#my_data.coarse_path][1]
	local dest_area = managers.groupai:state():get_area_from_nav_seg_id(dest_nav_seg_id)
	local follow_pos = follow_tracker:field_position()
	local threat_pos = nil

	if data.attention_obj and data.attention_obj.nav_tracker and AIAttentionObject.REACT_COMBAT <= data.attention_obj.reaction then
		threat_pos = data.attention_obj.nav_tracker:field_position()
	end

	local cover = managers.navigation:find_cover_in_nav_seg_3(dest_area.nav_segs, nil, follow_pos, threat_pos)

	if cover then
		local cover_entry = {
			cover
		}
		occupation = {
			type = "defend",
			cover = cover_entry
		}
	else
		local max_dist = nil

		if objective.called then
			max_dist = 600
		end

		local to_pos = CopLogicTravel._get_pos_on_wall(dest_area.pos, max_dist)
		occupation = {
			type = "defend",
			pos = to_pos
		}
	end
elseif objective.type == "revive" then
	local is_local_player = objective.follow_unit:base().is_local_player
	local revive_u_mv = objective.follow_unit:movement()
	local revive_u_tracker = revive_u_mv:nav_tracker()
	local revive_u_rot = is_local_player and Rotation(0, 0, 0) or revive_u_mv:m_rot()
	local revive_u_fwd = revive_u_rot:y()
	local revive_u_right = revive_u_rot:x()
	local revive_u_pos = revive_u_tracker:lost() and revive_u_tracker:field_position() or revive_u_mv:m_pos()
	local ray_params = {
		trace = true,
		tracker_from = revive_u_tracker
	}

	if revive_u_tracker:lost() then
		ray_params.pos_from = revive_u_pos
	end

	local stand_dis = nil

	if is_local_player or objective.follow_unit:base().is_husk_player then
		stand_dis = 120
	else
		stand_dis = 90
		local mid_pos = mvector3.copy(revive_u_fwd)

		mvector3.multiply(mid_pos, -20)
		mvector3.add(mid_pos, revive_u_pos)

		ray_params.pos_to = mid_pos
		local ray_res = managers.navigation:raycast(ray_params)
		revive_u_pos = ray_params.trace[1]
	end

	local rand_side_mul = math.random() > 0.5 and 1 or -1
	local revive_pos = mvector3.copy(revive_u_right)

	mvector3.multiply(revive_pos, rand_side_mul * stand_dis)
	mvector3.add(revive_pos, revive_u_pos)

	ray_params.pos_to = revive_pos
	local ray_res = managers.navigation:raycast(ray_params)

	if ray_res then
		local opposite_pos = mvector3.copy(revive_u_right)

		mvector3.multiply(opposite_pos, -rand_side_mul * stand_dis)
		mvector3.add(opposite_pos, revive_u_pos)

		ray_params.pos_to = opposite_pos
		local old_trace = ray_params.trace[1]
		local opposite_ray_res = managers.navigation:raycast(ray_params)

		if opposite_ray_res then
			if mvector3.distance(revive_pos, revive_u_pos) < mvector3.distance(ray_params.trace[1], revive_u_pos) then
				revive_pos = ray_params.trace[1]
			else
				revive_pos = old_trace
			end
		else
			revive_pos = ray_params.trace[1]
		end
	else
		revive_pos = ray_params.trace[1]
	end

	local revive_rot = revive_u_pos - revive_pos
	local revive_rot = Rotation(revive_rot, math.UP)
	occupation = {
		type = "revive",
		pos = revive_pos,
		rot = revive_rot
	}
else
	occupation = {
		seg = objective.nav_seg,
		pos = objective.pos
	}
end

return occupation
end

function TeamAILogicTravel.chk_should_turn(data, my_data)
return not my_data.advancing and not my_data.turning and not my_data.has_old_action and not data.unit:movement():chk_action_forbidden("turn") and (not my_data.coarse_path or my_data.coarse_path_index < #my_data.coarse_path - 1 or not data.objective.rot)
end

function TeamAILogicTravel.action_complete_clbk(data, action)
local my_data = data.internal_data
local action_type = action:type()

if action_type == "walk" then
	if action:expired() and not my_data.starting_advance_action and my_data.coarse_path_index and not my_data.has_old_action and my_data.advancing then
		my_data.coarse_path_index = my_data.coarse_path_index + 1

		if my_data.coarse_path_index > #my_data.coarse_path then
			debug_pause_unit(data.unit, "[CopLogicTravel.action_complete_clbk] invalid coarse path index increment", data.unit, inspect(my_data.coarse_path), my_data.coarse_path_index)

			my_data.coarse_path_index = my_data.coarse_path_index - 1
		end
	end

	my_data.advancing = nil

	if my_data.moving_to_cover then
		if action:expired() then
			if my_data.best_cover then
				managers.navigation:release_cover(my_data.best_cover[1])
			end

			my_data.best_cover = my_data.moving_to_cover

			CopLogicBase.chk_cancel_delayed_clbk(my_data, my_data.cover_update_task_key)

			local high_ray = CopLogicTravel._chk_cover_height(data, my_data.best_cover[1], data.visibility_slotmask)
			my_data.best_cover[4] = high_ray
			my_data.in_cover = true
			local cover_wait_time = my_data.coarse_path_index == #my_data.coarse_path - 1 and 0.3 or 0.6 + 0.4 * math.random()

			if not CopLogicTravel._chk_close_to_criminal(data, my_data) then
				cover_wait_time = 0
			end

			my_data.cover_leave_t = data.t + cover_wait_time
		else
			managers.navigation:release_cover(my_data.moving_to_cover[1])

			if my_data.best_cover then
				local dis = mvector3.distance(my_data.best_cover[1][1], data.unit:movement():m_pos())

				if dis > 100 then
					managers.navigation:release_cover(my_data.best_cover[1])

					my_data.best_cover = nil
				end
			end
		end

		my_data.moving_to_cover = nil
	elseif my_data.best_cover then
		local dis = mvector3.distance(my_data.best_cover[1][1], data.unit:movement():m_pos())

		if dis > 100 then
			managers.navigation:release_cover(my_data.best_cover[1])

			my_data.best_cover = nil
		end
	end

	if not action:expired() then
		if my_data.processing_advance_path then
			local pathing_results = data.pathing_results

			if pathing_results and pathing_results[my_data.advance_path_search_id] then
				data.pathing_results[my_data.advance_path_search_id] = nil
				my_data.processing_advance_path = nil
			end
		elseif my_data.advance_path then
			my_data.advance_path = nil
		end

		data.unit:brain():abort_detailed_pathing(my_data.advance_path_search_id)
	end
elseif action_type == "turn" then
	data.internal_data.turning = nil
elseif action_type == "shoot" then
	data.internal_data.shooting = nil
elseif action_type == "dodge" then
	local objective = data.objective
	local allow_trans, obj_failed = CopLogicBase.is_obstructed(data, objective, nil, nil)

	if allow_trans then
		local wanted_state = data.logic._get_logic_state_from_reaction(data)

		if wanted_state and wanted_state ~= data.name and obj_failed then
			if data.unit:in_slot(managers.slot:get_mask("enemies")) or data.unit:in_slot(17) then
				data.objective_failed_clbk(data.unit, data.objective)
			elseif data.unit:in_slot(managers.slot:get_mask("criminals")) then
				managers.groupai:state():on_criminal_objective_failed(data.unit, data.objective, false)
			end

			if my_data == data.internal_data then
				debug_pause_unit(data.unit, "[CopLogicTravel.action_complete_clbk] exiting without discarding objective", data.unit, inspect(data.objective))
				CopLogicBase._exit(data.unit, wanted_state)
			end
		end
	end
end
end


function TeamAILogicTravel._upd_enemy_detection(data)
	data.t = TimerManager:game():time()
	local my_data = data.internal_data
	local max_reaction = nil

	if data.cool then
		max_reaction = AIAttentionObject.REACT_SURPRISED
	end

	local delay = CopLogicBase._upd_attention_obj_detection(data, AIAttentionObject.REACT_CURIOUS, max_reaction)
	local new_attention, new_prio_slot, new_reaction = TeamAILogicIdle._get_priority_attention(data, data.detected_attention_objects, nil)

	TeamAILogicBase._set_attention_obj(data, new_attention, new_reaction)
	TeamAILogicIdle.check_idle_reload(data, new_reaction)

	if new_attention then
		local objective = data.objective
		local allow_trans, obj_failed = nil
		local dont_exit = false

		if data.unit:movement():chk_action_forbidden("walk") and not data.unit:anim_data().act_idle then
			dont_exit = true
		else
			allow_trans, obj_failed = CopLogicBase.is_obstructed(data, objective, nil, new_attention)
		end

		if obj_failed and not dont_exit then
			if objective.type == "follow" then
				debug_pause_unit(data.unit, "failing follow", allow_trans, obj_failed, inspect(objective))
			end

			data.objective_failed_clbk(data.unit, data.objective)

			return
		end
	end

	CopLogicAttack._upd_aim(data, my_data)

	if not my_data._intimidate_chk_t or my_data._intimidate_chk_t + 0.5 < data.t then
		if not data.unit:brain()._intimidate_t or data.unit:brain()._intimidate_t + 2 < data.t then
			my_data._intimidate_chk_t = data.t

			if data.unit:movement()._should_stay then
				local can_turn = nil

				if not my_data._turning_to_intimidate_t or my_data._turning_to_intimidate_t + 2 < data.t then
					if not data.unit:movement():chk_action_forbidden("turn") then
						if not new_prio_slot or new_prio_slot > 5 then
							can_turn = true
						end
					end
				end

				local shout_angle = can_turn and 180 or 90
				local shout_distance = 1200
				local civ = TeamAILogicIdle.find_civilian_to_intimidate(data.unit, shout_angle, shout_distance)

				if civ then
					if can_turn and CopLogicAttack._chk_request_action_turn_to_enemy(data, my_data, data.m_pos, civ:movement():m_pos()) then
						my_data._turning_to_intimidate_t = data.t
					else
						if TeamAILogicIdle.intimidate_civilians(data, data.unit, true, true) then
							data.unit:brain()._intimidate_t = data.t
						end
					end
				end
			else
				local civ = TeamAILogicIdle.intimidate_civilians(data, data.unit, true, true)

				if civ then
					data.unit:brain()._intimidate_t = data.t

					if not data.attention_obj then
						CopLogicBase._set_attention_on_unit(data, civ)

						local key = "RemoveAttentionOnUnit" .. tostring(data.key)

						CopLogicBase.queue_task(my_data, key, TeamAILogicTravel._remove_enemy_attention, {
							data = data,
							target_key = civ:key()
						}, data.t + 1.5)
					end
				end
			end
		end
	end

	TeamAILogicAssault._chk_request_combat_chatter(data, my_data)
	TeamAILogicIdle._upd_sneak_spotting(data, my_data)
	CopLogicBase.queue_task(my_data, my_data.detection_task_key, TeamAILogicTravel._upd_enemy_detection, data, data.t + delay)
end