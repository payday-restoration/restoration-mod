ModifierNoHurtAnims.IgnoredHurtTypes = {
	"heavy_hurt"
}