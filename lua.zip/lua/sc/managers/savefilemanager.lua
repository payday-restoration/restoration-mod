SavefileManager.PROGRESS_SLOT = SystemInfo:platform() == Idstring("WIN32") and 77
SavefileManager.BACKUP_SLOT = SystemInfo:platform() == Idstring("WIN32") and 77