function CustomSafehouseManager:is_being_raided()
	return false 
end