if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then
	
	NetworkMatchMakingSTEAM._BUILD_SEARCH_INTEREST_KEY = "restoration_dev_9.6.5"
	
end
