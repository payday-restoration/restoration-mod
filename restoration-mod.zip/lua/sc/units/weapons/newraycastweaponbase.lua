local mvec3_set = mvector3.set
local mvec3_add = mvector3.add
local mvec3_dot = mvector3.dot
local mvec3_sub = mvector3.subtract
local mvec3_mul = mvector3.multiply
local mvec3_norm = mvector3.normalize
local mvec3_dir = mvector3.direction
local mvec3_set_l = mvector3.set_length
local mvec3_len = mvector3.length
local math_clamp = math.clamp
local math_lerp = math.lerp
local math_map_range_clamped = math.map_range_clamped
local tmp_vec1 = Vector3()
local tmp_vec2 = Vector3()
local ids_single = Idstring("single")
local ids_auto = Idstring("auto")
local ids_burst = Idstring("burst")
local ids_volley = Idstring("volley")
local FIRE_MODE_IDS = {
	single = ids_single,
	auto = ids_auto,
	burst = ids_burst,
	volley = ids_volley
}
local is_pro = Global.game_settings and Global.game_settings.one_down

--Adds ability to define per weapon category AP skills.
Hooks:PostHook(NewRaycastWeaponBase, "init", "ResExtraSkills", function(self)
	--Since armor piercing chance is no longer used, lets use weapon category to determine armor piercing baseline.
	if self:is_category("bow", "crossbow", "saw") then
		self._use_armor_piercing = true
	end

	self._move_decay = 0.2

	self._skill_global_ap = (managers.player:has_category_upgrade("player", "ap_bullets") and managers.player:upgrade_value("player", "ap_bullets", 1)) or nil

	local fire_mode_data = self:weapon_tweak_data().fire_mode_data or {}
	local volley_fire_mode = fire_mode_data.volley

	self._shield_knock = managers.player:has_category_upgrade("player", "bullet_shield_knock")

	if volley_fire_mode then
		self._volley_spread_mul = volley_fire_mode.spread_mul or 1
		self._volley_damage_mul = volley_fire_mode.damage_mul or 1
		self._volley_damage_mul_step = volley_fire_mode.damage_mul_step or nil
		self._volley_ammo_usage = volley_fire_mode.ammo_usage or 1
		self._volley_rays = volley_fire_mode.rays or 1
	end

	self._is_controller = managers.menu:get_controller():get_default_controller_id() ~= "keyboard" and not _G.IS_VR
end)

if _G.IS_VR then
	--I might have to do something unique for VR, but we'll see.
else	
	function NewRaycastWeaponBase:clip_full()
		if self:ammo_base()._tactical_reload then
			return self:ammo_base():get_ammo_remaining_in_clip() == self:ammo_base():get_ammo_max_per_clip() + self:ammo_base()._tactical_reload
		else
			return self:ammo_base():get_ammo_remaining_in_clip() == self:ammo_base():get_ammo_max_per_clip()
		end
	end
	
	--Handle guns that can hold bullets in the chamber.
	local original_on_reload = NewRaycastWeaponBase.on_reload
	function NewRaycastWeaponBase:on_reload(amount, bypass_purse)
		if not self._setup.expend_ammo then
			original_on_reload(self, amount, bypass_purse)

			return
		end
		local ammo_base = self._reload_ammo_base or self:ammo_base()
		local no_purse = not bypass_purse and self._keep_ammo == 0 

		if ammo_base:weapon_tweak_data().uses_clip == true then
			if ammo_base:get_ammo_remaining_in_clip() <= ammo_base:get_ammo_max_per_clip()  then
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip(), ammo_base:get_ammo_remaining_in_clip() +  ammo_base:weapon_tweak_data().clip_capacity))
			end
		else
			if ammo_base:get_ammo_remaining_in_clip() > 0 and ammo_base._tactical_reload == 1 then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - (ammo_base:get_ammo_remaining_in_clip() - 1))
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip() + 1))

			elseif ammo_base:get_ammo_remaining_in_clip() > 1 and ammo_base._tactical_reload == 2 then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - (ammo_base:get_ammo_remaining_in_clip() - 2))
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip() + 2))
			elseif ammo_base:get_ammo_remaining_in_clip() == 1 and ammo_base._tactical_reload == 2 then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - (ammo_base:get_ammo_remaining_in_clip() - 1))
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip() + 1))

			elseif ammo_base:get_ammo_remaining_in_clip() >= 3 and ammo_base._tactical_reload == 3 then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - (ammo_base:get_ammo_remaining_in_clip() - 3))
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip() + 3))
			elseif ammo_base:get_ammo_remaining_in_clip() == 2 and ammo_base._tactical_reload == 3 then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - (ammo_base:get_ammo_remaining_in_clip() - 2))
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip() + 2))
			elseif ammo_base:get_ammo_remaining_in_clip() == 1 and ammo_base._tactical_reload == 3 then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - (ammo_base:get_ammo_remaining_in_clip() - 1))
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip() + 1))

			elseif ammo_base:get_ammo_remaining_in_clip() > 0 and (not ammo_base._tactical_reload or ammo_base._tactical_reload == 0) then
				if no_purse then
					ammo_base:set_ammo_total(ammo_base:get_ammo_total() - ammo_base:get_ammo_remaining_in_clip())
				end
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip()))
			elseif self._setup.expend_ammo then
				ammo_base:set_ammo_remaining_in_clip(math.min(ammo_base:get_ammo_total(), ammo_base:get_ammo_max_per_clip()))
			else
				ammo_base:set_ammo_remaining_in_clip(ammo_base:get_ammo_max_per_clip())
				ammo_base:set_ammo_total(ammo_base:get_ammo_max_per_clip())
			end
		end

		managers.job:set_memory("kill_count_no_reload_" .. tostring(self._name_id), nil, true)

		self._reload_ammo_base = nil
		self._shots_fired_mag = 0

		local user_unit = managers.player:player_unit()

		if user_unit then
			user_unit:movement():current_state():send_reload_interupt()
		end

		if not self._ignore_reload_objects then
			self:set_reload_objects_visible(false)
		end

		self._reload_objects = {}
		self._next_fire_allowed = self._unit:timer():time()
	end
	
	function NewRaycastWeaponBase:reload_expire_t(is_not_empty)
		if self._use_shotgun_reload then
			local shotgun_reload_tweak = self:_get_shotgun_reload_tweak_data(is_not_empty)
			if shotgun_reload_tweak and shotgun_reload_tweak.reload_queue then
				local ammo_total = self:get_ammo_total()
				local ammo_max_per_clip = self:get_ammo_max_per_clip() + (not self._started_reload_empty and self._tactical_reload and 1 or 0)
				local ammo_remaining_in_clip = self:get_ammo_remaining_in_clip()
				local ammo_to_reload = math.min(ammo_total - ammo_remaining_in_clip, ammo_max_per_clip - ammo_remaining_in_clip)
				local reload_expire_t = 0
				local queue_index = 0
				local queue_data = nil
				local queue_num = #shotgun_reload_tweak.reload_queue

				while ammo_to_reload > 0 do
					if queue_index == queue_num then
						reload_expire_t = reload_expire_t + (shotgun_reload_tweak.reload_queue_wrap or 0)
					end

					queue_index = queue_index % queue_num + 1
					queue_data = shotgun_reload_tweak.reload_queue[queue_index]
					reload_expire_t = reload_expire_t + queue_data.expire_t or 0.5666666666666667
					ammo_to_reload = ammo_to_reload - (queue_data.reload_num or 1)
				end

				return reload_expire_t
			else
				local reload_count = math.ceil(self:max_bullets_to_reload(not is_not_empty or self._started_reload_empty) / (shotgun_reload_tweak and shotgun_reload_tweak.reload_num or 1))
				return reload_count * self:reload_shell_expire_t(is_not_empty)
			end
		end
		
	end
	
	function NewRaycastWeaponBase:max_bullets_to_reload(from_empty)
		local max_per_mag = self:get_ammo_max_per_clip()
		if not from_empty and self._tactical_reload then
			max_per_mag = max_per_mag + self._tactical_reload or 1
		end
		return math.min(self:get_ammo_total(), max_per_mag) - self:get_ammo_remaining_in_clip()
	end	
	
	function NewRaycastWeaponBase:update_reloading(t, dt, time_left)
		if self._use_shotgun_reload and self._next_shell_reloded_t and t > self._next_shell_reloded_t then
			local speed_multiplier = self:reload_speed_multiplier()
			local shotgun_reload_tweak = self:_get_shotgun_reload_tweak_data(not self._started_reload_empty)
			local ammo_to_reload = 1
			local next_queue_data = nil

			if shotgun_reload_tweak and shotgun_reload_tweak.reload_queue then
				self._shotgun_queue_index = self._shotgun_queue_index % #shotgun_reload_tweak.reload_queue + 1

				if self._shotgun_queue_index == #shotgun_reload_tweak.reload_queue then
					self._next_shell_reloded_t = self._next_shell_reloded_t + (shotgun_reload_tweak.reload_queue_wrap or 0)
				end

				local queue_data = shotgun_reload_tweak.reload_queue[self._shotgun_queue_index]
				ammo_to_reload = queue_data and queue_data.reload_num or 1
				next_queue_data = shotgun_reload_tweak.reload_queue[self._shotgun_queue_index + 1]
				self._next_shell_reloded_t = self._next_shell_reloded_t + (next_queue_data and next_queue_data.expire_t or 0.5666666666666667) / speed_multiplier
			else
				self._next_shell_reloded_t = self._next_shell_reloded_t + self:reload_shell_expire_t(not self._started_reload_empty) / speed_multiplier
				ammo_to_reload = shotgun_reload_tweak and shotgun_reload_tweak.reload_num or 1
			end
			
			if ammo_to_reload > 1 then
				ammo_to_reload = math.min(ammo_to_reload, self:get_ammo_max_per_clip() - self:get_ammo_remaining_in_clip())
				ammo_to_reload = math.min(ammo_to_reload, self:get_ammo_total() - self:get_ammo_remaining_in_clip())
			end

			if not self._started_reload_empty and self._tactical_reload then
				self:set_ammo_remaining_in_clip(math.min(self:get_ammo_max_per_clip() + 1, self:get_ammo_remaining_in_clip() + ammo_to_reload))
			else
				self:set_ammo_remaining_in_clip(math.min(self:get_ammo_max_per_clip(), self:get_ammo_remaining_in_clip() + ammo_to_reload))
			end

			managers.job:set_memory("kill_count_no_reload_" .. tostring(self._name_id), nil, true)

			if not next_queue_data or not next_queue_data.skip_update_ammo then
				self:update_ammo_objects()
			end

			return true
		end
	end

end

NewRaycastWeaponBase.DEFAULT_BURST_SIZE = 3
NewRaycastWeaponBase.IDSTRING_SINGLE = Idstring("single")
NewRaycastWeaponBase.IDSTRING_AUTO = Idstring("auto")

--Multipliers for overall spread.
function NewRaycastWeaponBase:conditional_accuracy_multiplier(current_state, is_moving)
	local mul = 1
	local multi_ray = self._rays and self._rays > 1

	local pm = managers.player

	mul = mul * pm:get_property("desperado", 1)

	if not current_state then
		return mul
	end

	--local is_moving = current_state._moving or current_state:in_air()
	local full_steelsight = current_state:is_full_steelsight()
	local is_tacstance = self:second_sight_spread_mult()

	if full_steelsight then
		if self:weapon_tweak_data().always_hipfire or self.AKIMBO then
			mul = mul * ((tweak_data.weapon.stat_info.hipfire_only_spread_increase or 1) * ( (multi_ray and 0.133) or 1))
		end

		if self:second_sight_spread_mult() then
			mul = mul * (self:second_sight_spread_mult() / ((multi_ray and (tweak_data.weapon.stat_info.shotgun_spread_increase * 3.33)) or 1) )
		end

		if multi_ray then
			mul = mul * tweak_data.weapon.stat_info.shotgun_spread_increase_ads or 1
			
			for _, category in ipairs(self._tweak_categories) do
				local multishot_spread = tweak_data[category] and tweak_data[category].ads_multishot_spread_mult or 1
				mul = mul * multishot_spread
			end
		end

		if not is_moving then
			for _, category in ipairs(self._tweak_categories) do
				local stationary_spread = tweak_data[category] and tweak_data[category].ads_stationary_spread_mult or 1
				mul = mul * stationary_spread
			end
			if not is_tacstance then
				for _, category in ipairs(self:categories()) do
					mul = mul * pm:upgrade_value(category, "stationary_steelsight_accuracy_inc", 1)
				end
			end
		end

		if not is_tacstance then
			for _, category in ipairs(self:categories()) do
				mul = mul * pm:upgrade_value(category, "steelsight_accuracy_inc", 1)
			end
		end
	else
		--Multi-pellet spread increase.
		if multi_ray then
			mul = mul * tweak_data.weapon.stat_info.shotgun_spread_increase or 1
		end
		for _, category in ipairs(self:categories()) do
			mul = mul * pm:upgrade_value(category, "hip_fire_spread_multiplier", 1)
		end
	end

	return mul
end

function NewRaycastWeaponBase:second_sight_steelsight_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_ads then
			return self._pointshoot_ads
		end
	end

	return 1
end

function NewRaycastWeaponBase:second_sight_spread_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_spread then
			return self._pointshoot_spread
		end
	end

	return false
end

function NewRaycastWeaponBase:second_sight_hip_spread_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_hip_spread then
			return self._pointshoot_hip_spread
		end
	end

	return false
end

function NewRaycastWeaponBase:second_sight_strafe()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_strafe then
			return self._pointshoot_strafe
		end
	end

	return false
end

function NewRaycastWeaponBase:second_sight_falloff_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_falloff then
			return self._pointshoot_falloff
		end
	end

	return false
end
function NewRaycastWeaponBase:second_sight_falloff_start_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_falloff_start then
			return self._pointshoot_falloff_start
		end
	end

	return false
end
function NewRaycastWeaponBase:second_sight_falloff_end_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_falloff_end then
			return self._pointshoot_falloff_end
		end
	end

	return false
end

function NewRaycastWeaponBase:second_sight_damage_min_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_damage_min then
			return self._pointshoot_damage_min
		end
	end

	return false
end

function NewRaycastWeaponBase:second_sight_rof_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_rof then
			return self._pointshoot_rof
		end
	end

	return false
end

function NewRaycastWeaponBase:second_sight_recoil_mult()
	local second_sight = self:get_active_second_sight()

	if second_sight then
		local part_stats = tweak_data.weapon.factory.parts[second_sight.part_id].custom_stats

		if part_stats and part_stats.pointshoot_recoil then
			return self._pointshoot_recoil
		end
	end

	return false
end

function NewRaycastWeaponBase:_refresh_second_sight_extra_list()
	local second_sight_extras = managers.weapon_factory:get_parts_from_weapon_by_type_or_perk("second_sight_extra", self._factory_id, self._blueprint)

	table.sort(second_sight_extras, function (a, b)
		return b < a
	end)

	self._second_sight_extras = {}

	for _, part_id in ipairs(second_sight_extras) do
		table.insert(self._second_sight_extras, {
			part_id = part_id,
			unit = self._parts and self._parts[part_id] and self._parts[part_id].unit
		})
	end
end

Hooks:PostHook(NewRaycastWeaponBase, "_refresh_second_sight_list", "resmod_second_sight_extra_list", function(self)
	self:_refresh_second_sight_extra_list()
end)

Hooks:PostHook(NewRaycastWeaponBase, "set_second_sight_on", "resmod_second_sight_extra_on", function(self, second_sight_on, ignore_enable, second_sights, current_state)
	local second_sight_extra = nil
	for i, data in ipairs(self._second_sight_extras) do
		second_sight_extra = data

		if second_sight_extra and alive(second_sight_extra.unit) then
			second_sight_extra.unit:base():set_state(self._second_sight_on == i, self._sound_fire, current_state)
		end
	end
end)

--[[
local _orig_fire_rate_multiplier = NewRaycastWeaponBase.fire_rate_multiplier
function NewRaycastWeaponBase:fire_rate_multiplier(...)
	local result = _orig_fire_rate_multiplier(self, ...)

	local second_sight_rof_mult = self.second_sight_rof_mult and self:second_sight_rof_mult()
	if second_sight_rof_mult then
		result = result * second_sight_rof_mult
	end

	return result
end

local _orig_recoil_multiplier = NewRaycastWeaponBase.recoil_multiplier
function NewRaycastWeaponBase:recoil_multiplier(...)
	local result = _orig_recoil_multiplier(self, ...)

	local second_sight_recoil_mult = self.second_sight_recoil_mult and self:second_sight_recoil_mult()
	if second_sight_recoil_mult then
		result = result * second_sight_recoil_mult
	end

	return result
end
--]]

--Multiplier for movement penalty to spread.
function NewRaycastWeaponBase:moving_spread_penalty_reduction()
	local spread_multiplier = 1
	for _, category in ipairs(self:categories()) do
		spread_multiplier = spread_multiplier * managers.player:upgrade_value(category, "move_spread_multiplier", 1)
	end
	return spread_multiplier
end

--Simpler spread function. Determines area bullets can hit then converts that to the max degrees by which the rays can fire.
function NewRaycastWeaponBase:_get_spread(user_unit)
	local current_state = user_unit:movement()._current_state
	local is_steelsight = current_state and current_state:is_full_steelsight()
	local is_hipfire = current_state and not current_state:is_full_steelsight()
	local is_tacstance = self:second_sight_spread_mult()
	local t = self._unit:timer():time()
	local last_move_t = current_state and current_state._last_move_t or -10
	local is_moving = self._move_decay and last_move_t and (last_move_t + self._move_decay) > t or false --(current_state._moving or current_state:in_air())
	local is_bipod = current_state and current_state:_is_using_bipod()
	local is_ads_hipfire = is_steelsight and (self:weapon_tweak_data().always_hipfire or is_tacstance)

	if not current_state then
		return 0, 0
	end
	
	--Get spread area from accuracy stat.
	local spread_area = math.max(self._spread + 
		managers.blackmarket:accuracy_index_addend(self._name_id, self:categories(), self._silencer, current_state, self:fire_mode(), self._blueprint) * tweak_data.weapon.stat_info.spread_per_accuracy, 0.05)
	
	--Moving penalty to spread, based on stability stat- added to total area.
	if not is_bipod and is_moving then
		--Get spread area from stability stat.
		local moving_spread = math.max(self._spread_moving + managers.blackmarket:stability_index_addend(self:categories(), self._silencer) * tweak_data.weapon.stat_info.spread_per_stability, 0)
		local moving_spread_mult = 1
		for _, category in ipairs(self._tweak_categories) do
			local ms_mult = tweak_data[category] and tweak_data[category].moving_spread_mult or 1
			moving_spread_mult = moving_spread_mult * ms_mult
		end
		moving_spread = moving_spread * moving_spread_mult
		if is_steelsight and not is_ads_hipfire then
			local ads_moving_spread_mult = 1
			if self._ads_moving_mult then
				ads_moving_spread_mult = ads_moving_spread_mult * self._ads_moving_mult
			end
			for _, category in ipairs(self._tweak_categories) do
				local adsms_mult = tweak_data[category] and tweak_data[category].ads_moving_spread_mult or 1
				ads_moving_spread_mult = ads_moving_spread_mult * adsms_mult
			end
			moving_spread = moving_spread * ads_moving_spread_mult
		else
			local hipfire_moving_spread_mult = 1
			for _, category in ipairs(self._tweak_categories) do
				local hms_mult = tweak_data[category] and tweak_data[category].hipfire_moving_spread_mult or 1
				hipfire_moving_spread_mult = hipfire_moving_spread_mult * hms_mult
			end
			moving_spread = moving_spread * hipfire_moving_spread_mult
		end
		--Add moving spread penalty reduction.
		moving_spread = moving_spread * self:moving_spread_penalty_reduction()
		spread_area = spread_area + moving_spread
	end

	if is_bipod then
		spread_area = spread_area / 2
	end

	--Apply skill and stance multipliers to overall spread area.
	local multiplier = tweak_data.weapon.stat_info.stance_spread_mults[current_state:get_movement_state()] * self:conditional_accuracy_multiplier(current_state, is_moving)

	if is_ads_hipfire or not is_steelsight then
		local hipfire_spread_mult = (is_ads_hipfire and not is_tacstance and 0.7) or 1
		for _, category in ipairs(self._tweak_categories) do
			local hip_mult = tweak_data[category] and tweak_data[category].hipfire_spread_mult or 1
			hipfire_spread_mult = hipfire_spread_mult * hip_mult
		end
		if self._hipfire_mult then
			hipfire_spread_mult = hipfire_spread_mult * self._hipfire_mult
		end
		local second_sight_hip_spread_mult = self.second_sight_hip_spread_mult and self:second_sight_hip_spread_mult()
		if second_sight_hip_spread_mult then
			hipfire_spread_mult = hipfire_spread_mult * second_sight_hip_spread_mult
		end
		multiplier = multiplier * hipfire_spread_mult

	end

	if self:in_burst_mode() then
		if self._burst_fire_ads_spread_multiplier and is_steelsight then
			multiplier = multiplier * self._burst_fire_ads_spread_multiplier
		else
			multiplier = multiplier * (self._burst_fire_spread_multiplier or 1)
		end
	end

	if self._alt_fire_active and self._alt_fire_data then
		multiplier = multiplier * (self._alt_fire_data.spread_mul or 1)
	end

	local spread_multiplier = 1
	for _, category in ipairs(self._tweak_categories) do
		local spread_mult = tweak_data[category] and tweak_data[category].spread_mult or 1
		spread_multiplier = spread_multiplier * spread_mult
	end
	multiplier = multiplier * spread_multiplier

	spread_area = spread_area * multiplier

	--Convert spread area to degrees.
	local spread_x = math.sqrt((spread_area)/math.pi)
	local spread_y = spread_x
	
	if self._spread_multiplier then
		spread_x = spread_x * self._spread_multiplier[1]
		spread_y = spread_y * self._spread_multiplier[2]
	end

	local min_spread = is_hipfire and 1 or 0
	for _, category in ipairs(self._tweak_categories) do
		local min_spread_mult = tweak_data[category] and tweak_data[category].min_spread_mult or 1
		min_spread = min_spread * min_spread_mult
	end
	spread_x = math.max(min_spread, spread_x)
	spread_y = math.max(min_spread, spread_y)

	return spread_x, spread_y
end

function NewRaycastWeaponBase:recoil_wait()
	local tweak_is_auto = tweak_data.weapon[self._name_id].FIRE_MODE == "auto"
	local weapon_is_auto = self:fire_mode() == "auto"


	if self._is_controller or not tweak_is_auto then
		return nil
	end

	local multiplier = tweak_is_auto == weapon_is_auto and 1 or 2

	return self:weapon_fire_rate() * multiplier
end

local start_shooting_original = NewRaycastWeaponBase.start_shooting
local stop_shooting_original = NewRaycastWeaponBase.stop_shooting
local _fire_sound_original = NewRaycastWeaponBase._fire_sound
local trigger_held_original = NewRaycastWeaponBase.trigger_held
local trigger_pressed_original = NewRaycastWeaponBase.trigger_pressed
local recoil_multiplier_original = NewRaycastWeaponBase.recoil_multiplier

NewRaycastWeaponBase._SPIN_UP_T = 0.5
NewRaycastWeaponBase._SPIN_DOWN_T = 0.75

function NewRaycastWeaponBase:start_shooting(...)
	start_shooting_original(self, ...)
	if self._name_id == "m134" or self._name_id == "shuno" or self:weapon_tweak_data().spin_up_t then
		self:_start_spin()
	end
end

function NewRaycastWeaponBase:stop_shooting(...)
	stop_shooting_original(self, ...)

	self._shooting = nil
	self._shots_fired = 0
	if not self._fire_rate_init_reset_t then
		self._shots_fired_init = 0
	end
	if self._fire_rate_init_progress then
		self._fire_rate_init_progress = nil
		self._next_fire_allowed = self._next_fire_allowed + self._fire_rate_init_delay
	end

	if self._name_id == "m134" or self._name_id == "shuno" or self:weapon_tweak_data().spin_up_t then
		self._vulcan_firing = nil
		self:_stop_spin()
	end
end

function NewRaycastWeaponBase:_fire_sound(...)
	if (self._name_id ~= "m134" and self._name_id ~= "shuno" and not self:weapon_tweak_data().spin_up_t) or self._vulcan_firing then
		if self._fire_mode == ids_volley and self:weapon_tweak_data().sounds.fire_volley then
			self:play_tweak_data_sound("fire_volley", "fire")
			return
		end
		NewRaycastWeaponBase.super._fire_sound(self)
	end
end

function NewRaycastWeaponBase:trigger_held(...)
	local t = self._unit:timer():time()
	if self._fire_rate_init_reset_t and self._fire_rate_init_reset_t < t then
		self._shots_fired_init = 0
	end
	if self._name_id == "m134" or self._name_id == "shuno" or self:weapon_tweak_data().spin_up_t then
		self:update_spin()
		local fired
		local spin_up_t = (self:weapon_tweak_data().spin_up_t or NewRaycastWeaponBase._SPIN_UP_T) * self._spin_up_mult
		local spin_up_semi = self._fire_mode == ids_single and self:weapon_tweak_data().spin_up_semi
		if self._next_fire_allowed <= self._unit:timer():time() then
			if not self:weapon_tweak_data().spin_up_shoot then
				self._next_fire_allowed = self._next_fire_allowed + (tweak_data.weapon[self._name_id].fire_mode_data and tweak_data.weapon[self._name_id].fire_mode_data.fire_rate or 0) / self:fire_rate_multiplier()
			end
			if self._spin_done then
				if self:weapon_tweak_data().spin_up_shoot then
					self._next_fire_allowed = self._next_fire_allowed + (tweak_data.weapon[self._name_id].fire_mode_data and tweak_data.weapon[self._name_id].fire_mode_data.fire_rate or 0) / self:fire_rate_multiplier() + ((not spin_up_semi and not self:weapon_tweak_data().ads_spool and not self._vulcan_firing and spin_up_t) or 0)
				end
				fired = self:fire(...)
				if fired then
					if not self._vulcan_firing then
						self._vulcan_firing = true
						self:_fire_sound()
					end
				end
			end
		end
		return fired
	end
	return trigger_held_original(self, ...)
end


function NewRaycastWeaponBase:recoil_multiplier(...)
	local mult = recoil_multiplier_original(self, ...)

	mult = mult * (self._volley_recoil_mul or 1)
	self._volley_recoil_mul = nil

	if self:in_burst_mode() then
		if self._burst_fire_last_recoil_multiplier and (self._burst_rounds_remaining and self._burst_rounds_remaining < 1) then
			mult = mult * self._burst_fire_last_recoil_multiplier
		elseif self._burst_fire_recoil_multiplier then
			mult = mult * self._burst_fire_recoil_multiplier
		--elseif self._delayed_burst_recoil and self:burst_rounds_remaining() then
			--mult = 0
		end
	end
	
	if (self._fire_mode == ids_auto or self:weapon_tweak_data().spin_up_semi) and (self._name_id == "m134" or self._name_id == "shuno" or self:weapon_tweak_data().spin_up_t) and not self._vulcan_firing then
		return 0
	end

	local user_unit = self._setup and self._setup.user_unit
	local current_state = alive(user_unit) and user_unit:movement() and user_unit:movement()._current_state
	if current_state then
		local t = self._unit:timer():time()
		local last_move_t = current_state and current_state._last_move_t or -10
		local is_moving = self._move_decay and last_move_t and (last_move_t + self._move_decay) > t or false --(current_state._moving or current_state:in_air())
		local full_steelsight = current_state:is_full_steelsight()
		if full_steelsight then
			local weapon_stats = tweak_data.weapon.stats
			local base_zoom = weapon_stats.zoom and weapon_stats.zoom[1]
			local current_zoom = self:zoom()
			local percent_reduction = self:weapon_tweak_data().zoom_recoil_reduction or 0.1
			local zoom_mult = base_zoom and current_zoom and (1 + (((base_zoom / current_zoom) - 1) * percent_reduction))
			if zoom_mult then
				mult = mult / zoom_mult
			end
			if is_moving then
				for _, category in ipairs(self._tweak_categories) do
					local ads_moving_recoil = tweak_data[category] and tweak_data[category].ads_moving_recoil or 1
					mult = mult * ads_moving_recoil
				end
			end
		end
	end

	if self._fire_rate_init_count and self:fire_mode() ~= "single" and not self:in_burst_mode() then
		if (self._fire_rate_init_count > self._shots_fired) then
			mult = mult * self._fire_rate_init_recoil_mult
		end
	end

	if self.second_sight_recoil_mult then
		local second_sight_recoil_mult = self:second_sight_recoil_mult()
		if second_sight_recoil_mult then
			mult = mult * second_sight_recoil_mult
		end
	end

	mult = mult * ((self._is_controller and 0.7) or 1)

	return mult
end

local on_enabled_original = NewRaycastWeaponBase.on_enabled
function NewRaycastWeaponBase:on_enabled(...)
	self:cancel_burst()
	return on_enabled_original(self, ...)
end

local on_disabled_original = NewRaycastWeaponBase.on_disabled
function NewRaycastWeaponBase:on_disabled(...)
	self:cancel_burst()
	return on_disabled_original(self, ...)
end

local start_reload_original = NewRaycastWeaponBase.start_reload
function NewRaycastWeaponBase:start_reload(...)
	self:cancel_burst()
	return start_reload_original(self, ...)
end

function NewRaycastWeaponBase:_start_spin()
	if not self._spinning then
		local t = self._unit:timer():time()
		local spin_up_t = (self:weapon_tweak_data().spin_up_t or NewRaycastWeaponBase._SPIN_UP_T) * self._spin_up_mult
		local spin_down_t = (self:weapon_tweak_data().spin_down_t or NewRaycastWeaponBase._SPIN_DOWN_T) * self._spin_up_mult
		self._spin_up_start_t = t
		if self._spin_down_start_t and spin_down_t > 0 then
			self._spin_up_start_t = self._spin_up_start_t - (1 - math.clamp(t - self._spin_down_start_t, 0 , spin_down_t) / spin_down_t) * spin_up_t
		end
		if self:weapon_tweak_data().sounds.spin_start and (self._fire_mode == ids_auto or self:weapon_tweak_data().spin_up_semi) then
			self:play_tweak_data_sound("spin_start")
		end
		self._next_spin_animation_t = t
		self._spinning = true
		self._spin_down_start_t = nil
	end
end

function NewRaycastWeaponBase:_stop_spin()
	if self._spinning and not self._in_steelsight and (not self:in_burst_mode() or self:in_burst_mode() and (self._burst_rounds_remaining and self._burst_rounds_remaining < 1)) then
		local t = self._unit:timer():time()
		local spin_up_t = (self:weapon_tweak_data().spin_up_t or NewRaycastWeaponBase._SPIN_UP_T) * self._spin_up_mult
		local spin_down_t = (self:weapon_tweak_data().spin_down_t or NewRaycastWeaponBase._SPIN_DOWN_T) * self._spin_up_mult
		self._spin_down_start_t = t
		if self._spin_up_start_t and spin_up_t > 0 then
			self._spin_down_start_t = self._spin_down_start_t - (1 - math.clamp(t - self._spin_up_start_t, 0 , spin_up_t) / spin_up_t) * spin_down_t
		end
		if self:weapon_tweak_data().sounds.spin_end then
			self:play_tweak_data_sound("spin_end")
		end
		self._spinning = nil
		self._spin_up_start_t = nil
		self._spin_done = nil
		self._vulcan_firing = nil
	end
end

function NewRaycastWeaponBase:update_spin()
	if not self._spin_done and self._spinning then
		local t = self._unit:timer():time()
		local spin_up_t = (self:weapon_tweak_data().spin_up_t or NewRaycastWeaponBase._SPIN_UP_T) * self._spin_up_mult
		if (self._spin_up_start_t + spin_up_t) <= t then
			self._spin_done = true
			self._spin_up_start_t = nil
			self._spin_down_start_t = nil
		end
	end
	
	if self._spinning and not self._vulcan_firing then
		local t = self._unit:timer():time()
		if t >= self._next_spin_animation_t and self:weapon_tweak_data().spin_up_anims then
			self:tweak_data_anim_play("fire", self:fire_rate_multiplier())
			self._next_spin_animation_t = t + (tweak_data.weapon[self._name_id].fire_mode_data and tweak_data.weapon[self._name_id].fire_mode_data.fire_rate or 0) / self:fire_rate_multiplier()
		end
	end
end

function NewRaycastWeaponBase:vulcan_enter_steelsight()
	self._in_steelsight = true
	self:_start_spin()
end

function NewRaycastWeaponBase:vulcan_exit_steelsight()
	self._in_steelsight = nil
	if not self._vulcan_firing then
		self:_stop_spin()
	end
end

--Returns the weapon's current concealment stat.
function NewRaycastWeaponBase:get_concealment()
	local result = self._current_concealment or self._concealment
	if result then
		return math.max(result, 0)
	else
		log("Error: Missing concealment information")
		return 20
	end
	
end

--Le stats face
function NewRaycastWeaponBase:old_update_stats_values(disallow_replenish, ammo_data)
	self:_default_damage_falloff()
	self:_check_sound_switch()

	self._silencer = managers.weapon_factory:has_perk("silencer", self._factory_id, self._blueprint)
	local weapon_perks = managers.weapon_factory:get_perks(self._factory_id, self._blueprint) or {}

	if weapon_perks.fire_mode_auto then
		self._locked_fire_mode = ids_auto
	elseif weapon_perks.fire_mode_single then
		self._locked_fire_mode = ids_single
	elseif weapon_perks.fire_mode_burst then
		self._locked_fire_mode = ids_burst
	elseif weapon_perks.fire_mode_volley then
		self._locked_fire_mode = ids_volley
	else
		self._locked_fire_mode = nil
	end

	self._fire_mode = self._locked_fire_mode or self:get_recorded_fire_mode(self:_weapon_tweak_data_id()) or Idstring(self:weapon_tweak_data().FIRE_MODE or "single")
	self._ammo_data = ammo_data or managers.weapon_factory:get_ammo_data_from_weapon(self._factory_id, self._blueprint) or {}
	self._can_shoot_through_shield = tweak_data.weapon[self._name_id].can_shoot_through_shield
	self._can_shoot_through_enemy = tweak_data.weapon[self._name_id].can_shoot_through_enemy
	self._can_shoot_through_wall = tweak_data.weapon[self._name_id].can_shoot_through_wall
	self._armor_piercing_chance = self:weapon_tweak_data().armor_piercing_chance or 0
	local primary_category = self:weapon_tweak_data().categories and self:weapon_tweak_data().categories[1]
	self._movement_penalty = tweak_data.upgrades.weapon_movement_penalty[primary_category] or 1
	self._burst_count = self:weapon_tweak_data().BURST_COUNT or 3
	local fire_mode_data = self:weapon_tweak_data().fire_mode_data or {}
	local volley_fire_mode = fire_mode_data.volley

	if volley_fire_mode then
		self._volley_spread_mul = volley_fire_mode.spread_mul or 1
		self._volley_damage_mul = volley_fire_mode.damage_mul or 1
		self._volley_ammo_usage = volley_fire_mode.ammo_usage or 1
		self._volley_rays = volley_fire_mode.rays or 1
	end

	local custom_stats = managers.weapon_factory:get_custom_stats_from_weapon(self._factory_id, self._blueprint)
	local part_data = nil
	local is_underbarrel = self.is_underbarrel and self:is_underbarrel()
	local weap_factory_parts = tweak_data.weapon.factory.parts

	for part_id, stats in pairs(custom_stats) do
		part_data = weap_factory_parts[part_id]
		local can_apply = true

		if part_data.type == "underbarrel_ammo" then
			can_apply = is_underbarrel
		elseif part_data.type == "ammo" then
			can_apply = not is_underbarrel
		end

		if can_apply then
			if stats.movement_speed then
				self._movement_penalty = self._movement_penalty * stats.movement_speed
			end

			if part_data.type ~= "ammo" and part_data.type ~= "underbarrel_ammo" then
				if stats.ammo_pickup_min_mul then
					self._ammo_data.ammo_pickup_min_mul = self._ammo_data.ammo_pickup_min_mul and self._ammo_data.ammo_pickup_min_mul * stats.ammo_pickup_min_mul or stats.ammo_pickup_min_mul
				end

				if stats.ammo_pickup_max_mul then
					self._ammo_data.ammo_pickup_max_mul = self._ammo_data.ammo_pickup_max_mul and self._ammo_data.ammo_pickup_max_mul * stats.ammo_pickup_max_mul or stats.ammo_pickup_max_mul
				end

				if stats.ammo_offset then
					self._ammo_data.ammo_offset = (self._ammo_data.ammo_offset or 0) + stats.ammo_offset
				end

				if stats.fire_rate_multiplier then
					self._ammo_data.fire_rate_multiplier = (self._ammo_data.fire_rate_multiplier or 0) + stats.fire_rate_multiplier - 1
				end
			end

			if stats.burst_count then
				self._burst_count = stats.burst_count
			end

			if stats.volley_spread_mul then
				self._volley_spread_mul = stats.volley_spread_mul
			end

			if stats.volley_damage_mul then
				self._volley_damage_mul = stats.volley_damage_mul
			end

			if stats.volley_ammo_usage then
				self._volley_ammo_usage = stats.volley_ammo_usage
			end

			if stats.volley_rays then
				self._volley_rays = stats.volley_rays
			end

			if stats.launch_speed_mul then
				self._launch_speed_mul = stats.launch_speed_mul
			end

			if stats.charge_speed_mul then
				self._charge_speed_mul = stats.charge_speed_mul
			end
		end
	end

	local damage_falloff = {
		optimal_distance = self._optimal_distance,
		optimal_range = self._optimal_range,
		near_falloff = self._near_falloff,
		far_falloff = self._far_falloff,
		near_multiplier = self._near_multiplier,
		far_multiplier = self._far_multiplier
	}

	managers.blackmarket:modify_damage_falloff(damage_falloff, custom_stats)

	self._optimal_distance = damage_falloff.optimal_distance
	self._optimal_range = damage_falloff.optimal_range
	self._near_falloff = damage_falloff.near_falloff
	self._far_falloff = damage_falloff.far_falloff
	self._near_multiplier = damage_falloff.near_multiplier
	self._far_multiplier = damage_falloff.far_multiplier

	if self._ammo_data then
		if self._ammo_data.can_shoot_through_shield ~= nil then
			self._can_shoot_through_shield = self._ammo_data.can_shoot_through_shield
		end

		if self._ammo_data.can_shoot_through_enemy ~= nil then
			self._can_shoot_through_enemy = self._ammo_data.can_shoot_through_enemy
		end

		if self._ammo_data.can_shoot_through_wall ~= nil then
			self._can_shoot_through_wall = self._ammo_data.can_shoot_through_wall
		end

		if self._ammo_data.bullet_class ~= nil then
			self._bullet_class = CoreSerialize.string_to_classtable(self._ammo_data.bullet_class)
			self._bullet_slotmask = self._bullet_class:bullet_slotmask()

			if self._setup and self._setup.user_unit == managers.player:player_unit() then
				self._bullet_slotmask = managers.mutators:modify_value("RaycastWeaponBase:modify_slot_mask", self._bullet_slotmask)
			end

			self._blank_slotmask = self._bullet_class:blank_slotmask()
		end

		if self._ammo_data.armor_piercing_add ~= nil then
			self._armor_piercing_chance = math.clamp(self._armor_piercing_chance + self._ammo_data.armor_piercing_add, 0, 1)
		end

		if self._ammo_data.armor_piercing_mul ~= nil then
			self._armor_piercing_chance = math.clamp(self._armor_piercing_chance * self._ammo_data.armor_piercing_mul, 0, 1)
		end
	end

	if self._silencer then
		self._muzzle_effect = Idstring(self:weapon_tweak_data().muzzleflash_silenced or "effects/payday2/particles/weapons/9mm_auto_silence_fps")
	elseif self._ammo_data and self._ammo_data.muzzleflash ~= nil then
		self._muzzle_effect = Idstring(self._ammo_data.muzzleflash)
	else
		self._muzzle_effect = Idstring(self:weapon_tweak_data().muzzleflash or "effects/particles/test/muzzleflash_maingun")
	end

	self._muzzle_effect_table = {
		effect = self._muzzle_effect,
		parent = self._obj_fire,
		force_synch = self._muzzle_effect_table.force_synch or false
	}

	if self._ammo_data and self._ammo_data.trail_effect ~= nil then
		self._trail_effect = Idstring(self._ammo_data.trail_effect)
	else
		self._trail_effect = self:weapon_tweak_data().trail_effect and Idstring(self:weapon_tweak_data().trail_effect) or self.TRAIL_EFFECT
		self._trail_effect_npc = self:weapon_tweak_data().trail_effect_npc and Idstring(self:weapon_tweak_data().trail_effect_npc) or nil
	end

	self._trail_effect_table = {
		effect = self._trail_effect,
		position = Vector3(),
		normal = Vector3()
	}
	local base_stats = self:weapon_tweak_data().stats

	if not base_stats then
		return
	end

	local parts_stats = managers.weapon_factory:get_stats(self._factory_id, self._blueprint)
	local stats = deep_clone(base_stats)
	local stats_tweak_data = tweak_data.weapon.stats
	local modifier_stats = self:weapon_tweak_data().stats_modifiers
	local bonus_stats = self._cosmetics_bonus and self._cosmetics_data and self._cosmetics_data.bonus and tweak_data.economy.bonuses[self._cosmetics_data.bonus] and tweak_data.economy.bonuses[self._cosmetics_data.bonus].stats or {}

	if managers.job:is_current_job_competitive() or managers.weapon_factory:has_perk("bonus", self._factory_id, self._blueprint) then
		bonus_stats = {}
	end

	if self.modify_base_stats then
		self:modify_base_stats(stats)
	end

	if stats.zoom then
		stats.zoom = math.min(stats.zoom + managers.player:upgrade_value(primary_category, "zoom_increase", 0), #stats_tweak_data.zoom)
	end

	self._part_stats_uncapped = {}

	for stat, _ in pairs(stats) do
		if stats[stat] < 1 or stats[stat] > #stats_tweak_data[stat] then
			Application:error("[NewRaycastWeaponBase] Base weapon stat is out of bound!", "stat: " .. stat, "index: " .. stats[stat], "max_index: " .. #stats_tweak_data[stat], "This stat will be clamped!")
		end

		if parts_stats[stat] then
			stats[stat] = stats[stat] + parts_stats[stat]
			self._part_stats_uncapped[stat] = (self._part_stats_uncapped[stat] or 0) + parts_stats[stat]
		end

		if bonus_stats[stat] then
			stats[stat] = stats[stat] + bonus_stats[stat]
		end

		stats[stat] = math_clamp(stats[stat], 1, #stats_tweak_data[stat])
	end

	self._current_stats_indices = stats
	self._current_stats = {}

	for stat, i in pairs(stats) do
		self._current_stats[stat] = stats_tweak_data[stat] and stats_tweak_data[stat][i] or 1

		if modifier_stats and modifier_stats[stat] then
			self._current_stats[stat] = self._current_stats[stat] * modifier_stats[stat]
		end
	end

	self._current_stats.alert_size = stats_tweak_data.alert_size[math_clamp(stats.alert_size, 1, #stats_tweak_data.alert_size)]

	if modifier_stats and modifier_stats.alert_size then
		self._current_stats.alert_size = self._current_stats.alert_size * modifier_stats.alert_size
	end

	if stats.concealment then
		stats.suspicion = math.clamp(#stats_tweak_data.concealment - base_stats.concealment - (parts_stats.concealment or 0), 1, #stats_tweak_data.concealment)
		self._current_stats.suspicion = stats_tweak_data.concealment[stats.suspicion]
	end

	if parts_stats and parts_stats.spread_multi then
		self._current_stats.spread_multi = parts_stats.spread_multi
	end

	self._alert_size = self._current_stats.alert_size or self._alert_size
	self._suppression = self._current_stats.suppression or self._suppression
	self._zoom = self._current_stats.zoom or self._zoom
	self._spread = self._current_stats.spread or self._spread
	self._recoil = self._current_stats.recoil or self._recoil
	self._spread_moving = self._current_stats.spread_moving or self._spread_moving
	self._extra_ammo = self._current_stats.extra_ammo or self._extra_ammo
	self._total_ammo_mod = self._current_stats.total_ammo_mod or self._total_ammo_mod

	if self._ammo_data.ammo_offset then
		self._extra_ammo = self._extra_ammo + self._ammo_data.ammo_offset
	end

	self._reload = self._current_stats.reload or self._reload
	self._spread_multiplier = self._current_stats.spread_multi or self._spread_multiplier
	self._scopes = managers.weapon_factory:get_parts_from_weapon_by_type_or_perk("scope", self._factory_id, self._blueprint)
	self._has_range_distance_scope = self:_chk_has_range_distance_scope()
	self._unit_health_displays = managers.weapon_factory:get_parts_from_weapon_by_type_or_perk("display_unit_health", self._factory_id, self._blueprint)
	self._has_unit_health_display = self:_chk_has_unit_health_display()
	self._can_highlight_with_perk = managers.weapon_factory:has_perk("highlight", self._factory_id, self._blueprint)
	self._can_highlight_with_skill = managers.player:has_category_upgrade("weapon", "steelsight_highlight_specials")
	self._can_highlight = self._can_highlight_with_perk or self._can_highlight_with_skill

	self:_check_reticle_obj()

	if not disallow_replenish then
		self:replenish()
	end
end

function NewRaycastWeaponBase:_update_stats_values(disallow_replenish, ammo_data)
	self:old_update_stats_values(disallow_replenish, ammo_data)

	self._fire_rate_multiplier = self:is_npc() and 1 or managers.blackmarket:fire_rate_multiplier(self._name_id, self:categories(), self._silencer, nil, current_state, self._blueprint)
	--Use stability stat to get the moving accuracy penalty.
	--Moved this from "RaycastWeaponBase:setup" as it lead to funky lingering stats in intances of mid-heist loadout changes
	if not self:is_npc() then
		if self._current_stats_indices and self._current_stats_indices.recoil then
			self._spread_moving = tweak_data.weapon.stats.spread_moving[self._current_stats_indices.recoil] or 0
		else --Fallback method for getting stability moving accuracy penalty, in case the indices somehow don't get set.
			log("Using fallback")
			local moving_spread_index = 0
			local recoil_table = tweak_data.weapon.stats.recoil
			for i = 0, 100, 1 do
				if recoil_table[i] == self._recoil then
					moving_spread_index = i
					break
				end
			end
			self._spread_moving = tweak_data.weapon.stats.spread_moving[moving_spread_index] or 0
		end
	end

	local recoil_values = self:weapon_tweak_data().recoil_values
	self._recoil_speed = recoil_values and recoil_values[1] or { 90, 60 }
	self._recoil_center_speed = math.clamp(recoil_values and recoil_values[2] or 7.5, 1, 10)
	self._recoil_recovery = math.clamp(recoil_values and recoil_values[3] or 0.5, 0, 1)

	self._reload_speed_mult = self:weapon_tweak_data().reload_speed_multiplier or 1
	self._reload_not_empty_speed_multiplier = self._reload_not_empty_speed_multiplier or self:weapon_tweak_data().reload_not_empty_speed_multiplier or 1
	self._ads_speed_mult = self._ads_speed_mult or  1
	self._flame_max_range = self:weapon_tweak_data().flame_max_range or nil
	self._autograph_multiplier = self:weapon_tweak_data().autograph_multiplier or nil
	self._ignore_reload_objects = self:weapon_tweak_data().ignore_reload_objects or nil
	self._ammo_data = ammo_data or managers.weapon_factory:get_ammo_data_from_weapon(self._factory_id, self._blueprint) or {}
	
	self._deploy_anim_override = self:weapon_tweak_data().deploy_anim_override or nil
	self._deploy_ads_stance_mod = self:weapon_tweak_data().deploy_ads_stance_mod or {translation = Vector3(0, 0, 0), rotation = Rotation(0, 0, 0)}		
		
	self._can_shoot_through_enemy_unlim = self._can_shoot_through_enemy_unlim or self:weapon_tweak_data().can_shoot_through_enemy_unlim or false --No limit enemy piercing
	self._can_shoot_through_titan_shield = self._can_shoot_through_titan_shield or self:weapon_tweak_data().can_shoot_through_titan_shield or false --implementing Heavy AP
	self._shield_pierce_damage_mult = self:weapon_tweak_data().shield_pierce_damage_mult or 0.5
	self._ammo_ratio = self:weapon_tweak_data().ammo_ratio or 1
	self._kick_pattern = self._kick_pattern or self:weapon_tweak_data().kick_pattern
	self._min_shots_reset = self:weapon_tweak_data().min_shots_reset or 0

	self._warsaw = self:weapon_tweak_data().warsaw
	self._nato = self:weapon_tweak_data().nato
	self._plasma_b = self:weapon_tweak_data().plasma_b
	self._terminator = self:weapon_tweak_data().terminator

	if not self:is_npc() then
		local weapon = {
			factory_id = self._factory_id,
			blueprint = self._blueprint
		}
		self._current_concealment = managers.blackmarket:calculate_weapon_concealment(weapon) + managers.blackmarket:get_silencer_concealment_modifiers(weapon)

		self._burst_rounds_remaining = 0
		self._has_auto = not self._burst_toggle_to_semi and not self._locked_fire_mode and (self:can_toggle_firemode() or self:weapon_tweak_data().FIRE_MODE == "auto")
		self._auto_fire_range_multiplier = self:weapon_tweak_data().AUTO_FIRE_RANGE_MULTIPLIER
		self._single_fire_range_multiplier = self:weapon_tweak_data().SINGLE_FIRE_RANGE_MULTIPLIER
		self._rof_mult_semi = self._rof_mult_semi or self:weapon_tweak_data().SINGLE_FIRE_FIRERATE_MULTIPLIER
		
		self._has_burst_fire = self._has_burst_fire or type(self:weapon_tweak_data().BURST_FIRE) == "table" and self:weapon_tweak_data().BURST_FIRE ~= false
		self._adaptive_burst_size = self._adaptive_burst_size or self:weapon_tweak_data().ADAPTIVE_BURST_SIZE ~= false --deprecated AFAIK; will look into cleaning this up later
		local BURST_DATA = self._has_burst_fire and type(self:weapon_tweak_data().BURST_FIRE) == "table" and self:weapon_tweak_data().BURST_FIRE
		if BURST_DATA then
			self._burst_size = self._burst_size or BURST_DATA.count
			self._burst_fire_rate_multiplier = self._burst_fire_rate_multiplier or BURST_DATA.rof_mult
			self._burst_fire_recoil_multiplier = self._burst_fire_recoil_multiplier or BURST_DATA.recoil_mult
			self._burst_fire_last_recoil_multiplier = self._burst_fire_last_recoil_multiplier or BURST_DATA.last_recoil_mult
			self._burst_fire_spread_multiplier = self._burst_fire_spread_multiplier or BURST_DATA.spread_mult
			self._burst_fire_ads_spread_multiplier = self._burst_fire_ads_spread_multiplier or BURST_DATA.ads_spread_mult
			self._burst_fire_range_multiplier = self._burst_fire_range_multiplier or BURST_DATA.range_mult
			self._burst_ads_toggle = self._burst_ads_toggle or BURST_DATA.ads_toggle --toggle to burst while aiming
			self._burst_hipfire_toggle = self._burst_hipfire_toggle or BURST_DATA.hipfire_toggle --toggle to burstfire while hipfiring
			self._burst_fire_no_ads = self._burst_fire_no_ads or BURST_DATA.no_ads
			self._block_toggle = self._block_toggle or BURST_DATA.block_toggle--blocks toggling between semi-auto and full-auto; does not stop toggling off burst
			self._burst_toggle_to_semi = self._burst_toggle_to_semi or BURST_DATA.toggle_to_semi --forces toggling to semi-auto from burst; only applicable if the base firemode is full-auto
			self._burst_toggle_to_auto = self._burst_toggle_to_auto or BURST_DATA.toggle_to_auto --forces toggling to full-auto from burst; only applicable if the base firemode is semi-auto
			self._burst_delay_alt_calc = self._burst_delay_alt_calc or BURST_DATA.delay_alt_calc --BOOLEAN; changes up how delays are calculated in relation to the burst rof mult
			self._burst_delay = self._burst_delay or BURST_DATA.delay or (self.AKIMBO and 0.1) or 0.12
			self._burst_no_anim = self._burst_no_anim or BURST_DATA.no_anim --only play anims for the last shot in a burst
			self._burst_default = self._burst_default or BURST_DATA.burst_default
			self._lock_burst = self._lock_burst or BURST_DATA.lock
			self._auto_burst = self._auto_burst or BURST_DATA.auto_burst
			self._slamfire = self._slamfire or BURST_DATA.slamfire
		end

		--LEAVE THESE OUTSIDE OF THE 'BURST_DATA' if statement
		if self._burst_fire_rate_multiplier then
			self._burst_fire_rate_multiplier = self._burst_fire_rate_multiplier * 1.05 --to help with frame rounding as to err on the side of "too early" over "too late"
		end
		if self._lock_burst and not self._locked_fire_mode then
			self:_set_burst_mode(true, true)
		end
		
		self._burst_rounds_fired = 0

		self._single_fire_ap_add = self:weapon_tweak_data().SINGLE_FIRE_AP_ADD or 0
	
		self._object_damage_mult = self._object_damage_mult or self:weapon_tweak_data().object_damage_mult or 1
		self._object_damage_mult_exp = self._object_damage_mult or self:weapon_tweak_data().object_damage_mult or 1
		self._object_damage_mult_single_ray = self._object_damage_mult_single_ray or self:weapon_tweak_data().object_damage_mult_single_ray or 1
		self._object_damage_mult_volley = self._object_damage_mult_volley or self:weapon_tweak_data().object_damage_mult_volley or 1
		self._fire_rate_init_count = self._fire_rate_init_count or self:weapon_tweak_data().fire_rate_init_count or nil
		self._fire_rate_init_count_mag = self._fire_rate_init_count_mag or self:weapon_tweak_data().fire_rate_init_count_mag or nil
		self._fire_rate_init_mult = self._fire_rate_init_mult or self:weapon_tweak_data().fire_rate_init_mult and self:weapon_tweak_data().fire_rate_init_mult * 1.01 or 1
		self._fire_rate_init_delay = self._fire_rate_init_delay or self:weapon_tweak_data().fire_rate_init_delay or self._burst_delay or 0
		self._fire_rate_init_reset = self._fire_rate_init_reset or self:weapon_tweak_data().fire_rate_init_reset or 0
		self._fire_rate_init_reset_t = self._fire_rate_init_reset ~= 0 and 0
		self._fire_rate_init_recoil_mult = self._fire_rate_init_recoil_mult or self:weapon_tweak_data().fire_rate_init_recoil_mult or 1
		self._fire_rate_init_ramp_up = self._fire_rate_init_ramp_up or self:weapon_tweak_data().fire_rate_init_ramp_up or nil
		self._fire_rate_init_ramp_up_add = 0

		self._tactical_reload = self._tactical_reload or self:weapon_tweak_data().tactical_reload

		self._tweak_categories = self._tweak_categories or self:weapon_tweak_data().categories --exclusively for the use of category based movement, spread and recoil modifiers set in "tweakdata.lua"; zero plans of expanding this to change weapon categories for skill purposes so don't fucking ask
	else	
		self._has_burst_fire = false
		self._can_shoot_through_titan_shield = false --to prevent npc abuse
	end	
	
	self._hs_mult = self:is_npc() and 1 or self._hs_mult or self:weapon_tweak_data().hs_mult or 1
	self._ene_hs_mult = self:is_npc() and 1 or self._ene_hs_mult or self:weapon_tweak_data().ene_hs_mult or 1

	self._shots_fired = 0
	self._shots_fired_init = 0
	self._shots_fired_mag = 0

	local primary_category = self:weapon_tweak_data().categories and self:weapon_tweak_data().categories[1]
	self._movement_penalty = self:weapon_tweak_data().weapon_movement_penalty or tweak_data.upgrades.weapon_movement_penalty[primary_category] or 1

	local custom_stats = managers.weapon_factory:get_custom_stats_from_weapon(self._factory_id, self._blueprint)
	if not self._custom_stats_done then
		--Set range/rof multipliers to 1 to make anything else that changes them fuck off
		self._damage_near_mul = 1
		self._damage_far_mul = 1
		self._damage_min_mult = 1
		self._duration_falloff_start_mult = 1
		self._duration_falloff_end_mult = 1

		self._rof_mult = 1
		self._alt_rof_mult = 1
		self._ads_rof_mult = 1
		self._hip_rof_mult = 1
		self._spin_up_mult = 1

		self._alt_dmg_mult = 1

		self._movement_speed_add = 0

		self._melee_speed_mult = 1
		self._reload_anim_multiplier = 1
		self._reload_empty_anim_multiplier = 1
		self._reload_non_empty_anim_multiplier = 1

		self._hipfire_mult = 1
		self._ads_moving_mult = 1

		self._alt_melee_sounds = {}

		self._use_vapor_trail = self:weapon_tweak_data().use_vapor_trail
		self._use_sniper_trail = self:weapon_tweak_data().use_sniper_trail
		self._is_beam = self:weapon_tweak_data().is_beam

		self._use_silenced_muzzleflash = nil

		self._bypass_orig_firemode = nil
		self._bypass_orig_toggle_firemode = nil

		self._pointshoot_ads = 1
		self._pointshoot_spread = 1
		self._pointshoot_hip_spread = 1
		self._pointshoot_strafe = 0
		self._pointshoot_rof = 1
		self._pointshoot_recoil = 1
		self._pointshoot_falloff = 1
		self._pointshoot_falloff_start = 1
		self._pointshoot_falloff_end = 1
		self._pointshoot_damage_min = 1

		self._keep_ammo = self:weapon_tweak_data().keep_ammo

		if not self:is_npc() then
			self._descope_on_fire = self:weapon_tweak_data().descope_on_fire
			self._descope_on_fire_ignore_setting = self:weapon_tweak_data().descope_on_fire_ignore_setting
			self._descope_on_dmg = self:weapon_tweak_data().descope_on_dmg
			self._srm = self:weapon_tweak_data().recoil_values and self:weapon_tweak_data().recoil_values.srm
			self._sam = self:weapon_tweak_data().recoil_values and self:weapon_tweak_data().recoil_values.sam
			self._rms = self:weapon_tweak_data().rms
			self._sms = self:weapon_tweak_data().sms
			self._smt = self._sms and self:weapon_tweak_data().fire_mode_data and ((self:weapon_tweak_data().fire_mode_data.fire_rate * 5) * (self:weapon_tweak_data().smt_mult or 1))
		end

		for part_id, stats in pairs(custom_stats) do
			if stats.ads_speed_mult then
				self._ads_speed_mult = self._ads_speed_mult * stats.ads_speed_mult
			end
			if self._flame_max_range and stats.flame_max_range_set then
				self._flame_max_range = stats.flame_max_range_set
				NewRaycastWeaponBase.flame_max_range = stats.flame_max_range_set
			end
			if stats.block_b_storm or (stats.bullet_class and stats.bullet_class == "InstantExplosiveBulletBase") then
				self._no_bulletstorm = true
			end
			if stats.disable_steelsight_stance then
				if self:weapon_tweak_data().animations then
					self:weapon_tweak_data().animations.has_steelsight_stance = false
				end
			end

			if stats.rof_mult then
				self._rof_mult = self._rof_mult * stats.rof_mult
			end
			if stats.rof_mult_semi then
				self._rof_mult_semi = (self._rof_mult_semi and (self._rof_mult_semi * stats.rof_mult_semi)) or stats.rof_mult_semi
			end
			if stats.alt_rof_mult then
				self._alt_rof_mult = self._alt_rof_mult * stats.alt_rof_mult
			end
			if stats.ads_rof_mult then
				self._ads_rof_mult = self._ads_rof_mult * stats.ads_rof_mult
			end
			if stats.hip_rof_mult then
				self._hip_rof_mult = self._hip_rof_mult * stats.hip_rof_mult
			end

			if stats.default_firemode then
				self._bypass_orig_firemode = true
				self:weapon_tweak_data().FIRE_MODE_ORIG = self:weapon_tweak_data().FIRE_MODE_ORIG or stats.orig_firemode
				self:weapon_tweak_data().FIRE_MODE = stats.default_firemode
			end
			if stats.can_toggle_firemode then
				self._bypass_orig_toggle_firemode = true
				self:weapon_tweak_data().CAN_TOGGLE_FIREMODE_ORIG = self:weapon_tweak_data().CAN_TOGGLE_FIREMODE_ORIG or stats.orig_toggle_firemode
				self:weapon_tweak_data().CAN_TOGGLE_FIREMODE = stats.can_toggle_firemode
			end

			if stats.kick_pattern then
				self._kick_pattern = stats.kick_pattern
			end
			
			--BURST STUFF HERE
			if stats.burst_fire then
				local burst_data = stats.burst_fire
				self._has_burst_fire = true
				self._burst_size = burst_data.count or self._burst_size or 3
				self._burst_delay_alt_calc = burst_data.rof_mult_alt or self._burst_delay_alt_calc
				self._burst_fire_rate_multiplier = burst_data.rof_mult or self._burst_fire_rate_multiplier
				if burst_data.desired_burst_rof then
					local base_firerate = self:weapon_tweak_data().fire_mode_data and self:weapon_tweak_data().fire_mode_data.fire_rate / (self._fire_rate_multiplier * self._rof_mult)
					self._burst_fire_rate_multiplier = base_firerate and base_firerate / burst_data.desired_burst_rof
				end
				self._burst_fire_recoil_multiplier = burst_data.recoil_mult or self._burst_fire_recoil_multiplier
				self._burst_fire_last_recoil_multiplier = burst_data.last_recoil_mult or self._burst_fire_last_recoil_multiplier
				self._burst_fire_spread_multiplier = burst_data.spread_mult or self._burst_fire_spread_multiplier
				self._burst_fire_ads_spread_multiplier = burst_data.ads_spread_mult or self._burst_fire_ads_spread_multiplier
				self._burst_fire_range_multiplier = burst_data.range_mult or self._burst_fire_range_multiplier
				self._burst_fire_no_ads = (burst_data.no_ads ~= nil and burst_data.no_ads) or self._burst_fire_no_ads
				self._burst_no_anim = burst_data.no_anim or self._burst_no_anim --only play anims for the last shot in a burst
				self._burst_delay = burst_data.delay or self._burst_delay or 0.25
				self._auto_burst = (burst_data.auto_burst ~= nil and burst_data.auto_burst) or self._auto_burst
				self._slamfire  = (burst_data.slamfire ~= nil and burst_data.slamfire) or self._slamfire
				self._block_toggle = (burst_data.block_toggle ~= nil and burst_data.block_toggle) or self._block_toggle --blocks toggling between semi-auto and full-auto; does not stop toggling off burst
				self._lock_burst = (burst_data.lock ~= nil and burst_data.lock) or self._lock_burst --blocks toggling off burst altogether
				self._burst_toggle_to_semi = burst_data.toggle_to_semi or self._burst_toggle_to_semi --forces toggling to semi-auto from burst; only applicable if the base firemode is full-auto
				self._burst_toggle_to_auto = burst_data.toggle_to_auto or self._burst_toggle_to_auto --forces toggling to full-auto from burst; only applicable if the base firemode is semi-auto
				self._burst_default = (burst_data.burst_default ~= nil and burst_data.burst_default) or self._burst_default --make starting firemode burst-fire
			end
			if stats.block_burst then
				self._block_burst = true
			end
			
			if stats.tweak_categories then
				self._tweak_categories = stats.tweak_categories
			end

			if stats.init_rof then	
				self._fire_rate_init_count = stats.init_rof.count or self._fire_rate_init_count
				self._fire_rate_init_count_mag = stats.init_rof.count_mag or self._fire_rate_init_count_mag
				self._fire_rate_init_mult = stats.init_rof.rof_mult or self._fire_rate_init_mult
				self._fire_rate_init_delay = stats.init_rof.delay or self._fire_rate_init_delay
				self._fire_rate_init_reset = stats.init_rof.reset or self._fire_rate_init_reset
				self._fire_rate_init_recoil_mult = stats.init_rof.recoil_mult or self._fire_rate_init_recoil_mult
			end
	
			if stats.reload_not_empty_speed_multiplier then
				self._reload_not_empty_speed_multiplier = (self._reload_not_empty_speed_multiplier or 1) * stats.reload_not_empty_speed_multiplier
			end

			if stats.adj_timers then
				if self:weapon_tweak_data().timers then
					--self:weapon_tweak_data().timers.reload_empty = stats.adj_timers.reload_empty or self:weapon_tweak_data().timers.reload_empty
					--self:weapon_tweak_data().timers.reload_not_empty = stats.adj_timers.reload_not_empty or self:weapon_tweak_data().timers.reload_not_empty
					self._alt_reload_not_empty = stats.adj_timers.reload_not_empty
					self._alt_reload_exit_empty = stats.adj_timers.reload_exit_empty
					self._alt_reload_exit_not_empty = stats.adj_timers.reload_exit_not_empty
				end
			end	
			
			if stats.croon then
				self:weapon_tweak_data().BURST_USE_AUTO_LOGIC = true
				self:weapon_tweak_data().BURST_FIRE_RATE_MULTIPLIER = 200
			end

			if stats.bandana then
				self._bandana = stats.bandana
			end	

			if stats.type99_stats then
				--have to do this due to how this thing is set up, can't have both equipped anyways
				tweak_data.weapon.system.reload_speed_multiplier = 1.13
				tweak_data.weapon.system.timers = tweak_data.weapon.system.timers or {}
				tweak_data.weapon.system.timers.reload_empty = 8
				tweak_data.weapon.system.timers.reload_not_empty = 8
				tweak_data.weapon.system.timers.reload_exit_empty = 0.8
				tweak_data.weapon.system.timers.reload_exit_not_empty = 0.8
			end	

			if stats.disable_steelsight_recoil_anim then
				self._disable_steelsight_recoil_anim = true
			end					
	
			if stats.srm then		
				self._srm = stats.srm
			end
			if stats.hs_mult then		
				self._hs_mult = (self._hs_mult or 1) * stats.hs_mult
			end
			if stats.ene_hs_mult_add then
				self._ene_hs_mult = self._ene_hs_mult + stats.ene_hs_mult_add
			end

			if stats.tactical_reload then
				self._tactical_reload = stats.tactical_reload
			end
			
			if stats.pointshoot_ads then
				self._pointshoot_ads = (self._pointshoot_ads or 1) * stats.pointshoot_ads
			end
			if stats.pointshoot_spread then
				self._pointshoot_spread = (self._pointshoot_spread or 1) * stats.pointshoot_spread
			end
			if stats.pointshoot_hip_spread then
				self._pointshoot_hip_spread = (self._pointshoot_hip_spread or 1) * stats.pointshoot_hip_spread
			end
			if stats.pointshoot_strafe then
				self._pointshoot_strafe = math.min( (self._pointshoot_strafe or 0) + stats.pointshoot_strafe, 1 )
			end
			if stats.pointshoot_rof then
				self._pointshoot_rof = (self._pointshoot_rof or 1) * stats.pointshoot_rof
			end
			if stats.pointshoot_recoil then
				self._pointshoot_recoil = (self._pointshoot_recoil or 1) * stats.pointshoot_recoil
			end
			if stats.pointshoot_falloff then
				self._pointshoot_falloff = (self._pointshoot_falloff or 1) * stats.pointshoot_falloff
			end
			if stats.pointshoot_falloff_start then
				self._pointshoot_falloff_start = (self._pointshoot_falloff_start or 1) * stats.pointshoot_falloff_start
			end
			if stats.pointshoot_falloff_end then
				self._pointshoot_falloff_end = (self._pointshoot_falloff_end or 1) * stats.pointshoot_falloff_end
			end
			if stats.pointshoot_damage_min then
				self._pointshoot_damage_min = (self._pointshoot_damage_min or 1) * stats.pointshoot_damage_min
			end

			if stats.object_damage_mult_override then		
				self._object_damage_mult = stats.object_damage_mult_override
				self._object_damage_mult_single_ray = stats.object_damage_mult_override
			end
			if stats.object_damage_mult_exp_override then		
				self._object_damage_mult_exp = stats.object_damage_mult_exp_override
			end
			if stats.descope_on_fire then		
				self._descope_on_fire = stats.descope_on_fire
			end
			if stats.descope_on_fire_ignore_setting then		
				self._descope_on_fire_ignore_setting = stats.descope_on_fire_ignore_setting
			end
			if stats.use_vapor_trail then		
				self._use_vapor_trail = stats.use_vapor_trail
			end
			if stats.duration_falloff_start_mult then		
				self._duration_falloff_start_mult = self._duration_falloff_start_mult * stats.duration_falloff_start_mult
			end
			if stats.duration_falloff_end_mult then		
				self._duration_falloff_end_mult = self._duration_falloff_end_mult * stats.duration_falloff_end_mult
			end
			if stats.falloff_start_mult then
				self._damage_near_mul = self._damage_near_mul * stats.falloff_start_mult
			end
			if stats.falloff_end_mult then
				self._damage_far_mul = self._damage_far_mul * stats.falloff_end_mult
			end
			if stats.damage_min_mult then
				self._damage_min_mult = self._damage_min_mult * stats.damage_min_mult
			end
			if stats.spin_up_mult then
				self._spin_up_mult = self._spin_up_mult * stats.spin_up_mult
			end

			if stats.ignore_rof_mult_anims then
				self._ignore_rof_mult_anims = stats.ignore_rof_mult_anims
			end
			if stats.ignore_rof_mult_anims_semi then
				self._ignore_rof_mult_anims_semi = stats.ignore_rof_mult_anims_semi
			end

			if stats.alt_dmg_mult then
				self._alt_dmg_mult = self._alt_dmg_mult * stats.alt_dmg_mult
			end

			if stats.chf then
				self._chf = stats.chf
			end
			
			if stats.alt_melee_sounds then
				self._alt_melee_sounds = stats.alt_melee_sounds
			end
			if stats.natascha then		
				self._natascha = stats.natascha
			end

			if stats.keep_ammo then
				self._keep_ammo = stats.keep_ammo
			end
			if stats.starwars then
				if restoration.Options:GetValue("OTHER/GCGPYPMMSAC") then
					self._cbfd_to_add_this_check_elsewhere = true
				else
					self._starwars = deep_clone(stats.starwars)
				end
			end
			if stats.battery_mag then
				self._starwars = deep_clone(stats.battery_mag)
			end
			if stats.use_silenced_muzzleflash then
				self._use_silenced_muzzleflash = true
			end
			if stats.empire then
				self._empire = true
			end
			if stats.republic then
				self._republic = true
			end
			if stats.techno_union then
				self._techno_union = true
			end
			if stats.mandalorian then
				self._mandalorian = true
			end
			if stats.muzzleflash then
				self._muzzle_effect_pls = stats.muzzleflash
			end
			if stats.shell_ejection then
				self._shell_ejection_pls = stats.shell_ejection
			end
			if stats.trail_effect then
				self._trail_effect_pls = stats.trail_effect
			end
			if stats.trail_effect_npc then
				self._trail_effect_npc = stats.trail_effect_npc
			end
			if stats.trail_effect_ignore then
				self._trail_effect_ignore = stats.trail_effect_ignore
			end
			if stats.melee_speed_mult then
				self._melee_speed_mult = self._melee_speed_mult * stats.melee_speed_mult
			end
			if stats.hip_mult then
				self._hipfire_mult = self._hipfire_mult * stats.hip_mult
			end
			if stats.ads_moving_mult then
				self._ads_moving_mult = self._ads_moving_mult * stats.ads_moving_mult
			end
			if stats.fire2 then
				self:weapon_tweak_data().sounds.fire2 = stats.fire2
			end
			if stats.stop_fire2 then
				self:weapon_tweak_data().sounds.stop_fire2 = stats.stop_fire2
			end
			if stats.big_scope then
				self._has_big_scope = true
			end
			if stats.reload_anim_mult then
				self._reload_anim_multiplier = self._reload_anim_multiplier * stats.reload_anim_mult
			end
			if stats.reload_empty_anim_mult then
				self._reload_empty_anim_multiplier = self._reload_empty_anim_multiplier * stats.reload_empty_anim_mult
			end
			if stats.reload_non_empty_anim_mult then
				self._reload_non_empty_anim_multiplier = self._reload_non_empty_anim_multiplier * stats.reload_non_empty_anim_mult
			end
			if stats.movement_speed_add then
				self._movement_speed_add = self._movement_speed_add + stats.movement_speed_add
			end
			if stats.sks_clip then
				if self:weapon_tweak_data().timers then
					self:weapon_tweak_data().timers.reload_exit_not_empty = 1.2
				end
				self._tactical_reload = nil
				self:ammo_base()._tactical_reload = nil
			end
			if stats.no_chamber then
				self._tactical_reload = nil
				self:ammo_base()._tactical_reload = nil
			end

			if not self:is_npc() then
				if stats.sms then
					if not self._sms then
						self._sms = stats.sms
					else
						self._sms = self._sms + (1 * (stats.sms - 1))
					end
					self._smt = self:weapon_tweak_data().fire_mode_data and ((self:weapon_tweak_data().fire_mode_data.fire_rate * 5) * (self:weapon_tweak_data().smt_mult or 1))
				end
				if stats.rms then
					if not self._rms then
						self._rms = stats.rms
					else
						self._rms = self._rms + (1 * (stats.rms - 1))
					end
				end
			end
		end
	self._custom_stats_done = true --stops from repeating and hiking up the effects of the multiplicative stats
	end

	if self._movement_speed_add then
		self._movement_penalty = math.max(self._movement_penalty + self._movement_speed_add, 0.1)
	end

	for part_id, stats in pairs(custom_stats) do
		if stats.can_shoot_through_wall ~= nil then
			self._can_shoot_through_wall = stats.can_shoot_through_wall
		end
		if stats.can_shoot_through_enemy ~= nil then
			self._can_shoot_through_enemy = stats.can_shoot_through_enemy
		end
		if stats.can_shoot_through_shield ~= nil then
			self._can_shoot_through_shield = stats.can_shoot_through_shield
		end
		if stats.can_shoot_through_titan_shield ~= nil then
			self._can_shoot_through_titan_shield = stats.can_shoot_through_titan_shield
		end
		if stats.can_shoot_through_enemy_unlim ~= nil then
			self._can_shoot_through_enemy_unlim = stats.can_shoot_through_enemy_unlim
		end
		if stats.armor_piercing_override then
			self._armor_piercing_chance = stats.armor_piercing_override
		end
		if stats.armor_piercing_add_override then
			self._single_fire_ap_add = stats.armor_piercing_add_override
		end
		if stats.dot_data_name and self._ammo_data then
			self._ammo_data.dot_data_name = stats.dot_data_name
		end
		if tweak_data.weapon.factory.parts[part_id].type ~= "ammo" then
			if stats.ammo_pickup_min_mul then
				self._ammo_data.ammo_pickup_min_mul = self._ammo_data.ammo_pickup_min_mul and self._ammo_data.ammo_pickup_min_mul * stats.ammo_pickup_min_mul or stats.ammo_pickup_min_mul
			end

			if stats.ammo_pickup_max_mul then
				self._ammo_data.ammo_pickup_max_mul = self._ammo_data.ammo_pickup_max_mul and self._ammo_data.ammo_pickup_max_mul * stats.ammo_pickup_max_mul or stats.ammo_pickup_max_mul
			end
		end

		if part_id == "wpn_fps_ass_akm_m_helo" then
			self._extra_ammo = -tweak_data.weapon[self._name_id].CLIP_AMMO_MAX + 1
			self._tactical_reload = nil
			self:set_ammo_max_per_clip(1)
			self:set_ammo_remaining_in_clip(1)
		end
	end

	if self._use_silenced_muzzleflash then
		self._muzzle_effect = Idstring(self:weapon_tweak_data().muzzleflash_silenced or "effects/payday2/particles/weapons/9mm_auto_silence_fps")
		self._muzzle_effect_table.effect = self._muzzle_effect
	end

	if self._cbfd_to_add_this_check_elsewhere then
		self._sound_fire:set_switch("suppressed", "regular")
	end

	if self._ammo_data and self._ammo_data.muzzleflash == nil and self._muzzle_effect_table and self._muzzle_effect_pls then
		self._muzzle_effect_table.effect = Idstring(self._muzzle_effect_pls)
	end


	local is_underbarrel = self.is_underbarrel and self:is_underbarrel()
	local underbarrel_part = managers.weapon_factory:get_part_from_weapon_by_type("underbarrel", self._parts)

	if underbarrel_part and alive(underbarrel_part.unit) and underbarrel_part.unit:base() and underbarrel_part.unit:base().is_on then
		if underbarrel_part.unit:base():is_on() then
			--self._muzzle_effect_table.effect = Idstring("effects/payday2/particles/weapons/9mm_auto_silence_fps")
		end
	end

	if self._shell_ejection_pls and self._shell_ejection_effect_table then
		self._shell_ejection_effect_table.effect = Idstring(self._shell_ejection_pls)
	end

	local ignore_tracer = nil
	if self._trail_effect_table then
		if self._starwars and not self._starwars.no_tracers then
			self._use_shell_ejection_effect = (self._starwars.use_shell_eject and self._use_shell_ejection_effect) or nil
			ignore_tracer = true
			if self._empire then
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_e" .. ((self:is_npc() and "_npc") or "" ))
			elseif self._republic then
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_r" .. ((self:is_npc() and "_npc") or ""))
			elseif self._techno_union then
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_t" .. ((self:is_npc() and "_npc") or ""))
			elseif self._mandalorian then
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_m" .. ((self:is_npc() and "_npc") or ""))
			else
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail" .. ((self:is_npc() and "_npc") or ""))
			end
		elseif self._trail_effect_pls then
			self._trail_effect_table.effect = Idstring(self._trail_effect_pls .. (((self:is_npc() and self._trail_effect_npc) and "_npc") or ""))
			ignore_tracer = self._trail_effect_ignore
		elseif self._terminator then
			self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_t" .. ((self:is_npc() and "_npc") or ""))
			ignore_tracer = true
		elseif self._plasma_b then
			self._trail_effect_table.effect = Idstring("_dmc/effects/plasma_b_trail" .. ((self:is_npc() and "_npc") or ""))
			ignore_tracer = true
		elseif self._nato then
			self._trail_effect_table.effect = Idstring("_dmc/effects/nato_trail")
		elseif self._warsaw then
			self._trail_effect_table.effect = Idstring("_dmc/effects/warsaw_trail")
		elseif self._large_tracers then
			self._trail_effect_table.effect = Idstring("_dmc/effects/large_trail")
		end 
		
		pewpewpewpew = os.date("%m%d")
		if pewpewpewpew == "0401" and not ignore_tracer then
			self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_m" .. ((self:is_npc() and "_npc") or ""))
			if self._nato then
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail" .. ((self:is_npc() and "_npc") or ""))
			elseif self._warsaw then
				self._trail_effect_table.effect = Idstring("_dmc/effects/sterwers_trail_e" .. ((self:is_npc() and "_npc") or ""))
			end
		end
	end

	--REALLY gross way of doing this but I don't want to deal with the firemode HUD elements of which the HUD directly pulls from tweakdata to determine what to draw so AAAAAAAAAAAAAAAAAAAAAAAAAAA
	if not self._bypass_orig_firemode and self:weapon_tweak_data().FIRE_MODE_ORIG ~= nil then
		self:weapon_tweak_data().FIRE_MODE = self:weapon_tweak_data().FIRE_MODE_ORIG
	end

	if not self._bypass_orig_toggle_firemode and self:weapon_tweak_data().CAN_TOGGLE_FIREMODE_ORIG ~= nil then
		self:weapon_tweak_data().CAN_TOGGLE_FIREMODE = self:weapon_tweak_data().CAN_TOGGLE_FIREMODE_ORIG
	end

	if not self._locked_fire_mode and not self._block_burst and self._has_burst_fire == true and self._burst_default then 
		self:_set_burst_mode(true, true)
	end

	self._ignore_rof_mult_anims_semi = (self._has_burst_fire and not self._lock_burst) or self:weapon_tweak_data().CAN_TOGGLE_FIREMODE
	self._rof_mult_semi = not self._locked_fire_mode and self._rof_mult_semi

	self._fire_rate_multiplier = self._fire_rate_multiplier * self._rof_mult


	self._has_scope = managers.weapon_factory:has_perk("scope", self._factory_id, self._blueprint)

	if not disallow_replenish then
		self:precalculate_ammo_pickup()
	end
end

function NewRaycastWeaponBase:_check_reticle_obj()
	self._reticle_obj = nil
	--Kill reticle obj
end

function NewRaycastWeaponBase:armor_piercing_chance()
	local final_ap = 0
	local skill_ap = self._skill_global_ap or 0
	local skill_ap_min = self._skill_global_ap_min or 0
	local is_single = self._single_fire_ap_add and self:fire_mode() == "single" and not self:in_burst_mode()
	for _, category in ipairs(self:categories()) do
		if managers.player:has_category_upgrade(category, "ap_bullets") then
			skill_ap = skill_ap + managers.player:upgrade_value(category, "ap_bullets", 0)
		end
		if managers.player:has_category_upgrade(category, "ap_bullets_min") then
			skill_ap_min = skill_ap_min + managers.player:upgrade_value(category, "ap_bullets_min", 0)
		end
	end
	skill_ap = skill_ap + ((is_single and self._single_fire_ap_add) or 0)
	if self._fire_mode == ids_volley then
		local fire_mode_data = self:weapon_tweak_data().fire_mode_data
		local volley_fire_mode = fire_mode_data and fire_mode_data.volley
		local volley_ap = volley_fire_mode and volley_fire_mode.armor_piercing_chance or 0
		final_ap = math.min(volley_ap + skill_ap, 1)
		return math.max(skill_ap_min, final_ap) or 0
	else
		final_ap = math.min((self._armor_piercing_chance or 0) + skill_ap, 1)
		return math.max(skill_ap_min, final_ap) or 0
	end
end

function NewRaycastWeaponBase:should_reload_immediately()
	return self._should_reload_immediately or self:weapon_tweak_data().should_reload_immediately
end

function NewRaycastWeaponBase:tweak_data_anim_play(anim, speed_multiplier, set_offset, set_offset2)
	if anim ~= "deploy" and anim ~= "undeploy" and self._starwars and (not self._starwars.can_reload and not self._starwars.allow_anims) then return end

	if anim == "reload_slap" then
		speed_multiplier = self._current_reload_speed_multiplier or self:reload_speed_multiplier()
	end

	local active_burst = self:in_burst_mode() and self._burst_rounds_remaining and self._burst_rounds_remaining > 0
	local no_burst_anims = active_burst and self._burst_no_anim
	if no_burst_anims then return end

	local orig_anim = anim
	local unit_anim = self:_get_tweak_data_weapon_animation(orig_anim)
	local effect_manager = World:effect_manager()

	if self._active_animation_effects[anim] then
		for _, effect in ipairs(self._active_animation_effects[anim]) do
			World:effect_manager():kill(effect)
		end
	end

	self._active_animation_effects[anim] = {}

	local data = tweak_data.weapon.factory[self._factory_id]

	if data.animations and data.animations[unit_anim] then
		local animation_data = data.animations[unit_anim]
		local anim_name = type(animation_data) == "table" and animation_data.anim or animation_data
		local ids_anim_name = Idstring(anim_name)
		local length = self._unit:anim_length(ids_anim_name)

		speed_multiplier = speed_multiplier or 1
		self._unit:anim_stop(ids_anim_name)

		local offset = self:_get_anim_start_offset(animation_data) or set_offset2

		if offset then
			self._unit:anim_set_time(ids_anim_name, offset)
		end

		length = self:_get_anim_legth_modifier(animation_data, length)

		self._unit:anim_play_to(ids_anim_name, length, speed_multiplier)
	end

	if data.animation_effects and data.animation_effects[unit_anim] then
		local effect_table = data.animation_effects[unit_anim]

		if effect_table then
			effect_table = clone(effect_table)
			effect_table.parent = effect_table.parent and self._unit:get_object(effect_table.parent)
			local effect = effect_manager:spawn(effect_table)

			table.insert(self._active_animation_effects[anim], effect)
		end
	end

	for part_id, data in pairs(self._parts) do
		if data.unit and data.animations and data.animations[unit_anim] then
			local animation_data = data.animations[unit_anim]
			local anim_name = type(animation_data) == "table" and animation_data.anim or animation_data
			local ids_anim_name = Idstring(anim_name)
			local length = data.unit:anim_length(ids_anim_name)

			speed_multiplier = speed_multiplier or 1

			data.unit:anim_stop(ids_anim_name)

			local offset = self:_get_anim_start_offset(animation_data) or set_offset

			if offset then
				data.unit:anim_set_time(ids_anim_name, offset)
			end

			length = self:_get_anim_legth_modifier(animation_data, length)

			data.unit:anim_play_to(ids_anim_name, length, speed_multiplier)
		end

		if data.unit and data.animation_effects and data.animation_effects[unit_anim] then
			local effect_table = data.animation_effects[unit_anim]

			if effect_table then
				effect_table = clone(effect_table)
				effect_table.parent = effect_table.parent and data.unit:get_object(effect_table.parent)
				local effect = effect_manager:spawn(effect_table)

				table.insert(self._active_animation_effects[anim], effect)
			end
		end
	end

	self:set_reload_objects_visible(true, anim)
	NewRaycastWeaponBase.super.tweak_data_anim_play(self, orig_anim, speed_multiplier)

	return true
end


function NewRaycastWeaponBase:tweak_data_anim_offset(anim, offset, second_gun)
	if self._starwars and (not self._starwars.can_reload and not self._starwars.allow_anims) then return end
	
	local unit_anim = anim
	local data = tweak_data.weapon.factory[self._factory_id]
	if second_gun and alive(self._second_gun) then
		if data.animations and data.animations[unit_anim] then
			local anim_name = data.animations[unit_anim]
			local ids_anim_name = Idstring(anim_name)
			self._second_gun:base()._unit:anim_set_time(ids_anim_name, offset)
		end
		for part_id, data in pairs(self._second_gun:base()._parts) do
			if data.animations and data.animations[unit_anim] then
				local anim_name = data.animations[unit_anim]
				local ids_anim_name = Idstring(anim_name)
				if data.unit then
					data.unit:anim_set_time(ids_anim_name, offset)
				end
			end
		end
	else
		if data.animations and data.animations[unit_anim] then
			local anim_name = data.animations[unit_anim]
			local ids_anim_name = Idstring(anim_name)
			self._unit:anim_set_time(ids_anim_name, offset)
		end
	
		for part_id, data in pairs(self._parts) do
			if data.animations and data.animations[unit_anim] then
				local anim_name = data.animations[unit_anim]
				local ids_anim_name = Idstring(anim_name)
				if data.unit then
					data.unit:anim_set_time(ids_anim_name, offset)
				end
			end
		end
	end
	return true
end

function NewRaycastWeaponBase:replenish()
	local ammo_max_multiplier = managers.player:upgrade_value("player", "extra_ammo_multiplier", 1)

	for _, category in ipairs(self:categories()) do
		ammo_max_multiplier = ammo_max_multiplier * managers.player:upgrade_value(category, "extra_ammo_multiplier", 1)
	end

	if managers.player:has_category_upgrade("player", "tony_extra_ammo_multiplier") then
		ammo_max_multiplier = ammo_max_multiplier * managers.player:upgrade_value("player", "tony_extra_ammo_multiplier", 1)
	end

	ammo_max_multiplier = ammo_max_multiplier + ammo_max_multiplier * (self._total_ammo_mod or 0)

	if managers.player:has_category_upgrade("player", "add_armor_stat_skill_ammo_mul") then
		ammo_max_multiplier = ammo_max_multiplier * managers.player:body_armor_value("skill_ammo_mul", nil, 1)
	end

	ammo_max_multiplier = managers.modifiers:modify_value("WeaponBase:GetMaxAmmoMultiplier", ammo_max_multiplier)
	local ammo_max_per_clip = self:calculate_ammo_max_per_clip()
	local ammo_max = math.round((tweak_data.weapon[self._name_id].AMMO_MAX + managers.player:upgrade_value(self._name_id, "clip_amount_increase") * ammo_max_per_clip) * ammo_max_multiplier)
	ammo_max_per_clip = math.min(ammo_max_per_clip, ammo_max)

	self:set_ammo_max_per_clip(ammo_max_per_clip)
	self:set_ammo_max(ammo_max)
	self:set_ammo_total(ammo_max)
	self:set_ammo_remaining_in_clip(ammo_max_per_clip)

	self._ammo_pickup = tweak_data.weapon[self._name_id].AMMO_PICKUP

	if self._assembly_complete then
		for _, gadget in ipairs(self:get_all_override_weapon_gadgets()) do
			if gadget and gadget.replenish then
				gadget:replenish()
			end
		end
	end

	self:update_damage()
end

function NewRaycastWeaponBase:precalculate_ammo_pickup()
	--Precalculate ammo pickup values.
	if self:weapon_tweak_data().AMMO_PICKUP then
		self._ammo_pickup = {self:weapon_tweak_data().AMMO_PICKUP[1], self:weapon_tweak_data().AMMO_PICKUP[2]} --Get base gun ammo pickup.

		--Pickup multiplier from skills.
		local pickup_multiplier = managers.player:upgrade_value("player", "fully_loaded_pick_up_multiplier", 1)	
		local min_pickup_multiplier = managers.player:upgrade_value("player", "minimum_pick_up_multiplier", 1)	
		local is_solo = (Global.game_settings and Global.game_settings.single_player and 2) or 1
		if not is_pro then
			pickup_multiplier = pickup_multiplier * ( ((managers.player:upgrade_value("player", "passive_pick_up_multiplier", 1) - 1) * is_solo) + 1 )
		end

		for _, category in ipairs(self:categories()) do
			pickup_multiplier = pickup_multiplier + managers.player:upgrade_value(category, "pick_up_multiplier", 1) - 1
		end

		if managers.player:has_category_upgrade("player", "armor_pickup_mul") then
			pickup_multiplier = pickup_multiplier * managers.player:body_armor_value("skill_ammo_mul", nil, 1)
		end

		if managers.player:has_category_upgrade("player", "tony_pick_up_multiplier") then
			pickup_multiplier = pickup_multiplier * managers.player:upgrade_value("player", "tony_pick_up_multiplier", 1)
		end

		if managers.player:has_team_category_upgrade("player", "biker_ammo_pickup_boost") then
			local cohesion_stacks = managers.player:get_cohesion_stacks_as_treated() or 0
			pickup_multiplier = pickup_multiplier * (1 + managers.player:team_upgrade_value("player", "biker_ammo_pickup_boost", 0) * cohesion_stacks)
		end

		--Sharpeyed Team AI bonus, since now Enduring is a base thing
		--Moved to RaycastWeaponBase:add_ammo; precalculate_ammo_pickup is first called on spawn *before* the crew bonus becomes active and renders it useless unless you leave custody or do something else to call this function after crew AI is active
		--pickup_multiplier = pickup_multiplier + managers.player:crew_ability_upgrade_value("crew_scavenge", 1) - 1

		pickup_multiplier = pickup_multiplier * ((self._is_controller and 1.15) or 1)

		--Apply multiplier from skills and ammo.
		self._ammo_pickup[1] = self._ammo_pickup[1] * pickup_multiplier * min_pickup_multiplier * ((self._ammo_data and self._ammo_data.ammo_pickup_min_mul) or 1)
		self._ammo_pickup[2] = self._ammo_pickup[2] * pickup_multiplier * ((self._ammo_data and self._ammo_data.ammo_pickup_max_mul) or 1)
	end
end
					
--[[	fire rate multipler in-game stuff	]]--
function NewRaycastWeaponBase:fire_rate_multiplier( ignore_anims )
	local multiplier = self._fire_rate_multiplier or 1
	multiplier = multiplier * (self:weapon_tweak_data().fire_rate_multiplier or 1)
	local has_sharpshooter = managers.player:has_activate_temporary_upgrade("temporary", "headshot_fire_rate_mult") 
	if self:is_category("assault_rifle", "snp") and has_sharpshooter then
		local temp_mult = managers.player:temporary_upgrade_value("temporary", "headshot_fire_rate_mult", 1)
		if self:fire_mode() ~= "single" then
			local auto_mult = tweak_data.upgrades.sharpshooter_auto_mult
			temp_mult = ((temp_mult - 1) * auto_mult) + 1
		end
		multiplier = multiplier * temp_mult
	end 
	if ignore_anims then
		return multiplier / (self._rof_mult or 1)
	end
	local user_unit = self._setup and self._setup.user_unit --I'd like to know an instance where you can even shoot at all without there being a user_unit
	local current_state = alive(user_unit) and user_unit:movement() and user_unit:movement()._current_state
	if current_state then 
		if current_state:in_steelsight() then
			multiplier = multiplier * self._ads_rof_mult
		else
			multiplier = multiplier * self._hip_rof_mult
		end
	end
	if self:in_burst_mode() or self._macno then
		local no_burst_mult = multiplier
		multiplier = multiplier * (self._burst_fire_rate_multiplier or 1)
		if self._macno or (self._burst_rounds_remaining and self._burst_rounds_remaining < 1) and not self._slamfire then
			local fire_rate = self:weapon_tweak_data().fire_mode_data and self:weapon_tweak_data().fire_mode_data.fire_rate
			local moremath = fire_rate / no_burst_mult
			local delay = self._burst_delay - moremath
			local current_state_name = managers.player:current_state()
			local og_next_fire = (current_state_name and current_state_name == "tased" or self._spinning) and self._next_fire_allowed
			self._macno = nil
			if not self._burst_delay_alt_calc then
				self._next_fire_allowed = og_next_fire or (math.max(self._next_fire_allowed - ((bypass_firerate and moremath) or 0), self._unit:timer():time() + delay))
				self._ignore__next_fire_allowed = true
				multiplier = self:weapon_tweak_data().fire_rate_multiplier or 1
			end
		end
	end	

	local init_mult = self._fire_rate_init_mult
	if self._fire_rate_init_count and self:fire_mode() ~= "single" and not self:in_burst_mode() then
		if (self._fire_rate_init_count > self._shots_fired_init) then
			self._fire_rate_init_progress = true
			if self._fire_rate_init_ramp_up then
				local init_ramp_up_add = (1 - self._fire_rate_init_mult ) / self._fire_rate_init_count  * self._shots_fired_init + init_mult
				init_mult =  init_ramp_up_add
			end
			multiplier = multiplier * init_mult
		elseif (self._fire_rate_init_count < self._shots_fired_init) then
			self._fire_rate_init_progress = nil
		end
	end

	if self._fire_rate_init_count_mag and self._shots_fired_mag and self._fire_rate_init_count_mag > self._shots_fired_mag then
		multiplier = multiplier * self._fire_rate_init_mult
	end

	if self._alt_fire_active then
		multiplier = multiplier * self._alt_rof_mult
	end

	if not self._locked_fire_mode and ((self:can_toggle_firemode() and not has_sharpshooter) or self._rof_mult_semi) and self:fire_mode() == "single" and not self:in_burst_mode() then
		multiplier = multiplier * (self._rof_mult_semi or 0.8)
	end
	
	local second_sight_rof_mult = self.second_sight_rof_mult and self:second_sight_rof_mult()
	if second_sight_rof_mult then
		multiplier = multiplier * second_sight_rof_mult
	end

	return multiplier
end

function NewRaycastWeaponBase:fire(...)
	local ray_res = NewRaycastWeaponBase.super.fire(self, ...)

	if self._fire_mode == ids_burst and self._bullets_fired and self._bullets_fired > 1 and not self:weapon_tweak_data().sounds.fire_single then
		self:_fire_sound()
	end
	
	local t = self._unit:timer():time()
	if self._fire_rate_init_reset_t then
		self._fire_rate_init_reset_t = t + self._fire_rate_init_reset
	end
	self._shots_fired_init = self._shots_fired_init + 1

	self._shots_fired = self._shots_fired + 1

	if not self._starwars then
		self._shots_fired_mag = self._shots_fired_mag + 1
	end

	if ray_res and not self.AKIMBO and self:in_burst_mode() then
		if self:clip_empty() then
			self:cancel_burst()
		else
			self._burst_rounds_fired = self._burst_rounds_fired + 1
			self._burst_rounds_remaining = (self._burst_rounds_remaining <= 0 and self._burst_size or self._burst_rounds_remaining) - 1
			if self._burst_rounds_remaining <= 0 then
				self:cancel_burst()
			end
		end
	end

	if self._disable_steelsight_recoil_anim and not self:second_sight_spread_mult() then
		local camera = self._setup.user_unit:camera() and alive(self._setup.user_unit:camera():camera_unit()) and self._setup.user_unit:camera():camera_unit()
		if camera and managers.player:player_unit():movement():current_state():in_steelsight() then
			camera:play_redirect(Idstring("idle"))
		end
	end

	return ray_res
end

local toggle_firemode_original = NewRaycastWeaponBase.toggle_firemode
function NewRaycastWeaponBase:toggle_firemode(...)
	return self._has_burst_fire == true and not self._locked_fire_mode and not self._lock_burst and not self._burst_ads_toggle and not self._burst_hipfire_toggle and not self:gadget_overrides_weapon_functions() and self:_check_toggle_burst() or toggle_firemode_original(self, ...)
end

function NewRaycastWeaponBase:can_toggle_firemode()
	if self:gadget_overrides_weapon_functions() then
		return self:gadget_function_override("can_toggle_firemode")
	end

	if self._toggable_fire_modes then
		return #self._toggable_fire_modes > 1
	end

	return not self._block_toggle and not self._lock_burst and self._burst_rounds_remaining <= 0 and not self._macno and tweak_data.weapon[self._name_id].CAN_TOGGLE_FIREMODE
end


function NewRaycastWeaponBase:can_reload()
	if self:ammo_base()._starwars and not self:ammo_base()._starwars.can_reload then
		return false
	else
		return self:ammo_base():get_ammo_remaining_in_clip() < self:ammo_base():get_ammo_total()
	end
end

function NewRaycastWeaponBase:_check_toggle_burst()
	if not self._block_burst and not self:is_npc() and not self._lock_burst and self._burst_rounds_remaining == 0 then
		if self:in_burst_mode() then
			self:_set_burst_mode(false, self.AKIMBO and not self._has_auto)
			return true
		elseif (self._fire_mode == NewRaycastWeaponBase.IDSTRING_SINGLE) or (self._fire_mode == NewRaycastWeaponBase.IDSTRING_AUTO and not self:can_toggle_firemode()) then
			self:_set_burst_mode(true, self.AKIMBO)
			self._fire_rate_init_progress = nil
			return true
		end
	end
end


function NewRaycastWeaponBase:_set_burst_mode(status, skip_sound)
	self._in_burst_mode = status
	self._fire_mode = NewRaycastWeaponBase["IDSTRING_" .. (status and "SINGLE" or (self._has_auto or self._burst_toggle_to_auto) and "AUTO" or "SINGLE")]
	
	if not skip_sound then
		self._sound_fire:post_event(status and "wp_auto_switch_on" or self._has_auto and "wp_auto_switch_on" or "wp_auto_switch_off")
	end
	
	self:cancel_burst(nil, true)
end

function NewRaycastWeaponBase:can_use_burst_mode()
	return self._has_burst_fire == true and not self._block_burst
end

function NewRaycastWeaponBase:in_burst_mode()
	if self._fire_mode == NewRaycastWeaponBase.IDSTRING_SINGLE and self._in_burst_mode and not self:gadget_overrides_weapon_functions() then
		managers.hud:set_teammate_weapon_firemode_burst(self:selection_index())
		--[[
		if not self._afr_memory then
			self._afr_memory = self._afr_is_single
		end
		self._afr_is_single = false
		--]]
		return true --self._fire_mode == NewRaycastWeaponBase.IDSTRING_SINGLE and self._in_burst_mode and not self:gadget_overrides_weapon_functions()
	else
		--[[
		self._afr_is_single = self._afr_memory or nil
		--]]
		return false --self._fire_mode == NewRaycastWeaponBase.IDSTRING_SINGLE and self._in_burst_mode and not self:gadget_overrides_weapon_functions()
	end
end

function NewRaycastWeaponBase:burst_rounds_remaining()
	return self._burst_rounds_remaining > 0 and self._burst_rounds_remaining or false
end

function NewRaycastWeaponBase:cancel_burst(soft_cancel, macno)
	if self._adaptive_burst_size or not soft_cancel then
		if self._burst_rounds_remaining and self._burst_rounds_remaining > 0 and macno then
			self._macno = true
			self:play_sound("alarm_kosugi_on_slow_fade")
			self:play_sound("alarm_kosugi_off")
			if not self._i_know then
				self._i_know = 1
				managers.hud:show_hint( { text = "DON'T EVEN THINK ABOUT USING AUTOFIRE, OR I'LL KNOW" } )
			else
				self._i_know = self._i_know + 1
				if self._i_know == 5 then
					managers.hud:show_hint( { text = "TRYING TO BYPASS THE BURST DELAY MAKES THIS LONGER EACH TIME, FYI" } )
				end
			end
		end
		self._burst_rounds_remaining = 0
		if self._delayed_burst_recoil and self._burst_rounds_fired > 0 then
			self._setup.user_unit:movement():current_state():force_recoil_kick(self, self._burst_rounds_fired)
		end
		self._burst_rounds_fired = 0
	end
end	

--[[	Reload stuff	]]--
function NewRaycastWeaponBase:reload_speed_multiplier()
	if self._current_reload_speed_multiplier then
		return self._current_reload_speed_multiplier
	end
	local multiplier = self._reload_speed_mult
		
	for _, category in ipairs(self:categories()) do
		multiplier = multiplier * managers.player:upgrade_value(category, "reload_speed_multiplier", 1)
	end
	if not is_pro then
		multiplier = multiplier * managers.player:upgrade_value("weapon", "passive_reload_speed_multiplier", 1)
	end
	multiplier = multiplier * managers.player:upgrade_value("player", "reload_speed_multiplier", 1)
	multiplier = multiplier * managers.player:upgrade_value(self._name_id, "reload_speed_multiplier", 1)

	if self:get_ammo_remaining_in_clip() ~= 0 then
		if self._reload_not_empty_speed_multiplier then
			multiplier = multiplier * self._reload_not_empty_speed_multiplier
		end
	end
	
	if self._setup and alive(self._setup.user_unit) and self._setup.user_unit:movement() then
		local morale_boost_bonus = self._setup.user_unit:movement():morale_boost()

		if morale_boost_bonus then
			multiplier = multiplier * morale_boost_bonus.reload_speed_bonus
		end
		
		if self._setup.user_unit:movement():next_reload_speed_multiplier() then
			multiplier = multiplier * self._setup.user_unit:movement():next_reload_speed_multiplier()
		end
	end
	
	if managers.player:has_activate_temporary_upgrade("temporary", "reload_weapon_faster") then
		multiplier = multiplier * managers.player:temporary_upgrade_value("temporary", "reload_weapon_faster", 1)
	end
	if managers.player:has_activate_temporary_upgrade("temporary", "single_shot_fast_reload") and 
		self:is_category(unpack(managers.player:upgrade_value("temporary", "single_shot_fast_reload").allowed_categories)) then
		multiplier = multiplier * managers.player:temporary_upgrade_value("temporary", "single_shot_fast_reload", 1)
	end
	multiplier = multiplier * managers.player:get_property("shock_and_awe_reload_multiplier", 1)
	multiplier = multiplier * managers.player:get_temporary_property("bloodthirst_reload_speed", 1)
	multiplier = multiplier * managers.player:upgrade_value("team", "crew_faster_reload", 1)

	multiplier = multiplier * self:reload_speed_stat()
	multiplier = managers.modifiers:modify_value("WeaponBase:GetReloadSpeedMultiplier", multiplier)

	if managers.player:has_team_category_upgrade("player", "biker_crew_reload_bonus") then
		local potency_amount = managers.player:get_cohesion_stacks_as_treated()
		local bonus = managers.player:team_upgrade_value("player", "biker_crew_reload_bonus", 0) + managers.player:team_upgrade_value("player", "biker_additional_move_reload_bonus", 0)

		multiplier = multiplier * (1 + bonus * potency_amount)
	end

	--MERCENARY DECK
	if managers.player:has_category_upgrade("player","kmerc_reload_speed_per_max_armor") then
		local player = managers.player:local_player()
		if alive(player) then
			local dmg_ext = player:character_damage() 
			if dmg_ext then
				local rate_bonus = managers.player:upgrade_value("player","kmerc_reload_speed_per_max_armor",0)
				local rate_armor = tweak_data.upgrades.values.player.kmerc_generic_bonus_per_max_armor_rate
				local max_armor = dmg_ext:_max_armor()
				local bonus = math.floor(max_armor / rate_armor) * rate_bonus
				--log(tostring( bonus ))
				multiplier = multiplier + bonus
			end
		end
	end

	return multiplier
end

function NewRaycastWeaponBase:enter_steelsight_speed_multiplier( mult_only )
	local multiplier = 1
	local ads_time = self:weapon_tweak_data().ads_speed or 0.200
	local base_transition_dur = tweak_data.player.TRANSITION_DURATION

	if not mult_only then
		multiplier = multiplier / ( ads_time / base_transition_dur)
		multiplier = multiplier / self._ads_speed_mult / self:second_sight_steelsight_mult()
	end

	if not mult_only and managers.player:has_activate_temporary_upgrade("temporary", "single_shot_fast_reload") and 
		self:is_category(unpack(managers.player:upgrade_value("temporary", "single_shot_fast_reload").allowed_categories)) then
		multiplier = multiplier /  (1 + 1 - managers.player:upgrade_value("temporary", "single_shot_fast_reload", 1).ads_mult)
	end
	
	for _, category in ipairs(self:categories()) do
		multiplier = multiplier / (1 + 1 - managers.player:upgrade_value(category, "enter_steelsight_speed_multiplier", 1))
	end
	
	multiplier = multiplier / ( 1 + 1 - managers.player:upgrade_value("weapon", "enter_steelsight_speed_multiplier", 1))

	local fatty = managers.player and managers.player._fat_fuck
	if fatty and not mult_only then
		local current_ads_time = base_transition_dur / multiplier
		local penalty_cap = 0.6
		if current_ads_time < penalty_cap then
			ads_time = math.min(ads_time * 2, penalty_cap)
		end
		multiplier = base_transition_dur / ads_time
	end
	
	return multiplier
end

function NewRaycastWeaponBase:calculate_ammo_max_per_clip()
	local ammo = tweak_data.weapon[self._name_id].CLIP_AMMO_MAX + (self._extra_ammo or 0)
	local ammo_mult = 1
	if not self._starwars then
		ammo_mult = ammo_mult * managers.player:upgrade_value(self._name_id, "clip_ammo_increase", 1)
		if not self:upgrade_blocked("weapon", "clip_ammo_increase") then
			ammo_mult = ammo_mult + ((managers.player:upgrade_value("weapon", "clip_ammo_increase", 1) - 1))
		end
		for _, category in ipairs(tweak_data.weapon[self._name_id].categories) do
			if not self:upgrade_blocked(category, "clip_ammo_increase") then
				ammo_mult = ammo_mult + ((managers.player:upgrade_value(category, "clip_ammo_increase", 1) - 1))
			end
		end
	end
	ammo = ammo * ammo_mult
	ammo = math.round(ammo)
	return ammo
end

function NewRaycastWeaponBase:weapon_range()
	return self._weapon_range or 50000
end

function NewRaycastWeaponBase:_fire_raycast(user_unit, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, shoot_through_data, ammo_usage)
	if self:gadget_overrides_weapon_functions() then
		return self:gadget_function_override("_fire_raycast", self, user_unit, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul)
	end

	self._volley_recoil_mul = nil
	local is_civ_f = CopDamage.is_civilian
	if self._fire_mode == ids_volley then
		local ammo_usage_ratio = math.clamp(ammo_usage > 0 and ammo_usage / (self._volley_ammo_usage or ammo_usage) or 1, 0, 1)
		local rays = math.ceil(ammo_usage_ratio * (self._volley_rays or 1))
		spread_mul = spread_mul * (self._volley_spread_mul or 1)
		dmg_mul = dmg_mul * (self._volley_damage_mul or 1)
		self._volley_recoil_mul = rays or 1
		if self._volley_damage_mul and self._volley_damage_mul_step and self._volley_ammo_usage then
			local dmg_mul_step = self._volley_damage_mul / self._volley_ammo_usage
			dmg_mul = ammo_usage > 0 and ammo_usage * dmg_mul_step
		end
		local count_hits = {}
		local hit_units = {}
		local result = {
			rays = {}
		}

		for i = 1, rays do
			local raycast_res = NewRaycastWeaponBase.super._fire_raycast(self, user_unit, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, true)

			if raycast_res.enemies_in_cone then
				result.enemies_in_cone = result.enemies_in_cone or {}

				table.map_append(result.enemies_in_cone, raycast_res.enemies_in_cone)
			end

			result.hit_enemy = result.hit_enemy or raycast_res.hit_enemy

			table.list_append(result.rays, raycast_res.rays or {})
		end

		for _, hits in ipairs(result.rays) do
			if alive(hits.unit) then
				local unit_base = hits.unit:base()
				local unit_type = unit_base and unit_base._tweak_table
				local is_civilian = unit_type and is_civ_f(unit_type)
				local is_enemy = not is_civilian and (hits.unit:in_slot(self.enemy_mask) or hits.damage_result)
				local key = hits.unit:key()
				if is_enemy and not hit_units[key] then
					hit_units[key] = true
					count_hits[#count_hits + 1] = hits
				end
			end
		end

		managers.statistics:shot_fired({
			hit = result and result.hit_enemy,
			hit_count = #count_hits,
			weapon_unit = self._unit
		})

		return result
	end

	return NewRaycastWeaponBase.super._fire_raycast(self, user_unit, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul)
end


function NewRaycastWeaponBase:get_damage_falloff(damage, col_ray, user_unit, dot_only, ignore_ammo, lerp_mult)
	local is_rapidfire = self._burst_fire_range_multiplier and self:in_burst_mode()
	local is_fullauto = self._auto_fire_range_multiplier and not self:is_single_shot()
	local is_single = self:is_single_shot() and not self:in_burst_mode()
	local main_category = self.AKIMBO and self:categories()[2] or self:categories()[1]
	local damage_min_bonus = 1
	local head_hitboxes = {
		[Idstring("glass_shield"):key()] = true,
		[Idstring("glass_swat"):key()] = true,
		[Idstring("glass_c"):key()] = true,
		[Idstring("glass_d"):key()] = true,
		[Idstring("glass_l"):key()] = true,
		[Idstring("glass_r"):key()] = true,
		[Idstring("visor"):key()] = true,
		[Idstring("sg_mask"):key()] = true,
		[Idstring("glass_altyn"):key()] = true,
		[Idstring("altyn_visor"):key()] = true,
		[Idstring("glass_visor"):key()] = true
	}
	local check_col_ray_head = col_ray and col_ray.unit and col_ray.unit:character_damage() and col_ray.unit:character_damage()._ids_head_body_name and col_ray.body and col_ray.body:name() and col_ray.body:name() == col_ray.unit:character_damage()._ids_head_body_name or head_hitboxes[col_ray.body:name():key()]
	--Initialize base info.

	local has_mindblown_ace = managers.player:has_category_upgrade("player", "headshot_no_falloff") and self:is_single_shot() and self:is_category("assault_rifle", "snp") and check_col_ray_head --and (managers.player._last_no_falloff_headshot_t or 0) < self._unit:timer():time()
	if (self._chf and check_col_ray_head) or --[[not self:in_burst_mode() and not is_rapidfire and]] (not ignore_ammo and self._ammo_data and (self._ammo_data.bullet_class == "InstantExplosiveBulletBase")) or has_mindblown_ace or self:weapon_tweak_data().no_falloff then
		--if has_mindblown_ace then
			--managers.player._last_no_falloff_headshot_t = self._unit:timer():time() + (tweak_data.upgrades.headshot_no_falloff_cd or 0)
		--end
		return damage
	end

	local distance = col_ray.distance or mvector3.distance(col_ray.unit:position(), user_unit:position())
	local current_state = user_unit:movement()._current_state
	local damage_falloff = self:weapon_tweak_data().damage_falloff
	local falloff_start = damage_falloff and damage_falloff.start_dist or 3000
	local falloff_end = damage_falloff and damage_falloff.end_dist or 6000

	--[[
	log("falloff_start : " .. tostring( falloff_start /100 ))
	log("falloff_end : " .. tostring( falloff_end /100 ))
	
	
	log("falloff_start_mult : " .. tostring( self._damage_near_mul ))
	log("falloff_end_mult : " .. tostring( self._damage_far_mul ))
	--]]

	if current_state then
		--Get ADS multiplier.
		for v, category in ipairs(self:categories()) do
			if current_state:in_steelsight() then
				falloff_start = falloff_start * managers.player:upgrade_value(category, "steelsight_range_inc", 1)
				falloff_end = falloff_end * managers.player:upgrade_value(category, "steelsight_range_inc", 1)
			end
			if ((self.AKIMBO and v == 2) or v == 1) and category == main_category then
				damage_min_bonus = damage_min_bonus * managers.player:upgrade_value(category, "damage_min_bonus", 1)
			end
		end
		if current_state:_is_using_bipod() then
			falloff_start = falloff_start * 1.3
			falloff_end = falloff_end * 1.3
		end
	end

	local firemode_range_mod = (is_rapidfire and self._burst_fire_range_multiplier) or (is_fullauto and self._auto_fire_range_multiplier) or (is_single and self._single_fire_range_multiplier) or 1
	falloff_start = falloff_start * firemode_range_mod
	falloff_end = falloff_end * firemode_range_mod
	
	if self._alt_fire_active and self._alt_fire_data and self._alt_fire_data.range_mul then
		falloff_start = falloff_start * self._alt_fire_data.range_mul
		falloff_end = falloff_end * self._alt_fire_data.range_mul
	end

	--Apply global range multipliers.
	falloff_start = falloff_start * (1 + 1 - managers.player:get_property("desperado", 1))
	falloff_end = falloff_end * (1 + 1 - managers.player:get_property("desperado", 1))
	
	--[[
	log("falloff_start AFTER MULTS : " .. tostring( (falloff_start * self._damage_near_mul) / 100 ))
	log("falloff_end AFTER MULTS: " .. tostring( (falloff_end * self._damage_far_mul )/ 100))
	--]]
	
	falloff_start = falloff_start * self._damage_near_mul
	falloff_end = falloff_end * self._damage_far_mul

	local second_sight_falloff_mult = self.second_sight_falloff_mult and self:second_sight_falloff_mult()
	if second_sight_falloff_mult then
		falloff_start = falloff_start * second_sight_falloff_mult
		falloff_end = falloff_end * second_sight_falloff_end_mult
	else
		local second_sight_falloff_start_mult = self.second_sight_falloff_start_mult and self:second_sight_falloff_start_mult()
		local second_sight_falloff_end_mult = self.second_sight_falloff_end_mult and self:second_sight_falloff_end_mult()
		if second_sight_falloff_start_mult then
			falloff_start = falloff_start * second_sight_falloff_start_mult
		end
		if second_sight_falloff_end_mult then
			falloff_end = falloff_end * second_sight_falloff_end_mult
		end
	end

	if dot_only then
		falloff_start = falloff_start * self._duration_falloff_start_mult
		falloff_end = falloff_end * self._duration_falloff_end_mult
	end
	
	if lerp_mult then
		falloff_end = math.lerp(falloff_start, falloff_end, math.max(lerp_mult, 0))
	end

	--Cache falloff values for usage in hitmarkers.
	self.near_falloff_distance = falloff_start
	self.far_falloff_distance = falloff_end
	
	--Minimum damage multiplier when taking falloff into account
	local minimum_damage = damage_falloff and damage_falloff.min_mult or 0.3
	
	--Have a harsher falloff for Shotguns
	if self._rays and self._rays > 1 then
		if damage_falloff and damage_falloff.ignore_rays then
		else
			minimum_damage = 0.05 * damage_min_bonus
		end
	end

	local damage_min_mult = self._damage_min_mult

	local second_sight_damage_min_mult = self.second_sight_damage_min_mult and self:second_sight_damage_min_mult()
	if second_sight_damage_min_mult then
		damage_min_mult = damage_min_mult * second_sight_damage_min_mult
	end


	minimum_damage = ( minimum_damage * (damage_min_mult or 1)) / managers.player:temporary_upgrade_value("temporary", "overkill_damage_multiplier", 1)
	
	--[[
	log("DAMAGE: " .. tostring( damage * 10 ))
	log("DAMAGE MIN: " .. tostring( damage * minimum_damage * 10 ))
	log("HIT AT: " .. tostring( distance / 100 ) .. " METERS")
	log("DAMAGE DONE: " .. tostring( (math.max((1 - math.min(1, math.max(0, distance - falloff_start) / (falloff_end - falloff_start))) * damage, minimum_damage * damage)) * 10 ) .. "\n\n")
	--]]

	--Compute final damage.
	return math.lerp(damage, minimum_damage * damage, math.min(1, math.max(0, distance - falloff_start) / (falloff_end - falloff_start)))
end

function NewRaycastWeaponBase:give_reload_t(not_empty)
	local time = (not_empty and self:weapon_tweak_data().timers.reload_not_empty or 2.2) or (self:weapon_tweak_data().timers.reload_empty or 2.6)
	return time
end

function NewRaycastWeaponBase:reload_exit_expire_t()
	if not self._use_shotgun_reload then
		return self._alt_reload_exit_empty or self:weapon_tweak_data().timers.reload_exit_empty or 0
	end
	return self:weapon_tweak_data().timers.shotgun_reload_exit_empty or 0.7
end

function NewRaycastWeaponBase:reload_not_empty_exit_expire_t()
	if not self._use_shotgun_reload then
		return self._alt_reload_exit_not_empty or self:weapon_tweak_data().timers.reload_exit_not_empty or 0
	end
	return self:weapon_tweak_data().timers.shotgun_reload_exit_not_empty or 0.3
end

function NewRaycastWeaponBase:exit_run_speed_multiplier()
	local multiplier = 1
	local sprintout_anim_time = self:weapon_tweak_data().sprintout_anim_time or 0.4
	local ads_speed = self:weapon_tweak_data().ads_speed or 0.200

	for _, category in ipairs(self:categories()) do
		multiplier = multiplier * managers.player:upgrade_value(category, "exit_run_speed_multiplier", 1)
	end
	multiplier = multiplier * managers.player:upgrade_value("weapon", "exit_run_speed_multiplier", 1)
	multiplier = multiplier * managers.player:upgrade_value(self._name_id, "exit_run_speed_multiplier", 1)

	--multiplier = multiplier / ( (self:weapon_tweak_data().sprintout_time or 0.300) / (self:weapon_tweak_data().sprintout_anim_time or 0.350) )
	multiplier = multiplier / ( (ads_speed / self:enter_steelsight_speed_multiplier(true)) * 1 / sprintout_anim_time )
	return math.max( 0.01, multiplier)
end


local scope_colors = {
	green = Color(0, 1, 0),
	greenmid = Color(1, 0.5, 0),
	greenlow = Color(1, 0, 0),
	greenno = Color(1, 0, 1),
	red = Color(1, 0, 0),
	redmid = Color(1, 0, 1),
	redlow = Color(0, 0, 1),
	redno = Color(0, 1, 1),
	off = Color(0, 0, 0, 0),
}
function NewRaycastWeaponBase:set_scope_range_distance(distance)
	if not self._assembly_complete then
		return
	end
	
	local damage_falloff = self:weapon_tweak_data().damage_falloff
	local green_display = self:weapon_tweak_data().green_display
	local falloff_start = damage_falloff and damage_falloff.start_dist or 3000
	local falloff_end = damage_falloff and damage_falloff.end_dist or 6000
	falloff_start = falloff_start * (self._damage_near_mul or 1)
	falloff_end = falloff_end * (self._damage_near_mul or 1)
	local is_visible = nil
	local is_player = self._setup.user_unit == managers.player:player_unit()
	local steelsight_swap_state = false

	if is_player then
		steelsight_swap_state = self._setup.user_unit:camera() and alive(self._setup.user_unit:camera():camera_unit()) and self._setup.user_unit:camera():camera_unit():base():get_steelsight_swap_state() or false
	end

	if self._scopes and self._parts then
		local part = nil

		for i, part_id in ipairs(self._scopes) do
			part = self._parts[part_id]   

			local digital_gui = part and part.unit:digital_gui()

			is_visible = (part and (part.steelsight_visible == nil or part.steelsight_visible == steelsight_swap_state)) or nil

			if digital_gui and digital_gui.number_set then
				part.unit:digital_gui():number_set(distance and math.round(distance) or false, false)
				local dist = distance and distance * 100
				if not dist then
					part.unit:digital_gui()._title_text:set_color( not is_visible and scope_colors.off or green_display and scope_colors.greenno or scope_colors.redno )
				elseif dist < falloff_start then
					part.unit:digital_gui()._title_text:set_color( not is_visible and scope_colors.off or green_display and scope_colors.green or scope_colors.red )
				elseif dist < falloff_end then
					part.unit:digital_gui()._title_text:set_color( not is_visible and scope_colors.off or green_display and scope_colors.greenlow or scope_colors.redlow )
				else
					part.unit:digital_gui()._title_text:set_color( not is_visible and scope_colors.off or green_display and scope_colors.greenmid or scope_colors.redmid )
				end
			end

			local digital_gui_upper = part and part.unit:digital_gui_upper()

			if digital_gui_upper and digital_gui_upper.number_set then
				part.unit:digital_gui_upper():number_set(distance and math.round(distance) or false, false)
				local dist = distance and distance * 100
				if not dist then
					part.unit:digital_gui_upper()._title_text:set_color( not is_visible and scope_colors.off or scope_colors.greenno )
				elseif dist < falloff_start then
					part.unit:digital_gui_upper()._title_text:set_color( not is_visible and scope_colors.off or scope_colors.green )
				elseif dist < falloff_end then
					part.unit:digital_gui_upper()._title_text:set_color( not is_visible and scope_colors.off or scope_colors.greenlow )
				else
					part.unit:digital_gui_upper()._title_text:set_color( not is_visible and scope_colors.off or scope_colors.greenmid )
				end
			end
		end
	end
end

function NewRaycastWeaponBase:damage_multiplier()
	local user_unit = self._setup and self._setup.user_unit
	local current_state = alive(user_unit) and user_unit:movement() and user_unit:movement()._current_state
	local multiplier = managers.blackmarket:damage_multiplier(self._name_id, self:categories(), self._silencer, nil, current_state, self._blueprint)

	if self._alt_fire_active and self._alt_fire_data then
		multiplier = multiplier * (self._alt_fire_data.damage_mul or 1)
		multiplier = multiplier * self._alt_dmg_mult
	end

	return multiplier
end

--Fix for reload objects not appearing
function NewRaycastWeaponBase:set_reload_objects_visible(visible, anim)
	local data = tweak_data.weapon.factory[self._factory_id]
	local ignore_reload_objects_empty = self:weapon_tweak_data().ignore_reload_objects_empty
	local ignore_reload_objects_not_empty = self:weapon_tweak_data().ignore_reload_objects_not_empty
	local reload_objects = anim and data.reload_objects and data.reload_objects[anim]
	if not anim or (anim and ( (not ignore_reload_objects_not_empty and anim == "reload_not_empty") or (not ignore_reload_objects_empty and anim == "reload") )) then
		if reload_objects then
			self._reload_objects[self._name_id] = reload_objects
		elseif self._reload_objects then
			reload_objects = self._reload_objects[self.name_id]
		end
	
		if reload_objects then
			self:set_objects_visible(self._unit, reload_objects, visible)
		end
	
		for part_id, part in pairs(self._parts) do
			local reload_objects = anim and part.reload_objects and part.reload_objects[anim]
	
			if reload_objects then
				self._reload_objects[part_id] = reload_objects
			elseif self._reload_objects then
				reload_objects = self._reload_objects[part_id]
			end
	
			if reload_objects and part.unit then
				self:set_objects_visible(part.unit, reload_objects, visible)
			end
		end
	end
end

--Fix to remember burst mode
function NewRaycastWeaponBase:record_fire_mode()
	self._recorded_fire_modes = self._recorded_fire_modes or {}
	self._recorded_burst_mode = self:in_burst_mode()
	self._recorded_fire_modes[self:_weapon_tweak_data_id()] = self._fire_mode
end

function NewRaycastWeaponBase:get_recorded_fire_mode(id)
	if self._recorded_fire_modes and self._recorded_fire_modes[self:_weapon_tweak_data_id()] then
		if self._recorded_burst_mode and self._recorded_burst_mode == true then
			self:_set_burst_mode(true, true)
		end
		return self._recorded_fire_modes[self:_weapon_tweak_data_id()]
	end

	return nil
end

--Maybe hopefully fix the ammo eff. aced skill crash
function NewRaycastWeaponBase:_update_bullet_objects(ammo_func)
	if self._bullet_objects and not self:is_npc() and not self._starwars then
		for i, objects in pairs(self._bullet_objects) do
			for _, object in ipairs(objects) do
				local ammo_base = self:ammo_base()
				local ammo = ammo_base[ammo_func](ammo_base)
				if alive(object[1]) then
					if object[1].set_visibility then
						object[1]:set_visibility(i <= ammo)
					end
				end
			end
		end
	end
end

function NewRaycastWeaponBase:can_shoot_through_titan_shield()
	local fire_mode_data = self._fire_mode_data[self._fire_mode:key()]

	return fire_mode_data and fire_mode_data.can_shoot_through_titan_shield or self._can_shoot_through_titan_shield
end
function NewRaycastWeaponBase:can_shoot_through_enemy_unlim()
	local fire_mode_data = self._fire_mode_data[self._fire_mode:key()]

	return fire_mode_data and fire_mode_data.can_shoot_through_enemy_unlim or self._can_shoot_through_enemy_unlim
end


function NewRaycastWeaponBase:can_shoot_through_enemy()
	local can_shoot_through_enemy = nil
	--[[
	if self:fire_mode() == "auto" then
		for _, category in ipairs(self:categories()) do
			if managers.player:has_category_upgrade(category, "automatic_can_shoot_through_enemy") then
				can_shoot_through_enemy = true
				self._shoot_through_enemy_max_stacks = managers.player:upgrade_value(category, "automatic_can_shoot_through_enemy")[1]
				self._shoot_through_enemy_dmg_mult = managers.player:upgrade_value(category, "automatic_can_shoot_through_enemy")[2]
			end
		end
	end
	--]]
	if self._ammo_data and self._ammo_data.bullet_class ~= "InstantExplosiveBulletBase" then
		for _, category in ipairs(self:categories()) do
			if managers.player:has_category_upgrade(category, "can_shoot_through_enemy") then
				if self._rays > 1 then
					can_shoot_through_enemy = true
					break --you can already do it, stop the checks
				end
			end
		end
	end

	return can_shoot_through_enemy or self._can_shoot_through_enemy
end

-- 10th Anniversary Mutator Ammo
function NewRaycastWeaponBase:ammo_type_buff_add(ammo_id, ammo_buff_data)
	if self._buffs_data and self._buffs_data[ammo_id] then
		return
	end

	local change_data = {}

	if ammo_buff_data.extra_collisions then
		for class_name, collision_data in pairs(ammo_buff_data.extra_collisions) do
			local bullet_class = CoreSerialize.string_to_classtable(class_name)

			if bullet_class then
				self._extra_collisions = self._extra_collisions or {}
				self._extra_collisions[#self._extra_collisions + 1] = {
					bullet_class = bullet_class,
					dmg_mul = collision_data.dmg_mul,
					fire_dot_data = collision_data.fire_dot_data
				}
				change_data.collisions = change_data.collisions or {}

				table.insert(change_data.collisions, #self._extra_collisions)
			end
		end
	end

	if next(change_data) then
		self._buffs_data = self._buffs_data or {}
		self._buffs_data[ammo_id] = change_data
	end
end

function NewRaycastWeaponBase:ammo_type_buff_remove(ammo_id)
	local buff_data = self._buffs_data and self._buffs_data[ammo_id]

	if not buff_data then
		return
	end

	self._buffs_data[ammo_id] = nil

	if not next(self._buffs_data) then
		self._buffs_data = nil
	end

	if self._extra_collisions then
		for i, col_i in ipairs(buff_data.collisions) do
			self._extra_collisions[col_i] = nil
		end

		if not next(self._extra_collisions) then
			self._extra_collisions = nil
		end
	end
end

function NewRaycastWeaponBase:extra_collisions()
	return self._extra_collisions
end

function NewRaycastWeaponBase:_set_parts_enabled(enabled)
	if self._parts then
		local anim_groups = nil
		local empty_s = Idstring("")

		for part_id, data in pairs(self._parts) do
			if alive(data.unit) then
				if not enabled and (not data.unit:base() or (data.unit:base().GADGET_TYPE ~= "second_sight" and data.unit:base().GADGET_TYPE ~= "simple_anim")) then
					anim_groups = data.unit:anim_groups()
					for _, anim in ipairs(anim_groups) do
						if anim ~= empty_s then
							data.unit:anim_play_to(anim, 0)
							data.unit:anim_stop()
						end
					end
				end

				data.unit:set_enabled(enabled)

				if data.unit:digital_gui() then
					data.unit:digital_gui():set_visible(enabled)
				end

				if data.unit:digital_gui_upper() then
					data.unit:digital_gui_upper():set_visible(enabled)
				end

				if data.unit:digital_gui_thd() then
					data.unit:digital_gui_thd():set_visible(enabled)
				end
			end
		end
	end
end

function NewRaycastWeaponBase:_set_parts_visible(visible)
	if self._parts then
		local empty_s = Idstring("")
		local anim_groups, is_visible = nil
		local is_player = self._setup.user_unit == managers.player:player_unit()
		local steelsight_swap_state = false

		if is_player then
			steelsight_swap_state = self._setup.user_unit:camera() and alive(self._setup.user_unit:camera():camera_unit()) and self._setup.user_unit:camera():camera_unit():base():get_steelsight_swap_state() or false
		end

		for part_id, data in pairs(self._parts) do
			local unit = data.unit or data.link_to_unit

			if alive(unit) then
				is_visible = visible and self:_is_part_visible(part_id)
				is_visible = is_visible and (self._parts[part_id].steelsight_visible == nil or self._parts[part_id].steelsight_visible == steelsight_swap_state)

				unit:set_visible(is_visible)

				if not visible and (not unit:base() or (unit:base().GADGET_TYPE ~= "second_sight" and unit:base().GADGET_TYPE ~= "simple_anim")) then
					anim_groups = unit:anim_groups()

					for _, anim in ipairs(anim_groups) do
						if anim ~= empty_s then
							unit:anim_play_to(anim, 0)
							unit:anim_stop()
						end
					end
				end

				if unit:digital_gui() then
					unit:digital_gui():set_visible(visible)
				end

				if unit:digital_gui_upper() then
					unit:digital_gui_upper():set_visible(visible)
				end

				if unit:digital_gui_thd() then
					unit:digital_gui_thd():set_visible(visible)
				end
			end
		end
	end

	self:_chk_charm_upd_state()
end

-- Adds context to the highlighting to support marking enemies through walls in Pro Job.
function NewRaycastWeaponBase:check_highlight_unit(unit)
	if not self._can_highlight then
		return
	end

	if not self._can_highlight_with_skill and self:is_second_sight_on() then
		return
	end

	if unit:in_slot(8) and alive(unit:parent()) then
		unit = unit:parent() or unit
	end

	if not unit or not unit:base() then
		return
	end

	if unit:character_damage() and unit:character_damage().dead and unit:character_damage():dead() then
		return
	end

	local is_enemy_in_cool_state = managers.enemy:is_enemy(unit) and not managers.groupai:state():enemy_weapons_hot()

	if not is_enemy_in_cool_state and not unit:base().can_be_marked then
		return
	end

	managers.game_play_central:auto_highlight_enemy(unit, true, "steelsight")
end

local g3_niphen = restoration.Options:GetValue("WEAPONS/WEAPONANIMS/g3_niphen")

Hooks:PostHook(NewRaycastWeaponBase, "weapon_tweak_data", "res_weapon_tweak_data", function(self)
	local wtd = NewRaycastWeaponBase.super.weapon_tweak_data(self)

	if not self._parts then
		return wtd
	end

	if self._name_id == "ar23" and self._parts then
		local is_carbine = self._parts.wpn_fps_ck_ar23a
		local has_drum = self._parts.wpn_fps_ass_ar23_m_drum
		wtd.animations.reload_name_id = "ar23" .. ((is_carbine and "a") or "") .. ((has_drum and "_drum") or "")
	end

	if not g3_niphen and BeardLib.Utils:FindMod("JustAnotherG3 Reload") and self._name_id == "g3" then
		if self._parts.wpn_fps_ass_g3_b_sniper then 
			wtd.animations.reload_name_id = "g3_psg"
		elseif self._parts.wpn_fps_ass_g3_b_long or self._parts.wpn_fps_ass_g3_b_short then
			wtd.animations.reload_name_id = "g3_long"
		else
			wtd.animations.reload_name_id = "g3"
		end
	end

	return wtd
end)