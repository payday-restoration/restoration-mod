MutatorCloakerEffect.reductions = {money = 0, exp = 0}
MutatorCloakerEffect.disables_achievements = false