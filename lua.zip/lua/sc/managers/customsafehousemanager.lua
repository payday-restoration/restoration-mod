 if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then
 
	 function CustomSafehouseManager:is_being_raided()
		return false 
	 end
	 
end	 