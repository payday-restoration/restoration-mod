if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then

	MutatorEnemyDamage.reductions = {money = 0, exp = 0}
	MutatorEnemyDamage.disables_achievements = false

end