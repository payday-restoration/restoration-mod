function ModifierLessPagers:init(data)
end