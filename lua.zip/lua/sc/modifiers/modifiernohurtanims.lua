if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then

	ModifierNoHurtAnims.IgnoredHurtTypes = {
		"heavy_hurt"
	}

end