MutatorHydra.reductions = {money = 0, exp = 0}
MutatorHydra.disables_achievements = false