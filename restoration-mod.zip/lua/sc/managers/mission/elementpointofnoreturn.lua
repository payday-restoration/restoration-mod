local difficulty = Global.game_settings and Global.game_settings.difficulty or "normal"
local to_replace_key = "time_" .. difficulty

Hooks:PreHook(ElementPointOfNoReturn, "operation_add", "res_operation_add", function(self)
	self._values.original_time = self._values[to_replace_key] or self._values.time_hard
	self._values.time_balance_mul = self._values.time_balance_mul or { 1, 1, 1, 1, }
	if self._values.original_time then
		local balance_mul, include_team_ai = self._values.time_balance_mul, self._values.time_balance_mul_include_team_ai
		local final_mul = managers.groupai:state():_get_balancing_multiplier(balance_mul, include_team_ai) or balance_mul[#balance_mul] or 1
		self._values[to_replace_key] = self._values.original_time * final_mul
	end
end)
