function NetworkPeer:_update_equipped_armor()
	if not alive(self._unit) then
		return
	end

	local new_armor_id = self:armor_id(true) or self:armor_id()

	print("[NetworkPeer:update_equipped_armor]", "equipped_armor", self._equipped_armor_id, "new_armor", new_armor_id)

	if self._equipped_armor_id ~= new_armor_id then
		self._equipped_armor_id = new_armor_id
		
		--[[
		
		local armor_sequence = tweak_data.blackmarket.armors[new_armor_id].sequence
		local job = Global.level_data and Global.level_data.level_id

		for _,v in pairs(restoration.custom_suit_heists) do
			if job == v then
				armor_sequence = nil
			break
			end
		end

		if armor_sequence and self._unit:damage() and self._unit:damage():has_sequence(armor_sequence) then
			self._unit:damage():run_sequence_simple(armor_sequence)
		end

		if self._unit:base() and self._unit:base().set_armor_id then
			self._unit:base():set_armor_id(new_armor_id)
		end

		if self._unit:armor_skin() and self._unit:armor_skin().set_armor_id then
			self._unit:armor_skin():set_armor_id(new_armor_id)
		end
		
		]]--

		local con_mul, index = managers.blackmarket:get_concealment_of_peer(self)

		self._unit:base():set_suspicion_multiplier("equipment", 1 / con_mul)
		self._unit:base():set_detection_multiplier("equipment", 1 / con_mul)
		self._unit:base():setup_hud_offset(self)
	end
end

function NetworkPeer:mark_cheater(reason, auto_kick)
	--fuck
	return
end

Hooks:PostHook(NetworkPeer, "set_outfit_string", "res_set_outfit_string", function(self, outfit_string)

	if restoration.Options:GetValue("LogOutfitStrings") then
		restoration:log("[OUTFIT SET] peer id: " .. tostring(self._id))
		restoration:log("[OUTFIT SET] local peer id: " .. tostring(managers.network:session():local_peer():id()))
		restoration:log("[OUTFIT SET] outfit_string: " .. tostring(outfit_string))

		restoration:log(debug.traceback())
	end

end)

Hooks:PostHook(NetworkPeer, "sync_data", "res_sync_data", function(self, peer)
	if Network:is_server() then
		managers.enemy:update_intimidated_guard_data_to_peer(peer)
	end
end)

-- Hooks:PostHook( NetworkPeer, "send", "SC_Network", function(self, func_name, ...)
-- 	-- In SC mode if the func is matched, call the prefixed version instead
-- 	if restoration.network_handler_funcs[func_name] then
-- 		func_name = 'RestorationMod__' .. func_name
-- 	end
-- end)


function NetworkPeer:destroy()
	local _ = managers.wait and managers.wait:remove_waiting(self:id())

	print("[NetworkPeer:destroy]", self:id())

	if self._rpc then
		Network:reset_connection(self._rpc)

		if managers.network.voice_chat.on_member_removed then
			managers.network.voice_chat:on_member_removed(self)
		end
	end
	
	self._loading_outfit_assets = nil --add this
	self:_unload_outfit()
end