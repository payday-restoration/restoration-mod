if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then

	MutatorCloakerEffect.reductions = {money = 0, exp = 0}
	MutatorCloakerEffect.disables_achievements = false

end