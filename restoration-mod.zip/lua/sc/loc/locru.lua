--- Заметка тому, кто будет дальше копаться в это ебаном рулоке - развлекайтесь, пока можете. Проклятье Параши 2 все ещё живо.
--- А, ещё не используйте букву "ё" - без модов буква неверно отображается.

Month = os.date("%m")
Day = os.date("%d")
local easterless = restoration and restoration.Options:GetValue("OTHER/GCGPYPMMSAC")

-- Настройки
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Settings", function(loc)
	LocalizationManager:add_localized_strings({
		["RestorationModOptionsButtonTitleID"] = "Настройки Restoration Mod",
		["RestorationModOptionsButtonDescID"] = "Настройки для Restoration Mod.",
		["RestorationModHUDOptionsButtonTitleID"] = "Настройки интерфейса Restoration Mod",
		["RestorationModHUDOptionsButtonDescID"] = "Настройки интерфейса в Restoration Mod.",
		["RestorationModOTHEROptionsButtonTitleID"] = "Дополнительные настройки Restoration Mod",
		["RestorationModOTHEROptionsButtonDescID"] = "Дополнительные настройки Restoration Mod.",
		["RestorationModWeaponHandlingOptionsButtonTitleID"] = "+++ Настройки оружия +++",
		["RestorationModWeaponHandlingOptionsButtonDescID"] = "Опции, связанные с оружием.",
		["RestorationModUIOptionsButtonTitleID"] = "Alpha UI",
		["RestorationModUIOptionsButtonDescID"] = "Опции Alpha UI.",
		["RestorationModTimeOfDayTitleID"] = "Новые и случайные времена суток",
		["RestorationModTimeOfDayDescID"] = "Позволяет настраивать время суток на некоторых ограблениях.",
		["RestorationModOtherModsTitleID"] = "=== Настройки для других модов ===",
		["RestorationModOtherModsDescID"] = "Дополнительные настройки для других модов",
		["RestorationModAdVMovResOptOptionsButtonTitleID"] = "Настройки \"Advanced Movement Standalone\"",
		["RestorationModAdVMovResOptOptionsButtonDescID"] = "Дополнительные настройки мода \"Advanced Movement Standalone\"  от Solo Queue Pixy's.",
		["RestorationModDisableAdvMovTFTitleID"] = "Отключить бег и прыжки по стенам",
		["RestorationModDisableAdvMovTFDescID"] = "Отключает бег и прыжки по стенам, которые являются частью Advanced Movement мода.",
		["RestorationModAdvMovMeleeTitleID"] = "Оружие ближ. боя",
		["RestorationModAdvMovMeleeDescID"] = "Меняет поведение оружия ближ. боя от мода Advanced Movement (прыжки/подкаты/рывки/удар с разбега).",
			["resmod_advmov_melee_on"] = "По умолчанию",
			["resmod_advmov_melee_loud_only"] = "Во время громкого подхода",
			["resmod_advmov_melee_off"] = "Выключено",
		
		["RestorationModHearNonLocalPECMTitleID"] = "Звуки карманного ГП от других игроков",
		["RestorationModHearNonLocalPECMDescID"] = "Проигрывать звуки работающего КГП при активации его другим игроком.",
		["RestorationModAltLastDownColorTitleID"] = "Другой фильтр для последнего падения",
		["RestorationModAltLastDownColorDescID"] = "Переключает цветовой фильтр при последнем падении на color_sin_classic.",
		["RestorationModNoBleedoutTiltTitleID"] = "Отключить наклон камеры при падении",
		["RestorationModNoBleedoutTiltDescID"] = "Отключает наклон камеры, который происходит после падения.",
		["RestorationModGOTTAGETAGRIPTitleID"] = "Спрятать все рукоятки",
		["RestorationModGOTTAGETAGRIPDescID"] = "Прячет все вертикальные рукоятки в меню установки модификаций; не действует на оружие с предустановленной рукоятью. Требуется перезапуск.",
		["RestorationModADSTransitionStyleTitleID"] = "Стиль прицеливания",
		["RestorationModADSTransitionStyleDescID"] = "Выбор \"анимации\" прицеливания.",
		["RestorationModGCGPYPMMSACTitleID"] = "Сурьезный режим",
		["RestorationModGCGPYPMMSACDescID"] = "Отключает плазменные трассеры и регенерацию патронов от некоторых модулей. Требует перезапуска ограбления.",
		["RestorationModGCGPYPMMSACTextTitleID"] = "Сурьезный текст",
		["RestorationModGCGPYPMMSACTextDescID"] = "Выключает все текстовые пасхалки. Требует перезапуска ограбления.",
		["RestorationModForceEggsOptionsButtonTitleID"] = "",
		["RestorationModForceEggsOptionsButtonDescID"] = "",
		["RestorationModUpotteTitleID"] = "",
		["RestorationModUpotteDescID"] = "",
		["RestorationModCrabBattleTitleID"] = "",
		["RestorationModCrabBattleDescID"] = "",
		["RestorationModEmberMyBelovedTitleID"] = "",
		["RestorationModEmberMyBelovedDescID"] = "",
		["RestorationModBigManTitleID"] = "",
		["RestorationModBigManDescID"] = "",
		["RestorationModStaticAimTitleID"] = "Покачивание в прицеле",
		["RestorationModStaticAimDescID"] = "Включает визуальное покачивание во время прицеливания. Требуется перезапуск. ПРИ ОТКЛЮЧЕНИИ, НЕКОТОРУЮ ОПТИКУ БУДЕТ НЕВОЗМОЖНО ИСПОЛЬЗОВАТЬ.",
		["RestorationModViewmodelMovementTitleID"] = "Движение вьювмоделей",
		["RestorationModViewmodelMovementDescID"] = "Стиль движения моделей оружия при кручении камеры. Требует перезапуск.",
		["vm_vanilla"] = "Ванильное",
		["vm_drag"] = "Оружие отстает",
		["vm_lead"] = "Оружие опережает",
		["vm_static"] = "Без движения",
		["RestorationModCarpalTunnelTitleID"] = "Компенсация отдачи",
		["RestorationModCarpalTunnelDescID"] = "Оружие возвращается в изначальное положение, как в ванильной игре.",
		["rr_off"] = "Нет",
		["rr_per_weapon"] = "Частичная",
		["rr_full"] = "Полная",
		["RestorationModWpnCatTitleID"] = "Сортировка меню оружия",
		["RestorationModWpnCatDescID"] = "Изменить порядок оружия в меню покупки. Требуется перезапуск.",
		["RestorationModAutoDMRsTitleID"] = "Авто. марксманские винтовки",
		["RestorationModAutoDMRsDescID"] = "Марксманские винтовки будут сразу установлены в автоматический режим.",
		["RestorationModWpnFireDescopeTitleID"] = "Выход из прицеливания для некоторых оружий",
		["RestorationModWpnFireDescopeDescID"] = "Позволяет временно выйти из режима прицеливания во время стрельбы, чтобы не было ситуаций, когда руки во время анимации проходили через камеру игрока.\nНе работает для оружий, у которых в описании написано про выход из режима прицеливания.",
		["RestorationModSprintCancelTitleID"] = "'Изворотливый' отменяет перезарядку",
		["RestorationModSprintCancelDescID"] = "Пиковый навык \"Изворотливый\" отменит перезарядку при начале бега. Перезарядка во время бега не отменяется.",
		["RestorationModSevenHoldTitleID"] = "Липкие интеракции (Press2Hold)",
		["RestorationModSevenHoldDescID"] = "Для интеракций больше не требуется держать клавишу.",
		["RestorationModSevenHoldDeployCancelTitleID"] = "Снаряжение отменяет интеракцию",
		["RestorationModSevenHoldDeployCancelDescID"] = "Кнопка снаряжения будет отменять текущую интеракцию. Требует включения Липких интеракций.",
		["RestorationModQueuedShootingTitleID"] = "Очередь нажатий",
		["RestorationModQueuedShootingDescID"] = "Включить/выключить занос нажатия на курок в очередь для полуавтоматического оружия.\nПри использовании этой функции выключает оригинальную (ванильную) версию этой настройки.",
		["RestorationModQueuedShootingWindowTitleID"] = "Чувствительность очереди",
		["RestorationModQueuedShootingWindowDescID"] = "Время, которое ваши нажатия будут в очереди, в зависимости от задержки оружия. Чем выше, тем раньше нажатия попадут в очередь.",
		["RestorationModPerformanceOptionsButtonTitleID"] = "++ Impact FX Settings ++",
			["RestorationModPerformanceOptionsButtonDescID"] = "Extra options that change the playback of impact effects",
				["RestorationModQueuedImpactFXLimitEnabledTitleID"] = "Enable 'Impact FX Queue Limit'",
				["RestorationModQueuedImpactFXLimitEnabledDescID"] = "Toggle if the below 'Impact FX Queue Limit' setting is enabled or not; only applies to queued impact FX.\nDisabled by default",
					["RestorationModQueuedImpactFXLimitTitleID"] = "Impact FX Queue Limit",
					["RestorationModQueuedImpactFXLimitDescID"] = "Limits the amount of impact effects that can be queued at once; Default is 24.\nHigh values can lead to playback delays while low values can lead to FX-less impacts.",
		["RestorationModQueuedShootingExcludeTitleID"] = "Ограничение очереди",
		["RestorationModQueuedShootingExcludeDescID"] = "Ограничивает очередь для оружия, которое стреляет быстрее, чем указано в этой настройке.",
		["RestorationModQueuedShootingMidBurstTitleID"] = "Очередь нажатий во время стрельбы оружейной очередью",
		["RestorationModQueuedShootingMidBurstDescID"] = "Заносит нажатия на курок в очередь, если они были сделаны во время стрельбы оружейной очередью.",
		["RestorationModQueuedShootingBurstExcludeTitleID"] = "Ограничение для стрельбы очередями",
		["RestorationModQueuedShootingBurstExcludeDescID"] = "Ограничивает занесение нажатий в очередь, сделанных во время стрельбы очередью из огнестрела, для тех оружий, задержка которых ниже, чем выставленная этой настройкой.",
		["RestorationModNoADSRecoilAnimsTitleID"] = "Отключить отдачу в прицеле",
		["RestorationModNoADSRecoilAnimsDescID"] = "Отключает анимацию отдачи во время прицеливания. Опция не влияет на некоторое оружие (луки, огнеметы)",
		["RestorationModNoSwapOnReviveTitleID"] = "Отключить переключение оружия после того, как вы встали",
		["RestorationModNoSwapOnReviveDescID"] = "Когда вас поднимут, оружие больше не будет переключаться с вторичного на основное.",
		["RestorationModProjectileMagnetismTitleID"] = "Projectile Magnetism",
		["RestorationModProjectileMagnetismDescID"] = "Toggles the magnetism/tracking effect of non-explosive projectiles.",
		["RestorationModManualReloadsTitleID"] = AFR and "Перезарядка вручную (КОНФЛИКТ МОДОВ)" or "Перезарядка вручную",
		["RestorationModManualReloadsDescID"] = AFR and "У вас установлен \"Auto Fire & Reload\": эта опция не работает." or "Выключает автоматическую перезарядку, когда магазин оружия пуст.",
		["RestorationModSecondSightSprintTitleID"] = "Кнопка бега включает второй прицел",
		["RestorationModSecondSightSprintDescID"] = "Переключаться между прицелами с помощью кнопки бега, а не гаджета. С этой настройкой нельзя использовать бег во время прицеливания, а кнопка гаджета будет включать и выключать гаджеты даже во время прицеливания.",
		["RestorationModAimDeploysBipodTitleID"] = "Прицеливание с сошками",
		["RestorationModAimDeploysBipodDescID"] = "Кнопка прицеливания развернет сошки, если имеется такая возможность.",
		["RestorationModMoveCancelBipodTitleID"] = "Движение убирает сошки",
		["RestorationModMoveCancelBipodDescID"] = "Клавиши движения развернут сошки.",
		["RestorationModSeparateBowADSTitleID"] = "Прицеливание луков",
		["RestorationModSeparateBowADSDescID"] = "Отключает автоматическое прицеливание при стрельбе из лука. Клавиша перезарядки опускает заряженную стрелу.",
		["RestorationModClassicMoviesTitleID"] = "Классический фон подготовки",
		["RestorationModClassicMoviesDescID"] = "Включить или выключить фон экрана подготовки из PD:TH при игре на Классических ограблениях.",
		
		["RestorationModPaintingsTitleID"] = "Вырезанные картины в Картинной галерее",
		["RestorationModPaintingsDescID"] = "Включает или выключает отображение вырезанных картин на ограблении “Картинная галерея”. Работает только для хоста.",
		["RestorationModMainHUDTitleID"] = "Alpha HUD - ВКЛ/ВЫКЛ",
		["RestorationModMainHUDDescID"] = "Полностью включает или выключает интерфейс из альфа-версии игры.",
		["RestorationModWaypointsTitleID"] = "Иконки целей из Альфы",
		["RestorationModWaypointsDescID"] = "Включить или выключить иконки, указывающие на текущую цель из альфа-версии игры.",
		["RestorationModAssaultPanelTitleID"] = "Лента штурма из Альфы",
		["RestorationModAssaultPanelDescID"] = "Включить или выключить ленту штурма из альфа-версии игры.",
		["RestorationModAltAssaultTitleID"] = "Индикатор штурма из ранней Альфы",
		["RestorationModAltAssaultDescID"] = "Включить или выключить индикатор штурма из ранней альфа-версии игры. Заменяет ленту штурма.",
		["RestorationModObjectivesPanelTitleID"] = "Панель задач из Альфы",
		["RestorationModObjectivesPanelDescID"] = "Включить или выключить панель задач из альфа-версии игры.",
		["RestorationModPresenterTitleID"] = "Презентер из Альфы",
		["RestorationModPresenterDescID"] = "Включить или выключить презентер из альфа-версии игры, который используется при захвате добычи и для напоминания о задачах.",
		["RestorationModInteractionTitleID"] = "Шкала интеракции из Альфы",
		["RestorationModInteractionDescID"] = "Включить или выключить шкалу интеракции из альфа-версии игры.",
		["RestorationModStealthTitleID"] = "Индикатор скрытности из Альфы",
		["RestorationModStealthDescID"] = "Включить или выключить индикатор скрытности из Альфы. Используется при стелсе.",
		["RestorationModDownTitleID"] = "Таймер падения из Альфы",
		["RestorationModDownDescID"] = "Включить или выключить таймер падения из альфа-версии игры.",
		["RestorationModBagTitleID"] = "Панель сумок из Альфы",
		["RestorationModBagDescID"] = "Включить или выключить панель сумок из альфа-версии игры.",
		["RestorationModHostageTitleID"] = "Прятать панель заложников",
		["RestorationModHostageDescID"] = "Если включен, прячет панель заложников когда начинается штурм, при условии, что лента или индикатор штурма из Альфы включены.",
		["RestorationModDifficultyMarkersTitleID"] = "Иконки сложностей из пре-релиза",
		["RestorationModDifficultyMarkersDescID"] = "Включить или выключить иконки сложностей из пре-релиза игры.",
		["RestorationModStaminaIndicatorTitleID"] = "Дебаговая полоска выносливости",
		["RestorationModStaminaIndicatorDescID"] = "Включить или выключить дебаговую полоску выносливости.",
		["RestorationModBlackScreenTitleID"] = "Начало ограбления из Restoration",
		["RestorationModBlackScreenDescID"] = "Включить или выключить начальную заставку ограблений из Restoration.",
		["RestorationModLoadoutsTitleID"] = "Меню подготовки из Альфы",
		["RestorationModLoadoutsDescID"] = "Включить или выключить меню подготовки из альфа-версии игры.",
		["RestorationModDistrictTitleID"] = "Описания районов в CRIME.NET",
		["RestorationModDistrictDescID"] = "Включить или выключить описания районов в CRIME.NET. Описания не соответствуют геймплею.",
		["RestorationModSCOptionsButtonTitleID"] = "Опции Restoration Overhaul",
		["RestorationModSCOptionsButtonDescID"] = "Опции Restoration Overhaul",
		["RestorationModSCTitleID"] = "Complete Overhaul (DEBUG)",
		["RestorationModSCDescID"] = "Enable or disable Restoration's complete game overhaul. Toggling this option will automatically exit your game to prevent save corruption.",
		["RestorationModBotsNoDropTitleID"] = "Отключить сброс сумок у ботов",
		["RestorationModBotsNoDropDescID"] = "Боты больше не будут сбрасывать мешки.",
		["RestorationModCloakerTurnTitleID"] = "Пинок Клокера: Поворачивать камеру",
		["RestorationModCloakerTurnDescID"] = "Камера будет поворачиваться на Клокера, когда он вас пинает, как в ванилле.",
		["RestorationModDisableMutatorColorsTitleID"] = "Выключить смену цвета баннера штурма",
		["RestorationModDisableMutatorColorsDescID"] = "Выключает смену цвета баннера штурма, вызванное использованием мутаторов (работает только с обычным баннером).",
		["RestorationModDisableSoloBoonsTitleID"] = "Отключить преимущества Crime.Net Оффлайн",
		["RestorationModDisableSoloBoonsDescID"] = "Отключает дополнительные бонусы в одиночной игре.",	
		["RestorationModHolidayTitleID"] = "Праздничные эффекты",
		["RestorationModHolidayDescID"] = "Включает или выключает праздничные эффекты в моде.",
		["RestorationModRestoreHitFlashTitleID"] = "Вспышка при уроне",
		["RestorationModRestoreHitFlashDescID"] = "Включить или выключить вспышку экрана при получении урона из старых версий игры.",
		["RestorationModNotifyTitleID"] = "Уведомление",
		["RestorationModNotifyDescID"] = "Включить или выключить уведомления мода.",
		["RestorationModPauseTitleID"] = "Меню паузы из Альфы",
		["RestorationModPauseDescID"] = "Включить или выключить меню паузы из альфа-версии игры.",
		
		["vanilla_on_rails"] = "Стандартный/рельсовый",
		["kf_mw_style"] = "С задержкой",
		["tilt_in"] = "Наклон",

		["base_wpn_cat"] = "Основной навык",
		["sub_wpn_cat"] = "Саб-категория и урон",

		["RestorationModWepNamesTitleID"] = "Названия оружия",
		["RestorationModWepNamesDescID"] = "Стиль названия оружия и модулей. Требуется перезапуск.",
		["resmod_res_names"] = "Кириллица",
		["resmod_no_nicknames"] = "Латиница",
		["dmcwo_reelnames"] = "Реальные (DMCWO)",
		["resmod_no_renames"] = "Ванильные",
		
		["RestorationModColorOption"] = "Изменить цвет элемента интерфейса",
		["RestorationModColorsOptionsButtonTitleID"] = "Настройки цветов",
		["RestorationModColorsOptionsButtonDescID"] = "Изменить цвет различных элементов интерфейса.",
		["RestorationModObjectivesBGTitleID"] = "Задачи - задний план",
		["RestorationModObjectivesFGTitleID"] = "Задачи - передний план",
		["RestorationModAssaultBGTitleID"] = "Штурм - задний план",
		["RestorationModAssaultFGTitleID"] = "Штурм - передний план",
		["RestorationModNoReturnTitleID"] = "Текст Точки невозврата",
		["RestorationModTimerTextTitleID"] = "Таймер (время) ограбления",
		["RestorationModAssaultEndlessBGTitleID"] = "Штурм капитана",
		["RestorationModAssaultSurvivedBGTitleID"] = "Пережитый штурм",
		["RestorationModStaminaTitleID"] = "Выносливость",
		["RestorationModStaminaThresholdTitleID"] = "Порог выносливости",
		["RestorationModBagBitmapTitleID"] = "Сумка",
		["RestorationModBagTextTitleID"] = "Текст сумок",
		["RestorationModNoReturnTextTitleID"] = "Текст Точки невозврата",
		["RestorationModHostagesTextTitleID"] = "Текст заложников",
		["RestorationModHintTextTitleID"] = "Текст подсказок",
		["RestorationModMaskOnTextTitleID"] = "Текст надевания маски",
		["RestorationModDownsThreePlusTitleID"] = "Счетчик падений (при 3+ падений)",
		["RestorationModDownsTwoTitleID"] = "Счетчик падений (при 2 падениях)",
		["RestorationModDownsOneTitleID"] = "Счетчик падений (при 1 падении)",
		["RestorationModDownsZeroTitleID"] = "Счетчик падений (при 0 падений)",
		["RestorationModStopAllBotsTitleID"] = "Останавливать всех ботов",
		["RestorationModStopAllBotsDescID"] = "Останавливать всех ботов, если удержана кнопка остановки бота.",
		["RestorationModPONRTrackTitleID"] = "Музыка во время Точки невозврата",
		["RestorationModPONRTrackDescID"] = "Изменяет музыку во время Точки невозврата в режиме Pro-Job.",
		["RestorationModPONRTracksTitleID"] = "Музыка во время Точки невозврата",
		["RestorationModPONRTracksDescID"] = "Выберите музыку, которая начнется во время Точки невозврата в режиме Pro-Job.",
		["RestorationModMusicShuffleTitleID"] = "Перемешка музыки",
		["RestorationModMusicShuffleDescID"] = "Музыка будет меняться после конца каждого штурма.",
		["RestorationModOldEconomyTitleID"] = "Old Economy (Beta)",
		["RestorationModOldEconomyDescID"] = "Enables the old economy from pre update 11.",
		["RestorationModScaleTitleID"] = "Размер интерфейса",
		["RestorationModScaleDescID"] = "Изменяет размер интерфейса. Может потребоваться перезапуск игры.",
		["RestorationModSizeOnScreenTitleID"] = "Размер интерфейса на экране",
		["RestorationModSizeOnScreenDescID"] = "Изменяет размер интерфейса на экране. Может потребоваться перезапуск игры.",
		["RestorationModTeammateTitleID"] = "Панель команды из Альфы",
		["RestorationModTeammateDescID"] = "Включает или выключает панель команды из альфа-версии игры, которая отображает статистику вас и вашей команды.",
		["RestorationModHeistTimerTitleID"] = "Время ограбления из Альфы",
		["RestorationModHeistTimerDescID"] = "Включает или выключает время (таймер) ограбления из альфа-версии игры.",
		["RestorationModMaskOnTitleID"] = "Текст надевания маски из Альфы",
		["RestorationModMaskOnDescID"] = "Включает или выключает текст надевания маски из альфа-версии игры.",
		["RestorationModNameLabelsTitleID"] = "Ники игроков из Альфы",
		["RestorationModNameLabelsDescID"] = "Включить или выключить ники игроков из альфа-версии игры.",
		["RestorationModHintTitleID"] = "Панель подсказок из Альфы",
		["RestorationModHintDescID"] = "Включить или выключит панель подсказок из альфа-версии игры.",
		["RestorationModExtraOptionsButtonTitleID"] = "Дополнительные опции интерфейса",
		["RestorationModExtraOptionsButtonDescID"] = "Еще больше опций!",
		["RestorationModRealAmmoTitleID"] = "Действительный счетчик патронов",
		["RestorationModRealAmmoDescID"] = "Счетчик патронов в запасе будет игнорировать патроны, которые уже заряжены.",
		["RestorationModStealthOrigPosTitleID"] = "Стандартное расположение обнаружения",
		["RestorationModStealthOrigPosDescID"] = "Полоска обнаружения будет в том же месте, что и в ванильной игре.",
		["RestorationModLowerBagTitleID"] = "Понизить текст о подобранной сумке",
		["RestorationModLowerBagDescID"] = "Текст, который появляется, если подобрать сумку, будет расположен ниже.",
		["RestorationModAssaultStyleTitleID"] = "Стиль панели штурма",
		["RestorationModAssaultStyleDescID"] = "Позволяет выбрать стиль панели штурма.",
		["RestorationModCasingTickerTitleID"] = "Лента исследования из Альфы",
		["RestorationModCasingTickerDescID"] = "Включить или выключить ленту режима исследования из альфа-версии игры (Требует включенную ленту из Альфы).",
		["RestorationModCustodyTitleID"] = "Панель заключения под стражу из Альфы",
		["RestorationModCustodyDescID"] = "Включить или выключить панель заключения под стражу из альфа-версии игры.",
		["RestorationModCrimenetTitleID"] = "CRIMENET из Альфы",
		["RestorationModCrimenetDescID"] = "Включает или выключает CRIMENET из альфа-версии игры.",
		["RestorationModProfileTitleID"] = "Окно с профилями из Альфы",
		["RestorationModProfileDescID"] = "Включить или выключить окно с профилями из альфа-версии игры.",
		["RestorationModNewsfeedTitleID"] = "Лента новостей из Альфы",
		["RestorationModNewsfeedDescID"] = "Включить или выключить ленту новостей из альфа-версии игры.",
		["RestorationModUppercaseNamesTitleID"] = "Ники заглавными буквами",
		["RestorationModUppercaseNamesDescID"] = "Включить или выключить отображение ников игроков заглавными буквами.",
		["RestorationModPeerColorsTitleID"] = "Цвета товарищей из Альфы",
		["RestorationModPeerColorsDescID"] = "Включить или выключить цвета товарищей из альфа-версии игры.",
		["RestorationModPocoCrimenetAlignSortTitleID"] = "Подгонка и сортировка CRIMENET",
		["RestorationModPocoCrimenetAlignSortDescID"] = "Подгоняет и сортирует CRIMENET по сложности.",
		["RestorationModPocoCrimenetScaleTitleID"] = "Масштаб CRIMENET",
		["RestorationModPocoCrimenetScaleDescID"] = "Позволяет менять масштаб CRIMENET.",
		["RestorationModBriefingFontSizeTitleID"] = "Loadout Menu Briefing Font Size",
		["RestorationModBriefingFontSizeDescID"] = "Allows you to set the font size of the loadout menu briefing.",
		["RestorationModVoiceIconTitleID"] = "Голосовой чат",
		["RestorationModVoiceIconDescID"] = "Отображает иконку, когда игрок использует голосовой чат.",
		["RestorationModNewsFeedStyleTitleID"] = "Alpha Newsfeed Style",
		["RestorationModNewsFeedStyleDescID"] = "Allows you to choose to show both newsfeed and newheists box or just the newsfeed.",
		["alpha_assault"] = "Уголок",
		["beta_assault"] = "Лента",
		["show_both"] = "Default",
		["show_classic_newsfeed"] = "Classic",

		["RestorationModDodgeDisplayTitleID"] = "Цифра шкалы Уворота",
		["RestorationModDodgeDisplayDescID"] = "Максимальное число, которое *отображает* шкала Уворота. Требует перезапуска.",
		["dd_scale"] = "150 -Текущий Уворот",
		["dd_150"] = "150",
		["dd_100"] = "100",
		
		--Бафф трекер
		["RestorationModINFOHUDOptionsButtonTitleID"] = "Отображение иконок навыков (Buff Tracker)",
		["RestorationModINFOHUDOptionsButtonDescID"] = "Отображает иконки навыков, которые активны в данный момент, в левом верхнем углу экрана. Не требует включенного Alpha UI.",
		["RestorationModInfo_HudTitleID"] = "Включить иконки навыков",
		["RestorationModInfo_HudDescID"] = "Включает или выключает отображение иконок навыков.",
		["RestorationModInfo_SizeTitleID"] = "Размер иконок",
		["RestorationModInfo_SizeDescID"] = "Регулирует размер отображаемых иконок навыков.",
		["RestorationModInfo_CountTitleID"] = "Число рядов",
		["RestorationModInfo_CountDescID"] = "Регулирует количество рядов иконок навыков, которые будут отображаться, прежде чем добавится новый столбик.",
		["RestorationModInfo_single_shot_fast_reloadTitleID"] = "Агрессивная перезарядка",
		["RestorationModInfo_single_shot_fast_reloadDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_ammo_efficiencyTitleID"] = "Эффективный расход",
		["RestorationModInfo_ammo_efficiencyDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_bloodthirst_reload_speedTitleID"] = "Кровожадность",
		["RestorationModInfo_bloodthirst_reload_speedDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_bullet_stormTitleID"] = "Свинцовый ливень",
		["RestorationModInfo_bullet_stormDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_revive_damage_reductionTitleID"] = "Интерн",
		["RestorationModInfo_revive_damage_reductionDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_desperadoTitleID"] = "Меткий стрелок",
		["RestorationModInfo_desperadoDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_grinderTitleID"] = "Гистамин (Нападающий)",
		["RestorationModInfo_grinderDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_gamblerTitleID"] = "Медицинские припасы (Шулер)",
		["RestorationModInfo_gamblerDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_sicarioTitleID"] = "Похититель жизней (Интервент)",
		["RestorationModInfo_sicarioDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_sociopathTitleID"] = "Tension и прочее. (Социопат)",
		["RestorationModInfo_sociopathDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_body_expertiseTitleID"] = "Свинцовый ад",
		["RestorationModInfo_body_expertiseDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_long_dis_reviveTitleID"] = "Вдохновление",
		["RestorationModInfo_long_dis_reviveDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_hostage_takerTitleID"] = "Похититель",
		["RestorationModInfo_hostage_takerDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_messiahTitleID"] = "Мессия",
		["RestorationModInfo_messiahDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_overkill_damage_multiplierTitleID"] = "Overkill",
		["RestorationModInfo_overkill_damage_multiplierDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_bullseyeTitleID"] = "В Яблочко",
		["RestorationModInfo_bullseyeDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_revived_damage_reductionTitleID"] = "Анальгин",
		["RestorationModInfo_revived_damage_reductionDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_first_aid_damage_reductionTitleID"] = "Скорая помощь",
		["RestorationModInfo_first_aid_damage_reductionDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_uppersTitleID"] = "Колеса",
		["RestorationModInfo_uppersDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_crew_chiefTitleID"] = "Ситуация с заложниками (Капо)",
		["RestorationModInfo_crew_chiefDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_rogueTitleID"] = "Смертельный инстинкт (Шпион)",
		["RestorationModInfo_rogueDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_increased_movement_speedTitleID"] = "Бегущий от смерти",
		["RestorationModInfo_increased_movement_speedDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_headshot_fire_rate_multTitleID"] = "Крепкий хват",
		["RestorationModInfo_headshot_fire_rate_multDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_trigger_happyTitleID"] = "Неудержимый стрелок",
		["RestorationModInfo_trigger_happyDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_dmg_multiplier_outnumberedTitleID"] = "Давление",
		["RestorationModInfo_dmg_multiplier_outnumberedDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_unseen_strikeTitleID"] = "Удар исподтишка",
		["RestorationModInfo_unseen_strikeDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_survive_one_hitTitleID"] = "Татуировка Они (Якудза)",
		["RestorationModInfo_survive_one_hitDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_doctor_bag_health_regenTitleID"] = "Лечение от Медицинских сумок",
		["RestorationModInfo_doctor_bag_health_regenDescID"] = "Включает или выключает отображение лечения от Медицинских сумок.",
		["RestorationModInfo_cohesionTitleID"] = "Единство (Байкер)",
		["RestorationModInfo_cohesionDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_heisters_in_auraTitleID"] = "Датчик грабителей (Байкер)",
		["RestorationModInfo_heisters_in_auraDescID"] = "Включает или выключает отображение иконки данного навыка.",
		["RestorationModInfo_dig_in_your_heelsTitleID"] = "Заложить поворот (Байкер)",
		["RestorationModInfo_dig_in_your_heelsDescID"] = "Включает или выключает отображение иконки данного навыка.",
		
		["RestorationModmastermind_buffsTitleID"] = "===Манипулятор===",
		["RestorationModenforcer_buffsTitleID"] = "===Штурмовик===",
		["RestorationModtechnician_buffsTitleID"] = "===Техник===",
		["RestorationModghost_buffsTitleID"] = "===Призрак===",
		["RestorationModfugitive_buffsTitleID"] = "===Беглец===",
		["RestorationModperk_buffsTitleID"] = "===Перки===",
			
		-- Время суток
		["RestorationModEnv_BanksTitleID"] = "Ограбление банка",
		["RestorationModEnv_BanksDescID"] = "Выбрать погоду для ограбления банка.",
		["RestorationModEnv_RVD1TitleID"] = "Бешеные псы - день 1",
		["RestorationModEnv_RVD1DescID"] = "Выбрать погоду для ограбления Бешеные псы (день 1).",
		["RestorationModEnv_RVD2TitleID"] = "Бешеные псы - день 2",
		["RestorationModEnv_RVD2DescID"] = "Выбрать погоду для ограбления Бешеные псы (день 2).",
		["RestorationModEnv_FSD1TitleID"] = "Поджигатель - день 1",
		["RestorationModEnv_FSD1DescID"] = "Выбрать погоду для ограбления Поджигатель (день 1).",
		["RestorationModEnv_PBR2TitleID"] = "Рождение небес",
		["RestorationModEnv_PBR2DescID"] = "Выбрать погоду для ограбления Рождение небес.",
		["RestorationModEnv_CJ2TitleID"] = "Бомба: Доки",
		["RestorationModEnv_CJ2DescID"] = "Выбрать погоду для ограбления Бомба: Доки.",
		["RestorationModEnv_UnderPassTitleID"] = "Транспорт: Проезд",
		["RestorationModEnv_UnderPassDescID"] = "Выбрать погоду для ограбления Транспорт: Проезд.",
		["RestorationModEnv_MallCrasherTitleID"] = "Крушитель",
		["RestorationModEnv_MallCrasherDescID"] = "Выбрать погоду для ограбления Крушитель.",
		["RestorationModEnv_Mia_1TitleID"] = "Г.Л.Майами - день 1",
		["RestorationModEnv_Mia_1DescID"] = "Выбрать погоду для ограбления Горячая линия Майами (день 1).",
		["RestorationModEnv_FSD3TitleID"] = "Поджигатель - день 3",
		["RestorationModEnv_FSD3DescID"] = "Выбрать погоду для ограбления Поджигатель (день 3).",
		["RestorationModEnv_WDD1NTitleID"] = "Сторож. псы 1 (Ночь)",
		["RestorationModEnv_WDD1NDescID"] = "Выбрать погоду для ограбления Сторожевые псы (день 1 - ночной).",
		["RestorationModEnv_WDD1DTitleID"] = "Сторож. псы 1 (День)",
		["RestorationModEnv_WDD1DDescID"] = "Выбрать погоду для ограбления Сторожевые псы (день 1 - дневной).",
		["RestorationModEnv_WDD2DTitleID"] = "Сторож. псы 1 (День))",
		["RestorationModEnv_WDD2DDescID"] = "Выбрать погоду для ограбления Сторожевые псы (день  - дневной).",
		["RestorationModEnv_Alex3TitleID"] = "Крысы - день 3",
		["RestorationModEnv_Alex3DescID"] = "Выбрать погоду для ограбления Крысы (день 3).",
		["RestorationModEnv_BigTitleID"] = "Большой банк",
		["RestorationModEnv_BigDescID"] = "Выбрать погоду для ограбления Большой банк.",
		["RestorationModEnv_FSTitleID"] = "Четыре магазина",
		["RestorationModEnv_FSDescID"] = "Выбрать погоду для ограбления Четыре магазина.",
		["RestorationModEnv_UkraTitleID"] = "Украинское дело",
		["RestorationModEnv_UkraDescID"] = "Выбрать погоду для ограбления Украинское дело.",
		["RestorationModEnv_KosugiTitleID"] = "Теневой рейд",
		["RestorationModEnv_KosugiDescID"] = "Выбрать погоду для ограбления Теневой рейд.",
		["RestorationModEnv_PetaTitleID"] = "Симулятор козы - день 1",
		["RestorationModEnv_PetaDescID"] = "Выбрать погоду для ограбления Симулятор козы (день 1).",
		["RestorationModEnv_FRIENDTitleID"] = "Особняк",
		["RestorationModEnv_FRIENDDescID"] = "Выбрать погоду для ограбления Особняк Лица со шрамом.",
		
		["default"] = "Стандартная",
		["random"] = "Случайная",
		["mellowday"] = "Умеренный день",
		["xbox_bank"] = "E3 2013",
		["bank_day"] = "Улучшенная стандартная",
		["env_trailer_bank"] = "Банк - как в трейлере",
		["rvd1_alt1"] = "Ночная жизнь",
		["rvd1_alt2"] = "Розоватый туман",
		["rvd2_alt"] = "Пасмурная",
		["fsd1_eve"] = "Вечерняя",
		["bos_alt"] = "Розовое небо",
		["dockyard_alt"] = "Ночная смена",
		["underpass_foggyday"] = "Туманный день",
		["mall_alt"] = "Послеобеденный шоппинг",
		["hlm_morn"] = "Утренний звонок",
		["funny_and_epic_synthwave_very_eighties"] = "Ретро",
		["brightnight"] = "Белая ночь",
		["docks"] = "Порт",
		["bank_green"] = "Зеленоватый из беты",
		["cloudy_day"] = "Облачный день",
		["shadowraid_day"] = "Дневной рейд",
		["shadowraiud_darker"] = "Мрачный рейд",
		["friend_pink"] = "Розовый закат",
		["friend_night"] = "Ночь в Майами",
		["off"] = "Выключить",
	})
end)

-- Маски, костюмы и прочие косметики
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Blackmarket", function(loc)
	
	LocalizationManager:add_localized_strings({
	
	["bm_msk_shatter_true"] = "Шаттер",
	["bm_msk_shatter_true_desc"] = "Легендарная маска, о которой говорят вполголоса.\n\nРазумеется, это просто дубликат.\n\nВ настоящей маске есть кое-что особенное, но думаю, вас устроит и копия.\n\nФеникс символизирует перерождение того, кто не может быть убит. Попробуй его уничтожить, и он лишь нанесет огненный контр-удар.",
	["menu_l_global_value_veritas"] = "Restoration Mod",
	["menu_l_global_value_veritas_desc"] = "Это предмет из Restoration Mod!",
	
	["bm_msk_canada"] = "Адский хоккей",
		["bm_msk_canada_desc"] = "Ничего не оставляйте позади - даже когда становится жарко, вы сражаетесь за что хотите, когда хотите (даже если это термобарическая бомба).",
		["bm_msk_jsr"] = "Миссис Граффити",
		["bm_msk_jsr_desc"] = "Создана настоящим художником. Стирать граффити - все равно, что сжигать книги, не так ли?\n\nИскусство это искусство - его нужно уважать.",
		["bm_msk_jsrf"] = "Mистер Граффити",
		["bm_msk_jsrf_desc"] = "За каждым граффити стоит история. Быть художником в безликом городе может быть болезненно.\n\nГраффити - словно книга. Их нужно уметь читать.",
		["bm_msk_courier_stash"] = "Сумка для добычи",
		["bm_msk_courier_stash_desc"] = "Если нужно взять несколько лишних сотенных купюр, а в карманах уже не осталось места, эта маска вполне сойдет.",

		["bm_msk_female_mask"] = "Стандартная маска (женская)",
		["bm_msk_female_mask_desc"] = "Стандартная маска, предоставляемая организацией CRIMENET.\n\nСделана из плотного материала, носить ее не так просто, зато она прочная.",
		["bm_msk_female_mask_blood"] = "Восстановленная маска (женская)",
		["bm_msk_female_mask_blood_desc"] = "Стандартная маска, предоставляемая организацией CRIMENET.\n\nСделана из плотного материала, носить ее не так просто, зато она прочная.\n\nЭта маска была обнаружена после неудачного ограбления склада OMNIA, среди кровавого побоища.\n\nПоследним посланием банды, прежде чем они пропали навсегда, было ''ERIT PREMIUM SANGUINE SANCTUM''.",
		["bm_msk_female_mask_clown"] = "Рози",
		["bm_msk_female_mask_clown_desc"] = "Стандартная маска, предоставляемая организацией CRIMENET.\n\nСделана из плотного материала, носить ее не так просто, зато она прочная.\n\nЭту маску носила грабитель, известная как Рози, хотя теперь у нее новая маска.\n\nНа видеозаписи с ограбления было видно, как она обезвреживает целый отряд спецназа совершенно без оружия.",
		["bm_msk_male_mask"] = "Стандартная маска (мужская)",
		["bm_msk_male_mask_desc"] = "Стандартная маска, предоставляемая организацией CRIMENET.\n\nСделана из плотного материала, носить ее не так просто, зато она прочная.",
		["bm_msk_male_mask_blood"] = "Восстановленная маска (мужская)",
		["bm_msk_male_mask_blood_desc"] = "Стандартная маска, предоставляемая организацией CRIMENET.\n\nСделана из плотного материала, носить ее не так просто, зато она прочная.\n\nЭта маска была обнаружена после неудачного ограбления склада OMNIA, среди кровавого побоища.\n\nПоследним посланием банды, прежде чем они пропали навсегда, было ''ERIT PREMIUM SANGUINE SANCTUM''.",
		["bm_msk_male_mask_clown"] = "Кросс",
		["bm_msk_male_mask_clown_desc"] = "Стандартная маска, предоставляемая организацией CRIMENET.\n\nСделана из плотного материала, носить ее не так просто, зато она прочная.\n\nЭту маску носил грабитель, известный как Кросс, хотя теперь у него новая маска.\n\nКросс - талантливый стрелок, и однажды вывел из строя четыре бронегрузовика за пять секунд.",

		["bm_msk_twister_mask"] = "Человек-загадка",
		["bm_msk_twister_mask_desc"] = "Кто скрывается за этой маской - загадка.\n\nМожет, это какой-нибудь незнакомец, а может - кто-нибудь, кого вы знали все это время.",
		["bm_msk_voodoo_mask"] = "Темная магия",
		["bm_msk_voodoo_mask_desc"] = "Эта маска была найдена в джунглях после бомбардировки - она смогла вынести последствия разрушений, и теперь считается предвестником беды.\n\nОна найдет вас, когда вы будете нуждаться в ней больше всего и поможет пережить беду.\n\nВопрос лишь в том, какой ценой.",

		["bm_msk_f1"] = "Шлем X1",
		["bm_msk_f1_desc"] = "Не забывайте о защите, когда будете нестись по шоссе или проскальзывать через пробки.\n\nЭтот шлем защитит от жесткого падения, но явно не от пуль.",
		["bm_msk_f1_b"] = "Шлем X1 (Чистый)",
		["bm_msk_f1_b_desc"] = "Не забывайте о защите, когда будете нестись по шоссе или проскальзывать через пробки.\n\nЭтот шлем защитит от жесткого падения, но явно не от пуль.\n\nЭто дубликат шлема, без брендовых стикеров, который был найден в гараже с дорогими машинами.\n\nДержите этот шлем под рукой, и может быть однажды, вы поедете на одной из таких.",
		["bm_msk_sweettooth"] = "Сладкоежка",
		["bm_msk_sweettooth_desc"] = "Сладкоежка (настоящее имя - Маркус 'Нидлс' Кейн) - персонаж из серии игр Twisted Metal. Сладкоежка известен как клоун-убийца, который водит боевой фургончик с мороженым.\n\nГоворят, однажды он сбежал из психиатрической лечебницы. Теперь он ведет криминальную жизнь.",

		["bm_msk_wolf_stone"] = "Вульф из Stonecold",
		["bm_msk_wolf_stone_desc"] = "Оригинальная маска Вульфа, которую он носил, когда впервые сошел с ума и начал воплощать преступления из своих любимых игр. Считалось, что эта маска была утеряна во время ограбления, вдохновленного игрой ‘Hyper Heisting’.\n\nВо время ранних ограблений банды, маска нашлась и была доставлена в убежище одним из сообщников Бейна.\n\nОригинальный узор маски со временем потускнел, совсем как психическая стабильность Вульфа.",

		["bm_msk_thespian"] = "Thespian",
		["bm_msk_thespian_desc"] = "Thespian is a superhuman solider of fortune. In the future, space marines like Thespian protect the world of mankind and its space colonies from forces of evil\n\nHis helmet is a popular gift in the criminal underworld and is given to thieves, thugs and career criminals who show their loyalty and patience to the syndicate.",

		["bm_msk_dallas_aged"] = "Древний Даллас",
		["bm_msk_dallas_aged_desc"] = "Вы с бандой обнаружили эти маски в странной египетской шкатулке, найденной в Скале Генри. Сама шкатулка оказалась утеряна при перевозке, но ее содержимое было передано вам.\n\nВ этих масках есть что-то необычное. Нет информации, откуда они могли появиться.\n\nДжекел считает, что они могли быть сделаны в качестве практичной шутки, чтобы напугать банду.\n\nОднако вы замечаете, что эти маски выглядят очень, очень старыми.",
		["bm_msk_chains_aged"] = "Древний Чейнс",
		["bm_msk_chains_aged_desc"] = "Вы с бандой обнаружили эти маски в странной египетской шкатулке, найденной в Скале Генри. Сама шкатулка оказалась утеряна при перевозке, но ее содержимое было передано вам.\n\nВ этих масках есть что-то необычное. Нет информации, откуда они могли появиться.\n\nДжекел считает, что они могли быть сделаны в качестве практичной шутки, чтобы напугать банду.\n\nОднако вы замечаете, что эти маски выглядят очень, очень старыми.",
		["bm_msk_hoxton_aged"] = "Древний Хокстон",
		["bm_msk_hoxton_aged_desc"] = "Вы с бандой обнаружили эти маски в странной египетской шкатулке, найденной в Скале Генри. Сама шкатулка оказалась утеряна при перевозке, но ее содержимое было передано вам.\n\nВ этих масках есть что-то необычное. Нет информации, откуда они могли появиться.\n\nДжекел считает, что они могли быть сделаны в качестве практичной шутки, чтобы напугать банду.\n\nОднако вы замечаете, что эти маски выглядят очень, очень старыми.",
		["bm_msk_wolf_aged"] = "Древний Вульф",
		["bm_msk_wolf_aged_desc"] = "Вы с бандой обнаружили эти маски в странной египетской шкатулке, найденной в Скале Генри. Сама шкатулка оказалась утеряна при перевозке, но ее содержимое было передано вам.\n\nВ этих масках есть что-то необычное. Нет информации, откуда они могли появиться.\n\nДжекел считает, что они могли быть сделаны в качестве практичной шутки, чтобы напугать банду.\n\nОднако вы замечаете, что эти маски выглядят очень, очень старыми.",

		["bm_msk_beef_dallas"] = "Мясной Даллас",
		["bm_msk_beef_dallas_desc"] = "Банда использовала эти маски во время ограбления 'Скотобойня'.\n\nДаллас решил оставить дизайн своей полюбившейся маски.",
		["bm_msk_beef_chains"] = "Мясной Чейнс",
		["bm_msk_beef_chains_desc"] = "Банда использовала эти маски во время ограбления 'Скотобойня'.\n\nЧейнс, будучи силовиком, захотел в качестве дизайна устрашающее животное. Что может быть страшнее, чем чертов динозавр?!",
		["bm_msk_beef_hoxton"] = "Мясной Хокстон",
		["bm_msk_beef_hoxton_desc"] = "Банда использовала эти маски во время ограбления 'Скотобойня'.\n\nХокстон оставил простой список пожеланий для своей маски:\n- Защищающая!\n- Эффективная!\n- Стильная!\n\nТак и получилась эта маска.",
		["bm_msk_beef_wolf"] = "Мясной Вульф",
		["bm_msk_beef_wolf_desc"] = "Банда использовала эти маски во время ограбления 'Скотобойня'.\n\nДизайн Вульфа был вдохновлен его любимым персонажем, которого он придумал, когда еще разрабатывал игры.",

		["bm_msk_vyse_dallas"] = "Источник",
		["bm_msk_vyse_dallas_desc"] = "Vyse сразился лицом-к-лицу с самым дьявольским из дьяволов. Vyse выжил, а из костей дьявола сделали эту маску.",
		["bm_msk_vyse_chains"] = "Детская игра",
		["bm_msk_vyse_chains_desc"] = "Хоть Vyse и украл больше денег и золота, чем поместится в Форт-Нокс, у него хватает сердца, что бы поделиться частью добычи с больными детьми.\n\nОднажды, Бейн посетил этих детей - эта маска была их благодарностью для Vyse.",
		["bm_msk_vyse_hoxton"] = "Три балбеса",
		["bm_msk_vyse_hoxton_desc"] = "Говорят, если провалишься - нужно перетерпеть боль и попытаться снова. Vyse не был согласен. Каждый раз, когда он проигрывал, он шел вперед, не смотря ни на что. Даже Ларри, Керли и Мо не выдержали бы такого.",
		["bm_msk_vyse_wolf"] = "Беар Гриллс",
		["bm_msk_vyse_wolf_desc"] = "Vyse однажды вызвал Беара Гриллса на поединок по распитию урины... Vyse победил, и Мистер Гриллс использовал свои навыки выживания при создании этой маски.",

		["bm_msk_secret_old_hoxton"] = "Секретный Хокстон",
		["bm_msk_secret_old_hoxton_desc"] = "Хокстон покинул родной край ради больших денег. Когда Бейн рассказал ему о Секрете, ему понравилась идея искать древние артефакты - ведь они стоят дорого. Хокстону было совсем неважно, существует ли некая древняя сила или нет.",

		["bm_msk_secret_clover"] = "Секретная Кловер",
		["bm_msk_secret_clover_desc"] = "Когда Бейн рассказал Кловер о Секрете, она отнеслась скептически - ей всегда казалось, что легенды Бейна о древних артефактах с мифической силой были сильно преувеличены. Но когда она лично увидела сбор трех шкатулок, ни о каких сомнениях больше не было и речи.",

		["bm_msk_secret_dragan"] = "Секретный Драган",
		["bm_msk_secret_dragan_desc"] = "Как бывший полицейский, Драган всегда хорошо умел искать улики, и когда Бейн показал ему свое расследование Секрета, он был готов к охоте за древними артефактами.",

		["bm_msk_secret_bonnie"] = "Секретная Бонни",
		["bm_msk_secret_bonnie_desc"] = "Бонни, услышав от Бейна о секрете, сделала большой глоток своего любимого виски и закричала о том, что готова 'набить рожу Катару'.",

		["bm_msk_secret_sydney"] = "Секретная Сидни",
		["bm_msk_secret_sydney_desc"] = "Когда Сидни услышала о секрете от Бейна, она не поверила в легенды о древней силе. Тем не менее, возможность сразиться с неизвестной, но крайне опасной организацией достаточно заинтересовала ее.",

		["bm_msk_secret_richard"] = "Секретный Ричард",
		["bm_msk_secret_richard_desc"] = "По криминальному миру ходили слухи о киллере, которым вдохновлялся Джекет; киллер, который был ликвидирован неизвестной организацией. Когда Джекет услышал о секрете от Бейна, он вернулся с маской, похожей на ту, что носил его прародитель.",

		["bm_all_seeing"] = "Всевидящий якорь",
		["bm_all_seeing_desc"] = "Ужасающее видение, кошмарное зрелище.\n\nВысшие силы увидели вас и решили наградить.",

		["bm_msk_classic_helmet"] = "Классический силовик",
		["bm_msk_classic_helmet_desc"] = "Подарок от бывшего спецназовца. Прежде чем уйти на пенсию, он вычислил Джекела... И подарил ему единственную экипировку, которая у него осталась, чтобы помочь работе Джекела.\n\nЭто странное событие было не без причины: Он увидел своими глазами то, что OMNIA держала в тайне. Но он не стал копать эти тайны и вскоре покинул спецназ навсегда.\n\nДжекел прислал эти шлемы вам, в качестве награды за вашу помощь.",

		["bm_cube"] = "devmask.model",
		["bm_cube_desc"] = "Push the placeholder, we'll get around to it.",

		["bm_j4"] = "J-4",
		["bm_j4_desc"] = "Маска Джекела. Точнее, ее копия.\n\nНастоящая маска слишком важна для Джекела, по слухам, в ней полно чувствительной электронники.\n\nВ этой копии система дисплея очень простая и служит просто чтобы быть похожей на оригинал.\n\nПодарок за ваши старания.",


		["bm_msk_finger"] = "Наглец",
		["bm_msk_finger_desc"] = "Наглец - мифическое существо, которое существовало в мире давным-давно. Существо гонялось и вредило обычным деревенским и городским жителям, охотясь на них различными способами. Наглецу нравилось это делать, и он был угрозой покою, пока он не был обнаружен и уничтожен людьми Короля.",

		["bm_msk_instinct"] = "Интуиция",
		["bm_msk_instinct_desc"] = "Эта маска принадлежала мифическому войну из далеких земель. Он путешествовал по всему миру, полагаясь на интуицию, и охотился на злые силы. Он прошел через многие подземелья и победил тысячи злых существ на своем пути. В конце концов, он ушел на покой, зная, что его дело продолжат будущие поколения.",

		["bm_msk_unforsaken"] = "Неупокоенный",
		["bm_msk_unforsaken_desc"] = "Эта легендарная маска - знак благодарности нашему сообществу за упорство и поддержку. От нас, команды OVERKILL - мы благодарны вам.\n\nЧерез огонь и медные трубы, пусть шлемы продолжают лететь.",

		["bm_msk_chains_halloween"] = "Разбитый щит",
		["bm_msk_chains_halloween_desc"] = "Будучи наемником, приходится видеть большое количество боли и смерти. Даже если вам кажется что вы бессмертны и бесстрашны... Иногда, плохие воспоминания добираются до вас.\n\nВ светлый, снежный и прекрасный октябрьский день 2008-го года, Чейнс отсыпался. Недавно выполнив контракт на убийство от Murkywater, он получил деньги и неплохую комнату в отеле, где и спал.\n\nВпервые за много лет, ему приснился кошмар. Он не помнит его во всех подробностях, но он проснулся от паралича, и образ, напоминающий скелет, стоял над ним, пока он не мог пошевелиться.\n\nКаждый раз, когда он выполнял грязную работу, его последующие ночи были бессонными и ужасными.\n\nВ конце концов, ему пришлось сказать 'Хватит.', покинуть свою работу наемником и обратиться к психотерапевту. Ему прописали лекарства. На год жизнь стала хорошей...\n\nРовно через год, 31 октября 2009-го, компания Murkywater решила, что уволившийся человек собирается раскрыть секреты организации. Для них это непозволительно.\n\nЧейнс бросился в криминальную жизнь, чтобы спасти себя, и снова стал солдатом.\n\nНо в этот раз все было по-другому. Кошмары и паралич не вернулись. Он не собирался приносить страдания другим людям.\n\nВ этот раз, ему нужно было защитить себя.",

		["bm_msk_dallas_halloween"] = "Отражение монстра",
		["bm_msk_dallas_halloween_desc"] = "Тратя годы на выдумывание несуществующих личностей и историй, легко потерять настоящего себя.\n\nТы начинаешь перепрыгивать от личности к личности, подбирать черты своих друзей, любовниц и приятелей. Иногда они сливаются вместе, и ты начинаешь чувствовать себя невнятной смесью.\n\nДаллас проснулся октябрьским утром и взглянул в зеркало - его волосы были окрашены в дурацкий блондинистый цвет, а борода неровно побрита. На нем был безвкусный костюм, покрытый потом после жутких кошмаров. Его голова болела после выходных, проведенных на дне бутылки.\n\nВзглянул на себя, он подумал, что больше похож на монстра Франкенштейна, чем на человека: Просто сборные части, которые достаточно убедительны, чтобы презентовать себя в криминальной карьере.\n\nЭто утро было переломным моментом, но Далласу до сих пор иногда кажется, что не все его черты характера действительно принадлежат ему.",

		["bm_msk_hoxton_halloween"] = "Хеллоуинский сон",
		["bm_msk_hoxton_halloween_desc"] = "Одним из хеллоуинских воспоминаний Хокстона было посещение Нью-Йорка с дальними родственниками.\n\nЕму никогда не нравились конфеты, но он обожал тыквенный пирог, который подавали на вечеринке его родственника.\n\nКогда он вышел прогуляться с вечеринки, он увидел большую дверь хранилища, в которое завозили различные богатства.\n\nС тех пор он загорелся идеей ограблений во время праздников.",

		["bm_msk_wolf_halloween"] = "Плач дьявола",
		["bm_msk_wolf_halloween_desc"] = "Холодным октябрьским вечером 2010-го, Вульф до сих пор пытался выбраться из финансового кризиса после того, как его компания закрылась.\n\nОн лежал в гостинице, в полном одиночествеЮ и думал о своей семье, о том, что он их подвел и может их больше не увидеть - отрезанный от них целым океаном.\n\nОн потратил последние сбережения на поездку в США, в попытке накопить достаточно денег, чтобы начать сначала в новом доме, но он провалился.\n\nНесколько недель спустя, бродя по домам друзей, гостиницам и убежищам, ему позвонила его любимая, впервые за долгое время.\n\nОтношениям конец. 'Не вижу, как это может хорошо закончиться.'\n\nМожет, это и был повод начать сначала.\n\nМожет, настало время попробовать новую карьеру.",

	--Костюмы--
		--стринги дефолтного костюма
		["bm_suit_none_desc"] = "Это стандартный костюм грабителя с выбранной броней. Может измениться с костюма-двойки в зависимости от ограбления!",
		
		["bm_suit_two_piece_sc"] = "Костюм-двойка",
		["bm_suit_two_piece_desc_sc"] = "Классический подход к ограблениям. Когда кричишь 'Упали вниз!', почему бы не выглядеть стильно?\n\nС этой опцией персонаж будет носить свой стандартный костюм вне зависимости от ограбления.",

		["bm_suit_loud_suit"] = "Боевой жилет",
		["bm_suit_loud_suit_desc"] = "Костюм для тех, кто не прочь вступить в схватку. Он создан для удобства и в нем легко передвигаться. Отличный выбор для резких набегов на местные ювелирные магазины или секретные базы наемников.",

		["bm_suit_jackal_track"] = "Особый атрибут",
		["bm_suit_jackal_track_desc"] = "Костюм, сделанный по заказу, с логотипом Джекела и вариацией логотипа ВЕРИТАС.\n\nБадна получила их в немаркированных коробках. Джекел утверждает, что не посылал их, и никогда не видел их раньше.\nНеизвестно, откуда они взялись.\n\n\n\n...Внутри коробок была лишь записка:\n\n''##В ЗНАК БЛАГОДАРНОСТИ, ДЛЯ ТЕХ, КТО ВЕРЕН ДЕЛУ.\nXOXO\n--S.N.##''\n\n",

		["bm_suit_sunny"] = "Утренний грабитель",
		["bm_suit_sunny_desc"] = "Иногда хочется просто закатать рукава и немножко пограбить.",

		["bm_suit_pool"] = "Bodhi's Pool Repair Uniform",
		["bm_suit_pool_desc"] = "Sharp threads for pool repair men...",

		["bm_suit_prison"] = "Тюремный костюм",
		["bm_suit_prison_desc"] = "Вас забрали под стражу!",

		["bm_suit_var_jumpsuit_flecktarn"] = "Флектарн",
		["bm_suit_var_jumpsuit_flecktarn_desc"] = "Классический камуфляж, использующийся в двух европейских странах. Известен тем, что позволяет легко слиться с лесным окружением. Точно не будет работать в городе, но в сельской местности может неплохо обмануть зрение.",

		["bm_suit_var_jumpsuit_flatgreen"] = "Вязко-зеленый",
		["bm_suit_var_jumpsuit_flatgreen_desc"] = "Этот костюм, по слухам, принадлежал одному из трех членов банды психопатов и был найден в уничтоженном мусоровозе, который использовался в кровавом ограблении бронетранспорта GenSec, в ходе которого несколько членов SWAT были убиты и многие ранены. Личности этих бандитов до сих пор остаются в тайне, так как большинство улик было уничтожено вместе с мусоровозом - остался только этот костюм.",

		-- вариации - Combat Harness
			["bm_suit_var_loud_suit_default"] = "Профессиональный черный",
			["bm_suit_var_loud_suit_default_desc"] = "Костюм-двойка стал частью бренда банды PAYDAY. Модный, стильный, позволяет легко затеряться в толпе - настоящая икона. 'Подождите ка! В какой, блядь, толпе?', спросил Чейнс, пока банда направлялась в очередной раз грабить склад Murkywater. И почему он не додумался раньше...",

			["bm_suit_var_loud_suit_white"] = "Морозный белый",
			["bm_suit_var_loud_suit_white_desc"] = "Этот костюм предоставил Джимми для 'Точки кипения'. Быстро выяснилось, что они не подходят для жестких морозов. А сам Джимми вообще предпочел остаться в своем рванном костюме-двойке.",

			["bm_suit_var_loud_suit_red"] = "Неясный красный",
			["bm_suit_var_loud_suit_red_desc"] = "Красный - интересный цвет на поле боя. Либо это медик, который пришел спасать товарищей, либо самый опасный ублюдок из всех. Тебе решать, кем ты будешь.",

			["bm_suit_var_loud_suit_green"] = "Ядовитый зеленый",
			["bm_suit_var_loud_suit_green_desc"] = "Хватит унижений от Гренадера. Джемма МакШай предоставила вам целый арсенал ядовитого оружия - теперь время показать, кто здесь на самом деле травит насекомых.",

			["bm_suit_var_loud_suit_blue"] = "Полицейский синий",
			["bm_suit_var_loud_suit_blue_desc"] = "А почему копы не используют УКТЖ?",

			["bm_suit_var_loud_suit_purple"] = "Модный фиолетовый",
			["bm_suit_var_loud_suit_purple_desc"] = "Спрячьте этот костюм под свой УКТЖ, чтобы добавить нотку моды в вашу тактическую чушь.",

			["bm_suit_var_loud_suit_brown"] = "Загородный коричневый",
			["bm_suit_var_loud_suit_brown_desc"] = "Хьюстон бы хотел остаться в городских джунглях, где ему комфортнее всего. Но увы, за городом слишком много прибыльных для банды дел.",

			["bm_suit_var_loud_suit_gorkagreen"] = "Тактический лесной",
			["bm_suit_var_loud_suit_gorkagreen_desc"] = "Хорошо маскирует в лесу, или среди всех украденных денег.",

			["bm_suit_var_loud_suit_gorkaearth"] = "Тактический наемник",
			["bm_suit_var_loud_suit_gorkaearth_desc"] = "Да сколько униформ производит Murkywater? Можно уже открывать собственную линию одежды.",

			["bm_suit_var_loud_suit_gorkagrey"] = "Тактический городской",
			["bm_suit_var_loud_suit_gorkagrey_desc"] = "Какой смысл надевать костюм-двойку, если все уже знают ваше лицо?",

			["bm_suit_var_loud_suit_gorkapurple"] = "Тактический фиолетовый",
			["bm_suit_var_loud_suit_gorkapurple_desc"] = "Никогда не знаешь, когда придется грабить в фиолетовых джунглях.",

			["bm_suit_var_loud_suit_gorkasea"] = "Тактический морской",
			["bm_suit_var_loud_suit_gorkasea_desc"] = "Вульф раздобыл их в 2011-ом, когда Бейн планировал ограбление яхты. Кто же знал, что этим костюмам придется собирать пыль почти шесть лет.",
			-- вариации - Sunny Side
			["bm_suit_var_suit_sunny_default"] = "Повседневные дела",
			["bm_suit_var_suit_sunny_default_desc"] = "Будь героем боевиков 90-х, которым ты всегда хотел стать.",

			["bm_suit_var_suit_sunny_skull"] = "Смертоносные дела",
			["bm_suit_var_suit_sunny_skull_desc"] = "Этот символ подарил Скуллдозеру его страшное имя. Покажи, что для тебя он ничего не значит, сделав его просто украшением для одежды.",

			["bm_suit_var_suit_sunny_red"] = "Кровавые дела",
			["bm_suit_var_suit_sunny_red_desc"] = "Привязанный к стулу Клокер, Алабамская бритва, 'Troubles Always Inbound' по радио... Эта рубашка не останется чистой надолго.",

			["bm_suit_var_suit_sunny_blue"] = "Цифровые дела",
			["bm_suit_var_suit_sunny_blue_desc"] = "Хакеры - волшебники 21-го века, которые могут вытворять практически все что угодно... Но не останавливать пули. Для этого есть броня. Так что не будь слишком самоуверенным и носи защиту.",

			["bm_suit_var_suit_sunny_green"] = "Жадные дела",
			["bm_suit_var_suit_sunny_green_desc"] = "Вне зависимости от риска, ты уносишь всю добычу с любого ограбления. Дело даже не в деньгах: вычищенное хранилище - это твоя визитная карточка.",

			["bm_suit_var_suit_sunny_yellow"] = "Солнечные дела",
			["bm_suit_var_suit_sunny_yellow_desc"] = "Отличный костюм для романтичных поездок под солнцем.\nПод аккомпанемент полицейских сирен, разумеется.",

			["bm_suit_var_suit_sunny_pink"] = "Гладкие дела",
			["bm_suit_var_suit_sunny_pink_desc"] = "Мистеру Розовому повезло, что в банде Кабота нет цветного дресс-кода.",

			["bm_suit_var_suit_sunny_hawaii_black"] = "Отпуск в Майами",
			["bm_suit_var_suit_sunny_hawaii_black_desc"] = "Вульф купил эту стильную рубашку, когда узнал, что Дантист готовит работу под кодовым названием 'Горячая линия Майами'. Кто же знал, что они не поедут в Майами?",

			["bm_suit_var_suit_sunny_hawaii_blue"] = "Отпуск в видеоиграх",
			["bm_suit_var_suit_sunny_hawaii_blue_desc"] = "Джой относится к типу людей, которые уезжают в отпуск далеко-далеко чтобы просто играть там в видеоигры. 'Ну что за поколение', подумал Даллас, когда ему не удалось увлечь ее более консервативными развлечениями, такими как игрой в бильярд, наслаждением видами моря и распитием огромного количества скотча.",

			["bm_suit_var_suit_sunny_hawaii_cyan"] = "Отпуск в бассейне",
			["bm_suit_var_suit_sunny_hawaii_cyan_desc"] = "Сидни отличный пловец, и всегда хотела бассейн в убежище. Однако, Альдстоуну и так хватает хлопот, да и плавание - не самое любимое развлечение банды после дела на Мосту Грин.",

			["bm_suit_var_suit_sunny_hawaii_green"] = "Отпуск в притоне",
			["bm_suit_var_suit_sunny_hawaii_green_desc"] = "Влад отлично проводил время в Мексике. Новые земли - это новые возможности, и он расширял свой бизнес, пока однажды одну из его точек не атаковали. Федеральной полиции настучал Булук, который вскоре станет врагом Влада номер один. К счастью, банда PAYDAY всегда под рукой.",

			["bm_suit_var_suit_sunny_hawaii_orange"] = "Отпуск в оффшорах",
			["bm_suit_var_suit_sunny_hawaii_orange_desc"] = "Вот и все, вы справились. Белый дом ограблен, все злодеи побеждены, а ваш оффшор потрачен на крупную вечеринку. И куда двигаться теперь?\nЛадно, еще парочка ограблений банка не повредит.",

			["bm_suit_var_suit_sunny_hawaii_pink"] = "Отпуск на танцполе",
			["bm_suit_var_suit_sunny_hawaii_pink_desc"] = "Чейнс нечасто уходит в отпуск, но делает это с размахом. В 2016-ом, видео с его зажигательным танцем утекло в сеть. Ему пришлось просить Бейна стереть его оттуда.",

			["bm_suit_var_suit_sunny_hawaii_red"] = "Отпуск в архипелаге",
			["bm_suit_var_suit_sunny_hawaii_red_desc"] = "Джимми любит рассказывать, как его далекий отпуск прервала армия генно-модифицированных супер-солдат. Звучит как очередной кокаиновый бред, но после ограбления АКАНа... Кто знает?",

			["bm_suit_var_suit_sunny_payne"] = "Отпуск в нуаре",
			["bm_suit_var_suit_sunny_payne_desc"] = "Во время отпуска в Сан-Пауле, Вульф захотел купить эту рубашку, но получил ее бесплатно в знак благодарности за то что оказал отличную службу городу. \nВульф удивился, ведь он никогда не был там раньше.",

			["bm_suit_var_suit_sunny_vice"] = "Отпуск в пороках",
			["bm_suit_var_suit_sunny_vice_desc"] = "Сангреса нельзя заставить носить ничего, кроме ярких рубашек. Пока остальные гении преступного мира собираются в деловых костюмах, Сангрес врывается в потрепанной рубашке, которую он нашел на гаражной распродаже в городе порока. Выглядит так, будто ей уже больше сорока лет.",

			["bm_suit_var_suit_sunny_security_red"] = "Красный телохранитель",
			["bm_suit_var_suit_sunny_security_red_desc"] = "Элитный телохранитель Эрнеста Сосы. У Эрнеста Сосы было все. Большой особняк, надеждный бизнес и непробиваемая охрана. Мир принадлежит ему... Но как известно, история движется по спирали.",

			["bm_suit_var_suit_sunny_security_purple"] = "Фиолетовый телохранитель",
			["bm_suit_var_suit_sunny_security_purple_desc"] = "Элитный телохранитель Эрнеста Сосы. Постоянное наблюдение через дронов и организованная охрана. В особняк Сосы не пробраться. Вот бы еще кто-нибудь проверил последнюю партию кокаина...",

			["bm_suit_var_suit_sunny_soprano"] = "Мафиозные дела",
			["bm_suit_var_suit_sunny_soprano_desc"] = "Мафия не очень близка банде PAYDAY, но их стиль заслуживает уважения.",
		    -- вариации - Prison Suit
			["bm_suit_var_suit_prison_default"] = "Беглец",
			["bm_suit_var_suit_prison_default_desc"] = "Роба, которая изменила Хокстона навсегда. Он был уверен, что сжег это напоминание о жутком прошлом вместе со старым убежищем, но каким-то мистическим образом оно оказалось в новом.",

			["bm_suit_var_suit_prison_repairman"] = "31-ый",
			["bm_suit_var_suit_prison_repairman_desc"] = "Знаете, кто расставляет шпионские камеры?\n\nЛичности вы никогда не узнаете, но хотя бы можно оценить его одежду.",

			["bm_suit_var_suit_prison_comedy"] = "Воришка",
			["bm_suit_var_suit_prison_comedy_desc"] = "Роба Чинса из банды PAYCHECK. Ему почти удалось сбежать с 225 долларами из кассы магазина Pear, но его взяли под стражу. К счастью, его соратники взяли в заложники ноутбук Pear и сумели обменять его на Чинса.",

			["bm_suit_var_suit_prison_vaultboy"] = "Выживший",
			["bm_suit_var_suit_prison_vaultboy_desc"] = "К удивлению, Бейн никогда не верил в теории о скором конце света. Но после того, как Влад попросил украсть ядерные боеголовки, он построил себе подземное убежище. Ну вы знаете. Война.",

			["bm_suit_var_suit_prison_janitor"] = "Уборщик",
			["bm_suit_var_suit_prison_janitor_desc"] = "Ходят слухи, что OMNIA проводит сверхсекретные испытания, да такие, что даже бы ученые с Утеса Генри позавидовали. Всех в OMNIA заставляют подписать контракт. Даже уборщиков держат под... контролем.",

			["bm_suit_var_suit_prison_subject"] = "Подопытный",
			["bm_suit_var_suit_prison_subject_desc"] = "Джимми снял этот костюм с подопытного во время побега из лаборатории АКАНа. Вдруг секрет их сверхъестественных способностей таится в этой робе?",


		--краски для оружий
		["bm_wskn_resmod_blackgold"] = "Черное золото",
		["bm_wskn_resmod_cleangold"] = "Чистое золото",
		["bm_wskn_resmod_imissfauna"] = "Обработанное золото",
		["bm_wskn_resmod_imissfauna_desc"] = "",
		["bm_wskn_resmod_uuuuu"] = "Готическая Церера",
		["bm_wskn_resmod_uuuuu_desc"] = "",
		["bm_wskn_resmod_ownthiscity"] = "Царское золото",
		["bm_wskn_resmod_kindoffeel"] = "Абстрактно-темное золото",
		["bm_wskn_resmod_kindoffeel2"] = "Абстрактно-яркое золото",
		["bm_wskn_resmod_insubstantial"] = "Треснутое золото",
		["bm_wskn_resmod_palmtop"] = "Тигриное золото",
		["bm_wskn_resmod_palmtop_desc"] = "",
		["bm_wskn_resmod_blacktiger"] = "Золото черного тигра",
		["bm_wskn_resmod_joe"] = "Экзотическое золото",
		["bm_wskn_resmod_blackexotic"] = "Экзотическое золото (темное)",
		["bm_wskn_resmod_lildonnie"] = "Жемчужное золото",
		["bm_wskn_resmod_quacko"] = "Потемневшее золото",
		["bm_wskn_resmod_snake"] = "Расплавленное золото",
		["bm_wskn_resmod_camo"] = "Камуфляжное золото",
		["bm_wskn_resmod_camo2"] = "Затуманенное золото",
		["bm_wskn_resmod_digital"] = "Цифровое золото",
		["bm_wskn_resmod_splinter"] = "Составное золото",
		["bm_wskn_resmod_urban"] = "Поддельное золото",
		["bm_wskn_resmod_dioxide"] = "Углеродное золото",
		["bm_wskn_resmod_rat"] = "Воровское золото",
		["bm_wskn_resmod_ratdark"] = "Воровское золото (темное)",
		["bm_wskn_resmod_rocker"] = "Статичное золото",
		["bm_wskn_resmod_shocker"] = "Статичное золото (темное)",
		["bm_wskn_resmod_whitefire"] = "Пламенное золото",
		["bm_wskn_resmod_blackfire"] = "Пламенное золото (темное)",
		["bm_wskn_resmod_topography"] = "Топографическое золото",
		["bm_wskn_resmod_2019"] = "Закаленное золото",
		["bm_wskn_resmod_llenn"] = "Мистер Пинк",
		["bm_wskn_resmod_llenn_desc"] = "",
		["bm_wskn_resmod_sugarhoneyicetea"] = "Золото зебры",
		["bm_wskn_resmod_blackzebra"] = "Золото черной зебры",
		["bm_wskn_resmod_charlotte"] = "Паучье золото",
		["bm_wskn_resmod_joker"] = "Насмешка над золотом",
		["bm_wskn_resmod_jokerw"] = "Насмешка над обществом",

		["menu_weapon_color_index_11"] = "Металл + Прицел",
		["menu_weapon_color_index_12"] = "Металл + Магазин",
		["menu_weapon_color_index_13"] = "Металл + Прицел + Магазин",

	})
end)

-- Просто различные стринги, для которых не имееет смысла (или в падлу) выделять хуки
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Mix", function(loc)
	LocalizationManager:add_localized_strings({
		["menu_es_boost"] = "Лучшая",
		["menu_es_crew"] = "Командная",
		["menu_es_personal"] = "Личная",
		["menu_es_bad"] = "Плохая",
		["menu_es_other"] = "Прочая",
		["RestorationPDTHHudNeeded"] = "PD:TH HUD REBORN IS REQUIRED!",
		["menu_paygrade"] = "Степень оплаты: ",
		["menu_diffgrade"] = "Сложность: ",
		["menu_utility_radial_menu_name"] = "Utility Radial Menu",
		["menu_utility_radial_menu_desc"] = "Open the Utility Menu",
		["resmod_1st_time_title"] = "Placeholder title",
		["resmod_1st_time_desc"] = "Placeholder text info",
		["resmod_message_confirm"] = "OK",


		["res_credits"] = "Титры Restoration Mod",
		["res_credits_help"] = "Посмотреть титры RESTORATION MOD.",

		["Warning_overhaul_title"] = "WARNING: Game closing to prevent save corruption.",
		["dialog_show_overhaul_dialog"] = "You are DISABLING the Complete Overhaul. It is typically NOT RECOMMENDED to do this, and you should instead REMOVE the mod from your mods folder if you intend not to use the Overhaul actively.\n\nYour game will close automatically in $TIME seconds, or when you press OK.",
		["dialog_enable_overhaul_dialog"] = "You are ENABLING the Complete Overhaul. The Overhaul should typically remain ON at all times, and only be disabled by removing the mod from your mods folder.\n\nYour game will close automatically in $TIME seconds, or when you press OK.",

		["res_saveboost"] = "УДЕРЖИВАЙТЕ $BTN_INTERACT ЧТОБЫ ПРОКАЧАТЬСЯ ДО 100 УРОВНЯ",
		
		["bm_sc_blank"] = "", --assumedly this is a debug thing, but I'm not going to touch it--

		--Меню--
		["menu_hud_cheater"] = "",
		["menu_inspect_player"] = "Осмотреть игрока",
		["menu_inspect_player_desc"] = "Осмотреть статистику игрока",
		["menu_toggle_one_down_lobbies"] = "Разрешить режим Pro-Job",

		["heist_safehouse"] = "Старое Убежище",

		--События

		--Anniversary Event
		["menu_pda8_1_prog_obj_desc"] = "Найти 2 праздничные статуэтки в Ювелирном магазине, Четырех магазинах, Ночном клубе, Ограблении банка или Крушителе. Для выполнения задания, ограбление нужно пройти до конца.",
		["menu_pda8_2_prog_obj_desc"] = "Всем сообществом грабители должны потратить $5,000,000,000 на пенсию копов при помощи Бабломета, также вам нужно найти 3 разных праздничных статуэтки в Ювелирном магазине, Четырех магазинах, Ночном клубе, Ограблении банка или Крушителе. Для выполнения задания, ограбление нужно пройти до конца.",
		["menu_pda8_3_prog_obj_desc"] = "Всем сообществом грабители должны потратить $10,000,000,000 на пенсию копов при помощи Бабломета, также вам нужно найти 4 разных праздничных статуэтки в Ювелирном магазине, Четырех магазинах, Ночном клубе, Ограблении банка или Крушителе. Для выполнения задания, ограбление нужно пройти до конца.",
		["menu_pda8_item_1_desc"] = "Всем сообществом грабители должны потратить $15,000,000,000 на пенсию копов при помощи Бабломета, также вам нужно найти 3 разных праздничных статуэтки в Ювелирном магазине, Четырех магазинах, Ночном клубе, Ограблении банка или Крушителе. Для выполнения задания, ограбление нужно пройти до конца.",

		["menu_pda8_2_prog_obj"] = "Найти 3 праздничные статуэтки.",
		["menu_pda8_3_prog_obj"] = "Найти 4 праздничные статуэтки.",

		--Holdout--
		["menu_cn_skirmish"] = "Столкновение",
		["menu_skirmish"] = "Столкновение - оборона заложника",
		["hud_skirmish"] = "Столкновение",
		["heist_contact_skirmish"] = "Столкновение",
		["menu_skirmish_pick_heist"] = "Компания Джекела доверяет вам эту работу",
		["menu_skirmish_map_selection"] = "Локации",
		["menu_skirmish_selected_briefing"] = "В этом режиме вы можете выбрать любое СТОЛКНОВЕНИЕ.\n\nСТОЛКНОВЕНИЕ состоит из 9 волн. Каждая волна увеличивается в сложности.\n\nВы будете получать больше денег и опыта с каждой волной, но поражение заберет все накопленные награды.\n\nВы проиграете, если заложник будет освобожден.",
		["menu_skirmish_selected"] = "Столкновение",

		
		["windowofoppurtunity"] = "Window Of Opportunity",
		["wheresthevan"] = "Where's The Van",
		["menu_jukebox_heist_ponr"] = "Точка невозврата",
		

		["menu_support"] = "Гайд/помощь по ребалансу",
		["menu_support_help"] = "Просмотреть гайд по ребалансу в Restoration Mod, получить помощь, найти других игроков.",
		["menu_manual_header"] = "Placeholder Text",
		["hud_assault_alpha"] = "ПОЛИЦЕЙСКИЙ ШТУРМ",
		["hud_loot_secured_title"] = "ДОБЫЧА ЗАХВАЧЕНА!",
		["debug_none"] = "ЗАДАЧА",

		["heist_platinum_brief"] = "stir the boat",
		["heist_jackal_surface_tension_name"] = "OMNIA Research Vessel SN-XR-LETHE",
		["heist_jackal_surface_tension_brief"] = "PLACEHOLDER",

		["heist_vivinite_name"] = "Zero Day",

		["heist_contact_shatter"] = "Джекел",
		["heist_contact_akashic"] = "Нико",

		["menu_contacts_shatter"] = "Союзники CRIMENET",
		["heist_contact_jackal_description"] = "Джекел начал свою карьеру в GenSec, но уволился после инцидента, связанного с торговлей людьми, в котором были замешаны GenSec и OMNIA.\n\nТеперь он работает на CRIMENET, поставляя проблемы им прямо на дом.",
		["heist_contact_akashic_description"] = "В прошлом - высокопоставленный агент Гектора Моралеса, Николас 'Нико' Рене теперь командует остатками Синалоанского картеля в США. \nИх численность мала, и более крупный Колумбийский картель не собирается ни предоставлять помощь, ни восстанавливать союз с CRIMENET. Нико объединяется с различными мелкими бандами на Восточном побережье, а также с CRIMENET - он предоставит свои ресурсы в обмен на услуги.",


		

		["menu_alex_1_zipline"] = "Зиплайн для сумок",

		["menu_asset_wet_intel"] = "Разведданные",
		["menu_asset_risk_murky"] = "Наемники Murkywater",
		["menu_asset_risk_bexico"] = "Мексиканская федеральная полиция",
		["menu_asset_risk_zombie"] = "зОмбИ пОлиЦиЯ",
		["menu_asset_wet_boat"] = "Лодка",
		["menu_asset_wet_boat_desc"] = "Купить дополнительную точку сброса и побега",

		
		["pattern_jkl_patt01_title"] = "Шакалы",
		["pattern_jkl_patt02_title"] = "Компания",
		["material_jkl_matt01_title"] = "Грозные перья",
		["material_jkl_matt02_title"] = "Золото Веритас",

		["menu_scores"] = "SCORES",
		
		--Safe House--
		["dialog_safehouse_text"] = "Вы еще не посещали убежище.\n\nСоветуем это сделать, ведь там ждет кое-что новое.\n\nПерейти туда сейчас?",
		

		["menu_ingame_manual"] = "Гайд по Restoration",
		["menu_ingame_manual_help"] = "Просмотреть гайд по Restoration.",

		["menu_asset_wet_add_saw"] = "Дополнительная пила",
		["menu_asset_wet_add_saw_desc"] = "Закупить дополнительную пилу",
		["menu_rush_asset_sentrygun"] = "Турель",
		["menu_rush_asset_sentrygun_desc"] = "Закупить дополнительную турель",

		

		["wwburn_serverpku"] = "Secure",
		["wwburn_gaspku"] = "Collect",
		["wwburn_defend"] = "Defend",
		["wwburn_container"] = "Shipping Container",

		["menu_jukebox_resmusic_wetwork"] = "Spectre Shark",
		["menu_jukebox_screen_resmusic_wetwork"] = "Spectre Shark",
		["menu_jukebox_resmusic_bluewave"] = "Spectre Shark 2020",
		["menu_jukebox_screen_resmusic_bluewave"] = "Spectre Shark 2020",
		["menu_jukebox_resmusic_burnout"] = "Brute Force",
		["menu_jukebox_screen_resmusic_burnout"] = "Brute Force",
		["menu_jukebox_resmusic_doghouse"] = "Bleeding Edge",
		["menu_jukebox_screen_resmusic_doghouse"] = "Bleeding Edge",
		["menu_jukebox_resmusic_lethalforce"] = "Lethal Force",
		["menu_jukebox_screen_resmusic_lethalforce"] = "Lethal Force",
		["menu_jukebox_resmusic_redmarks"] = "Red Marks",
		["menu_jukebox_screen_resmusic_redmarks"] = "Red Marks",
		["menu_jukebox_resmusic_ticktockalpha"] = "Tick Tock (Альфа)",
		["menu_jukebox_screen_resmusic_ticktockalpha"] = "Tick Tock (Альфа)",
		["menu_jukebox_resmusic_doublecrossbeta"] = "Double Cross (Бета)",
		["menu_jukebox_screen_resmusic_doublecrossbeta"] = "Double Cross (Бета)",
		["menu_jukebox_resmusic_gunmetalgreybeta"] = "Gun Metal Grey (Бета)",
		["menu_jukebox_screen_resmusic_gunmetalgreybeta"] = "Gun Metal Grey (Бета)",
		["menu_jukebox_resmusic_thetakeoriginal"] = "Phoney Money / The Take (Старый)",
		["menu_jukebox_screen_resmusic_thetakeoriginal"] = "Phoney Money / The Take (Старый)",
		["menu_jukebox_resmusic_razormindbeta"] = "Razormind (Бета)",
		["menu_jukebox_screen_resmusic_razormindbeta"] = "Razormind (Бета)",
		["menu_jukebox_resmusic_ponr"] = "Window of Opportunity",
		["menu_jukebox_screen_resmusic_ponr"] = "Window of Opportunity",
		["menu_jukebox_resmusic_speciesnova"] = "Species Nova",
		["menu_jukebox_screen_resmusic_speciesnova"] = "Species Nova",
		["menu_jukebox_resmusic_madvlad"] = "Mad Vlad",
		["menu_jukebox_screen_resmusic_madvlad"] = "Mad Vlad",
		["menu_jukebox_resmusic_proto"] = "Jackknife",
		["menu_jukebox_screen_resmusic_proto"] = "Jackknife",
		["menu_jukebox_screen_m1"] = "Criminal Intent (Старый)",
		["menu_jukebox_screen_m2"] = "Preparations (Старый)",
		["menu_jukebox_screen_m3"] = "Blueprints (Прототип)",
		["menu_jukebox_screen_m4"] = "Resistance",
		["menu_jukebox_screen_m5"] = "Fortress",
		["menu_jukebox_screen_m6"] = "Payday Royale Theme",
		["menu_jukebox_screen_m7"] = "Pre-Planning",
		["menu_jukebox_screen_m_holiday"] = "The Headless Bulldozer",

		["menu_color_plus"] = "E3 PAYDAY+",
		["menu_color_rvd1"] = "Inverted",
		["menu_color_e3nice"] = "E3 Nice",
		["menu_color_force"] = "E3 BHD",
		["menu_color_halloween"] = "Change",
		["menu_color_halloween2"] = "Pumpkin Spice",

		["color_plus"] = "E3 PAYDAY+",
		["color_rvd1"] = "Inverted",
		["color_e3nice"] = "E3 Nice",
		["color_force"] = "E3 BHD",
		["color_halloween"] = "Change",
		["color_halloween2"] = "Pumpkin Spice",

		["gm_gms_purchase"] = "Купить монетами Континенталь",
		["gm_gms_purchase_window_title"] = "Вы уверены?",
		["gm_gms_purchase_window_message"] = "Вы действительно хотите купить '{1}'?\n\nЭто будет стоить вам {2} {3}.",
		["gm_gms_purchase_failed"] = "Невозможно купить",
		["gm_gms_free_of_charge_message"] = "{1} бесплатен и может быть использован сколько угодно раз.",
		["gm_gms_cannot_afford_message"] = "Вы не можете купить {1}, так как у вас недостаточно {3}. Чтобы купить {1}, нужно {2} {3}",

		["bm_menu_amount_locked"] = "НЕТ В НАЛИЧИИ",

		["resmod_challenges"] = "Испытания",
		["resmod_challenges_hint"] = "Посмотреть выполненные и активные испытания.",
		["resmod_active_challenges"] = "Активные испытания",
		["resmod_active_challenges_hint"] = "Текущие и активные испытания.",
		["resmod_completed_challenges"] = "Выполненные испытания",
		["resmod_completed_challenges_hint"] = "Завершенные испытания.",

		["ch_vs_desc"] = "Используя $weapon, устраните $count $eneType. Убийства в ближнем бою не засчитываются для выполнения этого испытания.",
		["ch_vs_head_shots_desc"] = "Используя $weapon, устраните $count $eneType выстрелами в голову.",
		["ch_vs"] = "$weapon против $eneType $no",
		["ch_vs_head_shots"] = "$weapon против $eneType В ГОЛОВУ $no",

		["ene_law"] = "всех",
		["ene_law_desc"] = "врагов",

		["menu_me"] = "Грабитель",

		["RestorationModPDTHChallengesTitleID"] = "Отображать испытания из PDTH",
		["RestorationModPDTHChallengesDescID"] = "Включает отображение испытаний из PDTH в меню и на HUD.",

		["RestorationModRaidLockPickingTitleID"] = "Modify Lockpicks",
		["RestorationModRaidLockPickingDescID"] = "Should the mod modify lockpicks? This changes the gameplay revolving lockpicks",
		["RestorationModRaidLockPickingVOTitleID"] = "Play Voice Lines",
		["RestorationModRaidLockPickingVODescID"] = "Should the mod play voice lines when picking a lock?",
		["hud_legend_lockpicking_interact"] = "$BTN_INTERACT Взломать",
		["hud_legend_persuade_interact"] = "$BTN_INTERACT Убедить",
		["hud_legend_exit"] = "$BTN_CANCEL Выйти",
		["RestorationModArmorFixTitleID"] = "Фикс подсвечивания брони",
		["RestorationModArmorFixDescID"] = "Включить или выключить фикс подсвечивания брони.",
		
		["menu_toggle_one_down"] = "Pro-Job",
		["menu_one_down"] = "Pro-Job",
		["menu_es_pro_job_bonus"] = "Pro-Job",

		["menu_pro_warning"] = "Режим PRO JOB: При провале, контракт будет отменен.\nПод конец ограбления может начаться Точка Невозврата, во время которой появятся более опасные противники.\nПрохождение в режиме Pro Job дает на 25% больше денег и опыта.",

		["menu_asset_lock_additional_assets_pro"] = "НЕДОСТУПНО В РЕЖИМЕ PRO-JOB!",
		["menu_asset_buy_all_req_skill"] = "##NOT AVAILABLE!##",

		["cn_menu_contract_daypay_header"] = "Дневная плата:",
		["cn_menu_contract_jobpay_header"] = "Плата за контракт:",

		["debug_interact_grenade_crate_take_grenades"] = "УДЕРЖИВАЙТЕ $BTN_INTERACT ЧТОБЫ ВЗЯТЬ МЕТАТЕЛЬНОЕ ОРУЖИЕ",
		["debug_interact_bodybags_bag_take_bodybag"] = "УДЕРЖИВАЙТЕ $BTN_INTERACT ЧТОБЫ ВЗЯТЬ МЕШКИ ДЛЯ ТРУПОВ И СТЯЖКИ",

	    ["menu_equipment_armor_kit"] = "Кейс с метательным оружием",
		["bm_equipment_armor_kit"] = "Кейс с метательным оружием",
		["debug_equipment_armor_kit"] = "Кейс с метательным оружием",
		["bm_equipment_armor_kit_desc"] = "Чтобы использовать кейс с метательным оружием, вам нужно установить его, зажав #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить, но можно использовать вам или вашим напарникам, нажатием #{skill_color}#$BTN_INTERACT##, чтобы восполнить запас метательного оружия. Он может быть использован #{skill_color}#3## раза.\n\nВы можете увидеть, сколько еще раз можно использовать кейс, посмотрев на него.\n\nКейс с метательным оружием это скрытная вещь, используемая солдатами и наемниками для переноски особого оружия на тяжелый случай.",
		["bm_equipment_armor_kit_desc_short"] = "Чтобы использовать кейс с метательным оружием, вам нужно установить его, зажав #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить, но можно использовать вам или вашим напарникам, нажатием #{skill_color}#$BTN_INTERACT##, чтобы восполнить запас метательного оружия. Он может быть использован #{skill_color}#3## раза.\n\nВы можете увидеть, сколько еще раз можно использовать кейс, посмотрев на него.",
		--Ordanance Bag
		["menu_equipment_grenade_crate"] = "Арсенальная сумка",
		["bm_equipment_grenade_crate"] = "Арсенальная сумка",
		["bm_equipment_grenade_crate_desc"] = "Чтобы использовать арсенальную сумку, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить, но можно использовать вам или вашим напарникам, нажатием $BTN_INTERACT, чтобы восполнить #{skill_color}#$deployable_secondary_info## запаса патронов и #{skill_color}#1## метательное оружие. Она может быть использована #{skill_color}#$deployable_uses## раза.\n\nВы можете увидеть, сколько еще раз можно использовать сумку, посмотрев на нее.\n\nАрсенальная сумка используется оперативниками для транспортировки взрывчатки на место боевых действий.",
		["bm_equipment_grenade_crate_desc_short"] = "Чтобы использовать арсенальную сумку, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить, но можно использовать вам или вашим напарникам, нажатием $BTN_INTERACT, чтобы восполнить #{skill_color}#$deployable_secondary_info## запаса патронов и #{skill_color}#1## метательное оружие. Она может быть использована #{skill_color}#$deployable_uses## раза.\n\nВы можете увидеть, сколько еще раз можно использовать сумку, посмотрев на нее.",
		--Trip Mine
		["bm_equipment_trip_mine_desc"] = "Чтобы использовать мину, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM## Лазер можно переключать между режимами детонации и сенсора, нажав #{skill_color}#$BTN_INTERACT.##\n\nЧтобы использовать кумулятивные заряды, их нужно установить, используя #{skill_color}#$BTN_INTERACT.## Когда нужное количество зарядов установлено, они детонируют через несколько секунд.\n\nШанс подбора: от #{skill_color}#$pickup_1 до $pickup_2## коробок.\n\nМины - это растяжки, которые уничтожат или нанесут существенный вред врагам, которые пересекут луч. Кумулятивные заряды используются для вскрытия дверей и сейфов. Оба - отличное дополнение при любой боевой ситуации.",
		["bm_equipment_trip_mine_desc_short"] = "Чтобы использовать мину, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM## Лазер можно переключать между режимами детонации и сенсора, нажав #{skill_color}#$BTN_INTERACT.##\n\nЧтобы использовать кумулятивные заряды, их нужно установить, используя #{skill_color}#$BTN_INTERACT.## Когда нужное количество зарядов установлено, они детонируют через несколько секунд.",
		--Ammo Bag
		["bm_equipment_ammo_bag_desc"] = "Чтобы использовать сумку с патронами, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM## После установки ее нельзя переместить, но можно использовать, удерживая $BTN_INTERACT, чтобы восполнить запас патронов.\n\nОна восстанавливает полный запас патронов #{skill_color}#$deployable_uses## раз(а); остаток запаса можно определить по виду сумки.\n\nСумка с патронами - портативная часть экипировки, позволяющая бойцам легко переносить большие запасы амуниции.",
		["bm_equipment_ammo_bag_desc_short"] = "Чтобы использовать сумку с патронами, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM## После установки ее нельзя переместить, но можно использовать, удерживая $BTN_INTERACT, чтобы восполнить запас патронов.\n\nОна восстанавливает полный запас патронов #{skill_color}#$deployable_uses## раз(а); остаток запаса можно определить по виду сумки.",
		--ECM Jammer
		["bm_equipment_ecm_jammer_desc"] = "Чтобы использовать генератор помех, вам нужно установить его, удерживая #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить. Он активируется на #{skill_color}#$deployable_uses## секунд.\n\nВы можете переключить режим работы генератора помех при взаимодействии с ним. В этом случае, генератор помех будет оглушать врагов в радиусе #{skill_color}#25## метров. Первые помехи имеют #{skill_color}#100%## шанс оглушить врага, затем каждые #{skill_color}#1.2## секунды помех имеют #{skill_color}#60%## шанс на оглушение. Помехи длятся #{skill_color}#$deployable_uses## секунд, и перезаряжаются через #{skill_color}#4## минуты.\n\nГенераторы помех могут взламывать банкоматы и ненадолго отключать электронные устройства - телефоны, камеры и прочие системы безопасности.",
		["bm_equipment_ecm_jammer_desc_short"] = "Чтобы использовать генератор помех, вам нужно установить его, удерживая #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить. Он активируется на #{skill_color}#$deployable_uses## секунд.\n\nВы можете переключить режим работы генератора помех при взаимодействии с ним. В этом случае, генератор помех будет оглушать врагов в радиусе #{skill_color}#25## метров. Первые помехи имеют #{skill_color}#100%## шанс оглушить врага, затем каждые #{skill_color}#1.2## секунды помех имеют #{skill_color}#60%## шанс на оглушение. Помехи длятся #{skill_color}#$deployable_uses## секунд, и перезаряжаются через #{skill_color}#4## минуты.",
		--FAQ U
		["bm_equipment_first_aid_kit_desc"] = "Удерживайте кнопку #{skill_color}#$BTN_USE_ITEM##, чтобы установить аптечку. Ее нельзя переместить после установки, но можно использовать, зажав кнопку #{skill_color}#$BTN_INTERACT##, чтобы восстановить #{skill_color}#150## здоровья. Аптечку первой помощи можно использовать только #{skill_color}#1## раз.\n\nАптечка первой помощи - небольшой ассортимент лечебных средств, используемый в экстренных ситуациях.",
        ["bm_equipment_first_aid_kit_desc_short"] = "Удерживайте кнопку #{skill_color}#$BTN_USE_ITEM##, чтобы установить аптечку. Ее нельзя переместить после установки, но можно использовать, зажав кнопку #{skill_color}#$BTN_INTERACT##, чтобы восстановить #{skill_color}#150## здоровья. Аптечку первой помощи можно использовать только #{skill_color}#1## раз.",
		--AAAAAAAAAAAAAAAAAAAAAAAAAAAAA
		["bm_equipment_doctor_bag_desc"] = "Чтобы использовать медицинскую сумку, вам нужно установить ее, используя #{skill_color}#$BTN_USE_ITEM##. После установки ее нельзя переместить, но можно использовать, удерживая #{skill_color}#$BTN_INTERACT##, чтобы восстановить #{skill_color}#20%## максимального здоровья сразу и #{skill_color}#4%## максимального здоровья каждые #{skill_color}#5## секунд в течение #{skill_color}#3## минут и получить #{skill_color}#10%## Устойчивости. Медицинскую сумку можно использовать #{skill_color}#$deployable_uses## раз(а).\n\nМедицинская сумка - портативный кейс, который используется профессиональными врачами для переноса медикаментов и лекарств.",
		["bm_equipment_doctor_bag_desc_short"] = "Чтобы использовать медицинскую сумку, вам нужно установить ее, используя #{skill_color}#$BTN_USE_ITEM##. После установки ее нельзя переместить, но можно использовать, удерживая #{skill_color}#$BTN_INTERACT##, чтобы восстановить #{skill_color}#20%## максимального здоровья сразу и #{skill_color}#4%## максимального здоровья каждые #{skill_color}#5## секунд в течение #{skill_color}#3## минут и получить #{skill_color}#10%## Устойчивости. Медицинскую сумку можно использовать #{skill_color}#$deployable_uses## раз(а).",
        --Sentry
		["bm_equipment_sentry_gun_desc"] = "Чтобы использовать турель, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM##. Вы используете #{skill_color}#$deployable_uses## вашего запаса патронов на установку. \n\nТурель можно забрать обратно, зажав #{skill_color}#$BTN_INTERACT## возле нее; это вернет вам остаток патронов и починит ее. \n\nПри получении большого количества урона, турель отключится. Если это произошло, вы можете запустить режим починки, удерживая #{skill_color}#$BTN_INTERACT##. \n\nТурели пугают гражданских, заставляя их оставаться на месте.\n\nТурель автоматически наводится и стреляет по целям, которые попадают под ее сенсор. Она используется для отвлечения противников от вас и вашей команды.",
		["bm_equipment_sentry_gun_desc_short"] = "Чтобы использовать турель, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM##. Вы используете #{skill_color}#$deployable_uses## вашего запаса патронов на установку. \n\nТурель можно забрать обратно, зажав #{skill_color}#$BTN_INTERACT## возле нее; это вернет вам остаток патронов и починит ее. \n\nПри получении большого количества урона, турель отключится. Если это произошло, вы можете запустить режим починки, удерживая #{skill_color}#$BTN_INTERACT##. \n\nТурели пугают гражданских, заставляя их оставаться на месте.",
		--Supp. Sentry
		["bm_equipment_sentry_gun_silent_desc"] = "Чтобы использовать приглушенную турель, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM##. Вы используете #{skill_color}#$deployable_uses## вашего запаса патронов на установку. \n\nТурель можно забрать обратно, зажав #{skill_color}#$BTN_INTERACT## возле нее; это вернет вам остаток патронов и починит ее. \n\nПри получении большого количества урона, турель отключится. Если это произошло, вы можете запустить режим починки, удерживая #{skill_color}#$BTN_INTERACT##. \n\nТурели пугают гражданских, заставляя их оставаться на месте.\n\nПриглушенная турель, в отличие от громкой обычной, используется для убийства врагов, а не отвлечения.",
		["bm_equipment_sentry_gun_silent_desc_short"] = "Чтобы использовать приглушенную турель, вам нужно установить ее, зажав #{skill_color}#$BTN_USE_ITEM##. Вы используете #{skill_color}#$deployable_uses## вашего запаса патронов на установку. \n\nТурель можно забрать обратно, зажав #{skill_color}#$BTN_INTERACT## возле нее; это вернет вам остаток патронов и починит ее. \n\nПри получении большого количества урона, турель отключится. Если это произошло, вы можете запустить режим починки, удерживая #{skill_color}#$BTN_INTERACT##. \n\nТурели пугают гражданских, заставляя их оставаться на месте.",
		--Body Bags
		["bm_equipment_bodybags_bag_desc"] = "Чтобы использовать кейс, вам нужно установить его, зажав #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить, но можно использовать, удерживая #{skill_color}#$BTN_INTERACT##, чтобы восстановить мешки для тел и стяжки.\n\nУ кейса ограниченный запас. По его виду можно понять, сколько сумок осталось. \n\nКейс позволяет восполнить мешки для тел и стяжки, использующиеся для транспортировки тел при скрытных операциях и контроле толп гражданских.",
		["bm_equipment_bodybags_bag_desc_short"] = "Чтобы использовать кейс, вам нужно установить его, зажав #{skill_color}#$BTN_USE_ITEM##. После установки его нельзя переместить, но можно использовать, удерживая #{skill_color}#$BTN_INTERACT##, чтобы восстановить мешки для тел и стяжки.\n\nУ кейса ограниченный запас. По его виду можно понять, сколько сумок осталось.",


		["hud_int_hold_take_pardons"] = "НАЖМИТЕ $BTN_INTERACT ЧТОБЫ ВЗЯТЬ ПОМИЛОВАНИЕ",
		["debug_interact_gage_assignment_take"] = "НАЖМИТЕ $BTN_INTERACT ЧТОБЫ ЗАБРАТЬ ПОСЫЛКУ ГЕЙДЖА",

		["hint_ability_no_grenade_pickup"] = "У ВАС НЕТ МЕТАТЕЛЬНОГО ОРУЖИЯ",
		["hint_full_grenades"] = "У ВАС УЖЕ ПОЛНЫЙ ЗАПАС.",
		["debug_interact_ordnance_bag_take_grenades"] = "НАЖМИТЕ $BTN_INTERACT ЧТОБЫ ВЗЯТЬ МЕТАТЕЛЬНОЕ ОРУЖИЕ И НЕМНОГО ПАТРОНОВ",

		["far_repair_sentry_macro"] = "Турель критически повреждена - требуется ремонт.",
		["fixing_sentry_macro"] = "Прогресс ремонта: $AMMO_LEFT",
		--Are concatenated to the related button prompts. Using Macros results in controller prompts at the wrong times.
		["repair_sentry_macro"] = " чтобы начать авто-починку турели",
		["pickup_sentry_macro"] = " чтобы забрать турель.\n$AMMO_LEFT патронов осталось. ", --Gets % health remaining appended to the end.
		["firemode_sentry_macro"] = " чтобы сменить режим стрельбы.\n$AMMO_LEFT патронов осталось.",
		["hud_interact_pickup_sentry_gun"] = "$AMMO_LEFT", --$AMMO_LEFT macro is a dummy macro to be replaced with desired string, since changing interaction objects is slightly cursed.
		["hud_interact_sentry_gun_switch_fire_mode"] = "$AMMO_LEFT",
		["hud_repair_sentry"] = "$AMMO_LEFT",
		["hud_action_repair_sentry"] = "Турель чинится...",
		
		-- Intimidated guards checking in in stealth
		["intimidated_guard_checkin_active"] = "Через $CHECKIN_TIME секунд уровень подозрения повысится на $SUSP_INC",
		["intimidated_guard_checkin_inactive"] = "Пока все в порядке...",
		
		["menu_button_deploy_bipod"] = "СОШКИ/АЛЬТЕРНАТИВНЫЙ ОГОНЬ",
		["hint_short_max_pagers"] = "Игнорирование пейджеров сильно увеличит полоску подозрения.",
		["hud_instruct_mask_on"] = "Нажмите $BTN_USE_ITEM чтобы надеть маску",
		["hud_instruct_mask_on_alpha"] = "Нажмите $BTN_USE_ITEM чтобы надеть маску",
		-- Ad Banner Change
		["menu_changelog"] = "Последний чейнджлог",
		["menu_discord"] = "Сервер в Discord",
		["menu_guide"] = "Гайд по моду",
		["menu_captains"] = "Информация о Капитанах",
		["menu_content_updates"] = "Гайд/Поддержка",
		["menu_content_updates_previous"] = "",

		--More fitting descriptions of difficulties--
		["menu_risk_elite"] = "ЖАЖДА СМЕРТИ. ДЛЯ ВАС ГЛАВНОЕ - ЭТО ЭФФЕКТНОСТЬ.",
		["menu_risk_sm_wish"] = "СМЕРТНЫЙ ПРИГОВОР. ПОКАЖИТЕ ИМ, ЧТО ВЫ НЕПОБЕДИМЫ.",
		
		["hud_interact_autumn_disable"] = "Отключено Капитаном Отемом!",

		["hud_assault_restored_down"] = "Штурм пережит - восстановлено 1 падение",
		["hud_assault_remaining_single"] = "1 штурм до восстановления падения",
		["hud_assault_remaining_plural"] = " штурма до восстановления падения",
		
		["test_net"] = "Fast.Net",
		["menu_test"] = "",
		["state_filter"] = "Статус",
		["menu_state_filter"] = "Фильтр по статусу",
		["menu_state_filter_help"] = "Показывает статус лобби",
		["menu_state_lobby"] = "В лобби",
		["menu_state_loading"] = "Загружается",
		["menu_state_ingame"] = "В игре",


		["menu_description"] = "План",
		-- ///Stuff ripped from the various locale files we had ///
		--And now we're doing it again--
		["menu_infamy_desc_root_new"] = "Вы новый член криминальной элиты, и первое, что вам нужно сделать - обзавестись вещами, которые подтверждают ваш статус.\n\nБОНУСЫ:\nШанс получить предмет с дурной репутацией увеличен с ##0.3%## до ##0.6%##\nПолучаемый опыт увеличен на ##5%##.",

		-- Бусты ботов
		["bm_menu_skill"] = "Бонусы для команды",

		["menu_crew_interact"] = "Ловкий",
		["menu_crew_interact_desc"] = "Игроки взаимодействуют на 15% быстрее за каждого бота в команде.",

	    ["menu_crew_inspire"] = "Вдохновление",
        ["menu_crew_inspire_desc"] = "Боты с этим перком могут использовать на вас Вдохновление.\n\nОни не могут его использовать чаще чем в 90 секунд. Перезарядка уменьшается на 15 секунд за каждого бота в команде.",

        ["menu_crew_scavenge"] = "Острый глаз",
		["menu_crew_scavenge_desc"] = "Подбор патронов для игроков увеличен на 10% за каждого бота в команде.",

        ["menu_crew_ai_ap_ammo"] = "Пробитие",
        ["menu_crew_ai_ap_ammo_desc"] = "Ваши боты теперь могут пробивать броню и так же они наносят на 25% больше урона.\n\nЭто позволяет им простреливать через броню и щитов.",

        ["menu_crew_healthy"] = "Подготовка",
        ["menu_crew_healthy_desc"] = "Максимальное здоровье игроков увеличено на 30.",

        ["menu_crew_sturdy"] = "Защитник",
        ["menu_crew_sturdy_desc"] = "Броня игроков увеличена на 10%.",

        ["menu_crew_evasive"] = "Отвлекающий маневр",
        ["menu_crew_evasive_desc"] = "Полоска Уворота игроков заполняется на 3% от их максимального Уворота.",

        ["menu_crew_motivated"] = "Тренер",
        ["menu_crew_motivated_desc"] = "Игроки получают на 15 больше выносливости.",

        ["menu_crew_regen"] = "Лекарь",
        ["menu_crew_regen_desc"] = "Игроки получают 1 здоровье каждые 4 секунды.",

        ["menu_crew_quiet"] = "Компактный",
        ["menu_crew_quiet_desc"] = "Игроки получают на 2 единицы компактности больше.",

        ["menu_crew_generous"] = "Подарочек",
        ["menu_crew_generous_desc"] = "Игроки получают дополнительное мететальное за каждые 70 убийств.",

        ["menu_crew_eager"] = "Адреналин",
        ["menu_crew_eager_desc"] = "Игроки перезаряжают оружие на 10% быстрее.",
		
		--Side Jobs
		["menu_challenge_menu_challenge_moon_6_obj"] = "Завершите контракт Скотобойня на уровне сложности OVERKILL или выше, не убивая капитана Спринга.",

		--Generic Captain Text
		["hud_assault_vip"] = "УБЕЙТЕ КАПИТАНА ЧТОБЫ ЗАКОНЧИТЬ ШТУРМ",
	
	})

	


	-- maybe need change banner descriptions
	local difficulty = Global.game_settings and Global.game_settings.difficulty or "normal"
	local difficulty_index = tweak_data:difficulty_to_index(difficulty)
	local job = Global.level_data and Global.level_data.level_id
	local captain_type = job and restoration.captain_spawns[job]
	if captain_type == restoration.captain_types.winter and job == "crojob3" or job == "crojob3_night" then
		LocalizationManager:add_localized_strings({
			["hud_assault_vip"] = "ГОСПОДА ГРАБИТЕЛИ, ВЫ ОКРУЖЕНЫ",
		})
	elseif captain_type == restoration.captain_types.winter then
		LocalizationManager:add_localized_strings({
			["hud_assault_vip"] = "УБЕЙТЕ КАПИТАНА ВИНТЕРСА ЧТОБЫ ЗАКОНЧИТЬ ШТУРМ",
		})
	elseif captain_type == restoration.captain_types.summer then
		LocalizationManager:add_localized_strings({
			["hud_assault_vip"] = "УБЕЙТЕ КАПИТАНА САММЕРСА ЧТОБЫ ЗАКОНЧИТЬ ШТУРМ",
		})
	elseif captain_type == restoration.captain_types.spring then
		LocalizationManager:add_localized_strings({
			["hud_assault_vip"] = "УБЕЙТЕ КАПИТАНА СПРИНГА ЧТОБЫ ЗАКОНЧИТЬ ШТУРМ",
		})
	elseif captain_type == restoration.captain_types.autumn then
		LocalizationManager:add_localized_strings({
			["hud_assault_vip"] = "УБЕЙТЕ КАПИТАНА ОТЕМА ЧТОБЫ ЗАКОНЧИТЬ ШТУРМ",
		})
	elseif captain_type == restoration.captain_types.hvh then
		LocalizationManager:add_localized_strings({
			["hud_assault_vip"] = "ПОБЕДИТЕ СТРАХ И ПРОСНИТЕСЬ",
		})
	end
	
local r = tweak_data.levels.ai_groups.russia --LevelsTweakData.LevelType.Russia
local difficulty = Global.game_settings and Global.game_settings.difficulty or "normal"
local difficulty_index = tweak_data:difficulty_to_index(difficulty)
local m = tweak_data.levels.ai_groups.murkywater --LevelsTweakData.LevelType.Murkywater
local z = tweak_data.levels.ai_groups.zombie --LevelsTweakData.LevelType.Zombie
local f = tweak_data.levels.ai_groups.federales
local o = tweak_data.levels.ai_groups.omnia
local ai_type = tweak_data.levels:get_ai_group_type()

if ai_type == r then
	Hooks:Add("LocalizationManagerPostInit", "SC_Localization_Ticker", function(loc)
		LocalizationManager:add_localized_strings({
			["hud_assault_assault"] = "ИДЕТ ШТУРМ НАЕМНИКОВ",
			["hud_assault_cover"] = "ОСТАВАЙТЕСЬ В УКРЫТИИ",
			["hud_assault_alpha"] = "ШTУPM HAЕMHИKOB"
		})
	end)
elseif ai_type == z then
	Hooks:Add("LocalizationManagerPostInit", "SC_Localization_Ticker", function(loc)
		LocalizationManager:add_localized_strings({
			["hud_assault_assault"] = "Итде Плоиецский Шрутм",
			["hud_assault_cover"] = "ОСТВЙТСЬ В УРКЫТИИ...МОЗГИИ",
			["hud_assault_alpha"] = "ПЛОИЕЦСКИЙ ШРУТМ"
		})
	end)
elseif ai_type == f then
	Hooks:Add("LocalizationManagerPostInit", "SC_Localization_Ticker", function(loc)
		LocalizationManager:add_localized_strings({
			["hud_assault_assault"] = "Asalto En Marcha",
			["hud_assault_cover"] = "MANTENTE A CUBIERTO",
			["hud_assault_alpha"] = "ASALTO"
		})
	end)
elseif ai_type == m then
	Hooks:Add("LocalizationManagerPostInit", "SC_Localization_Ticker", function(loc)
		LocalizationManager:add_localized_strings({
			["hud_assault_assault"] = "Идет операция Murkywater",
			["hud_assault_alpha"] = "ОПЕРАЦИЯ MURKYWATER"
		})
	end)
end

 if _G.HopLib then
	local ai_type = tweak_data.levels:get_ai_group_type()
	local murkywetew = tweak_data.levels.ai_groups.murkywater --LevelsTweakData.LevelType.Murkywater
	local lapd = tweak_data.levels.ai_groups.lapd
	local mex = tweak_data.levels.ai_groups.federales
	local akan = tweak_data.levels.ai_groups.russia
	local nypd = tweak_data.levels.ai_groups.nypd
	local fbi = tweak_data.levels.ai_groups.fbi
	local breins = tweak_data.levels.ai_groups.zombie

	Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat", function(loc)
		loc:load_localization_file(ModPath .. "lua/sc/loc/hoplibkillfeedcompat_ru.json")
	end)

	if ai_type == murkywetew then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_murkywetew", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/murkywetew_ru.json")
		end)
	elseif ai_type == lapd then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_LAPD", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/lapd_ru.json")
		end)
	elseif ai_type == mex then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_mex", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/mex_ru.json")
		end)
	elseif ai_type == akan then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_akan", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/akan_ru.json")
		end)
	elseif ai_type == nypd then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_nypd", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/nypd_ru.json")
		end)
	elseif ai_type == fbi then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_fbi", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/fbi_ru.json")
		end)
	elseif ai_type == breins then
		Hooks:Add("LocalizationManagerPostInit", "SC_HoplibKillFeedCompat_breins", function(loc)
			loc:load_localization_file(ModPath .. "lua/sc/loc/breins_ru.json")
		end)
	end
end

end)
-- Испытания
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Challenges", function(loc)
	LocalizationManager:add_localized_strings({
		["ch_deploy_ammobag_hl"] = "Last Bullet!",
		["ch_deploy_ammobag"] = "Разложить $count сумок с патронами.",
		["ch_plant_tripmine_hl"] = "Лазерное шоу",
		["ch_plant_tripmine"] = "Разложить $count мин.",
		["ch_deploy_medicbag_hl"] = "Медицинская страховка",
		["ch_deploy_medicbag"] = "Разложить $count сумок с медикаментами.",
		["ch_deploy_ecm_hl"] = "Враг системы",
		["ch_deploy_ecm"] = "Разложить $count генераторов помех.",
		["ch_deploy_fak_hl"] = "Линия жизни",
		["ch_deploy_fak"] = "Разложить $count аптечек первой помощи.",
		["ch_deploy_sentry_hl"] = "Любитель Уайт Месы",
		["ch_deploy_sentry"] = "Разложить $count турелей.",

		["ch_bridge_no_bleedouts_hl"] = "Зеленый Мост: непробиваемый",
		["ch_bridge_no_bleedouts"] = "Завершите контракт \"Зеленый мост\" на уровне сложности \"Сложно\", \"Очень Сложно\" или \"OVERKILL\", ни разу не упав",
		["ch_duck_hunting_hl"] = "Мост слишком далеко!",
		["ch_duck_hunting"] = "Завершите контракт \"Зеленый мост\" на уровне сложности \"Сложно\", \"Очень Сложно\" или \"OVERKILL\". Для выполнения необходимо играть контракт с самого начала",


		["ch_watchdogs_d1_heavy_wpn1_hl"] = "ТОЛСТАЯ БРОНЯ, БОЛЬШИЕ ПУШКИ",
		["ch_watchdogs_d1_heavy_wpn1"] = "Пройти первый день ограбления 'Сторожевые псы', используя только УКТЖ, миниганы, ракетометы или снайперскую винтовку Thanatos, на уровни сложности OVERKILL или выше. Для выполнения этого испытания, ограбление нужно играть с самого начала.",

		-- Новые испытания
		["ch_melee_test"] = "Босс качалки",
		["ch_melee_test_desc"] = "Убейте капитана Отема кулаками",
		["ch_pro_job_test"] = "Даже армия не остановит нас",
		["ch_pro_job_test_desc"] = "Завершите контракт \"Поджигатель\" с модификатором Pro Job на уровне сложности \"Хаос\" и выше            ",
		["ch_summers_test"] = "Да не горит у меня!!!",
		["ch_summers_test_desc"] = "Убейте капитана Саммерса огнеметом Mk.1",
		["ch_winters_test"] = "Торжество несправедливости",
		["ch_winters_test_desc"] = "Убейте капитана Винтерса ножом-бабочкой или выкидным ножом, пока он держит щит",
		["ch_spring_test"] = "У меня волына больше",
		["ch_spring_test_desc"] = "Убейте капитана Спринга миниганом Вулкан или микроганом XL 5.56",

		["ch_pdth_style_fwb"] = "Старая школа: Первый Всемирный Банк",
		["ch_pdth_style_fwb_desc"] = "Завершите контракт \"Первый Всемирный Банк\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_heat"] = "Старая школа: Схватка на улице",
		["ch_pdth_style_heat_desc"] = "Завершите контракт \"Схватка на улице\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_panic"] = "Старая школа: Комната паники",
		["ch_pdth_style_panic_desc"] = "Завершите контракт \"Комната паники\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_bridge"] = "Старая школа: Зеленый мост",
		["ch_pdth_style_bridge_desc"] = "Завершите контракт \"Зеленый мост\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_diamond"] = "Старая школа: Кража бриллиантов",
		["ch_pdth_style_diamond_desc"] = "Завершите контракт \"Кража бриллиантов\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_slaughterhouse"] = "Старая школа: Скотобойня",
		["ch_pdth_style_slaughterhouse_desc"] = "Завершите контракт \"Скотобойня\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_counterfeit"] = "Старая школа: Подделка",
		["ch_pdth_style_counterfeit_desc"] = "Завершите контракт \"Подделка\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_undercover"] = "Старая школа: Под прикрытием",
		["ch_pdth_style_undercover_desc"] = "Завершите контракт \"Под прикрытием\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",
		["ch_pdth_style_nomercy"] = "Старая школа: Нет милосердию",
		["ch_pdth_style_nomercy_desc"] = "Завершите контракт \"Нет милосердию\" на уровне сложности OVERKILL или выше, надев костюм-двойку или ЛББ, не потратив ни одного очка навыков в деревья навыков, используя набор перков Прирожденный или Перерожденный, приклад и оружия из PD:TH",

	})
end)

-- Стринги для ограблений
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Heists", function(loc)
	LocalizationManager:add_localized_strings({
		
		["heist_junker_name"] = "Наркопритон",
		["heist_junker_brief"] = "Это работа на Влада. После неудачной сделки его люди и товар оказались в тяжелом положении - федералы уже близко. Мы подготовили транспорт, чтобы доставить вас к месту сделки, где вы будете обеспечивать прикрытие. Мы пришлем вертолет и эвакуируем оттуда вас вместе с товаром.\n\nРабота не очень долгая, но не стоит недооценивать полицию. Экипируйтесь для боя.",
		["heist_junk_name"] = "Сторожи",
		["heist_junk_brief"] = "Стройплощадка уже близко. Копы еще не прибыли, но будут на месте очень скоро. Ребята Влада обеспечат вам прикрытие, но скорее всего не смогут держаться долго.\n\nГоворят, на месте есть мет-лаборатория, поэтому можете попробовать сварить себе премию, если сможете одновременно уследить за товаром Влада.",
		["junk_01"] = "ЗАЩИЩАТЬ ДЕНЬГИ И НАРКОТИКИ",
		["junk_01_desc"] = "Держите копов подальше от товара! И кокаин, и деньги должны быть в безопасности.",
		["junk_02"] = "ПОСТАВИТЬ КАНИСТРЫ И ВЫСТРЕЛИТЬ В КАЖДУЮ ИЗ НИХ",
		["junk_02_desc"] = "Зажгите костер, который оповестит пилота о вашей позиции.",
		["junk_03"] = "ЗАЩИЩАТЬ ДЕНЬГИ И НАРКОТИКИ",
		["junk_03_desc"] = "Не позволяйте копам уносить товар Влада! Если вы потеряете слишком много мешков, дело будет провалено!",
		["junk_04"] = "ЗАБРАТЬ ТОВАР ВЛАДА",
		["junk_04_desc"] = "Забрать кокаин Влада. Его собственные люди проследят, чтобы деньги были в безопасности.",
		["junk_05"] = "ДОСТУПНА ЭВАКУАЦИЯ",
		["junk_05_desc"] = "Эвакуируйтесь, как только будете довольны наградой.",

		["heist_int_dock_name"] = "Мокрое дело",
		["heist_int_dock_brief"] = "Этот склад принадлежит Murkywater Logistics, по крайней мере, на данный момент. Они использовали его для хранения добычи, но недавно мы заметили,  что туда было доставлено несколько серверов с засекреченной информацией. По нашим данным, там содержатся материалы о союзе между ними и OMNIA.\n\nТихо или громко, ваша единственная задача - захватить сервера и завладеть информацией. Ожидайте сопротивления, вне зависимости от метода.",
		["heist_wetwork_name"] = "Мокрое дело",
		["heist_wetwork_brief"] = "Этот склад принадлежит Murkywater Logistics, по крайней мере, на данный момент. Они использовали его для хранения добычи, но недавно мы заметили,  что туда было доставлено несколько серверов с засекреченной информацией. По нашим данным, там содержатся материалы о союзе между ними и OMNIA.\n\nТихо или громко, ваша единственная задача - захватить сервера и завладеть информацией. Ожидайте сопротивления, вне зависимости от метода.",
		["obj1_enterwarehouse"] = "ПРОНИКНУТЬ НА СКЛАД",
		["obj1_enterwarehouse_desc"] = "Проникните на склад.",
		["obj2_findsecuritydoor"] = "НАЙТИ СЕРВЕРНУЮ",
		["obj2_findsecuritydoor_desc"] = "Найдите серверную комнату. Она должна быть где-то на складе, вероятнее всего за закрытой дверью.",
		["obj3_getsecuritydooropen"] = "ОТКРЫТЬ ДВЕРЬ",
		["obj3_getsecuritydooropen_desc"] = "Найти способ открыть дверь.",
		["obj4_openseconddoor"] = "ВСКРЫТЬ СЕРВЕРНУЮ КОМНАТУ",
		["obj4_openseconddoor_desc"] = "Проникнуть в серверную комнату. Ключ-карта или дрель помогут в этом.",
		["obj5_hack"] = "ВЗЛОМАТЬ НОУТБУК",
		["obj5_hack_desc"] = "Взломать ноутбук, используя софт, предоставленный Джекелом.",
		["obj5b_explode"] = "ОБЕЗВРЕДИТЬ C4!",
		["obj5b_explode_desc"] = "Здесь C4! Обезвредьте его или убегайте!",
		["obj6_wait"] = "ОТПРАВИТЬ ДАННЫЕ",
		["obj6_wait_desc"] = "Взлом завершен. Отправьте данные Джекелу.",
		["obj7_escapeorloot"] = "ДОСТУПНА ЭВАКУАЦИЯ",
		["obj7_escapeorloot_desc"] = "Эвакуируйтесь, как только будете довольны наградой.",

		["heist_int_dock_burn_name"] = "Выгорание",
		["heist_int_dock_burn_brief"] = "Нет времени продумывать план, они собираются перевозить мастер-серверы.\nВодитель подвезет грузовик с вооруженными клоунами прямо к воротам.",
		["heist_wetwork_burn_name"] = "Выгорание",
		["heist_wetwork_burn_brief"] = "Итак, мы почти у места. Вы уже были здесь, но в этот раз мы вторгаемся с шумом.\nВозможно, тут еще осталась добыча, но это не главное.\n\nИщите все, что поможет вам узнать, что внутри закрытых контейнеров. Камеры, вещи вокруг контейнеров, надписи на досках и тому подобное.",
		["wwburn_01"] = "ПОДГОТОВИТЬСЯ",
		["wwburn_01_desc"] = "Мы у главных ворот, наемники будут повсюду, поэтому готовьтесь к перестрелке.",
		["wwburn_02"] = "НАЙТИ СЕРВЕРЫ",
		["wwburn_02_desc"] = "Найдите три контейнера, в которых содержатся мастер-серверы.",
		["wwburn_03"] = "СЖЕЧЬ РЕЗЕРВНЫЕ КОПИИ",
		["wwburn_03_desc"] = "Сожгите резервные копии мастер-серверов, они будут в тех же контейнерах.",
		["wwburn_04"] = "ДОСТУПНА ЭВАКУАЦИЯ",
		["wwburn_04_desc"] = "Покиньте локацию, или найдите дополнительную добычу.",
	
	
	
	["restoration_level_data_unknown"] = "НЕИЗВЕСТНОЕ ВРЕМЯ, НЕИЗВЕСТНОЕ МЕСТО",
		["restoration_level_data_welcome_to_the_jungle_1"] = "18:24, база байкерской банды 'Overkill'",
		["restoration_level_data_welcome_to_the_jungle_1_night"] = "01:32, база байкерской банды 'Overkill'",
		["restoration_level_data_welcome_to_the_jungle_2"] = "18:00, Вилла Вивальди",
		["restoration_level_data_framing_frame_1"] = "23:30, Капитолийская картинная галерея",
		["restoration_level_data_framing_frame_2"] = "00:30, Заброшенный вокзал",
		["restoration_level_data_framing_frame_3"] = "02:20, Пентхаус 'Хайрайз'",
		["restoration_level_data_election_day_1"] = "12:37, Пирс 39",
		["restoration_level_data_election_day_2"] = "08:10, Склад",
		["restoration_level_data_election_day_3"] = "Hi! If you see this string during gameplay, report it to Restoration! Thank you!",
		["restoration_level_data_election_day_3_skip1"] = "16:25, Банк 'Капитолийский'",
		["restoration_level_data_election_day_3_skip2"] = "15:25, Банк 'Капитолийский'",
		["restoration_level_data_watchdogs_1"] = "16:10, Грузовик с мясом",
		["restoration_level_data_watchdogs_1_res"] = "21:10, Грузовик с мясом",
		["restoration_level_data_watchdogs_2"] = "00:25, Порт 'Альмендия'",
		["restoration_level_data_watchdogs_2_res"] = "00:25, Порт 'Альмендия'",
		["restoration_level_data_watchdogs_1_night"] = "1:10, Грузовик с мясом",
		["restoration_level_data_watchdogs_2_day"] = "18:05, Порт 'Альмендия'",
		["restoration_level_data_watchdogs_3_res"] = "00:20 Мост 'Вашингтон Джастайс'",
		["restoration_level_data_alex_1"] = "03:30, Тихий холм",
		["restoration_level_data_alex_2"] = "05:55, Наркопритон",
		["restoration_level_data_alex_3"] = "07:20, Мост 'Вашингтон Джастайс'",
		["restoration_level_data_alex_1_res"] = "03:30, Тихий холм",
		["restoration_level_data_alex_2_res"] = "05:55, Наркопритон",
		["restoration_level_data_alex_3_res"] = "07:20, Мост 'Вашингтон Джастайс'",
		["restoration_level_data_firestarter_1"] = "09:25, Частный аэропорт",
		["restoration_level_data_firestarter_1_res"] = "09:25, Частный аэропорт",
		["restoration_level_data_firestarter_2"] = "22:05, Офис ФБР",
		["restoration_level_data_firestarter_2_res"] = "22:05, Офис ФБР",
		["restoration_level_data_firestarter_3"] = "12:15, банк 'Харвест & Трасти'",
		["restoration_level_data_firestarter_3_res"] = "12:15, банк 'Харвест & Трасти'",
		["restoration_level_data_ukrainian_job"] = "14:50, 'Прекрасные штучки'",
		["restoration_level_data_ukrainian_job_res"] = "14:50, 'Прекрасные штучки'",
		["restoration_level_data_jewelry_store"] = "14:50, 'Прекрасные штучки'",
		["restoration_level_data_four_stores"] = "13:20, Магазины",
		["restoration_level_data_mallcrasher"] = "12:50, ТЦ 'Щит'",
		["restoration_level_data_nightclub"] = "20:00, Ночной клуб 'Со вкусом'",
		["restoration_level_data_branchbank"] = "12:15, банк 'Харвест & Трасти'",
		["restoration_level_data_escape_cafe"] = "Скрывайтесь!",
		["restoration_level_data_escape_park"] = "Скрывайтесь!",
		["restoration_level_data_escape_cafe_day"] = "Скрывайтесь!",
		["restoration_level_data_escape_park_day"] = "Скрывайтесь!",
		["restoration_level_data_escape_street"] = "Скрывайтесь!",
		["restoration_level_data_escape_overpass"] = "Скрывайтесь!",
		["restoration_level_data_escape_garage"] = "Скрывайтесь!",
		["restoration_level_data_escape_overpass_night"] = "Скрывайтесь!",
		["restoration_level_data_safehouse"] = "12:00, Убежище",
		["restoration_level_data_arm_fac"] = "9:30, Гавань",
		["restoration_level_data_arm_par"] = "14:25, Центр города",
		["restoration_level_data_arm_hcm"] = "14:15, Центр города",
		["restoration_level_data_arm_cro"] = "12:55, Пересечение ул. МакКарти и ул. Джеймс",
		["restoration_level_data_arm_und"] = "20:15, Проезд",
		["restoration_level_data_arm_for"] = "12:25, Поезд 'Армадилло'",
		["restoration_level_data_family"] = "11:25 AM, Джойелли ди Фамилья",
		["restoration_level_data_family_res"] = "11:25 AM, Джойелли ди Фамилья",
		["restoration_level_data_big"] = "14:15, Банк 'Беневолент'",
		["restoration_level_data_big_res"] = "14:15, Банк 'Беневолент'",
		["restoration_level_data_roberts"] = "08:47, Банк 'Робертс'",
		["restoration_level_data_roberts_v2"] = "08:47, Банк 'Робертс'",
		["restoration_level_data_mia_1"] = "21:30, Мотель Комиссара",
		["restoration_level_data_mia_2"] = "11:45, Апартаменты Комиссара",
		["restoration_level_data_mia2_new"] = "11:45, Апартаменты Комиссара",
		["restoration_level_data_kosugi"] = "04:00, Склад 'Терминал'",
		["restoration_level_data_gallery"] = "23:45, Капитолийская картинная галерея",
		["restoration_level_data_hox_1"] = "10:30, Подземный переход здания суда",
		["restoration_level_data_hox_2"] = "16:10, Здание им. Джона Эдгарда Гувера",
		["restoration_level_data_pines"] = "17:52, В глубине леса",
		["restoration_level_data_mus"] = "20:15, Музей старинного искусства им. МакКендрика",
		["restoration_level_data_crojob2"] = "18:10, Вашингтонский порт",
		["restoration_level_data_crojob3"] = "15:35, Окраина леса",
		["restoration_level_data_crojob3_night"] = "20:35, Окраина леса",
		["restoration_level_data_cage"] = "19:55, 'Тойер Автос'",
		["restoration_level_data_hox_3"] = "23:55, Убежище ФБР",
		["restoration_level_data_rat"] = "19:55, Тихий холм",
		["restoration_level_data_shoutout_raid"] = "09:00, Склад 'Терминал'",
		["restoration_level_data_arena"] = "21:00, GENSEC-Арена",
		["restoration_level_data_kenaz"] = "20:00, Лас-Вегас-Стрип-Казино 'Голден Грiн'",
		["restoration_level_data_jolly"] = "16:00, Лос-Анджелес - Зона катастрофы",
		["restoration_level_data_red2"] = "14:15, ЦЕНТР ГОРОДА - ПЕРВЫЙ ВСЕМИРНЫЙ БАНК",
		["restoration_level_data_dinner"] = "08:01, Район скотобойни - в засаде!",
		["restoration_level_data_nail"] = "00:00, Тихий холм",
		["restoration_level_data_haunted"] = "??:??, 'Убежище'",
		["restoration_level_data_pbr"] = "04:40, Невада - Исследовательский центр 'Блекридж'",
		["restoration_level_data_pbr2"] = "ВРЕМЯ НЕИЗВЕСТНО, Z-170 'ЗЕВС' - Грузовой самолет Murkywater",
		["restoration_level_data_cane"] = "15:15, Мастерская Санты",
		["restoration_level_data_peta"] = "12:00, Район в центре города",
		["restoration_level_data_peta2"] = "17:43, Разрушенный амбар",
		["restoration_level_data_man"] = "18:00, Заброшенное здание",
		["restoration_level_data_pal"] = "12:00, Пригород - Ремонт сантехники 'Bodhi'",
		["restoration_level_data_short1_stage1"] = "ВРЕМЯ НЕИЗВЕСТНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_short1_stage2"] = "ВРЕМЯ НЕИЗВЕСТНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_short2_stage1"] = "ВРЕМЯ НЕИЗВЕСТНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_short2_stage2"] = "ВРЕМЯ НЕИЗВЕСТНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_short2_stage2b"] = "ВРЕМЯ НЕИЗВЕСТНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_dark"] = "02:21, Скрытый вокзал",
		["restoration_level_data_mad"] = "ВРЕМЯ НЕИЗВЕСТНО, Где-то в России...",
		["restoration_level_data_born"] = "10:15, Байкерский клуб OVERKILL",
		["restoration_level_data_chew"] = "17:25, за Вашингтоном - Идущий поезд!",
		["restoration_level_data_flat"] = "16:02, Неблагополучный район - Притон Чавеза",
		["restoration_level_data_chill"] = "13:00, Убежище",
		["restoration_level_data_chill_combat"] = "13:00, Убежище - рейд полиции!",
		["restoration_level_data_help"] = "DON'T TOUCH THAT DIAL, WE'RE JUST GETTING STARTED",
		["restoration_level_data_friend"] = "16:30, Майами - Особняк Эль Фурейдис",
		["restoration_level_data_fish"] = "19:30, Около Нью-Йорка - Яхта 'Лета'",
		["restoration_level_data_spa"] = "19:00, Ньй-Йорк - Засада!",
		["restoration_level_data_moon"] = "23:00, Торговый центр 'Murica'",
		["restoration_level_data_run"] = "11:00, Жилой квартал - Подстава!",
		["restoration_level_data_glace"] = "22:45, Мост Грин - южная сторона",
		["restoration_level_data_dah"] = "01:30, 22 этаж - Небоскреб Гарнет Груп",
		["restoration_level_data_hvh"] = "ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК. ТИК-ТАК.",
		["restoration_level_data_wwh"] = "ВРЕМЯ НЕИЗВЕСТНО, Где-то на Аляске...",
		["restoration_level_data_rvd1"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_rvd2"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_brb"] = "18:53, Нью-Йорк, Бруклин - Банк 'Харвест & Трасти'",
		["restoration_level_data_des"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Невада - Скала Генри",
		["restoration_level_data_sah"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Массачусетс - Особняк Шэклторн",
		["restoration_level_data_tag"] = "00:43, Здание им. Джона Эдгарда Гувера",
		["restoration_level_data_bph"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Тюрьма 'Форт Клэтсоп'",
		["restoration_level_data_nmh"] = "20:24, Госпиталь 'Милосердие' - Изоляционная палата",
		["restoration_level_data_nmh_res"] = "20:24, Госпиталь 'Милосердие' - Изоляционная палата",
		["restoration_level_data_vit"] = "13:07, Вашингтон - Белый дом",
		["restoration_level_data_mex"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, США - Южная граница",
		["restoration_level_data_mex_cooking"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Мексика - база Койопов",
		["restoration_level_data_bex"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Мексика - Банк Сан Мартин",
		["restoration_level_data_pex"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Мексика - Полицейский участок",
		["restoration_level_data_fex"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Мексика - Особняк Булука",
		["restoration_level_data_chas"] = "20:30, Сан Франциско - Чайнатаун",
		["restoration_level_data_sand"] = "22:30, Сан Франциско - Порт",
		["restoration_level_data_chca"] = "21:24, Залив Сан Франциско - Лайнер Black Cat",
		["restoration_level_data_pent"] = "23:30, Сан Франциско - Пентхаус Юфу Венга",
		["restoration_level_data_ranc"] = "18:24, Техас - Ранчо Мидленд",
		["restoration_level_data_trai"] = "19:40, Форт-Уэрт - Дэлтон Ярд",
		["restoration_level_data_corp"] = "20:35, Даллас - Исследовательский центр корпорации SERA",
		["restoration_level_data_deep"] = "21:00, Мексиканский залив - Нефтяная вышка корпорации SERA",
		["restoration_level_data_wetwork"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_junk"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, ЛОКАЦИЯ ЗАСЕКРЕЧЕНА",
		["restoration_level_data_holly"] = "17:00, Los Angeles - Lukas' Mansion",
		["restoration_level_data_lvl_friday"] = "17:00, Торговый центр 'Щит'",
		["restoration_level_data_skm_nightmare_lvl"] = "Прачечная? Хочешь отмыть грехи?",
		["restoration_level_data_bluewave"] = "ВРЕМЯ ЗАСЕКРЕЧЕНО, Склад Aurelian",
		["restoration_level_data_secret_stash"] = "18:00, Заброшенное здание",
		["restoration_level_data_bridge"] = "22:45, Мост Грин - южная сторона",
		["restoration_level_data_four_stores_remixed"] = "13:20, Магазины",


         --кастомные хайсты
		["restoration_level_data_flatline_lvl"] = "22:26, Больница им. Н.И. Пирогова", --Flatline
		["restoration_level_data_ahopl"] = "21:06, Yuri's Private Club", --A House of Pleasure
		["restoration_level_data_atocl"] = "1:03, Penthouse Party", --A Touch of Class
		["restoration_level_data_rusdl"] = "10:23 , Garnet Group Jewelery Store", --Cold Stones
		["restoration_level_data_crimepunishlvl"] = "13:19, Correctional Facility Somewhere in Russia", --Crime and Punishment
		["restoration_level_data_deadcargol"] = "20:36, Sewers Under The Depot", --Deadly Cargo
		["restoration_level_data_hunter_party"] = "15:56, Nikolai's Penthouse", --Hunter and Hunted d1
		["restoration_level_data_hunter_departure"] = "22:13, Aleksandr's Private Airport", --Hunger and Hunted d2
		["restoration_level_data_hunter_fall"] = "1:36, Somewhere Over International Waters", --Hunter and Hunted d3
		["restoration_level_data_ruswl"] = "11:50, Somewhere in Russia", --Scorched Earth

		["heist_greattrain_name"] = "Time Window",
		["heist_easystore_name"] = "Twenty-Four Seven",
		["heist_sin_villa_name"] = "SCORE: Villa Vivaldi",
		["heist_dragon_name"] = "Stonefist",
		["heist_jkl_base_name"] = "Jackal's Safehouse",
		["heist_junger_name"] = "Distorted Angels",
		["heist_deep_name"] = "Deep Six",
		["heist_blood_name"] = "Body/Prison",
		["heist_crystal_name"] = "Slaves of Fear",
		["heist_gold_name"] = "Remains of Nothing",
		["heist_titanium_name"] = "Turf War",
		["heist_airport_name"] = "Dead Reckoning",
		["heist_platinum_name"] = "Surface Tension",
		["heist_cursed_name"] = "Green Harvest",
		["heist_holly_name"] = "Blockbuster Night",
	
	--Holdout Heists--
		["heist_skm_mallcrasher"] = "Торговый центр 'Щит'",
		["heist_skm_mallcrasher_h1"] = "Торговый центр 'Щит'",
		["heist_skm_arena"] = "Стадион 'Монарх'",
		["heist_skm_arena_h1"] = "Стадион 'Монарх'",
		["heist_skm_big2"] = "Банк 'Беневолент'",
		["heist_skm_big2_h1"] = "Банк 'Беневолент'",
		["heist_skm_watchdogs_stage2"] = "Склад 'Альмендия'",
		["heist_skm_watchdogs_stage2_h1"] = "Склад 'Альмендия'",
		["heist_skm_mus"] = "Музей 'Андерсониан'",
		["heist_skm_mus_h1"] = "Музей 'Андерсониан'",
		["heist_skm_run"] = "Жилой район - здание 'Инквелл'",
		["heist_skm_run_h1"] = "Жилой район - здание 'Инквелл'",
		["heist_skmc_fish_name"] = "Яхта 'Лета'",
		["heist_skmc_ovengrill_name"] = "Магазин Ovengrill",
		["heist_skmc_mad_name"] = "Лаборатория DRAK",
		["heist_skm_friend_name"] = "Особняк Эль-Фурейдис",
		["heist_skm_nightmare_name"] = "Старое убежище",
		["heist_skm_nightmare_lvl_name"] = "Убежище?",

		--Heist Breifings--
		["heist_pines_briefing"] = "Место нахождения в такой дальней глуши, что вам надо поторопиться и бежать сломя голову. Найдите пилота. Он должен быть рядом с местом крушения. Мы отправим вертолет, чтобы эвакуировать его. Пилот должен быть в полной безопасности до тех пор, пока не отправится к нам. И еще кое-что: Влад говорит, что в самолете был неплохой товар. Прочешите лес и утащите столько кокаина, сколько сможете. На Рождество деньги лишними не будут.\n\nСООБЩЕНИЕ ОТ ДЖЕКЕЛА:\nШум от падения самолета привлек внимание находившихся неподалеку наемников организации REAPER. Сражаться будете не с полицией.",

		----достижения из сторонних модов----

		--Scarface Mansion--
		["skm_friend_name"] = "Столкновение: Особняк Эль-Фурейдис",
		["friend_3"] = "Вор в окопе",
		["friend_3_desc"] = "Начиная с первой волны, продержитесь три волны в Особняке Эль-Фурейдис.",
		["friend_3_obj"] = "Начиная с первой волны, продержитесь три волны в Особняке Эль-Фурейдис.",
		["friend_5"] = "Заложник у твоих ног",
		["friend_5_desc"] = "Начиная с первой волны, продержитесь пять волн в Особняке Эль-Фурейдис.",
		["friend_5_obj"] = "Начиная с первой волны, продержитесь пять волн в Особняке Эль-Фурейдис.",
		["friend_7"] = "Оборона Монтана",
		["friend_7_desc"] = "Начиная с первой волны, продержитесь семь волн в Особняке Эль-Фурейдис.",
		["friend_7_obj"] = "Начиная с первой волны, продержитесь семь волн в Особняке Эль-Фурейдис.",
		["friend_9"] = "Столкновение со шрамом",
		["friend_9_desc"] = "Начиная с первой волны, продержитесь девять волн в Особняке Эль-Фурейдис.",
		["friend_9_obj"] = "Начиная с первой волны, продержитесь девять волн в Особняке Эль-Фурейдис.",

		--Safehouse Nightmare--
		["skm_nightmare_name"] = "Столкновение: Старое убежище",
		["nightmare_3"] = "Неужели снова настало это самое время?", --translation note: quote from HL2 ending gman speech
		["nightmare_3_desc"] = "Начиная с первой волны, продержитесь три волны в Старом Убежище.",
		["nightmare_3_obj"] = "Начиная с первой волны, продержитесь три волны в Старом Убежище.",
		["nightmare_5"] = "Главное, что бы не произошло ничего неординарного", --translation note: quote from TF2 spy (Helltower event)
		["nightmare_5_desc"] = "Начиная с первой волны, продержитесь пять волн в Старом Убежище.",
		["nightmare_5_obj"] = "Начиная с первой волны, продержитесь пять волн в Старом Убежище.",
		["nightmare_7"] = "Ночь темна, но всегда настает утро", --translation note: quote from Lulu (Final Fantasy X)
		["nightmare_7_desc"] = "Начиная с первой волны, продержитесь семь волн в Старом Убежище.",
		["nightmare_7_obj"] = "Начиная с первой волны, продержитесь семь волн в Старом Убежище.",
		["nightmare_9"] = "Так проснитесь же, Мистер Стил", --translation note: quote from HL2 intro gman speech + Dallas' alias
		["nightmare_9_desc"] = "Начиная с первой волны, продержитесь девять волн в Старом Убежище.",
		["nightmare_9_obj"] = "Начиная с первой волны, продержитесь девять волн в Старом Убежище.",
	
	--Ranted NMH
        ["heist_no_mercy_ranted_name"] = "Нет милосердию",
		["heist_no_mercy_ranted_brief"] = "Мы отправляется в госпиталь 'Милосердие' за кровью. У местного пациента обнаружили какой-то редкий вирус, образец которого нам нужно заполучить. Пусть вас ничего не останавливает, ибо платят очень хорошо. Конец света не наступит, если мы прольем немного крови за большие деньги, не так ли?",

		["heist_nmh_res_name"] = "Госпиталь 'Милосердие'",
		["heist_nmh_res_brief"] = "Нашему клиенту нужен образец крови пациента, находящегося в отделе интенсивной терапии в госпитале 'Милосердие'. Вам нужно будет войти туда, вырубить камеры, проконтролировать толпу и дать мне доступ в базу данных, чтобы я смог найти цель. Учитывая слабую охрану там, это должна быть чистая и красивая работа. Я заберу вас с крыши, когда вы закончите. Работа немного мутная, заказана через третьих лиц, у которых есть знакомые в военной сфере, но это стоит того. За работу мы получим кое-что, что нам пригодится в будущем, и довольно неплохие деньги.",

		["heist_nmh_new"] = "Возьмите и протестируйте кровь у пациента",
		["heist_nmh_new_desc"] = "Вам нужно найти центрифугу и проверить образцы крови.",

		["heist_nmh_new2"] = "Вызовите лифт",
		["heist_nmh_new2_desc"] = "Нажмите кнопку и ожидайте лифт",

		["heist_nmh_new3"] = "Вызовите лифт",
		["heist_nmh_new3_desc"] = "Нажмите кнопку и ожидайте лифт",

		--GO Bank remastered
		["menu_nh_mod_gobank_v2"] = "Банк GO - Ремастер",

		["heist_gobank_v2_name"] = "Банк GO - Ремастер",
		["heist_gobank_v2_brief"] = "Классическое ограбление банка. Взломайте хранилище, опустошите клиентские ячейки и вынесите ценности. Бэйн говорит, что у этих банков самый низкий рейтинг ограблений в стране. Пора изменить это.\n\n» Найдите ключ-карты. Для хранилища нужно две\n» Если не получится - используйте термобур\n» Взломайте клиентские ячейки\n» Соберите небесный крюк\n» Вытащите деньги",

		["heist_roberts_v2_name"] = "Банк Робертс",
		["heist_roberts_v2_brief"] = "У нас есть наводка на банк. Не самый большой, но есть информация, что в его хранилище временно хранится очень много наличных. Иностранная валюта для обмена.\n\nВ любом случае, вы знаете, как действовать: как вам захочется. Тихо прокрадитесь в банк или устройте пекло и погром. В любом случае, я знаю, как вытащить оттуда деньги. Вы узнаете, о чем я, когда увидите. Я думаю, вам это понравится.",

		["csgo_plane_timer_text"] = "Ожидайте самолет &&TIMER",
		["csgo_plane_timer_desc"] = "Ожидайте самолет &&TIMER",

		["hud_equipment_pickup_spraycan"] = "Нажмите $BTN_INTERACT чтобы подобрать краску",
		["hud_action_spraypaint"] = "Нажмите $BTN_INTERACT чтобы рисовать",
		["hud_action_spraypaint_none"] = "Необходима краска",
		["spraycan_obtained"] = "Краска получена",
		["hud_equipment_obtained_spraycan"] = "Краска получена",

		["trophy_csgo01"] = "Ящик с граффити",
		["trophy_csgo01_desc"] = "И за него даже не пришлось платить!",
		["trophy_csgo01_objective"] = "На ограблении Банк GO - Ремастер, найдите краску и нарисуйте граффити в хранилище.",

		["END"] = "КОНЕЦ",

		--Whurr Heat Street Edit
		["heist_heat_street_new_name"] = "Схватка на улице (классика)",
		["heist_heat_street_new_brief"] = "Говорят, что ничего не бывает наверняка, но эта работа выглядит как нельзя проще: зайти, взять кейс, уйти. Ваш доверенный водитель Мэтт будет ждать вас в ближайшей аллее, и, если вы доберетесь до фургона, все пройдет как по маслу.",
		["heist_street_new_name"] = "Схватка на улице (классика)",
		["heist_street_new_brief"] = "Говорят, что ничего не бывает наверняка, но эта работа выглядит как нельзя проще: зайти, взять кейс, уйти. Ваш доверенный водитель Мэтт будет ждать вас в ближайшей аллее, и, если вы доберетесь до фургона, все пройдет как по маслу.",

		--Heat Street, Holdout edition
		["heist_skm_heat_street_name"] = "Жилой район - здание 'Инквелл'",
		["heist_skm_heat_street_brief"] = "Недавно копы допросили заключенного, который утверждает, что видел лицо Бейна и может его опознать. Разумеется, это неправда - но об этом не догадываются ни копы, ни наши враги, поэтому мы воспользуемся ситуацией, чтобы срубить немного денег. Перехватите заключенного, когда его будут перевозить около старой фабрики, где еще разбился тот идиот Мэтт, когда пытался убежать тот нас.",
		["heist_skm_street_name"] = "Столкновение: Жилой район - здание 'Инквелл'",
		["heist_skm_street_brief"] = "Недавно копы допросили заключенного, который утверждает, что видел лицо Бейна и может его опознать. Разумеется, это неправда - но об этом не догадываются ни копы, ни наши враги, поэтому мы воспользуемся ситуацией, чтобы срубить немного денег. Перехватите заключенного, когда его будут перевозить около старой фабрики, где еще разбился тот идиот Мэтт, когда пытался убежать тот нас.",

		--Xmas Hoxout and Breaking Feds
		["heist_xmn_hox"] = "Рождественское спасение Хокстона",
		["heist_xmn_hox1"] = "Рождественский побег",
		["heist_xmn_hox_1_brief"] = "Дантист организовал новое судебное разбирательство для Хокстона. Нет, не для тебя, Хокс. Я имел в виду... Для старого. Ладно, с кличками потом разберемся. Суд пройдет быстро. С его статьей он все равно не выйдет из тюрьмы. Мы должны перехватить Хокса, пока его ведут с заседания. Спасем Хокстона и покажем огромный средний палец судебной системе. Действуйте громко: взорвите стену в здании суда, хватайте Хокса и сваливайте.$NL;$NL;Улицы вокруг здания суда перекрыты. Они ожидают подвоха, так что готовьте пушки покрупнее и боеприпасов побольше.",
		["heist_xmn_hox2"] = "Рождественские поиски",
		["heist_xmn_hox_2_brief"] = "Парни, спасибо за то, что вытащили меня. Только я уверен в том, что меня подставили. Я не должен был попасть в тюрьму. У федералов было на меня гораздо больше, чем эти сволочи смогли бы раскопать. Кто-то решил меня сдать. Я узнаю, кто это сделал.$NL;$NL;Это будет нелегко, так что мы не будем ходить вокруг да около, ладно? Никаких сделок или связей с контактами. Мы отправимся сразу к месту, где все началось. В здание имени Эдгара Гувера, самый главный улей FBI. Мы выясним, кто попытался меня поиметь.",
		["heist_xmn_hox_brief"] = "Дантист сфальсифицировал новое судебное разбирательство для Хокстона. Мы должны перехватить его сразу после слушания. Действовать будете настолько громко, насколько это возможно: взрываете стену, хватаете Хокстона и сбегаете к чертям.$NL;$NL;» Освободите Хокстона$NL;» Проведите его до бронированного грузовика$NL;» Сопровождайте грузовик$NL;» Скройтесь с места преступления вместе с Хокстоном.",

		["heist_xmn_tag_name"] = "Проникновение на Рождество",

		--Rats Zipline
		["menu_alex_1_zipline_desc"] = "Лебедка для быстрого переноса сумок",

		--The Bomb: Forest Breifing
		["heist_crojob3_briefing"] = "Этим утром, взрывчатку погрузили на поезд, который двигается в Норфолк. Возможно, их собираются продать или списать - это неважно, ведь она туда не доедет. Поезд остановить нелегко, так что мы прибегнем к методам Дикого запада. Взорвете опоры моста - и поезд рухнет. План громкий и грязный, зато эффективный. Вагоны будут разбросаны повсюду. В одном из них наша взрывчатка - обыщите все вагоны, пока не найдете ее.\n\nЗАПИСКА ОТ ДЖЕКЕЛА:\nЯ получил информацию, что туда движутся наемники АКАНа - похоже, он захотел бомбу себе.",

		--Watchdogs Holdout
		["heist_skm_watchdogs_stage2_briefing"] = "Миа Калиенте — хорошая добыча, друзья. В течение многих лет она была мозгом операций Murkywater в Вашингтоне. Не так давно Murkywater заняли портовый склад, который они используют как дополнительную точку распределения. Наша цель находится там, проверяет какую-то добычу, недавно награбленную из-за границы. Мы проникнем туда и возьмем девку в заложники. Мурки не могут позволить себе потерять ее и они заплатят за ее освобождение, может быть даже вышеупомянутой и весьма ценной добычей. Что скажете, банда?",

	
	--Boiling Point RU text tweaks
		["mad_txt_005"] = "КОМНАТА МЕДОСМОТРА",
		["mad_txt_006"] = "ОПЕРАЦИОННАЯ",
		
		--We assets now--
		["menu_asset_dinner_safe"] = "Сейф",
		["menu_asset_bomb_inside_info"] = "Информация от инсайдера",
		["menu_asset_mad_cyborg_test_subject"] = "Подопытный",
		
	})
end)

--Оружия и все, что с ними связано (и по мелочи всякие статы)
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Weapons", function(loc)
	LocalizationManager:add_localized_strings({
		--Halloween Dozer Sword
		["bm_melee_halloween_sword"] = "Меч Безголового Бульдозера",
		["bm_melee_titham"] = "Молот Безголового Бульдозера",
		["menu_l_global_value_halloween_sword"] = "Это предмет из Хеллоуина 2013!",
		--Zweihander
		["bm_melee_zweihander"] = "Двуручник",
		["bm_melee_zweihander_info"] = "Огромный двуручный меч, который больше похож на алебарду, нежели чем меч.\n\nПарирование противника наносит ему #{skill_color}#180## урона в ближнем бою. Навыки позволяют увеличить этот урон.",
		["bm_melee_broad"] = "Длинный меч",
		["bm_melee_broad_info"] = "Самое знаковое оружие большинства рыцарей.",
		--Toasty
		["bm_melee_toast"] = "Тост Алмира",
		["bm_melee_toast_info"] = "Ты - не ты, когда голоден.\n\nУменьшает получаемый урон на #{skill_color}#10%## во время замаха.",

		--S&W .500
        ["bm_wp_wpn_fps_pis_shatters_fury_b_comp1"] = "Ствол 'Горус'",
		["bm_wp_wpn_fps_pis_shatters_fury_b_comp2"] = "Ствол 'Шаттер'",
		["bm_wp_wpn_fps_pis_shatters_fury_b_long"] = "Ствол 'Хатхор'",
		["bm_wp_wpn_fps_pis_shatters_fury_b_short"] = "Ствол 'Фаерберд'",

		["bm_wp_wpn_fps_pis_shatters_fury_g_ergo"] = "Эргономичная рукоять",

		["bm_wp_wpn_fps_pis_shatters_fury_body_smooth"] = "Гладкий барабан",

		["menu_l_global_value_shatters_fury"] = "Это предмет ВЕРИТАС!",

		--MK-23
		--Semi-automatic pistol. Hold down ■ to aim. Release to fire.
		["bm_w_socom"] = "Пистолет Anubis .45",
		["bm_w_x_socom"] = "Парные Anubis .45",
		["bm_wp_wpn_fps_upg_fl_pis_socomlam"] = "Комбинированный модуль 'Ра'",
		["bm_wp_wpn_fps_upg_fl_pis_socomlam_desc"] = "Включается на кнопку $BTN_GADGET.",
		----Weapons + Mods Descriptions/names----

		--Reinfield--
		["bm_wp_r870_s_folding_ext"] = "Раскрытый приклад 'Muldon'",

		--Bernetti--
		["bm_wp_upg_i_93r"] = "Набор Бернетти 93Т",
		["bm_wp_upg_i_93r_desc"] = "#{risk}#Добавляет выбор режимов огня##, позволяя стрелять #{skill_color}#очередями по три, со скоростью 1100##, но #{important_1}#увеличивает отдачу.##",

		--10-0
		["bm_wp_upg_i_tekna"] = "Набор 'Текна'",
		["bm_wp_upg_i_tekna_desc"] = "Оружие стреляет только #{risk}#очередями##.",
		["bm_wally_desc"] = "#{important_2}#Эй, малой...##",

		--AMR16--
		["bm_wp_upg_i_m16a2"] = "Набор Кросскилл B3",
		["bm_wp_upg_i_m16a2_desc"] = "Заменяет автоматический огонь на стрельбу #{skill_color}#очередями по три##. #{risk}#Очереди#{skill_color}# имеют повышенную скорость в #{skill_color}#950.##",

		--Bernetti Auto--
		["bm_wp_upg_i_b93o"] = "Набор Бернетти ОВЕРКИЛЛ",
		["bm_wp_upg_i_b93o_desc"] = "Заменяет стрельбу очередями на #{skill_color}#автоматическую##, но #{important_1}#увеличивает отдачу.##",

		--2006M Hailstorm
		["bm_w_hailstorm_2006m"] = "Хейлшторм-9",
		["bm_w_hailstorm_rsh12"] = "Хейлшторм-12",
		["bm_wp_upg_i_iw_hailstorm"] = "Набор Хейлшторм",
		["bm_wp_upg_i_iw_hailstorm_desc"] = "Позволяет стрелять особыми #{skill_color}#тройными боеприпасами.##",
		["bm_wp_upg_i_iw_hailstorm_no_pen_desc"] = "Позволяет стрелять особыми #{skill_color}#тройными боеприпасами##, но #{important_1}#урон по броне уменьшается на 50% и отключается пробитие щитов.##",

		--M200 WIDOWMAKER
		["bm_wp_upg_i_iw_widowmaker"] = "Набор Овдовителя",
		["bm_wp_upg_i_iw_widowmaker_desc"] = "Прототип оружейного набора, изготовленного компанией Kendall Ballistics.\n\nМодифицирует оружие под использование особых #{skill_color}#боеприпасов с двойным штабелем.##",
					
		--M32 MK32 Kit
		["bm_wp_upg_i_ghosts_mk32"] = "Набор Марк 32",
		["bm_wp_upg_i_ghosts_mk32_desc"] = "Заменяет одиночную стрельбу на #{skill_color}#стрельбу очередями по два.##",

		--Shotgun Generic Mods--
		["bm_wp_ns_duck_desc_sc"] = "Дробь #{risk}#летит горизонтально##, а не распыляется.",
		["bm_wp_ns_ultima_desc_sc"] = "Увеличивает разброс дроби на 75%.",
		["bm_wp_upg_a_slug_sc"] = "Бронебойная пуля",
		["bm_wp_upg_a_slug_desc"] = "Свинцовая пуля, которая #{skill_color}#пробивает броню, врагов, щиты и тонкие стены.##",
		["bm_wp_upg_a_slug_spam_desc"] = "Свинцовая пуля, которая #{skill_color}#наносит 75% урона через броню, пробивает врагов и тонкие стены.##",
		["bm_wp_upg_a_slug_titan_desc"] = "Свинцовая пуля, которая #{skill_color}#пробивает броню, врагов, щиты, титан щиты и тонкие стены.##",
		["bm_wp_upg_a_explosive_desc_sc"] = "#{heat_warm_color}#Взрывная## пуля с радиусом взрыва #{skill_color}#2## метра.\n#{skill_color}#Не теряет урон с расстоянием##, но #{risk}#урон поделен поровну между пулей и взрывом.##",
		["bm_wp_upg_a_custom_desc"] = "#{important_1}#6## больших дробинок, которые #{skill_color}#увеличивают урон##",
		["bm_wp_upg_a_custom_4_desc"] = "#{important_1}#4## большие дробинки, которые #{skill_color}#увеличивают урон##",
		["bm_wp_upg_a_dragons_breath_auto_desc_sc"] = "Магниевые осколки обладают шансом #{heat_warm_color}#поджечь врагов##, нанося #{heat_warm_color}#90## урона в течение #{skill_color}#2## секунд.\n\n#{risk}#Шанс уменьшается с расстоянием.##",
		["bm_wp_upg_a_dragons_breath_semi_desc_sc"] = "Магниевые осколки обладают шансом #{heat_warm_color}#поджечь врагов##, нанося #{heat_warm_color}#120## урона в течение #{skill_color}#2## секунд.\n\n#{risk}#Шанс уменьшается с расстоянием.##",
		["bm_wp_upg_a_dragons_breath_pump_desc_sc"] = "Магниевые осколки обладают шансом #{heat_warm_color}#поджечь врагов##, нанося #{heat_warm_color}#180## урона в течение #{skill_color}#2## секунд.\n\n#{risk}#Шанс уменьшается с расстоянием.##",
		["bm_wp_upg_a_dragons_breath_heavy_desc_sc"] = "Магниевые осколки обладают шансом #{heat_warm_color}#поджечь врагов##, нанося #{heat_warm_color}#240## урона в течение #{skill_color}#2## секунд.\n\n#{risk}#Шанс уменьшается с расстоянием.##",
		["bm_wp_upg_a_rip"] = "Дробь 'Томбстоун'",
		["bm_wp_upg_a_rip_auto_desc_sc"] = "#{stats_positive}#Ядовитая## дробь, которая может оглушить врагов. Наносит #{stats_positive}#60## урона ядом в течение #{skill_color}#2## секунды.\n\n#{risk}#Время действия уменьшается с расстоянием.##",
		["bm_wp_upg_a_rip_semi_desc_sc"] = "#{stats_positive}#Ядовитая## дробь, которая может оглушить врагов. Наносит #{stats_positive}#120## урона ядом в течение #{skill_color}#4## секунд.\n\n#{risk}#Время действия уменьшается с расстоянием.##",
		["bm_wp_upg_a_rip_pump_desc_sc"] = "#{stats_positive}#Ядовитая## дробь, которая может оглушить врагов. Наносит #{stats_positive}#180## урона ядом в течение #{skill_color}#6## секунды.\n\n#{risk}#Время действия уменьшается с расстоянием.##",
		["bm_wp_upg_a_rip_heavy_desc_sc"] = "#{stats_positive}#Ядовитая## дробь, которая может оглушить врагов. Наносит #{stats_positive}#240## урона ядом в течение #{skill_color}#8## секунды.\n\n#{risk}#Время действия уменьшается с расстоянием.##",
		["bm_wp_upg_a_piercing_auto_desc_sc"] = "12 флешеттов, которые #{skill_color}#пробивают броню##.",
		["bm_wp_upg_a_piercing_9_auto_desc_sc"] = "9 флешетт, которые #{skill_color}#пробивают броню##.",
		["bm_wp_upg_a_piercing_auto_desc_per_pellet"] = "12 флешеттов, которые #{skill_color}#пробивают броню##. #{skill_color}#Урон в голову увеличен на 100%.##",
		["bm_wp_upg_a_piercing_9_auto_desc_per_pellet"] = "9 флешетт, которые #{skill_color}#пробивают броню##. #{skill_color}#Урон в голову увеличен на 100%.##",
		["bm_wp_upg_a_piercing_semi_desc_per_pellet"] = "12 флешеттов, которые #{skill_color}#пробивают броню##. #{skill_color}#Урон в голову увеличен на 100%.##",
		["bm_wp_upg_a_piercing_pump_desc_per_pellet"] = "12 флешеттов, которые #{skill_color}#пробивают броню##. #{skill_color}#Урон в голову увеличен на 100%.##",
		["bm_wp_upg_a_piercing_heavy_desc_per_pellet"] = "12 флешеттов, которые #{skill_color}#пробивают броню##. #{skill_color}#Урон в голову увеличен на 100%.##",

		--Generic Mods--
		["bm_wp_upg_vg_afg"] = "Рукоятка 'AFG'",
		["bm_wp_upg_vg_stubby"] = "Вертикальная рукоятка 'Стабби'",
		["bm_wp_upg_vg_tac"] = "Вертикальная рукоятка 'TAC'",

		["fucktheatf"] = "Погодите, это реально?",

		["bm_wp_upg_ns_ass_smg_stubby"] = "Пламегаситель 'Стабби'",

		["bm_wp_upg_flash_hider"] = "#{skill_color}#Прячет пламя## и #{risk}#уменьшает шанс того, что противники увернутся от вашего огня.##",
		["bm_wp_upg_suppressor"] = "#{skill_color}#Заглушает## оружие и #{risk}#уменьшает шанс того, что противники увернутся от вашего огня.##",
		["bm_wp_upg_suppressor_boss"] = "\"What a thrill...\"\n\n#{skill_color}#Заглушает## оружие и #{risk}#уменьшает шанс того, что противники увернутся от вашего огня.##",
		["bm_wp_upg_suppressor_warn"] = "#{skill_color}#Заглушает## оружие и #{risk}#уменьшает шанс того, что противники увернутся от вашего огня.##\n\n#{important_1}#Может мешать прицеливанию.##",

		["bm_wp_upg_s_saintvictor_hera"] = "Новомодный приклад",
		["bm_wp_upg_vintage_fal_sc"] = "Классический магазин",
		["bm_wp_upg_vintage_sc"] = "Винтажный магазин",
		["bm_wp_upg_mil_sc"] = "Армейский магазин",
		["bm_wp_upg_tac_sc"] = "Тактический магазин",

		["bm_wp_upg_mil_desc"] = "", --These didn't do anything when edited, maybe they aren't actually called?--
		["bm_wp_upg_drum_desc"] = "",
		["bm_wp_upg_drum2_desc"] = "",
		["bm_wp_upg_quad_desc"] = "",
		["bm_wp_upg_quad2_desc"] = "",
		["bm_wp_upg_vintage_desc"] = "",

		--RPK--
		["bm_wp_rpk_m_ban_sc"] = "Банановый магазин",
		["bm_wp_ak_m_drum"] = "Барабанный магазин",
		["bm_wp_upg_i_rpk74"] = "Конверсия под 5.45",

		--Saw--
		["bm_ap_saw_sc_desc"] = "#{skill_color}#Прорезает броню.##",
		["bm_ap_saw_blade_sc_desc"] = "Лезвия становятся настолько острыми, что прорезают броню.",
		["bm_fast_motor_sc_desc"] = "Увеличивает скорость ротации на 15%.",
		["bm_slow_motor_sc_desc"] = "Уменьшает скорость ротации на 15%.",

		--Generic Optic Zoom Descriptions--
		["bm_wp_upg_o_1_1"] = "Отражательный прицел.\n#{risk}#Увеличение 1.1x.##",
		["bm_wp_upg_o_1_1_health"] = "Отражательный прицел,  #{skill_color}#который показывает здоровье противников при наведении##.\n#{risk}#Увеличение 1.1x.##",
		["bm_wp_upg_o_1_2"] = "Коллиматорный прицел.\n#{risk}#Увеличение 1.2x.##",
		["bm_wp_upg_o_1_5"] = "Голографический прицел.\n#{risk}#Увеличение 1.5x.##",
		["bm_wp_upg_o_1_5_pris"] = "Призматический прицел.\n#{risk}#Увеличение 1.5x##",
		["bm_wp_upg_o_1_5_scope"] = "Слабая оптика.\n#{risk}#Увеличение 1.5x.##",
		["bm_wp_upg_o_1_8"] = "Коллиматорный прицел.\n#{risk}#Увеличение 1.8.##",
		--["bm_wp_upg_o_1_8_irons"] = "Коллиматорный прицел с дополнительной мушкой.\n#{risk}#Увеличение 1-1.8x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между прицелами.",
		["bm_wp_upg_o_2"] = "Обычная оптика.\n#{risk}#Увеличение 2х.##",
		["bm_wp_upg_o_2_5"] = "Обычная оптика.\n#{risk}#Увеличение 2.5х.##",
		["bm_wp_upg_o_3"] = "Средняя оптика.\n#{risk}#Увеличение 3x##",
		["bm_wp_upg_o_3_range"] = "Средняя оптика с #{skill_color}#дальномером.##\n#{skill_color}#Автоматически помечает## охранников (только до поднятия тревоги), элитных и особых противников при наведении на них.\n#{risk}#Увеличение 3x.##",
		["bm_wp_upg_o_3_rds"] = "Средняя оптика с дополнительным отражательным прицелом.\n#{risk}#Увеличение 1-3x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между прицелами.",
		["bm_wp_upg_o_3_4"] = "Средняя оптика.\n#{risk}#Увеличение 3.4x.##",
		["bm_wp_upg_o_3_5"] = "Средняя оптика.\n#{risk}#Увеличение 3.5x.##",
		["bm_wp_upg_o_4"] = "Средняя оптика.\n#{risk}#Увеличение 4x.##",
		["bm_wp_upg_o_4_cod"] = "Средняя оптика.\n#{risk}#Увеличение 4x.##",
		["bm_wp_upg_o_4_default"] = "Стандартная оптика у этого оружия.\n#{risk}#Увеличение 4x.##\n\n#{item_stage_2}#Прицел нельзя убрать, но его можно заменить на другой.##",
		["bm_wp_upg_o_4_range"] = "Средняя оптика с #{skill_color}#дальномером.##\n#{skill_color}#Автоматически помечает## охранников (только до поднятия тревоги), элитных и особых противников при наведении на них.\n#{risk}#Увеличение 4x.##",
		["bm_wp_upg_o_4_irons"] = "Средняя оптика с дополнительной мушкой.\n#{risk}#Увеличение 1-4x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между прицелами.",
		["bm_wp_upg_o_4_rds"] = "Средняя оптика со встроенным прицелом.\n#{risk}#Увеличение 1.1-4x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между прицелами.",
		["bm_wp_upg_o_4_rds_mount"] = "Регулируемая оптика с дополнительным отражательным прицелом.\n#{risk}#Увеличение 1.1 + 2-4x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между кратностью увеличения и прицелами.",
		["bm_wp_upg_o_4_vari"] = "Оптика с настраиваемым прицелом.\n#{risk}#Увеличение 4-8x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между прицелами.",
		--Я отказываюсь это переводить --да и не надо - Марши
		["bm_wp_upg_o_4_valentine"] = "Оптика с настраиваемым прицелом.\n#{risk}#Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы переключится между прицелами.",
		--А я возьму и переведу! - Вавло
		--["bm_wp_upg_o_4_valentine_x"] = "I don't give a shit, I don't give a fuck!\nI don't give a shit! I don't give a fuck!\nNow if I give a shit, I might just give a fuck!\nBut I don't give a shit, so I don't give a fuck!",
		["bm_wp_upg_o_4_valentine_x"] = "Не ебет и не колышет!\nНе ебет и не колышет!\nЕсли же ебет, может, и колышет!\nПохуй, что ебет, похуй, что колышет...",
		["bm_wp_upg_o_5"] = "Дальнобойная оптика.\n#{risk}#Увеличение 5x.##",
		["bm_wp_upg_o_5_range"] = "Дальнобойная оптика с #{skill_color}#дальномером.##\n#{risk}#Увеличение 5x.##",
		["bm_wp_upg_o_5_vari"] = "Регулируемая оптика.\n#{risk}#Увеличение 5-8x.##\n\nНажмите #{skill_color}#$BTN_GADGET## во время прицеливания, чтобы изменить кратность увеличения.",
		["bm_wp_upg_o_6"] = "Дальнобойная оптика.\n#{risk}#Увеличение 6x.##",
		["bm_wp_upg_o_6_range"] = "Дальнобойная оптика c #{skill_color}#дальномером.##\n#{skill_color}#Автоматически помечает## охранников (только до поднятия тревоги), элитных и особых противников при наведении на них.\n#{risk}#Увеличение 6x.##",
		["bm_wp_upg_o_8"] = "Дальнобойная оптика.\n#{risk}#Увеличение 8x.##",
		["bm_wp_upg_o_8_range"] = "Дальнобойная оптика с #{skill_color}#дальномером.##\n#{skill_color}#Автоматически помечает## охранников (только до поднятия тревоги), элитных и особых противников при наведении на них.\n#{risk}#Увеличение 8x.##",

		["bm_wp_upg_o_iwelo"] = "Оптика с подсвечиванием.\n#{risk}#Увеличение 1.1x.##",
		["bm_wp_upg_o_iwrds"] = "Коллиматорный прицел особой точности.\n#{risk}#Увеличение 1.5x.##",

		["bm_wpn_fps_upg_o_hamr"] = "Прицел Тригоном",

		["bm_wp_upg_o_shortdot_dmc"] = "Прицел Шортдот",
		["bm_wp_upg_o_5_default"] = "Дальнобойная оптика.\nИспользуйте, чтобы модифицировать перекрестие у стандартного прицела.\n#{risk}#Увеличение 5x.##",

		["bm_wp_upg_fl_flashlight"] = "Фонарик переключается на #{skill_color}#$BTN_GADGET##",
		["bm_wp_upg_fl_laser"] = "Лазер переключается на #{skill_color}#$BTN_GADGET##",
		["bm_wp_upg_fl_dual"] = "Переключение между лазером и фонариком на #{skill_color}#$BTN_GADGET##",
		["bm_wp_upg_fl_vmp_marker"] = "#{skill_color}#Автоматически помечает## охранников, особых и титановых врагов на расстоянии #{skill_color}#40## метров при прицеливании.\n\n#{risk}#Охранники помечаются только в стелсе.##",
		["bm_wp_upg_fl_second_sight_warning"] = "\n\n#{important_1}#ВО ВРЕМЯ ПРИЦЕЛИВАНИЯ НЕЛЬЗЯ ВКЛЮЧИТЬ ИЗ-ЗА ВТОРОСТЕПЕННОГО ПРИЦЕЛА.##",

		["bm_wp_upg_o_angled_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания чтобы переключиться между оптикой и угловым прицелом.",
		["bm_wp_upg_o_angled_1_1_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания чтобы переключиться между оптикой и угловым прицелом.\n#{skill_color}#Увеличение 1.1х.##",
		["bm_wp_upg_o_angled_1_2_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания чтобы переключиться между оптикой и угловым прицелом.\n#{skill_color}#Увеличение 1.2х.##",
		["bm_wp_upg_o_angled_laser_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания чтобы переключиться между оптикой или использовать лазер для прицеливания.\nПрицеливание лазером на #{skill_color}#25%## быстрее и штраф к передвижению во время прицеливания уменьшен на #{skill_color}#50%##, #{important_1}#в ущерб прицельной точности.##\n\n#{risk}#Для эффективного использования необходимо установить лазер.##", --VMP Point Shoot Laser
		["bm_wp_upg_o_angled_aim_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания чтобы переключиться между обычным и наклонным прицеливанием.##", --VMP Point Shoot Laser

		["bm_wp_upg_o_magnifier_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## во время прицеливания чтобы использовать линзу.\n#{risk}#Увеличение 3x.##",

		--Гранатоснаряды--
		["bm_wp_upg_a_grenade_launcher_incendiary_desc_sc"] = "Снаряд создает #{heat_warm_color}#огненную лужу## на месте взрыва.\nЛужа обладает радиусом #{skill_color}#3.75м## и горит #{skill_color}#5 секунд##, нанося #{skill_color}#120 урона/сек## врагам, которые в нее попадают, что вызывает панику и наносит еще #{skill_color}#60 урона## в течение #{skill_color}#3 секунд.##",
		["bm_wp_upg_a_grenade_launcher_incendiary_arbiter_desc_sc"] = "Снаряд создает #{heat_warm_color}#огненную лужу## на месте взрыва.\nЛужа обладает радиусом #{skill_color}#3.75м## и горит #{skill_color}#5 секунд##, нанося #{skill_color}#80 урона/сек## врагам, которые в нее попадают, что вызывает панику и наносит еще #{skill_color}#60 урона## в течение #{skill_color}#3 секунд.##",
		["bm_wp_upg_a_grenade_launcher_incendiary_ms3gl_desc_sc"] = "Снаряд создает #{heat_warm_color}#огненную лужу## на месте взрыва.\nЛужа обладает радиусом #{skill_color}#3.75м## и горит #{skill_color}#5 секунд##, нанося #{skill_color}#40 урона/сек## врагам, которые в нее попадают, что вызывает панику и наносит еще #{skill_color}#60 урона## в течение #{skill_color}#3 секунд.##.",
		["bm_wp_upg_a_grenade_launcher_frag_desc_sc"] = "Снаряд #{risk}#взрывается## при попадании. Взрыв наносит #{skill_color}#720## урона и обладает радиусом #{skill_color}#5## метров.",
		["bm_wp_upg_a_grenade_launcher_electric_desc_sc"] = "Снаряд производит #{ghost_color}#электроразряд## на месте взрыва. Разряд наносит #{skill_color}#360## урона, имеет радиус #{skill_color}#5## метров и обладает шансом #{ghost_color}#наэлектризовать врагов.##",
		["bm_wp_upg_a_grenade_launcher_electric_ms3gl_desc_sc"] = "Снаряд производит #{ghost_color}#электроразряд## на месте взрыва. Разряд наносит #{skill_color}#180## урона, имеет радиус #{skill_color}#5## метров и обладает шансом #{ghost_color}#наэлектризовать врагов.##",
		["bm_wp_upg_a_grenade_launcher_electric_arbiter_desc_sc"] = "Снаряд производит #{ghost_color}#электроразряд## на месте взрыва. Разряд наносит #{skill_color}#300## урона, имеет радиус #{skill_color}#3## метра и обладает шансом #{ghost_color}#наэлектризовать врагов.##",
		["bm_wp_upg_a_grenade_launcher_poison"] = "Граната Manticore-6",
		["bm_wp_upg_a_grenade_launcher_poison_desc_sc"] = "Снаряд производит #{stats_positive}#облако ядовитого газа## на месте взрыва.\nГаз имеет радиус #{skill_color}#6## метров, держится #{skill_color}#8## секунд, наносит #{skill_color}#240## урона в течение #{skill_color}#8## секунд и #{stats_positive}#отравляет## врагов, которые #{important_1}#впервые## попали в него.",
		["bm_wp_upg_a_grenade_launcher_poison_arbiter_desc_sc"] = "Снаряд производит #{stats_positive}#облако ядовитого газа## на месте взрыва.\nГаз имеет радиус #{skill_color}#6## метров, держится #{skill_color}#6## секунд, наносит #{skill_color}#180## урона в течение #{skill_color}#6## секунд и #{stats_positive}#отравляет## врагов, которые #{important_1}#впервые## попали в него.",
		["bm_wp_upg_a_grenade_launcher_poison_ms3gl_desc_sc"] = "Снаряд производит #{stats_positive}#облако ядовитого газа## на месте взрыва.\nГаз имеет радиус #{skill_color}#6## метров, держится #{skill_color}#4## секунд, наносит #{skill_color}#120## урона в течение #{skill_color}#4## секунд и #{stats_positive}#отравляет## врагов, которые #{important_1}#впервые## попали в него.",

		--Огнеметы--
		["bm_wp_fla_mk2_mag_rare_sc"] = "Слабая прожарка",
		["bm_wp_fla_mk2_mag_rare_desc_sc"] = "Удваивает время горения, но наполовину уменьшает его урон.",
		["bm_wp_fla_mk2_mag_well_desc_sc"] = "Уменьшает время горения наполовину, но удваивает урон от него.",
		["bm_ap_flamethrower_sc_desc"] = "Тысячи градусов чистой боли. Кто мог придумать такое?\n#{heat_warm_color}#Прожигает через броню.##",
		["bm_ap_money_sc_desc"] = "Тысячи долларов чистого счастья. Поверните кран и выпускайте бабло.\n#{competitive_color}#Подкупает через броню.##", --used by both flamethrowers, decouple later?--

		--Пулеметы/Миниганы--
		["bm_wp_upg_a_halfthatkit"] = "Двойная порция", -- lol
		["bm_wp_m134_body_upper_light"] = "Легкий корпус",
		["bm_wp_upg_a_halfthatkit_desc"] = "Добавляет 10% штраф к скорости при ношении данного оружия.\n\nУвеличивает подбор патронов на 20%.",
		["bm_wp_upg_a_halfthatkit_tecci_desc"] = "Добавляет 25% штраф к скорости при ношении данного оружия.\n\nУвеличивает подбор патронов на 50%.",

		--Phoenix .500--
		["bm_wp_shatters_fury_desc"] = "Массивный револьвер калибра .500 с дикой отдачей и мощностью. Любимое оружие Шаттера.\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",

		--ЛЕГЕНДАРНЫЕ скины--
		["bm_menu_sc_legendary_ak"] = "Vlad's Rodina",
		["bm_menu_sc_legendary_flamethrower"] = "Dragon Lord",
		["bm_menu_sc_legendary_deagle"] = "Midas Touch",
		["bm_menu_sc_legendary_m134"] = "The Gimp",
		["bm_menu_sc_legendary_r870"] = "Big Kahuna",
		["bm_wskn_ak74_rodina_desc_sc"] = "Особенный АК, который продемонстрировал свою кровожадность как на войне, так и на ограблениях.",
		["bm_wskn_deagle_bling_desc_sc"] = "Вручную собранный Deagle, сделанный в дань уважения сумасшедшему стрелку, который тренировался в компьютерных играх.",

		--Наборы--
		["bm_wp_upg_ultima_body_kit_desc_sc"] = "Этот набор добавляет уникальный #{risk}#тройной лазерный прицел##, несовместимый с другими устройствами.",
		["bm_wp_upg_fmg9_conversion_desc_sc"] = "Этот набор добавляет #{risk}#счетчик патронов и лазерный прицел##, несовместимые с другими устройствами.",

		--Модификаторы--
		["bm_wp_upg_bonus_sc_none"] = "Нет модификатора",
		["bm_wp_upg_bonus_sc_none_desc"] = "ИСПОЛЬЗУЙТЕ, ЧТОБЫ УБРАТЬ БОНУСЫ, ПОЛУЧЕННЫЕ ОТ СКИНОВ.",

		["bm_welrod_sc_desc"] = "Это компактное и замаскированное под насос оружие #{skill_color}#cо встроенным глушителем## способно бесшумно поражать изолированные цели.",
		--Gecko Pistol
		["bm_tranq_maxim_sc_desc"] = "Первый в мире пистолет #{skill_color}#со встроенным глушителем##. Удобность и скрытность хорошо сочетаются с ослабляющими боеприпасами-транквилизаторами.\n\n#{stats_positive}#Наносит периодический урон.##",
		["bm_tranq_x_maxim_sc_desc"] = "Парочка первых в мире пистолетов #{skill_color}#со встроенным глушителем##. Удобность и скрытность хорошо сочетаются с ослабляющими боеприпасами-транквилизаторами.\n\n#{stats_positive}#Наносят периодический урон.##",
		--Igor (APS)
		["bm_stech_sc_desc"] = "Тяжелый и медленный автоматический пистолет, который потерял популярность из-за огромных габаритов. Его вес делает его стабильным, но не очень скрытным.",
		["bm_x_stech_sc_desc"] = "Тяжелый и медленный автоматический пистолет, который потерял популярность из-за огромных габаритов. Его вес делает его стабильным, но не очень скрытным.",
		--Chimano Compact
		["bm_jowi_sc_desc"] = "Пистолет 'Чимано' с максимальной скрытностью - за счет всего остального.\n\nГоворят, Уик его использовал, когда мстил русской мафии.",
		["bm_x_jowi_sc_desc"] = "Раз они такие маленькие, почему бы не взять два? Эту парочку неверно приписывают Уику как его любимое оружие.",
		--Glock 18c
		["bm_g18c_sc_desc"] = "Полностью автоматический австрийский пистолет. Его трудно удержать, но вблизи он абсолютно смертоносен.",
		["bm_x_g18c_sc_desc"] = "Отдачи от одного тебе мало? Ну держи второй!",
		--CZ 75
		["bm_czech_sc_desc"] = "Один из пистолетов, которые предписывают к 'Wonder Nine', обладающий автоматической стрельбой и хорошей эргономикой. Используется контр-террористическими подразделениями всего мира.",
		["bm_x_czech_sc_desc"] = "Пример того, как не стоит использовать автоматические пистолеты. Ты как их перезаряжать будешь?",
		--PPK (Gruber)
		["bm_ppk_sc_desc"] = "Компактная альтернатива большим и опасным пушкам. Классическое оружие для классических целей.",
		["bm_x_ppk_sc_desc"] = "Когда ты уже не Бонд, а Кингсмэн.",
		--Makarov (Strix)
		["bm_pmm_sc_desc"] = "Этот пистолет советской эпохи до сих пор используется по всему миру. Благодаря своим небольшим размерам его легко спрятать, но при этом он обладает достаточной мощностью в условиях интенсивного огня.",
		["bm_x_pmm_sc_desc"] = "На случай, если выстрела из одного пистолета во время стрима ограбления будет недостаточно для вечного бана.",
		--M13
		["bm_legacy_sc_desc"] = "Модель из Западной Германии, которая не потерпела конкуренции с Бернетти, но может постоять за себя.",
		["bm_x_legacy_sc_desc"] = "Два пистолета, забытых историей. Напомните об их существовании, залив комнату свинцом.",
		--Glock 17
		["bm_g17_sc_desc"] = "Надежный и легкий в обращении. Отличный выбор для начинающего грабителя.",
		["bm_x_g17_sc_desc"] = "Маленький калибр - не беда, когда стреляешь настолько быстро.\n\nИх использовал Хокстон во время освобождения.",
		--Bernetti 9
		["bm_b92fs_sc_desc"] = "Популярный пистолет благодаря впечатляющему магазину и неплохому урону. Подойдет, когда злодеи окружили вас.",
		["bm_x_b92fs_sc_desc"] = "Два веселее чем один. Превратите окружение в девятимиллиметровую вечеринку.",
		--White Streak
		["bm_pl14_sc_desc"] = "Современный российский пистолет, использующий пост-советские технологии из-за рубежа. Любим Риперами за надежность и футуристический дизайн.",
		["bm_x_pl14_sc_desc"] = "Современный российский пистолет, использующий пост-советские технологии из-за рубежа. Любим Риперами за надежность и футуристический дизайн.",
		--Holt 9mm
		["bm_holt_sc_desc"] = "Рабочий прототип пистолета, застрявшего в разработке. Инновационный дизайн, который помогает компенсировать отдачу.",
		["bm_x_holt_sc_desc"] = "Целых два пистолета, которые считаются потерянными.",
		--FMG-9
		["bm_fmg9_sc_desc"] = "Экспериментальное оружие, служащее продвинутым держателем для 'Стрика'. В комплекте футуристическая технология разворота!",
		--93R
		["bm_beer_sc_desc"] = "Практически фантастический пистолет с разными режимами огня. Живой или мертвый, ты пройдешь со мной.",
		--Contractor Pistols
		["bm_packrat_sc_desc"] = "Выбор Уика за свою надежность и простоту в использовании. Говорят, именно с ним он нанес визит в клуб The Red Circle.",
		["bm_x_packrat_sc_desc"] = "Выбор для тех, кому нужно зачистить клуб русской мафии ради кровавой мести.",
		--Breech (Luger)
		["bm_breech_sc_desc"] = "Пистолет, который почти захватил мир. Дважды. Этот немецкий артефакт стильный, точный и абсолютно устаревший.",
		--Chimano Custom
		["bm_g22c_sc_desc"] = "Комбинация высокой емкости и мощности. Один из лучших боевых пистолетов.",
		["bm_x_g22c_sc_desc"] = "Когда за голос дают один ствол, хочется обмануть систему и заполучить себе парочку.",
		--Signature .40
		["bm_p226_sc_desc"] = "Этот классический боец с законом проявит себя и в банке, и при ограблении транспорта.",
		--LEO
		["bm_hs2000_sc_desc"] = "Этот компактный пистолет приглянется агентам Интерпола, продажным хорватским копам и международным преступникам.",
		--5/7 pistol
		["bm_lemming_sc_desc"] = "Мощность и емкость в одном флаконе. Если кто-то не гибнет после 20 патронов, может, не стоит с ним сражаться?\n\n#{skill_color}#Наносит 75% урона через броню.##",
		--Baby Deagle--
		["bm_sparrow_sc_desc"] = "Ты что, ковбой?",
		["bm_w_sparrow_sc_g_cowboy_desc"] = "SEE YOU SPACE COWBOY...",
		--Ballerina 9mm (Pivot PCC)
		["bm_speen_sc_desc"] = "Пользующийся популярностью среди агентов под прикрытием, этот карабин пистолетного калибра аккуратно складывается, что облегчает его скрытое ношение.",
		--socom deez nuts--
		["bm_w_socom_desc"] = "Любимое оружие Джекела. Надежный и мощный пистолет под .45 ACP со стильным дизайном.",
		--Crosskill
		["bm_1911_sc_desc"] = "Когда 9мм кажется мало, возьмите этот модифицированный пистолет, заряженный мощными .45ACP. Беспрецедентная жестокость.",
		["bm_x_1911_sc_desc"] = "Может они и не обладают демоническими силами, но то, что они после себя оставляют, способно напугать любого.",
		--Crosskill Guard
		["bm_shrew_sc_desc"] = "Маленький и более компактный, чем модель А1. Увеличенная скрытность за счет уменьшения магазина и длины ствола.",
		["bm_x_shrew_sc_desc"] = "Выбор Ханаанитов - два пистолета под .45 помогут отбить любую атаку.",
		["bm_shrew_g_bling_sc_desc"] = "\"In a world filled with misery and uncertainty, it is a great comfort to know that, in the end, there is light in the darkness.\"",
		--USP
		["bm_usp_sc_desc"] = "Один из лучших пистолетов S&G преуспевает в уроне, емкости и дальнобойности.",
		["bm_x_usp_sc_desc"] = "Парочка пистолетов S&G, когда нужно дать о себе знать.",
		--Model 54
		["bm_type54_sc_desc"] = "Советский пистолет под тяжелый калибр 7.62×25мм, обладает подствольным дробовиком в качестве дополнительного способа избавиться от проблем.",
		["bm_x_type54_sc_desc"] = "Двух стволов мало? Попробуйте четыре.",
		--Broomstick--
		["bm_c96_sc_desc"] = "\"...Ваше слово, товарищ Маузер!\"\n\nИнновационный немецкий пистолет, который модифицировали под автоматический огонь.\n\n#{risk}#Это оружие перезаряжается обоймами по десять патронов.##",
		["bm_wp_c96_nozzle"] = "Насадка Бластер-44",
		["bm_wp_c96_nozzle_desc_sc"] = "#{skill_color}#Технология из далекой галактики.## Оружие будет стрелять #{risk}#плазменными болтами## и #{skill_color}#автоматически заряжаться.##\n\nВремя зарядки: #{skill_color}#1.5 сек.##\nСкорость зарядки: #{skill_color}#3/сек## #{important_1}#(На 50% медленнее при перегреве)##\nПерегрев: #{important_1}#2 сек.##",
		--Sub2000
		["bm_sub2000_sc_desc"] = "Пистолет сомнительного качества сборки. Слабые пистолетные пули становятся мощнее из-за длины ствола, а возможность свертки дает хорошую скрытность.",
		--Deagle
		["bm_deagle_sc_desc"] = "Оружие крутых парней на все времена. Главное не вывихнуть руку.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		["bm_x_deagle_sc_desc"] = "Нужно быть безумцем, чтобы додуматься взять на поле боя сразу два.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		--Kahn .357
		["bm_korth_r8"] = "#{skill_color}#Попадания в голову всем, кроме капитанов и боссов, наносят на 100% больше урона.##",
		--Matever 2006m
		["bm_2006m_sc_desc"] = "Очень редкий револьвер предоставляет дорогостоящую возможность пострелять девятимиллиметровками.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		["bm_wp_2006m_b_short"] = "Ствол 'Тачикома'",
		["bm_wp_2006m_b_medium"] = "Ствол 'Тогуса'",
		["bm_wp_2006m_b_long"] = "Ствол 'Кусанаги'",
		["bm_x_2006m_sc_desc"] = "Неудобность этой идеи компенсируется ее крутостью.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		--Frenchman Model 87
		["bm_model3_sc_desc"] = "Старомодный ответ на вопрос \"Что делать со всеми этими мудаками?\"\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		["bm_x_model3_sc_desc"] = "Копы не уважают правила дуэли, так что и тебе незачем.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		--Raging bull
		["bm_rage_sc_desc"] = "Мощная и недальнобойная пушка. Враги будут падать как кегли, если держать огонь ровно.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		["bm_x_rage_sc_desc"] = "Совсем неудобно и непрактично, но свидетели ограбления будут впечатлены.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		--Castigo
		["bm_chinchilla_sc_desc"] = "Мощный, точный, стильный. Подойдет против самых сильных вашингтонских копов.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		["bm_x_chinchilla_sc_desc"] = "Сикарио не дает своей жертве шанса выжить - помогают эти револьверы.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
		--RUS-12
		["bm_rsh12_sc_desc"] = "Больше не нужно меряться малокалиберными стволами.\n\n#{skill_color}#Может пробивать броню, врагов, щитов и тонкие стены.##",
		--Chunky 1911
		["bm_m1911_sc_desc"] = "Перевыпуск старенького Crosskill .45. Почти не отличается от оригинала.",
		--SAA/Peacemaker
		["bm_ap_weapon_peacemaker_sc_desc"] = "#{risk}#The greatest handgun ever made.##\nАльтернативный огонь выпускает боезапас #{skill_color}#с повышенной скоростью##, за счет #{important_1}#отдачи, точности и невозможности прицеливания.##\n\n##Может пробивать броню, врагов, щитов и тонкие стены.##",
		--CUSTOM HANDGUNS AND ATTACHMENTS
			--Zippy
			["bm_zippy_sc_desc"] = "Самое малогабаритное летальное оружие, которое придумало человечество. Правда не стоит ожидать, что оно будет работать без осечек. Вам повезет, если после пары выстрелов это оружие не взорвется в Вашей руке.",
			--Auto-9
			["bm_w_rc_auto9_desc"] = "Табельное оружие, #{skill_color}#стреляющее очередью по 3 патрона##. Создано специально для самых жестяных блюстителей закона.",
			["bm_wp_rc_auto9_cartoon"] = "Мультяшные трейсеры",
			["bm_wp_rc_auto9_cartoon_desc"] = "Вечеринка прямо как в 1988!",
			--M2019 Blaster
			["thatgun_desc"] = "Вот это волына!\n\nИменно та самая!\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов.##",
			--Malorian 3516
				
			-- PAYDAY 3 Bullkick 500
			  ["bm_w_bk500_desc"] = "Это чертова портативная осадная пушка!\nДословно переводится как ''Пинок Быка 500''. И название не врет, эта вещь звучит и бъет как бык. Смотри чтоб руки твои не оторвало, вместе с головой несчастного копа по другую сторону ствола.",
				
			--Киберсрань
			["whydoyoucome"] = "Единственный в своем роде, сделанный специально для Джонни Сильверхенда.\n\n#{skill_color}#Может пробивать врагов и их броню.\nВо время стрельбы от бедра пули будут рикошетить от поверхностей. Пули пробивают стены, если стрелять в режиме прицеливания.\nУдар прикладом выпускает волну огня в небольшом радиусе.##",
			--Colt Detective
			["bm_lemon_dmc_desc"] = "Мечтаете о скрытном и мощном револьвере? Мечты сбываются.\n\n#{skill_color}#Наносит двойной урон при атаке сзади.##",
			--SIG P320
			["bm_wp_wpn_fps_pis_papa320_magazine_ext2"] = "Магазин на 32",
			--Triad
			["bm_triad_sc_desc"] = "#{skill_color}#Может пробивать броню, врагов, щитов (на растоянии макс.дальности) и тонкие стены.##\n\nРежим очередью стреляет #{skill_color}#тремя стволами разом## за счет пониженной #{important_1}#точности и стабильности.##",
			--GSh18
			["bm_gsh18_sc_desc"] = "#{skill_color}#Наносит 50% урона через броню.##",
			--SR1M
			["bm_sr1_sc_desc"] = "#{skill_color}#Наносит 75% урона через броню.##",
			--Howa Type 20
			["menu_l_global_value_howa_type20_mod"] = "Предмет, Япония.",
			--Видишь суслика? Вот и я не вижу. А он есть.
			["bm_w_nothing"] = "Без оружия",
			["bm_w_nothing2"] = "Без оружия",
			["menu_l_global_value_nothing"] = "Предмет из... а где",
					
		--Кастомные аттачменты
					--M6D
					["kfa_scope"] = "Прицел Смарт-Линк",
					["kfa_scope_desc"] = "Подключает вашу маску к системе #{skill_color}#Smart-Link##.\n#{risk}#Увеличение 2x.##",
					--Raygun
					["bm_wp_raygun_o_waw"] = "Старое прицеливание",
					["bm_wp_raygun_o_waw_desc"] = "Меняет выравнивание прицела так, как это было до Call of Duty: Black Ops II",
					--AR 23 LIBERATOR
					["bm_wp_wpn_fps_ass_ar23_o_carbine"] = "Коллиматорный прицел МК2",
					["bm_wp_carbine_optic_desc"] = "Разновидность коллиматорного прицела.",
					["bm_wp_wpn_fps_upg_ar23_o_promo"] = "Механический прицел",
	                                ["bm_wp_promo_irons_desc"] = "Простой механический прицел. Для Адских Десантников, мечтающих преодолевать в битвах те же сложности, что и их предки.",
					["bm_wp_wpn_fps_ass_ar23_optic_3"] = "Трубчатый коллиматор (1.5х)",
					["bm_wp_concussive_optic_desc"] = "Стандартный прицел большинства видов оружия. Обеспечивает хорошее и точное прицеливание.",
					["bm_wp_wpn_fps_ass_ar23_optic"] = "Боевой прицел 4х",
					["bm_wp_penetrator_optic_desc"] = "Хорошо подходит для средней и большой дальности, дает максимальное приближение, которое используется на обычном оружии.",
					["bm_wp_wpn_fps_ass_ar23_laser"] = "Лазерный прицел с фонариком",
					["bm_wp_laser_sight_desc"] = "Крупногабаритное устройство, совмещающее в себе функции лазерного прицела и фонарика.",
					--StA-52 Assault Rifle
					["bm_wp_wpn_fps_ass_sta52_carry_handle_flipped"] = "Стандартная рукоятка для переноски с перевернутой мушкой",

                    -- AR-2 Coyote
					["bm_wp_wpn_fps_ass_coyote_4x_optic"] = "Боевой прицел 4х",
					["bm_wp_4x_desc"] = "Хорошо подходит для средней и большой дальности, дает максимальное приближение, которое используется на обычном оружии.",
					["bm_wp_wpn_fps_ass_coyote_reflex_sight_mk2"] = "Коллиматорный прицел МК2",
					["bm_wp_wpn_fps_ass_coyote_holographic_sight"] = "Голографический прицел",
					["bm_wp_holographic_desc"] = "Голографический прицел.", -- Ебать как информативно, спасибо команда локализации HD2, очень круто. - Hylie

                    -- AR-59 Suppressor
					["bm_w_ar59"] = "Подавитель",
					["bm_w_ar59_desc"] = "Автоматическая штурмовая винтовка с несъемным глушителем и дозвуковыми боеприпасами. Медленные выстрелы отлично подходят для скрытых операций.",

					["bm_wp_wpn_fps_upg_hd2_4x_scope_ar59"] = "Боевой прицел 4х",
					["bm_wp_4x_scope_desc"] = "Хорошо подходит для средней и большой дальности, дает максимальное приближение, которое используется на обычном оружии.",
					["bm_wp_wpn_fps_upg_hd2_1_5x_scope_ar59"] = "Трубчатый коллиматор (1.5х)",
					["bm_wp_wpn_fps_upg_hd2_alt_1x_scope_ar59"] = "Коллиматорный прицел",
					["bm_wp_alt_1x_scope_desc"] = "Прицел с тонкими элементами, обеспечивающий максимальную видимость цели.",
					["bm_wp_wpn_fps_upg_hd2_holo_sight_ar59"] = "Голографический прицел",
					["bm_wp_1x_scope_desc"] = "Голографический прицел.",

					["bm_wp_wpn_fps_upg_hd2_m_short_ar59"] = "Короткий магазин",
					["bm_wp_short_desc"] = "Укороченный и менее вместительный магазин. При этом более легкий и управляемый.",
					["bm_wp_wpn_fps_upg_hd2_m_quick_ar59"] = "Увеличенный магазин с магпулом",
					["bm_wp_quick_desc"] = "Тип магазина, популярный у военных Супер-Земли, которым непрерывный огонь важнее управляемости. Имеет магпул для быстрой перезарядки.",
					["bm_wp_wpn_fps_upg_hd2_m_drum_ar59"] = "Барабанный магазин",
					["bm_wp_drum_desc"] = "Крайне вместительный, но при этом громодзкий и тяжелый магазин.",

					["bm_wp_wpn_fps_ass_ar59_s_folded"] = "Складенный приклад",

					["bm_wp_wpn_fps_upg_hd2_laser"] = "Лазерный прицел",
					["bm_wp_laser_desc"] = "Лазерный прицел, отцентрированный относительно ствола оружия, который помогает стрелку попасть в цель.",

                    -- R-72 Censor
					["bm_w_r72"] = "Цензор",
					["bm_w_r72_desc"] = "Точная винтовка средней дальности. Оснащена встроенным глушителем и дозвуковыми боеприпасами для незаметных операций.",

					["bm_wp_wpn_fps_upg_hd2_4x_scope_r72"] = "Боевой прицел 4х",
					["bm_wp_wpn_fps_upg_hd2_1_5x_scope_r72"] = "Трубчатый коллиматор (1.5х)",
					["bm_wp_reflex2_desc"] = "Стандартный прицел большинства видов оружия. Обеспечивает хорошее и точное прицеливание.",
					["bm_wp_wpn_fps_upg_hd2_alt_1x_scope_r72"] = "Коллиматорный прицел",
					["bm_wp_wpn_fps_upg_hd2_1x_scope_r72"] = "Коллиматорный прицел МК2",
					["bm_wp_wpn_fps_upg_hd2_holo_sight_r72"] = "Голографический прицел",

					["bm_wp_wpn_fps_ass_r72_m_ext"] = "Увеличенный магазин",
					["bm_wp_r72_ext_desc"] = "Тип магазина, популярный у военных Супер-Земли, которым непрерывный огонь важнее управляемости.",

                    -- AR/GL-21 One-Two
					["bm_w_glar21"] = "Двоечка",
					["bm_w_glar21_desc"] = "Штурмовая винтовка, оснащенная гранатометом. Универсальное, но тяжелое оружие.",

                    -- LAS-5 Scythe
					["bm_w_las5"] = "Коса",
					["bm_w_las5_desc"] = "Лазерная винтовка, стреляющая непрерывным лучом. Не требует перезарядки, но в случае перегрева нужно заменить радиатор.",

					["bm_wp_wpn_fps_scythe_m_heatsink_highcap"] = "Высокоемкий радиатор",
					["bm_wp_highcap_desc"] = "Более крупный радиатор, способный вместить больше тепла.",
					["bm_wp_wpn_fps_scythe_m_heatsink_highdiss"] = "Высокоэффективный радиатор",
					["bm_wp_highdiss_desc"] = "Радиатор с более тонкими охлаждающими элементами, что повышает эффективность его работы.",

                    -- LAS-58 Talon
					["bm_w_las58"] = "Коготь",
					["bm_w_las58_desc"] = "Точный и мощный лазерный револьвер с особым переломным затвором, позволяющим иметь радиаторы.",

					["bm_wp_wpn_fps_pis_las58_cowboy_hold"] = "Одно-рукий стиль удержания",
					["bm_wp_cowboy_hold_desc"] = "Косметическая модификация: Меняет удержание оружия на более ''ковбойский'' одно-рукий стиль. Включает в себя много крутизны для максимальной Демократии.",

					["bm_wp_wpn_fps_upg_hd2_1x_pistol_scope_default"] = "Пистолетный коллиматор",
					["bm_wp_1x_pistol_scope_desc"] = "Прицел с тонкими элементами, обеспечивающий максимальную видимость цели.",

					["bm_menu_weapon_hold"] = "Стиль удержания",
					["bm_menu_weapon_hold_plural"] = "Стили удержания",

                    -- P-4 Senator
					["bm_w_senator"] = "Сенатор",
					["bm_w_senator_desc"] = "Мощный револьвер, который можно перезаряжать по одному патрону. Надежное оружие, наносящее большой урон.",

					["bm_w_x_senator"] = "Парные Сенаторы",
					["bm_w_x_senator_desc"] = "Личная разработка Генерала Браша. Так можно только ему, и его наследовательным 10-звездочным Генералам.",

					["bm_wp_wpn_fps_pis_senator_cowboy_hold"] = "Одно-рукий стиль удержания",

					["bm_wp_wpn_fps_pis_p4_flashlight"] = "Фонарик",
					["bm_wp_p4_flashlight_desc"] = "Простой, компактный фонарик, обеспечивающий видимость ночью и в темноте.",

                    -- Konstantinov SA-1
					["bm_w_sa1"] = "Константинов СА-1",
					["bm_w_sa1_desc"] = "Спроектирован как ''инвертированный булл-пап, где пистолетная рукоятка расположена поверх ствола. Дизайн был признан слишком не удобным и радикальным, так что он эволюционировал в более обыкновенное оружие - СА-001.",

					["bm_wp_wpn_fps_ass_sa1_b_short"] = "Ствол для CQB",

					["bm_wp_wpn_fps_ass_sa1_m_low"] = "Магазин ИЖМАЖ на 20 патронов",
					["bm_wp_wpn_fps_ass_sa1_m_quick"] = "Стандартный магазин с магпулом",

                    -- KSG-25 Barrel
					["bm_wp_wpn_fps_sho_ksg_b_25"] = "Ствол KSG-25",

                    --

					["menu_l_global_value_helldivers2rr_mod"] = "Это предмет из Helldivers 2 - Полк [Вырезано]!",
					["menu_l_global_value_helldivers2pc_mod"] = "Это предмет из Helldivers 2 - Питоны-Коммандос!",
					["menu_l_global_value_helldivers2bj_mod"] = "Это предмет из Helldivers 2 - Пограничное Правосудие!",


		--Kobus 90--
		["bm_p90_sc_desc"] = "ПП по схеме буллпап. Конкурент ПП 'SpecOps-7'. Ее часто называют футуристической космической пушкой.\n\n#{skill_color}#Наносит 75% урона через броню.##",
		["bm_wp_p90_body_p90_tan"] = "Бежевый приклад",
		["bm_wp_90_body_boxy"] = "Приклад OMNIA",
		["bm_wp_90_body_boxy_desc"] = "Найденный на заброшенном складе корпорации OMNIA, этот корпус совершенно не влияет на функционал или удобность оружия, но его квадратный дизайн приятен глазу.",
		--Spec Ops
		["bm_mp7_sc_desc"] = "Легкий ПП. Конкурент ПП Project-90. Оказывается, у него нет подствольного гранатомета.\n\n#{skill_color}#Наносит 75% урона через броню.##",
	    --Tec-9
		["bm_tec9_sc_desc"] = "Классический, недорогой и скорострельный ПП, надежность которого была продемонстрирована различными бандами и картелями юго-восточных Штатов.",
		--Heather
		["bm_sr2_sc_desc"] = "Разработанный под специализированный калибр 9×21мм, ''Пихта'' - российский аналог Проджект-90 и СпекОпс-7.\n\n#{skill_color}#Наносит 75% урона через броню.##",
		--Cobra/Skorpion
		["bm_wp_scorpion_m_extended"] = "Двойные магазины",
		--Compact-5/MP5
		["bm_mp5_sc_desc"] = "Младшая сестра Гевер-3.\nСкорострельная, точная и удобная, что еще можно желать от ПП?",
		--Swedish K
		--["bm_w_m45"] = "Карл M-45",
		--Pachett/Sterling
		["bm_wp_sterling_b_e11"] = "Глушитель Бластер-11",
		["bm_wp_sterling_b_e11_desc_sc"] = "#{skill_color}#Технология из далекой галактики.## Оружие будет стрелять #{risk}#плазменными болтами## и #{skill_color}#автоматически заряжаться.##\n\nВремя зарядки: #{skill_color}#1 сек.##\nСкорость зарядки: #{skill_color}#6/сек## #{important_1}#(На 50% медленнее при перегреве)##\nПерегрев: #{important_1}#2 сек.##",
		--Uzi
		["bm_uzi_sc_desc"] = "Несмотря на скорострельность, Узи - надежный и простой в обращении ПП, а переделка под калибр .41 AE прибавляет ему мощности.",
		--Chicago Typewriter
		["bm_thompson_sc_desc"] = "Снабженный барабанным магазином, этот ПП позволяет вспомнить деньки мафии, пока вы расстреливаете толпы врагов.",
		--Mark 10
		--["bm_w_mac10"] = "Марк 10",
		--["bm_w_x_mac10"] = "Парные Марк 10",
		--MP40
		["bm_erma_sc_desc"] = "Весьма надежный ПП, популярный у пехоты Второй мировой. Главное не использовать магазин как рукоять.",

		--Jackal
		--["bm_w_schakal"] = "Шакал",
		--Kross Vertex
		--["bm_w_polymer"] = "Кросс Вертекс",
		--CUSTOM SMGs
			--AR57
			["bm_w_alpha57_prim_desc"] = "Этот автомат жертвует дальнобойностью и мощностью ради большого запаса патронов и улучшенной стабильности.\n\n#{skill_color}#Наносит 75% урона через броню.##",
			--LWRC
			["bm_w_smg45_desc"] = "Американский клон ПП 'Шакал'.",
			--Typhoon
			["bm_w_crysis3_typhoon_desc"] = "\"Самая чистая форма самовыражения - и сейчас мне есть что сказать.\"\n\nЭтот десятиствольный пистолет-пулемет использует особую технологию зарядки, которая позволяет добиться чрезвычайно высокой скорости стрельбы за счет низкого урона.\n\nАльтернативный огонь выстреливает #{skill_color}#залп## из #{skill_color}#10## патронов разом.",
			--AR57
			["bm_w_fang45_desc"] = "Эффективное оружие для столкновений на короткой и средней дистанции.\n\n#{skill_color}#Увеличенная скорострельность для первых 5-ти выстрелов. Перезарядка оружия обновляет эффект.##",
			--KSP 45
			["bm_w_ksp45_desc_sc"] = "Пистолет-пулемет стреляющий очередями по 3 патрона. Подходит для средних дистанций. Менее эффективен на дальней дистанции из-за разброса пуль.",
			--LC10
			["bm_w_lc10_desc_sc"] = "Автоматический пистолет-пулемет. Неплохая точность и скорострельность.",
            --BO6 Grendel R31
		    ["bm_w_r31_desc"] = "Полуавтоматический карабин, стреляющий калибром .22 Winchester Magnum. Произведен компанией ''Grendel Inc.''",

	        ["bm_wp_wpn_fps_smg_r31_b_highcal"] = "Ствол CHF I",
	        ["bm_wp_wpn_fps_smg_r31_b_highcal2"] = "Ствол CHF II",
	        ["bm_wp_wpn_fps_smg_r31_b_int"] = "Короткий Ствол",
	        ["bm_wp_wpn_fps_smg_r31_b_mix"] = "Закаленный Ствол",
	        ["bm_wp_wpn_fps_smg_r31_b_range"] = "Длинный Ствол",
	        ["bm_wp_wpn_fps_smg_r31_b_velocity"] = "Усиленный Ствол",

	        ["bm_wp_wpn_fps_smg_r31_g_mix"] = "Рукоять Коммандо",
	        ["bm_wp_wpn_fps_smg_r31_g_quickdraw"] = "Быстрорукая Рукоять",
	        ["bm_wp_wpn_fps_smg_r31_g_sprintout"] = "Эргономичная Рукоять",
	        ["bm_wp_wpn_fps_smg_r31_g_sprintout2"] = "Рукоять для CQB",

	        ["bm_wp_wpn_fps_smg_r31_m_extclip"] = "Увеличенный Магазин I",
	        ["bm_wp_wpn_fps_smg_r31_m_extclip2"] = "Увеличенный Магазин II",
	        ["bm_wp_wpn_fps_smg_r31_m_fastreload"] = "Флип-Магазин",
	        ["bm_wp_wpn_fps_smg_r31_m_fastreload2"] = "Быстросъемный Магазин I",

	        ["bm_wp_wpn_fps_smg_r31_s_adsmove"] = "Приклад Инфильтратора",
	        ["bm_wp_wpn_fps_smg_r31_s_flinch"] = "Тяжелый Приклад",
	        ["bm_wp_wpn_fps_smg_r31_s_mix"] = "Сбалансированный Приклад",
	        ["bm_wp_wpn_fps_smg_r31_s_mix2"] = "Боевой Приклад",
	        ["bm_wp_wpn_fps_smg_r31_s_hipfiremove"] = "Без Приклада/Убрать Приклад",

			--SBR .45
			["bm_w_ar45_desc"] = "Пистолет-пулемет, созданный на платформе CAR-4 и принимаюший магазины от STRYK. Для экономных грабителей самое то.",
			--Jackal PDW
			["bm_w_geasy9_desc"] = "Мощный ПП, известный своей компакностью и высокой скорострельностью, что делает его лучшим выбором на ближней дистанции",
		--Bootleg/HK416c
		["bm_w_tecci_desc_sc"] = "Винтовка с возвратной пружиной, переделанная под пулемет.",
		--KSP/M249
		["bm_m249_sc_desc"] = "Перезаряжать эту вещь трудно, но скорее всего к моменту перезарядки все уже будут мертвы.",
		--ChainSAW
		["bm_kacchainsaw_sc_desc"] = "Roaming frothing madness in a machine gun.\n\n#{skill_color}#Лучше стрелять от бедра.##",
		["bm_wp_upg_i_kacchainsaw_adverse"] = "Прямой отвод",
		--RPK
		["bm_rpk_sc_desc"] = "Отличный выбор, если любите точные (и восточные) пулеметы.",
		--Brenner 21/HK21
		["bm_hk21_sc_desc"] = "Большая младшая сестра винтовки Гевер-3. Увеличенная скорострельность отлично подходит для подавляющего огня.",
		--HCAR
		["bm_hcar_sc_desc"] = "Современная версия классического автомата Второй мировой.",
		--M60
		["bm_m60_sc_desc"] = "Так называемая 'Свинка' - тяжелая и пожирающая патроны. Вблизи никому не выжить.",
		--Ksp 58
		["bm_par_sc_desc"] = "Более тяжелый родственник КСП-90, который обычно ставят на технику. Меньше мобильность, больше пуля.",
		--Buzzsaw/Mg42
		--я рестор тут перевожу или аниме? - Вавло
		["bm_wolf_brigade_sc_desc"] = "\"Мы не люди, замаскированные под собак.\nМы - #{important_1}#волки,## замаскированные под людей.\"\n\n#{skill_color}#Лучше стрелять от бедра.##",
		["bm_wp_mg42_b_vg38"] = "Насадка Бластер-19",
		["bm_wp_mg42_b_vg38_desc_sc"] = "#{skill_color}#Технология из далекой галактики.## Оружие будет стрелять #{risk}#плазменными болтами## и #{skill_color}#автоматически заряжаться.##\n\nВремя зарядки: #{skill_color}#2 сек.##\nСкорость зарядки: #{skill_color}#9/сек## #{important_1}#(На 50% медленнее при перегреве)##\nПерегрев: #{important_1}#4 сек.##",
		--["bm_wp_mg42_b_mg34_desc_sc"] = "Slows your rate of fire to 800 RPM",
		--Versteckt-51/HK51B
		["bm_hk51b_sc_desc"] = "Подпольная модификация Бреннера, которая уменьшает его до размеров Компакт-5.",
		["bm_wp_hk51b_magazine_belt_60"] = "Лента на 60 патронов",
		["bm_wp_hk51b_magazine_belt_80"] = "Лента на 80 патронов",
		--M134
		["bm_m134_sc_desc"] = "\"У пути, по которому ты идешь, нет конца. Каждый свой шаг ты выстилаешь трупами своих врагов...\"\n\n#{risk}#Раскручивается перед стрельбой, прицеливание продолжает раскрутку.\nТеряет точность при стрельбе от бедра.##",
		--Microgun
		["bm_shuno_sc_desc"] = "\"This is your road. When you come, you'll walk it alone.\"\n\n#{risk}#Раскручивается перед стрельбой, прицеливание продолжает раскрутку.\nТеряет точность при стрельбе от бедра.##",
		--Custom MGs
			--Madsen MG
		["bm_wp_wpn_fps_lmg_madsen_mg_xmag"] = "Магазин на 40 патронов",
			--Stoner 63 (LMG)
		["bm_wp_wpn_fps_lmg_stoner63a_quickdraw_01"] = "Speed Tape",
		["bm_wp_wpn_fps_lmg_stoner63a_mixhandle_01"] = "Dropshot Wrap",
		["bm_wp_wpn_fps_lmg_stoner63a_handle_01"] = "Field Tape",
		["bm_wp_wpn_fps_lmg_stoner63a_handle_02"] = "SASR Jungle Grip",
		["bm_wp_wpn_fps_lmg_stoner63a_quickdraw_02"] = "Serpent Wrap",
		["bm_wp_wpn_fps_lmg_stoner63a_mixhandle_02"] = "Airborne Elastic Wrap",
		["bm_wp_wpn_fps_lmg_stoner63a_magazine_ext_01"] = "100 Rnd",
		["bm_wp_wpn_fps_lmg_stoner63a_magazine_ext_02"] = "STANAG 125 Rnd",
		["bm_wp_wpn_fps_lmg_stoner63a_magazine_fast_01"] = "Fast Mag",
		["bm_wp_wpn_fps_lmg_stoner63a_magazine_fast_02"] = "Vandal Speed Loader",
			--TF2 Minigun
		["bm_wp_wpn_fps_lmg_sasha_body_desc"] = "",
		["bm_wp_wpn_fps_lmg_iron_curtain_body_desc"] = "",
		["bm_wp_wpn_fps_lmg_tomislav_body_desc"] = "#{skill_color}#Раскручивается на 20% быстрее.##",
		["bm_wp_wpn_fps_lmg_natascha_body_desc"] = "#{skill_color}#Попадания по противникам на расстоянии не более 9.75 метров сбивают их с ног.##\n\n#{important_1}#Раскручивается на 30% медленнее.##",
		["bm_wp_wpn_fps_lmg_gatling_gun_body_desc"] = "#{important_1}#Раскручивается на 50% медленнее.##",
		["bm_wp_wpn_fps_lmg_canton_body_desc"] = "#{skill_color}#80% шанс при попадании по врагу поджечь его, нанося## #{heat_warm_color}#60## #{skill_color}#урона в течение 4 секунд.##\n#{risk}#Шанс уменьшается с расстоянием.\nНаносит огненный урон.##",

		-- PAYDAY 3 Blyspruta MX63
		["bm_w_mx63_desc"] = "Настоящая машина смерти.\nКстати, название переводится со шведского как ''Распылитель свинца''",

         --Grimm
		--["bm_w_basset"] = "Гримм 12",
		--Saiga
		["bm_saiga_sc_desc"] = "Полностью автоматический дробовик для дней, когда вам лень целиться.",
		--AA12
		["bm_aa12_sc_desc"] = "Автоматический дробовик с коробчатым магазином. Оставит бурю эмоций.",
		--Spas12
		["bm_spas12_sc_desc"] = "Тяжелая и сложная альтернатива полуавтоматическим дробовикам. Обладает альтернативным режимом стрельбы, будто созданный пришельцами.",
		--Benelli
		["bm_benelli_sc_desc"] = "Тактический дробовик премиум-класса. Для зачистки особенно шумных комнат.",
		--Argos III
		["bm_ultima_sc_desc"] = "Нет ничего современнее пластика и алюминия. Тут даже есть слот для подзарядки телефона.\n\nПерезаряжает по #{skill_color}#2## патрона за раз.",
		--Street Sweeper
		--["bm_w_striker"] = "Чистильщик",
		--Goliath
		--["bm_w_rota"] = "Голиаф 12",
		--VD-12
		--["bm_w_sko12"] = "ВД 12",
		--["bm_w_x_sko12"] = "Парные ВД 12",
		--GSPS
		--["bm_w_m37"] = "ДжиЭс 12",
		--Supernova
		["bm_supernova_sc_desc"] = "Дробовик-монстр, способный переключаться между помповым и полуавтоматическим режимами.",
		--Loco
		["bm_serbu_sc_desc"] = "Уменьшенная подпольная версия Рейнфилда 880 для любителей скрытности и сломанных запястий.",
		--Reinfeld 88
		["bm_menu_sc_m1897_desc"] = "Этот исторический артефакт повидал как грязные траншеи, так и жаркие джунгли. Известен тем, что им легко развязать пожар.",
		--Mosconi 12g
		["bm_menu_sc_m590_desc"] = "Улучшенная версия классического ружья. Подходит для полиции, армии, гражданских и грабителей.",
		--R870
		["bm_menu_sc_r870_desc"] = "Длинная рука закона и свободы. Свободы, которая вооружена дробовиком!",
		--KSG
		["bm_menu_sc_ksg_desc"] = "В будущем все сделано из пластика! Буллпап-дробовик сомнительного качества сборки, но никому это не мешает вооружать им легкую пехоту.",
		--Breaker 10g
		["bm_menu_sc_boot_desc"] = "Старое ружье, обладающее мощным десятым калибром и еще более мощной аурой мачо. Иди со мной, если хочешь жить.",
		--Claire Angélique Florette du Bertrand
		--["bm_w_coach"] = "Клэр 12",
		--Mosconi
		["bm_menu_sc_huntsman_desc"] = "Два ствола, двойное удовольствие. Конечно, два патрона это мало, но это не так важно, если они выпущены одновременно и в упор.",
		--Judge
		["bm_x_judge_sc_desc"] = "Наконец-то на одной сцене.",
		--Joceline
		["bm_b682_sc_desc"] = "Спортивная горизонталка, которая скоро будет состязаться в ограблении банков.",
		--Custom Shotguns
		--Doomstick
		["bm_wp_wpn_fps_upg_quadbarrel_ammo_buckshot_close_desc"] = "Дробь, эффективная вблизи.\n#{skill_color}#Количество дроби увеличено до 10.##",
		["bm_wp_wpn_fps_upg_quadbarrel_ammo_buckshot_med_desc"] = "Дробь, эффективная на средних дистанциях.\n#{important_1}#Количество дроби уменьшено до 6.##",
		["bm_wp_wpn_fps_upg_quadbarrel_ammo_slug_desc"] = "Мощная стальная пуля, эффективная на дальних дистанциях.\nМожет пробивать#{skill_color}#броню, врагов, щиты, титановые щиты и стены.##",
		--MP153
		--["bm_w_mp153"] = "Аргос 1",

		-- TOZ-81 MARS
		  ["bm_w_toz81"] = "ТОЗ-81 МАРС",
		  ["bm_w_toz81_desc"] = "Прототип специального револьвера двойного действия, предназначеного для использования космонавтами, охотниками и геологами. Идея, конечно, была обещающей, но из-за неизвестных причин, ТОЗ-81 был отменен. Только один экземпляр был официально создан.",

		  ["bm_w_x_toz81"] = "Парные ТОЗ-81 МАРС",
		  ["bm_w_x_toz81_desc"] = "Да, только один экземпляр этого специального револьвера двойного действия был официально создан.\nНо для Гау Фонга это не проблема.\nПросто... не пытайся лететь в космос с ними, хорошо?",
        -- PAYDAY 3 FSA-12G

          ["bm_w_fsa12_desc"] = "Этот дробовик плюется свинцом так быстро, как может позволить твой палец на спусковом крючке. Зрелищный и идеальный вариант среди всех дробовиков для зачистки комнат от полицейской пакости.",

		-- PAYDAY 3 M7 Pursuivant
          ["bm_w_bp12_desc"] = "Компактный, точный и убойный дробовик, #{skill_color}#выпускает три заряда менее чем за секунду##. Не могу ничего сказать насчет его надежности и безопасности. Ох уж эти Турки...",

                -- PAYDAY 3 ORIGIN-12
		  ["bm_w_or12_desc"] = "Мощный, быстрый, и смертельный. Легко рвет все как бумагу. Смотри только, чтоб руки не оторвало.",

                -- MW2023 ORIGIN-12
		  ["bm_w_haymaker"] = "Авто-дробовик ORIGIN-12 (MW2023)",
		  ["bm_w_haymaker_desc"] = "Очень эффективный на близкой дистанции, этот боевой дробовик - хороший выбор, чтобы остановить стоящих между тобой и твоей добычей.",

                -- MW2023 Omni .410
		  ["bm_w_riveter_desc"] = "Быстрый авто-дробовик, сделанный на основе ресивера модели AR-15. Пробивает дыры в стенах также легко, как и дыры в головах законопослушников.",

		--REBECCA CYBERPUNK
		["bm_w_rebecca_desc"] = "С помощью этого можно превратить все в кровавое месиво, хоть оружие порой ведет себя непредсказуемо.\n#{risk}#Выстрелы отбрасывают Вас назад и выбивают из режима прицеливания.##",
		--S552
		["bm_s552_sc_desc"] = "Элегантный выбор для любителей компактных винтовок под 5.56, ее предпочитает МНБ. Использует специальный швейцарский калибр 5.6мм для увеличенной дальнобойности.",
		--M733/AMCAR
		["bm_amcar_sc_desc"] = "Самая распространенная винтовка под .223. Подойдет для любых целей.",
		["bm_wp_upg_i_patriot"] = "Патриот",
		["bm_wp_upg_i_patriot_desc"] = "Штурмовой пистолет, созданный для #{important_1}#[ЗАСЕКРЕЧЕНО]##.\n\nМеханизм подачи внутри барабанного магазина напоминает #{important_1}#[ЗАСЕКРЕЧЕНО]##.",
		["bm_wp_upg_i_og_rof"] = "Ограничитель скорострельности",
		["bm_wp_upg_i_og_rof_desc"] = "Восстанавливает абсурдно низкую скорострельность, если вы так сильно  хотите...",
		--G36
		["bm_g36_sc_desc"] = "Еще один претендент на звание 'лучшей пластиковой винтовки'.",
		["bm_wp_upg_i_m8a1"] = "Набор М8",
		["bm_wp_upg_i_m8a1_desc"] = "Оружие будет стрелять только #{risk}#очередями по 4##, взамен увеличивая скорость стрельбы и размер магазина",
		--VHS/Lion's Roar
		["bm_vhs_sc_desc"] = "Тяжелая в пользовании винтовка, способная на впечатляющий результат в руках умельца.\n\nВозможно, в ней боевой дух Драгана.",
		["bm_wp_upg_i_swordfish"] = "Набор 'Рыба-меч'",
		["bm_wp_upg_i_swordfish_desc"] = "Оружие будет стрелять только #{risk}#очередями по 5##, взамен увеличивая скорость стрельбы и размер магазин",
		--Olympic/Para
		["bm_menu_sc_olympic_desc"] = "Чудовищный пистолет-переросток, стреляющий винтовочными патронами в автоматическом режиме. Экзистенциальный кризис, из которого можно стрелять.",
		--TAR-21/Para
		["bm_menu_sc_komodo_desc"] = "Мощь в крайне компактной упаковке. Хорошо показывает себя и вблизи, и на расстоянии.",
		--Famas
		["bm_menu_sc_famas_desc"] = "Уменьшенный магазин взамен на точность и скорострельность. Подойдет, чтобы отстрелить яблоко с чьей-нибудь головы.",
        --OICW--
		["bm_w_osipr_desc_pc"] = "Военная технология нового поколения. Снаряжен #{skill_color}#20мм гранатометом.##\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на гранатомет.",
		["bm_w_osipr_desc"] = "Военная технология нового поколения. Снаряжен #{skill_color}#20мм гранатометом.##\nУдерживайте #{skill_color}#$BTN_BIPOD## чтобы переключиться на гранатомет.",
		--M4/CAR-4
		["bm_m4_sc_desc"] = "Удобная, компактная, смертоносная. Популярная у современных армий винтовка под калибр 5.56.",
		["bm_wp_upg_fg_m4a1"] = "Набор 'Эмка'",
		["bm_wp_upg_fg_m4a1_desc"] = "Этот набор меняет прицелы с черного рынка на более традиционные. #{risk}#Перекрывает внешний вид ручки.##",
		["bm_wp_upg_s_fixed"] = "Фиксированный приклад",
		--AK5
		["bm_ak5_sc_desc"] = "Отличная винтовка, знаменитая использованием для ограблений банков, а также тем, что все путают, чем она стреляет.",
		["fnc_burst_desc"] = "Добавлять стрельбу очередями по три.",
		--Union 5.56
		["bm_corgi_sc_desc"] = "Несмотря на внешний вид, поплавать на этой винтовке не получится.",
        ["bm_wp_corgi_b_short"] = "Ствол MSG",
		--UAR
		["bm_aug_sc_desc"] = "Классический буллпап. Сделает решето из любого плохого парня.",
		["bm_wp_upg_b_hbar"] = "Тяжелый ствол",
		--AK17
		["bm_flint_sc_desc"] = "Современная версия классического АК. #{skill_color}#Умеет стрелять очередями по 2## и обладает кризисом личности.",
		--AK 5.45
		["bm_ak74_sc_desc"] = "Обладающая меньшим калибром, чем ее сестра под 7.62, эта винтовка не менее опасна.",
		--CR 805
		["bm_menu_sc_hajk_desc"] = "Молодой и современный кузен ПП Cobra. Поддерживает разные режимы стрельбы и конверсии под другие калибры. (Нет в наличии)",
		--AMR-16
		["bm_m16_sc_desc"] = "Классическая винтовка - предок CAR-4. Ее трудно спрятать, но зато она дальнобойная и мощная.",
		--Queen's Wrath
		["bm_l85a2_sc_desc"] = "Хоть ее репутация и была подпорчена ранними версиями, она является одной из самых точных винтовок в мире.\n\nНо она остается эргономическим кошмаром.",
		--AK 7.62
		["bm_akm_sc_desc"] = "Отличный выбор против возрастающей популярности брони в Вашингтоне.\n\nВыбор повстанцев и радикальных режимов всего мира.",
		["bm_akm_gold_sc_desc"] = "Что общего у грабителя, мексиканского наркобарона и диктатора? Любовь к позолоченным винтовкам, конечно же.",
		--Сталкер, вали отсюда--
		--Мы кого попало не пропускаем--
		--ты че
		--бычара????
		--Ех, вотева
		["bm_groza_sc_desc_pc"] = "Буллпап-родственник АК, любящий взрывы.\n\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		["bm_groza_sc_desc"] = "Буллпап-родственник АК, любящий взрывы.\n\nУдерживайте #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		--CHIKUBI
		["bm_wp_tkb_m_bakelite"] = "Сибирский магазин 15x3",
		--Krinkov
		["bm_akmsu_sc_desc"] = "Маленькая винтовка против больших людей. Подойдет для любого случая.",
		--Akimbo Krinkov
		["bm_x_akmsu_sc_desc"] = "Маленькие винтовки против больших людей. Подойдут для любого случая.",

		--CUSTOM ARs
			--QBZ-191
			["bm_qbz191_sc_desc"] = "Китайская штурмовая винтовка нового поколения, использующая калибр 5,8х42 мм.\n\n#{skill_color}#Наносит 25% урона через броню.##",
			--AN-94/92
			["bm_tilt_sc_desc"] = "#{risk}#Первые два выстрела## каждого нажатия на курок обладают #{skill_color}#тройной скорострельностью.##",
			--NV4

                        -- BO6 CETME Model L
		          ["bm_w_modl_desc"] = "Автоматическая винтовка. Стреляет медленно, но прямо. Наносит приемлемый урон.",

		          ["bm_wp_wpn_fps_ass_modl_b_1"] = "Короткий Ствол",
		          ["bm_wp_wpn_fps_ass_modl_b_2"] = "Ствол DHF",
		          ["bm_wp_wpn_fps_ass_modl_b_3"] = "Закаленный Ствол",
		          ["bm_wp_wpn_fps_ass_modl_b_4"] = "Длинный Ствол",

		          ["bm_wp_wpn_fps_ass_modl_m_2"] = "Удлиненный Магазин I",
		          ["bm_wp_wpn_fps_ass_modl_m_3"] = "Удлиненный Магазин II",
		          ["bm_wp_wpn_fps_ass_modl_m_4"] = "Быстрый Магазин I",
		          ["bm_wp_wpn_fps_ass_modl_m_5"] = "Флип-Магазин",

		          ["bm_wp_wpn_fps_ass_modl_g_2"] = "Рукоять ''Коммандо''",
		          ["bm_wp_wpn_fps_ass_modl_g_3"] = "Рукоять ''Быстрорукая''",
		          ["bm_wp_wpn_fps_ass_modl_g_4"] = "Эргономичная Рукоять",
		          ["bm_wp_wpn_fps_ass_modl_g_5"] = "Штурмовая Рукоять",
		          ["bm_wp_wpn_fps_ass_modl_g_6"] = "Рукоять для CQB",

		          ["bm_wp_wpn_fps_ass_modl_s_2"] = "Приклад ''Инфильтратор''",
		          ["bm_wp_wpn_fps_ass_modl_s_3"] = "Тяжелый Приклад",
		          ["bm_wp_wpn_fps_ass_modl_s_4"] = "Легкий Приклад",
		          ["bm_wp_wpn_fps_ass_modl_s_5"] = "Сбалансированный Приклад",
		          ["bm_wp_wpn_fps_ass_modl_s_6"] = "Боевой Приклад",

		          ["menu_l_global_value_commissioned_mod"] = "Это заказанный мод от Hylie!",

                        -- MW2023 Beretta ARX 200
		          ["bm_w_soa_desc"] = "Сильная винтовка калибра 7.62. Бъет сильно, а также может стрелять на средней и дальней дистанции за счет медленного темпа огня и предсказуемой отдачи.", -- <- Стопэ, это точно не верный ID <- Упс. Мой косяк, сорян. - Hylie

		          ["bm_wp_wpn_fps_ass_soa_b_2"] = "Длинный Ствол Dozer-90",
		          ["bm_wp_wpn_fps_ass_soa_b_3"] = "Короткий Ствол Fervor 762",

		          ["bm_wp_wpn_fps_ass_soa_m_2"] = "Магазин на 30 Патронов 7.62x51",
		          ["bm_wp_wpn_fps_ass_soa_m_3"] = "Магазин-Барабан на 50 Патронов",

		          ["bm_wp_wpn_fps_ass_soa_s_2"] = "Тяжелый Приклад Motion-V2",
		          ["bm_wp_wpn_fps_ass_soa_s_3"] = "Точный Приклад STT-88",
		          ["bm_wp_wpn_fps_ass_soa_s_4"] = "Тяжелый и Точный Приклад ST-Motion V3",
		          ["bm_wp_wpn_fps_ass_soa_s_5"] = "Телескопический Приклад",

                        -- War Sport LVOA-C
		          ["bm_w_lvoac_desc"] = "Скорострельная винтовка с ультра-современным внешним видом. Произведена компанией ''War Sport''",

                        -- Half-Life 2 OSIPR
		          ["bm_w_ar2_desc"] = "Также известна как AR2, эта винтовка снабжена темной энергией и произведена Комбайнами.\n...Ну ладно-ладно! Альянсом! Гребанная Бука...",

                        -- Fortnite Holo Twister
		          ["bm_w_holoar_desc"] = "Винтовка с встроенным прицелом. Имеет средний темп огня, хороший контроль, очень эффективна во многих боевых сценариях.\nНу че пацаны, куда дропаемся?",

                        -- PAYDAY 3 FIK-22 TLR
		          ["bm_w_fik22_desc"] = "По силе эта винтовка конечно не ахти, но калашматит она быстро, да и много.",

		          ["bm_wp_wpn_fps_ass_fik22_mag_ext"] = "Длинный Магазин (30 патронов)",
		          ["bm_wp_wpn_fps_ass_fik22_mag_quick"] = "Быстросъемный Магазин",
		          ["bm_wp_wpn_fps_ass_fik22_mag_short"] = "Короткий Магазин (15 патронов)",

		          ["bm_wp_wpn_fps_ass_fik22_barrel_long"] = "Дальнобойный Ствол",
		          ["bm_wp_wpn_fps_ass_fik22_barrel_short"] = "Ствол для CQC",

		          ["menu_l_global_value_hylie_pd3_mod"] = "Это предмет из PAYDAY 3 от Hylie!",

                        -- S.T.A.L.K.E.R. 2 Gauss Gun
		          ["bm_w_gauss_gun"] = "Гаусс-Пушка",
		          ["bm_w_gauss_gun_desc"] = "Снайперская винтовка, использующая для разгона пули систему электромагнитов. Была разработана и используется исключительно внутри Зоны.\nНо в каждом правиле есть исключение, особенно здесь. \n\n#{skill_color}#Может пробивать броню, нескольких врагов, щиты(включае Титановые) и тонкие стены.##",

		          ["bm_wp_wpn_fps_gauss_magazine_ext"] = "Увеличенный Магазин Гаусс",
		          ["bm_wp_gauss_extmag_desc"] = "Уникальный прототип улучшенного магазина для Гаусс-Пушки. Имеет намного больше запаса энергии, позволяя стрелять дольше, но взамен придется попрощаться с точностью из-за нестабильного потребления энергии.",

		          ["menu_l_global_value_stalker2_mod"] = "Это предмет из С.Т.А.Л.К.Е.Р. 2 - Сердце Чернобыля!",

			["bm_nova4_sc_desc"] = "Полностью автоматическая баллистическая винтовка. Восхитительная точность за счет уменьшенной скорострельности. Идеальна для перестрелок на средних и дальних дистанциях.",
			["bm_wp_wpn_fps_ass_nova4_flatline_desc"] = "#{skill_color}#Отсутствие штрафа на расстояние##, но #{important_1}#уменьшена скорострельность##.\n#{skill_color}#Увеличена точность##.",
			["bm_wp_wpn_fps_ass_nova4_chaos_desc"] = "#{skill_color}#Увеличена скорострельность от бедра##, #{important_1}#уменьшена скорострельность в прицеливании##.\n#{skill_color}#Уменьшена кучность от бедра##.",
			--VMP Honey Badger
			--["bm_w_bdgr_desc"] = "",
			--MW22 Honey Badger
			["bm_w_mcbravo_desc"] = "#{skill_color}#Встроенный глушитель## и дозвуковые патроны #{risk}#.300 BLK## делают Химеру идеальной для близких дистанций.",
			--BOCW CARV2
			["bm_wp_upg_i_g11"] = "Система К1",
			["bm_wp_upg_i_g11_desc"] = "Увеличивает скорострельность стрельбы очередью до #{skill_color}#2100## и #{skill_color}#дает возможность менять режим стрельбы.##",
			--AR-18
			--["bm_w_ar18"] = "КАР-18",
			--ПРЕСВЯТАЯ ДЕМОКРАТИЯ !!! HD2 AR-23 
			["bm_w_ar23"] ="Освободитель",
			["bm_w_ar23_desc"] = "Стандартная штурмовая винтовка ВССЗ, обладающая сбалансированными мощью, скорострельностью и весом, чтобы надежно поражать небольшие цели.",
			["bm_wp_wpn_fps_ass_ar23_ck_carbine"] = "Набор АР-23А ''Карабин''",
			["bm_wp_ck_carbine_desc"] = "Компактная версия ''Освободителя'', отличающаяся повышенной эффективностью на ближней дистанции. Скорострельность повышенна за счет увеличения разброса.#",
			["bm_wp_wpn_fps_ass_ar23_ck_penetrator"] = "Набор АР-23Р ''Пробойный''",
			["bm_wp_ck_penetrator_desc"] = "Модифицированная версия ''Освободителя'', оснащенная прицелом и #{skill_color}#бронебойными боеприпасами##, способными уничтожать бронированные цели.",
			["bm_wp_wpn_fps_ass_ar23_ck_concussive"] = "Набор АР-23С ''Сотрясающий''",
			["bm_wp_ck_concussive_desc"] = "Модифицированная версия ''Освободителя'', стреляющая #{skill_color}#контузящими боеприпасами.##\n#{skill_color}#Оглушающие пули сбивают врагов с ног на расстоянии до 20 метров.##\n#{risk}#Эффект сбивания с ног нельзя модифицировать и огонь очередями удален.##",
			["menu_l_global_value_helldivers2_mod"] = "Это предмет из Helldivers 2 - Адские Десантники, в бой!",
			["menu_l_global_value_helldivers2sv_mod"] = "Это предмет из Helldivers 2 - Закаленные Ветераны!",
			["menu_l_global_value_helldivers2vc_mod"] = "Это предмет из Helldivers 2 - Змеи-Коммандос!",
			--LAS 16 Sickle
			    ["bm_w_sickle"] = "Серп",
	            ["bm_w_sickle_desc"] = "Лазерная винтовка, стреляющая короткими очередями. Не требует перезарядки, но в случае перегрева нужно заменить радиатор.",
			--StA-52 Assault Rifle
			["bm_w_sta52"] = "СтА-52",
	        ["bm_w_sta52_desc"] = "Штурмовая винтовка с вместительным барабанным магазином.\nХорошо подходит для ведения непрерывного огня.\nПроизведено ''Оружием Шталя''.",
			--AR-32 Pacifier
            ["bm_w_ar32"] = "Усмиритель",
            ["bm_w_ar32_desc"] = "Штурмовая винтовка с большим магазином, стреляющая гуманными оглушающими боеприпасами. #{risk}#Сообщения о смертельных исходах были достоверно опровергнуты.##\n#{skill_color}#Пробивает броню## и сбивает врагов с ног.\n#{skill_color}#Оглушение сбивает врагов с ног на расстоянии до 30 метров.##\n#{risk}#Эффект сбивания с ног нельзя модифицировать.##",

			["bm_wp_wpn_fps_ass_ar32_ammo_lethal"] = "Боевые боеприпасы",
			["bm_wp_lethalammo_desc"] = "Если на то пошло, и преступник продолжает сопротивляться... Копам всегда можно использовать смертельную силу. Даже если эта сила исходит из оглушающей пукалки...\n#{skill_color}#Увеличивает урон на 25%, позволяет оружию наносить критический урон,## но #{risk}#режет подбор патронов и общий боезапас на пополам. Патроны-то дорогие, как знаешь.##",

			["menu_l_global_value_forceoflaw_mod"] = "Это предмет из Helldivers 2 - Сила Закона!",

		--Galant--
		["bm_galant_sc_desc"] = "Классическая винтовка времен Второй мировой. Надежная, точная и  #{skill_color}#быстро перезаряжается при опустошении.##\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов и тонкие стены.##",
		--M308
		["bm_m14_sc_desc"] = "Довольно меткая винтовка, если следить за отдачей, особенно при автоматической стрельбе.\n\n#{skill_color}##{skill_color}#Наносит 50% урона через броню и может пробивать врагов и тонкие стены.####",
		--FAL
		["bm_fal_sc_desc"] = "Правая рука свободного мира. Ваш выбор, если нужно пробить тяжелую броню.\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##",
		["bm_fal_ap25_sc_desc"] = "Правая рука свободного мира. Ваш выбор, если нужно пробить тяжелую броню.\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов.##",
		--SCAR
		["bm_scar_sc_desc"] = "Боевая винтовка будущего. Совмещает удобность и урон, она стала популярной у морской пехоты и спецназа.\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##",
		["bm_scar_ap25_sc_desc"] = "Боевая винтовка будущего. Совмещает удобность и урон, она стала популярной у морской пехоты и спецназа.\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов.##",
		["bm_scarl_sc_desc"] = "Боевая винтовка будущего... или нет. Она заслужила популярность на гражданском рынке, а вот армия не увидела нужды в еще одной винтовке под 5.56.",
		--G3
		["bm_g3_sc_desc"] = "Старшая сестра Компакт-5 и Бреннера-21, не уступает по точности снайперским винтовкам.\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов.##",
		["bm_g3_ap25_sc_desc"] = "Старшая сестра Компакт-5 и Бреннера-21, не уступает по точности снайперским винтовкам.\n\n#{skill_color}#Наносит 75% урона через броню и может пробивать врагов.##",
		["bm_g3_sg1_sc_desc"] = "Старшая сестра Компакт-5 и Бреннера-21, не уступает по точности снайперским винтовкам.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
		--Little Friend
		["bm_m203_weapon_sc_desc_pc"] = "Старшая сестра личного АМР 16 Лица со шрамом.\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		["bm_m203_weapon_sc_desc"] = "Старшая сестра личного АМР 16 Лица со шрамом.\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##\nУдерживайте #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		--VMP
		["bm_m203_vmp_sc_desc_pc"] = "Копия \"Маленького дружка\" Лица со шрамом.\n\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		["bm_m203_vmp_sc_desc"] = "Копия \"Маленького дружка\" Лица со шрамом.\n\nУдерживайте #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		["bm_mesa_vmp_sc_desc_pc"] = "Интересный продукт из украденного груза OMNIA.\n\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		["bm_mesa_vmp_sc_desc"] = "Интересный продукт из украденного груза OMNIA.\n\nУдерживайте #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
		--ASS VAL
		["bm_asval_sc_desc"] = "Обычным людям нравятся обычные винтовки, но кто-то хочет чего-то особенного.\n\nОбладает #{skill_color}#встроенным глушителем##, #{skill_color}#наносит 25% урона через броню и может пробивать врагов.##",
		--Galil
		["bm_galil_sc_desc"] = "Копия финского дизайна, который был скопирован с классического АК. Имитация? Нет, дань уважения!\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##",
		["bm_galil_ap25_sc_desc"] = "Копия финского дизайна, который был скопирован с классического АК. Имитация? Нет, дань уважения!\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов.##",
		["bm_galil_556_sc_desc"] = "Копия финского дизайна, который был скопирован с классического АК. Имитация? Нет, дань уважения!",
		--KS12
		["bm_shak12_sc_desc"] = "Боевая винтовка по схеме буллпап с мощнейшим калибром 12.7x55мм. Дикая мощность в компактной упаковке.\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов и тонкие стены.##",
		["bm_shak12_sc_oden_desc"] = "Боевая винтовка по схеме буллпап с мощнейшим калибром 12.7x55мм. Дикая мощность в компактной упаковке.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
		--ShAK-12
		["bm_wp_shak12_body_vks"] = "Выхлопной приклад",
		["bm_wp_shak12_body_vks_ap_desc"] = "Предоставляет еще более мощный калибр, который позволяет #{skill_color}#пробивать броню и щиты.## Приклад и затвор укреплены тяжелым материалом, что #{important_1}#уменьшает скорострельность.##",

            --Custom DMRs
			--MCX Spear
			["bm_mcx_spear_sc_desc"] = "#{skill_color}#Наносит 75% урона через броню.##",
			["bm_ngsierra_sc_desc"] = "Использует уникальную систему уменьшения отдачи для контроля его пластикового картриджа TCVM.\n\n#{skill_color}#Наносит 75% урона через броню и может пробивать врагов.##",
			--["bm_w_xeno"] = "MA14 Surge Rifle",
			["bm_xeno_sc_desc_pc"] = "\"Armat\" предлагает странную винтовку будущего. #{skill_color}#Интегрирован гранатомет.##\n\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на гранатомет.",
			["bm_xeno_sc_desc"] = "\"Armat\" предлагает странную винтовку будущего. #{skill_color}#Интегрирован гранатомет.##\n\nУдерживайте #{skill_color}#$BTN_BIPOD## чтобы переключиться на гранатомет",
			--VSS
			["bm_vss_sc_desc"] = "Вариант 'Валькирии' с превосходящими дальностью и точностью.\n\nОбладает #{skill_color}#встроенным глушителем## и #{skill_color}##{skill_color}#Наносит 50% урона через броню и может пробивать врагов и тонкие стены.####",
			--G3 HK79
			["bm_g3hk79_sc_desc_pc"] = "Вариация Гевер 3 с #{skill_color}#подствольным гранатометом.## #{skill_color}##{skill_color}#Наносит 50% урона через броню и может пробивать врагов и тонкие стены.####\n\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на гранатомет.",
			--BO3 XR2
			["bm_wp_xr2_handle_01_sc"] = "Полная автоматика",
			["bm_xr2_handle_01_sc_desc"] = "Позволяет  использовать #{skill_color}#полностью автоматический огонь##, взамен на #{important_1}#бонус за стрельбу очередями.##",
			["bm_wp_xr2_handle_02_sc"] = "Быстрые очереди",
			["bm_xr2_handle_02_sc_desc"] = "Увеличивает скорострельность до#{skill_color}#950##, но #{important_1}#увеличивает отдачу.\n\nНе влияет на одиночную стрельбу.##",
	        --SIERRA .458
			["bm_w_sierra458_sc_desc"] = "Собственная разработка Чейнса - мощная и скорострельная альтернатива винтовке 'Текки'.\n\n#{skill_color}#Наносит 50% урона через броню, может пробивать тонкие стены.##",
			["bm_w_sierra458_beo_desc"] = "Собственная разработка Чейнса - мощная и скорострельная альтернатива винтовке 'Текки'.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
			["bm_wp_wpn_fps_snp_sierra458_m_bush_desc"] = "Заменяет патроны .458 SOCOM на #{stats_positive}#ядовитые .450 Bushmaster## которые #{stats_positive}#наносят 30 урона в секунду и могут прерывать врагов.##\n\n#{important_1}#Теперь не может пробивать нескольких врагов.##",
			["bm_w_sierra458_ivy_desc"] = "Собственная разработка Чейнса - мощная и скорострельная альтернатива винтовке 'Текки'.\n\n#{skill_color}#Наносит 50% урона через броню, может пробивать тонкие стены## и #{stats_positive}#наносит периодический урон ядом.##",
			--BR 14 Adjudicator
			["bm_w_br14"] = "Эксперт",
			["bm_w_br14_desc"] = "Точная бронебойная винтовка БР-14 ''Эксперт'' обрушивает праведную справедливость на цели среднего размера, но небольшой магазин ограничивает ее эффективность против больших групп врагов.\n",
			--R-2 Amendment
	                ["bm_w_r2"] = "Поправка",
 	                ["bm_w_r2_desc"] = "Церемониальная полуавтоматическая винтовка со штыком. Можно установить режим трех выстрелов, чтобы было проще совершать оружейный салют в честь Павших Героев.\n",

			-- RAID WWII BAR Heavy Rifle
 	                  ["bm_w_m1918_desc"] = "Еще один ребенок Джона Браунинга. Большая и громоздкая вещь, наносящая большущий урон. Конечно, на один магазин только 20 патронов, но дружище, для таких ворошиловских стрелков, как ты, это не должно быть проблемой, ведь так?",

			-- Apex Legends G7 Scout
	                  ["bm_w_g7"] = "G7 Разведчик",
 	                  ["bm_w_g7_desc"] = "Наследник винтовок G2A4 и G2A5. Точная, мощная, сасная. Хорошо бъет по головам на дальней дистанции. Обновленный снайперский приклад отлично балансирует эффективность издалека и на средней дистанции.",


	        ["menu_l_global_value_ceremony_mod"] = "Это предмет из Helldivers 2 - Церемониймейстер!",
	        ["menu_l_global_value_fiery_hylie_mod"] = "Это ТОЧНО не мод от Hylie!",

        --MSR
		["bm_msr_sc_desc"] = "Стандартная винтовка армии США. Хорошие точность, удобность и скрытность делают ее винтовкой на любой случай.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		--R700
		["bm_r700_sc_desc"] = "Предок винтовки Раттлснейк. Хорошие точность и удобность, а еще превосходящая дальнобойность по сравнению с младшим братом. В чем подвох? Устаревшие магазины на пять патронов.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		--QBU88
		["bm_qbu88_sc_desc"] = "Буллпап-винтовка с востока. Подходит, чтобы нагнетать свою волю на окружающих.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
		--Winchester 1874
		["bm_winchester1874_sc_desc"] = "Винтовка, покорившая запад. Священная реликвия среди оружия, она до сих пор остается мощной благодаря своему калибру .44-40.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##\n\nМожет #{skill_color}#быстро стрелять## за счет #{important_1}#повышенной отдачи и пониженной дальнобойности.##",
		--TTI(TTY)
		["bm_tti_sc_desc"] = "Личное оружие Уика. Говорят, где-то в интернете можно найти видео, где он выполняет контракт с этой винтовкой.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
		--Icky Vicky
		--["bm_victor_sc_desc"] = "\n\n#{skill_color}#Can pierce body armor, enemies, shields and thin walls.##",
		--Scunt
		--["bm_scout_sc_desc"] = "\n\n#{skill_color}#Can pierce body armor, enemies, shields and thin walls.##",
		["bm_wp_scout_m_extended"] = "Магазин дуэлянта",
		--AWP
		["bm_awp_sc_desc"] = "Винтовка, известная дальнобойностью и точностью. Кто бы мог подумать, что ее собрали три энтузиаста в сарае?\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		["bm_awp_cs_dragon"] = "АВП | Драгон Лор",
		["bm_awp_cs"] = "АВП",
		["bm_wp_upg_bazooka"] = "Беспонтовый Слонобой",
		["bm_wp_upg_bazooka_desc"] = "Высокий риск - высокая награда. 'Слонобой' известен правилом 'один выстрел - одно убийство'.\n\n#{skill_color}#Позволяет пробивать титановые щиты.##\n\n#{risk}#После выстрела вы выходите из режима прицеливания.##",
		["bm_bazooka_sc_desc"] = "Высокий риск - высокая награда. 'Слонобой' известен правилом 'один выстрел - одно убийство'.\n\n#{skill_color}#Попадания в голову всем, кроме Капитанов и боссов, наносят на 50% больше урона.\n\n#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##\n\n#{risk}#После выстрела вы выходите из режима прицеливания.##",
        --WA2000
		["bm_wa2000_sc_desc"] = "Их существует всего несколько сотен. Винтовка для престижного хитмана.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
		--Rangerhitter
		["bm_sbl_sc_desc"] = "Рычажная винтовка двадцатого века, которая превосходит винтовки девятнадцатого века благодаря увеличенной пуле. Больше отдачи - больше смертоносности, когда на твоей стороне .45-70.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##\n\nМожет #{skill_color}#быстро стрелять## за счет #{important_1}#повышенной отдачи и пониженной дальнобойности.##",
		--Contender G2
		["bm_contender_sc_desc"] = "",
		--Model 70
		["bm_model70_sc_desc"] = "Ранняя болтовка, сделанная дизайнерами Репитера 1874.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		--SVD
		["bm_siltstone_sc_desc"] = "Мощная полуавтоматическая винтовка из семейства AK. Как и у других членов семьи, ее репутация проверена временем.\n\n#{skill_color}#Может пробивать броню, врагов, щиты (до начала падения урона) и тонкие стены.##",
		--Mosin--
		["bm_mosin_sc_desc"] = "Не хватает даже на еду, но нужен ствол? Подойдет эта классическая мощная винтовка со скользящим затвором.\n\nПерезаряжается обоймами по 5 патронов и #{skill_color}#может пробивать броню, врагов, щиты и тонкие стены.##",
		["bm_wp_upg_a_tranq_mosin"] = "Транквилизаторы",
		["bm_wp_upg_a_tranq_mosin_desc"] = "For true oblivion, The End.\n\n#{stats_positive}#Транквилизаторы## наносят #{skill_color}#30 урона/сек в течение 6 секунд и могут прерывать врагов.##\n\n#{important_1}#Теперь не может пробивать нескольких врагов.##",
		["bm_mosin_tranq_desc"] = "Не хватает даже на еду, но нужен ствол? Подойдет эта классическая мощная винтовка со скользящим затвором.\n\nПерезаряжается обоймами по 5 патронов,\n\n#{stats_positive}#наносит периодический урон транквилизаторами## и #{skill_color}#может пробивать броню, щиты и тонкие стены.##",
        --Desert Fox
		["bm_desertfox_sc_desc"] = "Компактная снайперская платформа, использовавшаяся Уиком при рейде на убежище русской мафии.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		--R93
		["bm_r93_sc_desc"] = "Немецкая винтовка с большой пулей, которая остановит больших людей. Популярная винтовка среди полиции и контр-террористических подразделений мира.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		--Flinklock
		["bm_bessy_sc_desc"] = "Хорошо организованная милиция необходима для безопасности свободного государства, и право людей хранить и носить оружие не должно нарушаться.\n\n#{skill_color}#Наносит на 100% больше урона специальным и элитным врагам.\nМожет пробивать нескольких врагов, их броню, щиты, титан-щиты и тонкие стены.##",
		--Thanatos--
		["bm_m95_sc_desc"] = "Крупнокалиберная винтовка, обычно используется против небольшой техники. Использовать ее против органических целей, вероятно, военное преступление.\n\n#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##",
		--Кастомные снайперки
			--Guerilla
			--["bm_w_sgs"] = "Партизан 553",
			--M107
			["bm_m107cq_sc_desc"] = "Не понравился Танатос? Морс .50 превращает врагов в красную пасту еще эффективнее.\n\n#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##",
			["bm_m200_sc_desc"] = "Для любителей 360 no-scope.\n\n#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##",
			--S7
			["bm_w_srs99_s7_desc"] = "I see headshots in your future, Spartan.\n\n#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##",
			["bm_w_srs99_s7_flexfire_desc"] = "I see headshots in your future, Spartan.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
			["flexfire_desc"] = "#{important_1}#Увеличение прицела будет равняться 3х\nНе может пробивать титановые щиты.##",
			["oracle_scope"] = "Прицел Oracle TechLink",
			["oracle_scope_desc"] = "Меняет точку прицела на #{skill_color}#Smart-Link##.\n#{risk}#Увеличение 5-10x.##",
			--R6 Deadeye
			["bm_w_r6"] = "Меткий Стрелок",
	        ["bm_w_r6_desc"] = "Мощная винтовка с рычажным затвором, позволяющим перезаряжать ее по одному патрону. Высокая точность подходит для боя на средней и дальней дистанции.\n",
		--SVD
		["bm_wp_wpn_fps_snp_svd_pso"] = "Оптический прицел СВ-7",
		--L115
		--["bm_w_l115"] = "АИМ 90",
		--Highly Modified CAR-4
		["bm_hmcar_sc_desc"] = "Когда полиция избавлялась от этого оружия, вы решили прибрать его к себе.\n\nСтреляет #{stat_maxed}#патронами титанового снайпера##, которые #{skill_color}#пробивают врагов, броню, щиты (до начала падения урона) и тонкие стены##. Альтернативный огонь выстреливает #{event_color}#снайперский патрон максимальной мощности##, который #{skill_color}#тратит в два раза больше патронов##, но #{skill_color}#наносит в два раза больше урона и пробивает титановые щиты.##",
		["bm_wp_hmcar_hd_kit"] = "Набор 32bit 8K HD",
		["bm_wp_hmcar_hd_kit_desc"] = "Application has crashed: C++ exception\nCould not load texture because IDirect3D9::CreateTexture call failed.\nDirect3D could not allocate sufficient memory to complete the call.\n\n\n\n\n\n\n ",
		--ONE OF A KIND HOLY GRAIL
		["bm_w_holygrail"] = "СРАНЬ ГОСПОДНЯ",
		["menu_l_global_value_holygrailmod"] = "ЭТО ЧТО ВООБЩЕ ТАКОЕ???\n\n",

		--Light Crossbow
		["bm_w_frankish_avelyn"] = "Авелин",
		["bm_wp_avelyn"] = "Набор Авелин",
		["bm_wp_avelyn_desc"] = "Превращает арбалет в #{skill_color}#репитер##.\nПозволяет запускать очередь из #{skill_color}#3## болтов одним нажатием.",
		["bm_wp_avelyn_override_desc"] = "Очень редкий экземпляр скорострельного арбалета.\nПоследовательно стреляет #{skill_color}#3-мя## болтами.\n\n#{skill_color}#Может пробивать броню.##",
		--GL40
		["bm_w_gre_m79_sc_desc"] = "Стук - бум.\n\nНажмите #{skill_color}#$BTN_GADGET## чтобы поднять прицел.\n\nПрицел #{risk}#выверен на 30 метров.##",
		--3GL
		["bm_w_ms3gl"] = "Василиск",
		["bm_ms3gl_sc_desc"] = "Стреляет укомплектованными вместе 40мм гранатами, позволяя быстро выстреливать по несколько зарядов.\n\nАльтернативный огонь #{skill_color}#выстреливает три гранаты разом.##",
		--PIGLET/M32
		["bm_m32_sc_desc"] = "Никто не спасется от этого шестизарядного гранатомета... Пока вам не понадобится перезаряжаться.",
		--China Puff
		["bm_w_china_sc_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## чтобы поднять прицел.\n\nПрицел #{risk}#выверен на 30 метров.##",
		--Compact 40mm
		--["bm_w_slap"] = "Компакт 40",
		--Arbiter
		--["bm_w_arbiter"] = "Арбитр",
		--RPG
		--["bm_w_rpg7"] = "РПГ",
		--COMMANDO 101/M202 FLASH
		--["bm_w_ray"] = "Коммандо 101",
		["bm_ray_sc_desc"] = "Ракеты создают #{heat_warm_color}#огненные лужи## и #{skill_color}#мгновенно уничтожают турели.##",


	    --прочие моды на оружие
		["bm_w_hmcar"] = "Модифицированный КАР-4",
		["bm_wp_wpn_fps_upg_goodlaser"] = "Прицельный лазер",
        ["bm_wp_wpn_fps_upg_o_hmscope"] = "Дальнобойный прицел",

		["bm_w_super"] = "Супер двустволка",
	    ["bm_wp_wpn_fps_upg_super_body_burst"] = "Двойное веселье",
	    ["bm_wp_wpn_fps_upg_super_body_burst_desc"] = "Стреляет из двух стволов сразу.",
	    ["bm_wp_wpn_fps_upg_super_classic"] = "Старая школа",
	    ["bm_wp_wpn_fps_upg_super_meathook"] = "Крюк",

		--Текст для описаний пушек (оставить для кастомок)--
		["bm_menu_weapon_ene_hs_mult_sub"] = "Урон в голову уменьшен на ",
		["bm_menu_weapon_ene_hs_mult_add"] = "Урон в голову увеличен на ",
		["bm_menu_weapon_ene_hs_mult_end"] = ".",
		["bm_menu_weapon_multishot_1"] = "Урон поделен на",
		["bm_menu_weapon_multishot_2"] = "дробинок, каждая из которых наносит",
		["bm_menu_weapon_multishot_3"] = "урона.",
		["bm_menu_weapon_hs_mult_1"] = "Урон в голову увеличен на ",
		["bm_menu_weapon_hs_mult_2"] = " для всех противников, кроме капитанов и боссов.",
		["bm_menu_weapon_exp_no_hs_info"] = "\n#{risk}#Используются взрывные боеприпасы; Урон поделен поровну между пулей и взрывом.##",
		["bm_menu_weapon_movement_penalty_info"] = "Скорость передвижения уменьшена на ",
		["bm_menu_weapon_movement_bonus_info"] = "Скорость передвижения увеличена на ",
		["bm_menu_weapon_sms_bonus_info"] = "Скорость передвижения при стрельбе увеличена на ",
		["bm_menu_weapon_movement_penalty_info_2"] = ", пока это оружие в руках.",
		["bm_menu_sms_info_cont"] = "штраф увеличивается во время стрельбы.",
		["bm_menu_sms_info_cont_2"] = "штраф увеличивается во время стрельбы из-за установленных модулей.",
		["bm_menu_sms_info_2"] = " при стрельбе.",
		["bm_menu_stat_sms_info_2"] = " во время стрельбы из-за установленных модулей.",
		["bm_menu_weapon_slot_search_empty"] = "\n##НИЧЕГО НЕ НАЙДЕНО ПО ЗАПРОСУ## ##\"$search\"##",
		["bm_menu_weapon_slot_warning_1"] = "\n##//////////               НЕ ИСПОЛЬЗОВАТЬ               //////////\n",
		["bm_menu_weapon_slot_warning_2"] = "\n//////////               НЕ ИСПОЛЬЗОВАТЬ               //////////##",
		["bm_menu_weapon_slot_warning_primary"] = "ОРУЖИЕ БЫЛО ПЕРЕМЕЩЕНО В ОСНОВНОЙ СЛОТ\nПРИ ИСПОЛЬЗОВАНИИ ВО ВТОРОСТЕПЕННОМ СЛОТЕ ПРОИЗОЙДЕТ ВЫЛЕТ",
		["bm_menu_weapon_slot_warning_secondary"] = "ОРУЖИЕ БЫЛО ПЕРЕМЕЩЕНО ВО ВТОРОСТЕПЕННЫЙ СЛОТ\nПРИ ИСПОЛЬЗОВАНИИ В ОСНОВНОМ СЛОТЕ ПРОИЗОЙДЕТ ВЫЛЕТ",
		["bm_menu_weapon_slot_warning_disabled"] = "ОРУЖИЕ ОТКЛЮЧЕНО КАПИТАНОМ ОТЕМОМ\nПРИ ИСПОЛЬЗОВАНИИ ПРОИЗОЙДЕТ ВЫЛЕТ",
		["bm_menu_weapon_slot_warning_wtfdoido"] = "НЕ ИСПОЛЬЗОВАТЬ ЭТО ОРУЖИЕ.\n\nНА ДАННЫЙ МОМЕНТ НЕТ ВОЗМОЖНОСТИ ЕГО ЗАБАЛАНСИТЬ",
		["empty"] = "",
		["missing_cap"] = "#{risk}#Custom Attachment Points## #{important_1}#не установлен.##\n\nМодуль будет выглядеть как стандартный модуль слота.",
		["bm_slamfire_generic_desc"] = "Альтернативный огонь позволяет #{skill_color}#отстрелять боезапас в три раза быстрее## за счет #{important_1}#отдачи, точности и невозможности прицеливания.##",
		["bm_rapidfire_generic_desc"] = "Может #{skill_color}#быстро стрелять## за счет #{important_1}#повышенной отдачи и пониженного урона на расстоянии.##",
		["bm_ap_weapon_sc_desc"] = "#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
		["bm_ap_weapon_semi_sc_desc"] = "#{skill_color}#Может пробивать броню, нескольких врагов, щиты в пределах максимального расстояния и тонкие стены.##",
		["bm_ap_armor_weapon_sc_desc"] = "#{skill_color}#Может пробивать броню.##",
		["bm_ap25_armor_weapon_sc_desc"] = "#{skill_color}#Позволяет дополнительно наносить 25% урона через броню.##",
		["bm_ap_armor_25_weapon_sc_desc"] = "#{skill_color}#Наносит 25% урона через броню.##",
		["bm_ap_armor_50_weapon_sc_desc"] = "#{skill_color}#Наносит 50% урона через броню и может пробивать врагов.##",
		["bm_ap_armor_75_weapon_sc_desc"] = "#{skill_color}#Наносит 75% урона через броню и может пробивать врагов.##",
		["bm_pdw_gen_sc_desc"] = "#{skill_color}#Наносит 75% урона через броню.##",
		["bm_heavy_ap_weapon_sc_desc"] = "#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##",
		["bm_heavy_ap_no_mult_weapon_sc_desc"] = "#{skill_color}#Может пробивать броню, врагов, щиты, титановые щиты и тонкие стены.##",
		["bm_ap_2_weapon_sc_desc"] = "Стрелы можно подобрать обратно. Чем дольше держать тетиву, тем выше будет дальность.\n\n#{skill_color}#Может пробивать броню.##",
		["bm_ap_3_weapon_sc_desc"] = "Стрелы можно подобрать обратно.\n\n#{skill_color}#Может пробивать броню.##",
		["bm_bow_sc_desc"] = "Зажмите #{skill_color}#$BTN_FIRE## чтобы приготовить стрелу, отпустите для стрельбы.\nЧем сильнее стрела оттянута, тем выше будут урон и дальность.\n\nНажмите #{skill_color}#$BTN_AIM##, чтобы опустить стрелу.\n\nИспользованные стрелы можно забрать обратно.\n#{skill_color}#Пробивает броню.##",
		["bm_bow_exp_sc_desc"] = "Зажмите #{skill_color}#$BTN_FIRE## чтобы приготовить стрелу, отпустите для стрельбы.\nЧем сильнее стрела оттянута, тем выше будут урон и дальность.\n\nНажмите #{skill_color}#$BTN_AIM##, чтобы опустить стрелу.\n\n#{risk}#Стрелы взрываются при попадании. Урон поделен поровну между прямым попаданием стрелой и взрывом.##",
		["bm_w_bow_exp_desc"] = "Стрелы #{risk}#взрываются## при попадании с радиусом в #{skill_color}#2## метра.\n\n#{important_1}#Скорость полета стрел снижена и их нельзя подобрать.##",
		["bm_w_bow_light_poison_desc"] = "Стрелы обладают #{stats_positive}#ядом##, который оглушает врагов и наносит #{stats_positive}#180## урона ядом в течение #{skill_color}#6## секунд.\n\n#{important_1}#Скорость полета стрел слегка снижена.##",
		["bm_w_bow_heavy_poison_desc"] = "Стрелы обладают #{stats_positive}#ядом##, который оглушает врагов и наносит #{stats_positive}#240## урона ядом в течение #{skill_color}#8## секунд.\n\n#{important_1}#Скорость полета стрел слегка снижена.##",
		["bm_xbow_sc_desc"] = "Использованные болты можно забрать обратно.\n\n#{skill_color}#Пробивает броню.##",
		["bm_integral_suppressor_desc"] = "Обладает #{skill_color}#встроенным глушителем.##",
		
		["bm_xbow_exp_sc_desc"] = "#{risk}#Болты взрываются при попадании. Урон поделен поровну между прямым попаданием болта и взрывом.##",
		["bm_w_xbow_exp_desc"] = "Болты #{risk}#взрываются## при попадании с радиусом в #{skill_color}#2## метра\n\n#{important_1}#Дальность болтов снижена и их нельзя подобрать.##",
		["bm_w_xbow_light_poison_desc"] = "Болты обладают #{stats_positive}#ядом##, который оглушает врагов и наносит #{stats_positive}#180## урона ядом в течение #{skill_color}#6## секунд.\n\n#{important_1}#Скорость полета болтов слегка снижена.##",
		["bm_w_xbow_heavy_poison_desc"] = "Болты обладают #{stats_positive}#ядом##, который оглушает врагов и наносит #{stats_positive}#240## урона ядом в течение #{skill_color}#8## секунд.\n\n#{important_1}#Скорость полета болтов слегка снижена.##",
		["bm_airbow_sc_desc"] = "Использованные стрелы можно забрать обратно.\n\n#{skill_color}#Пробивает броню.##",
		
		["bm_airbow_exp_sc_desc"] = "#{risk}#Стрелы взрываются при попадании. Урон поделен поровну между прямым попаданием стрелы и взрывом.##",
		["bm_w_airbow_poison_desc"] = "Стрелы обладают #{stats_positive}#ядом##, который оглушает врагов и наносит #{stats_positive}#120## урона ядом в течение #{skill_color}#4## секунд.\n\n#{important_1}#Скорость полета стрелы слегка снижена.##",
		
		["bm_40mm_weapon_sc_desc"] = "Нажмите #{skill_color}#$BTN_GADGET## чтобы поднять прицел.\n\nПрицел #{risk}#выверен на 30 метров.##",
		["bm_rocket_launcher_sc_desc"] = "#{skill_color}#Ракеты мгновенно уничтожают турели.##",
		["bm_quake_shotgun_sc_desc"] = "Стреляет из двух стволов сразу, удваивая количество дробинок.",
		["bm_hx25_buck_sc_desc"] = "Выстреливает 12 дробинок с большим разбросом.\n\nИспользует навыки гранатометов.",
		["bm_auto_generated_sc_desc"] = "Характеристики этого оружия сгенерированны автоматически и могут не соответствовать видению автора или балансу.",
		["bm_auto_generated_ap_sc_desc"] = "Характеристики этого оружия сгенерированны автоматически и могут не соответствовать видению автора или балансу.\n\n#{skill_color}#Может пробивать броню, щиты и тонкие стены.##",
		["bm_auto_generated_sap_sc_desc"] = "Характеристики этого оружия сгенерированны автоматически и могут не соответствовать видению автора или балансу.\n\n#{skill_color}#Может пробивать броню, щиты и тонкие стены.##",
		["bm_auto_generated_lmg_sc_desc"] = "Характеристики этого оружия сгенерированны автоматически и могут не соответствовать видению автора или балансу.",
		["bm_auto_generated_mod_sc_desc"] = "Характеристики этого модуля автоматически убраны, так как генерация характеристик для модулей пока не реализована.",
		

		--Overhaul Content Indicators--
		["loot_sc"] = "Restoration",
		["loot_sc_desc"] = "ПРЕДМЕТ ИЗ RESTORATION!",
		["loot_sc_wcc_desc"] = "ПРЕДМЕТ ИЗ RESTORATION! (Необходим WEAPON COLOR PACK 2)",
		["loot_sc_ocp_desc"] = "ПРЕДМЕТ ИЗ RESTORATION! (Необходим WEAPON COLOR PACK 3)",
		["loot_sc_faco_desc"] = "ПРЕДМЕТ ИЗ RESTORATION! (Необходим JIU FENG SMUGGLER PACK 1)",

		["menu_l_global_value_omnia"] = "OMNIA",
		["menu_l_global_value_omnia_desc"] = "ПРЕДМЕТ OMNIA!",

		["menu_rifle"] = "ВИНТОВКИ",
		["menu_jowi"] = "Уик",
		["menu_moving_target_sc"] = "Subtle",

		["bm_wp_upg_i_singlefire_sc"] = "Slower Cyclic",
		["bm_wp_upg_i_singlefire_sc_desc"] = "SLOWS YOUR RATE OF FIRE BY 15%", --RIP RoF mods
		["bm_wp_upg_i_autofire_sc"] = "Faster Cyclic",
		["bm_wp_upg_i_autofire_sc_desc"] = "INCREASES YOUR RATE OF FIRE BY 15%",

		["bm_hint_titan_60"] = "The Titandozer leaves in 60 seconds!",
		["bm_hint_titan_10"] = "The Titandozer leaves in 10 seconds!",
		["bm_hint_titan_end"] = "The Titandozer left to haunt another world!",

		["bm_menu_gadget_plural"] = "Гаджеты",
		["menu_pistol_carbine"] = "Pistol Carbine",
		["menu_battle_rifle"] = "Battle Rifle",

		-- Melee weapon descriptions (don't forget to call them in blackmarkettweakdata, not weapontweakdata) --
		["bm_melee_pattern_knife"] = "Атакует быстрыми ударами. Заряженная атака (#{skill_color}#на 50% и более##) бьет с небольшим размахом.",

		["bm_melee_pattern_knife2"] = "Бьет с широким размахом. Движение в сторону влияет на направление атаки.", --Also works with "melee_clean" and "melee_grip"

		["bm_melee_pattern_ballistic"] = "Атакует быстрыми ударами. Заряженная атака (#{skill_color}#на 50% и более##) бьет размахом и сверху вниз. Движение в сторону влияет на направление атаки.",
		["bm_melee_pattern_poker"] = "Бьет атаками сверху вниз. Заряженная атака (#{skill_color}#на 50% и более##) бьет выпадом вперед.",

		["bm_melee_pattern_boxcutter"] = "Бьет с широким размахом.", --Also works with "melee_catch" and "melee_agave"

		["bm_melee_pattern_shield"] = "Атакует обычным ударом. Заряженная атака (#{skill_color}#на 50% и более##) бьет размахом.",

		["bm_melee_pattern_briefcsae"] = "Атакует обычным ударом. Заряженная атака (#{skill_color}#на 50% и более##) бьет размахом.",

		["bm_melee_pattern_blunt"] = "Бьет атаками сверху вниз. Заряженная атака (#{skill_color}#на 50% и более##) бьет размахом.", --Also works with "melee_brick", "melee_happy", "melee_cleaver", "melee_beardy"
		["bm_melee_pattern_blunt_90"] = "Бьет атаками сверху вниз. Заряженная атака (#{skill_color}#на 50% и более##) бьет широким размахом.",

		["bm_melee_pattern_beardy"] = "Бьет атаками сверху вниз. Заряженная атака (#{skill_color}#на 50% и более##) бьет размахом. Движение в сторону влияет на направление атаки.",

		["bm_melee_pattern_axe"] = "Бьет атаками сверху вниз.", --Also works with "melee_psycho" and "melee_pickaxe"

		["bm_melee_pattern_cutter"] = "Бьет атаками сверху вниз. Заряженная атака (#{skill_color}#на 50% и более##) бьет выпадом вперед.",

		["bm_melee_pattern_great"] = "Бьет атаками сверху вниз, а движения в сторону позволяют провести атаку с широким размахом. Заряженная атака (#{skill_color}#на 90% и более##) бьет выпадом вперед, увеличивая дальность атаки.",
		["bm_melee_pattern_great_no_stab"] = "Бьет атаками сверху вниз, а движения в сторону позволяют провести атаку с широким размахом.", -- Also works for "melee_cs"

		["bm_melee_pattern_katana"] = "Бьет по диагонали. Движения в сторону позволяют провести атаку с широким размахом.",

		["bm_melee_pattern_fist"] = "Атакует быстрыми ударами. Заряженная атака (#{skill_color}#на 50% и более##) позволяет прописать хук оппоненту. Движение в сторону влияет на направление атаки.",

		["bm_melee_pattern_boxing"] = "Атакует быстрыми ударами. Заряженная атака (#{skill_color}#на 50% и более##) позволяет прописать оппоненту хук с левой или апперкот с правой. Движение в сторону влияет на направление атаки.",

		["bm_melee_pattern_tiger"] = "Атакует быстрыми ударами. Заряженная атака (#{skill_color}#на 50% и более##) позволяет прописать оппоненту апперкот с левой или хук с правой. Движение в сторону влияет на направление атаки.",

		["bm_melee_pattern_jab"] = "Атакует быстрыми ударами.", --For anything that basically only has centered hitboxes like "melee_pitchfork", "melee_wing" and "melee_fight"

		--Оружия ближнего боя
		["bm_melee_weapon_info"] = "Обычно жертв ограбления бьют прикладом, а не стреляют в них.\n\nСкорость удара зависит от Компактности оружия.",
		["bm_melee_katana_info"] = "Свежескованная катана, которая еще не пробовала кровь - она ждет своего владельца. Кажется, она его нашла.\n\nПолностью заряженные атаки бьют на #{skill_color}#50%## быстрее, позволяя быстро повторить атаку.\n\nПри игре за Джиро, убийство Клокера имеет особый визуальный эффект.",
		["bm_melee_raiden_info"] = "This is no \"tool of justice\" in your hands.\n\nПолностью заряженные атаки бьют на #{skill_color}#50%## быстрее, позволяя быстро повторить атаку.",
		["bm_melee_thejobissnotyours_info"] = "This isn't even your sword.\n\nПолностью заряженные атаки бьют на #{skill_color}#50%##быстрее, позволяя быстро повторить атаку.",
		["bm_melee_thebestweapon_info"] = "#{stats_positive}#Лучшее оружие в игре.##",
        ["bm_melee_2077tkata_info"] = "Катана из раскаленного нано-волокна.\nЧистая эссенция катаны - никаких примочек, лишь закаленная сталь.\n\nПолностью заряженные атаки поджигают врагов, нанося #{heat_warm_color}#120## огненного урона в течение #{skill_color}#3## секунд.",
		["bm_melee_buck_info"] = "Удивительно эффективен против современного оружия.\n\nУменьшает получаемый урон на #{skill_color}#10%## во время замаха.", --Buckler Shield
		["bm_melee_briefcase_info"] = "Что бы там внутри не было, оно довольно крепкое.\n\nУменьшает получаемый урон на #{skill_color}#10%## во время замаха.", --Briefcase
		["bm_melee_pitch_info"] = "Грабительская готика.\n\nБег запускает атаку, которая наносит #{skill_color}#45## секунд каждые #{skill_color}#0.4## секунды врагам, на которых вы бежите. Навыки позволяют увеличить этот урон.\n\nПопадание по врагу во время бега тратит #{important_1}#15% выносливости##, убийство врага возвращает #{skill_color}#10%##.\n\n#{important_1}#Не позволяет парировать атаки.##", --Randal Pitchfork
		["bm_melee_charge_info"] = "Бег запускает атаку, которая наносит #{skill_color}#45## секунд каждые #{skill_color}#0.4## секунды врагам, на которых вы бежите. Навыки позволяют увеличить этот урон.\n\nПопадание по врагу во время бега тратит #{important_1}#15% выносливости##, убийство врага возвращает #{skill_color}#10%##.\n\n#{important_1}#Не позволяет парировать атаки.##",
		["bm_melee_cs_info"] = "Рви их в клочья, пока не уничтожишь всех.\n\nНаносит #{skill_color}#30## урона каждые #{skill_color}#0.25## секунд тому, кто стоит впереди вас во время зарядки. Этот урон можно улучшить навыками.\n\n#{important_1}#Не позволяет парировать атаки.##", -- ROAMING FR-
		["bm_melee_ostry_info"] = "Вжуууууух.\n\nНаносит #{skill_color}#18## урона каждые #{skill_color}#0.18## секунд тому, кто стоит впереди вас во время зарядки. Этот урон можно улучшить навыками.\n\n#{important_1}#Не позволяет парировать атаки.##", --Kazaguruma
		["bm_melee_wing_info"] = "Хорошо подходит к набору маскировки!\n\nНаносит #{skill_color}#четырехкратный## урон при атаке сзади.",-- Wing Butterfly Knife
		["bm_melee_switchblade_info"] = "Придуманный для насилия, смертельный как револьвер - это выкидной нож!\n\nНаносит #{skill_color}#двойной## урон при атаке сзади.",-- Switchblade Knife
		["bm_melee_chef_info"] = "Не думаю, что он подойдет для мяса.\n\nПолностью заряженные удары разносят панику в радиусе #{skill_color}#12## метров от вас.\n\n#{important_1}#Навыки, влияющие на скорость зарядки, не работают с этим оружием.##", -- Psycho Knife
		["bm_melee_headless_sword_info"] = "Меч, собранный из кошмаров.\n\nПолностью заряженные удары разносят панику в радиусе #{skill_color}#12## метров от вас.\n\n#{important_1}#Навыки, влияющие на скорость зарядки, не работают с этим оружием.##", -- Headless Dozer Sword
		["bm_melee_titan_hammer_info"] = "Молот, собранный из кошмаров.\n\nПолностью заряженные удары разносят панику в радиусе #{skill_color}#12## метров от вас.\n\n#{important_1}#Навыки, влияющие на скорость зарядки, не работают с этим оружием.##",
		["bm_melee_goat_info"] = "Полностью заряженные удары разносят панику в радиусе #{skill_color}#12## метров от вас.\n\n#{important_1}#Навыки, влияющие на скорость зарядки, не работают с этим оружием.##", -- ай-яй-яй
		["bm_melee_great_info"] = "Меч, ставший знаменитым благодаря Уильяму Уоллесу. Шестифутовый клинок из острой как бритва стали отрубает любую конечность за один взмах.", -- Great Sword
		["bm_melee_jebus_info"] = "Свет и мрак.\n\nЧерное и белое.\n\nЖизнь и смерть.\n\nБинарный меч не знает середины, он отключает врагов.",
		["bm_melee_nin_info"] = "Стреляет гвоздями, которые мгновенно летят на маленькое расстояние. Считается за оружие ближнего боя.", -- Pounder
		["bm_melee_iceaxe_info"] = "Используется альпинистами для взбирания в гору. Что-то мне подсказывает, что вы не будете заниматься альпинизмом.\n\nНаносит на #{skill_color}#200%## больше урона в голову при полной зарядке оружия.", -- Icepick
		["bm_melee_iceaxe_gen_info"] = "Наносит на #{skill_color}#50%## больше урона в голову.",
		["bm_melee_mining_pick_info"] = "Эта кирка старого образца когда-то использовалась золотоискателями в надежде найти заветный куш. Время идет, а что-то все равно не меняется.\nНаносит на #{skill_color}#300%## больше урона в голову при полной зарядке оружия.", --Gold Fever (Pickaxe)
		["bm_melee_boxing_gloves_info"] = "Разве уже был гонг?\n\nУбийства, совершенные этим оружием, #{skill_color}#полностью восстановят выносливость.##", -- OVERKILL Boxing Gloves
		["bm_melee_freedom_info"] = "Тринадцать полос красного, чередующихся с белым, синий прямоугольник в кантоне, пятьдесят маленьких белых пятиконечных звезд, щепотка патриотизма, две чашки свободы и сломанный флагшток.\n\nВуаля - у тебя есть смертоносное оружие.",
		["bm_melee_clean_info"] = "Пусть копы побреются.\n\nНаносит #{skill_color}#120## урона в течение #{skill_color}#трех## секунд.", --Alabama Razor
		["bm_melee_barbedwire_info"] = "Отличное оружие против ходячих мертвецов. Наносит #{skill_color}#120## урона в течение трех секунд.\n\nаносит на #{skill_color}#100%## больше урона в голову при полной зарядке оружия.", --Lucille Baseball Bat
		["bm_melee_bleed_info"] = "Наносит #{skill_color}#120## урона в течение #{skill_color}#трех## секунд.",
		["bm_melee_inner_child_info"] = "Твой внутренний ребенок рвется наружу.\n\nНаносит 120 урона в течение трех секунд.",
		["bm_melee_spoon_gold_info"] = "Не бойся вилки, бойся ложки, один удар - и череп в крошки. \n\n#{skill_color}#50%## шанс нанести #{heat_warm_color}#120## огненного урона и прервать врага на #{skill_color}#3## секунды.", --Gold Spoon
		["bm_melee_fire_info"] = "#{skill_color}#50%## шанс нанести #{heat_warm_color}#120## огненного урона и прервать врага на #{skill_color}#3## секунды.",
		["bm_melee_cqc_info"] = "Даже самый сильный и могучий противник упадет, если его хоть раз коснется этот пропитанный ядом кунай.\n\nСодержит экзотический яд, который наносит #{stats_positive}#120## урона в течение #{skill_color}#четырех## секунд.", --Kunai, Syringe
		["bm_melee_fight_info"] = "Будь водой, друг мой.\n\nПарирование противника наносит ему #{skill_color}#120## урона в ближнем бою. Навыки позволяют увеличить этот урон.", --Empty Palm Kata
		["bm_melee_slot_lever_info"] = "Ты кто такой, чтобы это делать?\n\nИмеет #{skill_color}#5%## шанс нанести #{skill_color}#десятикратные## урон и нокдаун.",
		["bm_melee_specialist_info"] = "Теперь в два раза больше лезвий.\n\nНаносит #{skill_color}#двойной## урон после первого удара.", --Specialist Knives, Talons, Knuckle Daggers, Push Daggers
		["bm_melee_cleaver_info"] = "Специальное оружие для вытаскивания кишок в течение десяти минут.\n\nНаносит на #{important_1}#50%## меньше урона в голову, но эффективен для ударов по телу и конечностям.",
		["bm_melee_meat_cleaver_info"] = "Специальное оружие Драгана, которое он использовал до вступления в банду PAYDAY для выполнения #{important_1}#\"очень грязной\"## работы.\n\nНаносит на #{important_1}#50%## меньше урона в голову, но эффективен для ударов по телу и конечностям.",
		["bm_melee_erica_info"] = "Адекватные люди бросают это во врагов.\n\nПолностью заряженные удары по врагам имеют #{skill_color}#100%## шанс взорваться, нанося #{risk}#720## урона в #{skill_color}#5## метровом радиусе, #{important_1}#включая вас.##",
		["bm_melee_piggy_hammer_info"] = "Наносит на #{skill_color}#100%## больше урона особым и элитным врагам.\n\nИмеет шанс наложить один из #{risk}#эффектов## при успешном попадании:\n\n-#{skill_color}#12%## шанс вызвать #{important_1}#кровотечение##\n-#{skill_color}#7%## шанс ударить противника #{ghost_color}#током##\n-#{skill_color}#5%## шанс вызвать #{stats_positive}#отравление##\n-#{skill_color}#1%## шанс #{risk}#убить противника мгновенно##",
		["bm_melee_kabar_info"] = "Нож URSA - это износостойкий, неразрушимый боевой/хозяйственный нож, выпущенный в 1942 году.\n\nНастоящая классика среди ценителей ножей.",
		["bm_melee_kampfmesser_info"] = "Официальный боевой нож Вооруженных сил Германии Бундесвера. Ножи этой серии производятся в соответствии со строгими стандартами ISO с существенно улучшенной режущей способностью.\n\nОтличный выбор при схватке с врагом с глазу на глаз.",
		["bm_melee_gerber_info"] = "Боевой нож Berger - популярный тактический нож со складывающимся клинком. Компактный, легкий и изготовленный из высокотехнологичных материалов - это все, что нужно для хорошего ножа.",
		["bm_melee_rambo_info"] = "Нож для выживания с тяжелым лезвием типа \"Боуи\". Длина, пилообразный корешок и заостренный по центру наконечник одинаково хорошо подходят как в дикой местности, так и в ближнем бою.",
		["bm_melee_kabar_tanto_info"] = "Форма клинка Танто, характерная для ножей из Азии, имеет толстое заостренное лезвие и хорошую проникающую способность. Этот нож предназначен для самых сложных задач.",
		["bm_melee_tomahawk_info"] = "Когда вы находитесь в ситуации, когда время имеет решающее значение, вы не можете тратить время на размышления о том, есть ли у вас подходящий инструмент для ограбления. Независимо от того, что находится по ту сторону двери или хранилища, вам нужен инструмент с такой же целеустремленностью, как у грабителя, владеющего им.",
		["bm_melee_becker_info"] = "Специализированное мачете, которое может крушить, колотить, поддевать и резать.\nОдинаково эффективен для вскрытии дверей и окон, выбивании витрин, а также при перерезании полицейских стяжек.",
		["bm_melee_baton_info"] = "Самое тактически совершенное оружие, доступное для правоохранительных органов.\nПротестирован самыми элитными федералами. Зарекомендовал себя как практически несокрушимое оружие по наведению порядка.",
		["bm_melee_happy_info"] = "Личная телескопическая дубинка Джой для борьбы с не виртуальными противниками.",
		["bm_melee_shovel_info"] = "Лопата КЛАСС может использоваться для различных рекреационных целей. Ее также можно использовать как оружие - острыми краями можно резать плоть и кости, а плоской частью можно загнать какого-нибудь бедолагу в могилу.",
		["bm_melee_moneybundle_info"] = "Один взмах - и жертва сразу поймет, что проще банк ограбить, чем у него же занимать.",
		["bm_melee_fists_info"] = "Ты не боксер, но все равно можешь нанести довольно хороший удар.\nВсе, что требуется, - это немного силы, скорости и времени, и ты нанесешь сокрушительный удар в мгновение ока.",
		["bm_melee_brass_knuckles_info"] = "Кастеты использовались во всем мире на протяжении сотен лет.\nКастеты концентрируют силу удара, позволяя с легкостью нанести ушибы или даже переломать несколько костей оппоненту.",
		["bm_melee_bayonet_info"] = "Прочный штык, предназначенный для крепления на конце вашей винтовки и втыкания его в тела ваших врагов. Но ты ведь будешь пользоваться им как обычным ножом, не так ли?",
		["bm_melee_bullseye_info"] = "Самое известное оружие #{important_1}#Винницкого потрошителя##, который за маской аскетизма пытался скрывать свои самые бесчеловечные поступки.",
		["bm_melee_x46_info"] = "X-46 представляет собой цельный 6-дюймовый клинок из стали А2 с покрытием, выполненный в форме частично зазубренного клинка \"Боуи\" с ложной верхней кромкой. Также имеет наконечник для разбивания стекла. Универсальный полевой дизайн этого ножа делает его столь же полезным как на поле боя, так и в чрезвычайной ситуации.",
		["bm_melee_dingdong_info"] = "Три в одном:\n- Кувалда.\n- Таран.\n- Монтировка.\nЧто может быть лучше?",
		["bm_melee_bat_info"] = "Бейсбольная бита. Ни больше, ни меньше.\n\nПредназначенная для использования в спорте, но вы, конечно, будете использовать ее для чего-то гораздо более зловещего.\n\nПолностью заряженные атаки бьют на #{skill_color}#25%## быстрее, позволяя быстро провести повторную атаку.",
		["bm_melee_machete_info"] = "Тебе нравится причинять боль людям, поэтому ты предпочитаешь пользоваться этим грязным старым мачете. Море крови, отрубленные конечности и крики твоих врагов только подстегивают тебя продолжать это делать. Поистине оружие для жестокого и бесчеловечного грабителя.",
		["bm_melee_fireaxe_info"] = "Вам нравится причинять боль другим людям?\n\nЕсли ваш ответ \"Да!\", то вам может подойти орудие, которое предназначено для спасения жизней! Покажите своим жертвам огонь в ваших глазах, когда вы спасаете их от самих себя одним быстрым рубящим ударом.",
		["bm_melee_toothbrush_info"] = "Маленькая пластиковая зубная щетка, превращенная в самодельную заточку, готова вонзиться в вашу следующую жертву.",
		["bm_melee_fairbair_info"] = "Этот траншейный нож - любимчик среди британских коммандосов. Отлично подходит для нанесения рубящих ударов. Очень популярный нож, который используется и производится по сей день.",
		["bm_melee_swagger_info"] = "Отдавайте приказы, улучшайте свой имидж в обществе или просто используйте его для применения телесных наказаний! Жезл - обязательный аксессуар для любого уважающего себя лидера.",
		["bm_melee_hammer_info"] = "\"Вдохновение плотника\" - любимый молоток Джекета. Наиболее распространенное применение молотков - забивать гвозди, подгонять детали, ковать металл и разбивать предметы на части. Джекет же предпочитает им избивать людей до смерти.",
		["bm_melee_shillelagh_info"] = "Трудно определить происхождение этой дубинки. Коллекционеры готовы отгрохать неплохую сумму за эту большую палку, но зачем ее продавать тому, у кого она просто будет пылиться? Лучше пойти и с ее помощью разломить несколько черепушек.",
		["bm_melee_poker_info"] = "Длинный кусок железа с заостренным концом - прекрасное орудие для тушения тлеющих углей, но это также идеальное орудие для причинения увечий и крайнего дискомфорта в пятой точке.",
		["bm_melee_tenderizer_info"] = "Хотя он был разработан в основном для размягчения и расплющивания жестких частей мяса, он также оказался полезным для размягчения и расплющивания черепов копов.",
		["bm_melee_fork_info"] = "Этой вилкой толчки не почистишь, но зато можно воткнуть ее кому-нибудь прямо в глаза.",
		["bm_melee_spatula_info"] = "Вы забрали эту лопатку у Митчелла и продолжили готовить стейки, пока взламываются щитки для доступа в подвал. Как оказалось, ей даже можно лупить копов.",
		["bm_melee_scalper_info"] = "Для победителя это символ войны, власти и доминирования.\n\nДля проигравшего это символ очень, очень плохой стрижки.",
		["bm_melee_bowie_info"] = "Девять дюймов закаленной стали. Его истоки уходят в эпоху классических пиратов, но широкую известность ему принесла знаменитая драка в округе Кэрролл (и дюжина окровавленных мужчин).",
		["bm_melee_branding_iron_info"] = "Возможно, он был разработан для маркировки крупного рогатого скота, но раскаленное на огне железо еще более эффективно для маркировки какого-нибудь депутата или маршала.",
		["bm_melee_microphone_info"] = "Незаменимая вещь для звезд шоу-бизнеса, стендаперов, публичных выступлений и т.д.\nВы, в каком-то смысле, тоже звезда.",
		["bm_melee_micstand_info"] = "Эта стойка позволяет спокойно поставить микрофон, но кто запрещал махаться ей во все стороны?",
		["bm_melee_oldbaton_info"] = "#{stats_positive}#\"СТОП-СЛОВО НА СЕГОДНЯ: ПОЛИЦЕЙСКАЯ ЖЕСТОКОСТЬ!\"##",
		["bm_melee_detector_info"] = "Желательно, чтобы эта штука была выключена.",
		["bm_melee_croupier_rake_info"] = "Казино всегда в выигрыше.",
		["bm_melee_alien_maul_info"] = "Молоток, изготовленный в честь запуска Alienware Alpha.",
		["bm_melee_beardy_info"] = "Викинги вышли из темных лесов языческого Севера и оставили за собой лишь кровавый след и разрушения от Исландии до Стамбула. Их основным оружием был двуручный бородатый топор.",
		["bm_melee_morning_info"] = "Если глубокие проколы от шипов вас не убьют, то катастрофическая травма от удара тупым предметом по голове - безусловно отправит к праотцам.\n\nНаносит #{skill_color}#120## урона в течение #{skill_color}#трех## секунд.",
		["bm_melee_cutters_info"] = "Серийным убийцам нужно нечто большее, чем просто топор, нож или перчатка с острыми как бритва пальцами.\nИм нужны болторезы, чтобы незаметно проникнуть в те места, которые, как вы думали, были заперты. Там, где, как ты думал, ты был в безопасности...",
		["bm_melee_boxcutter_info"] = "Оказывается, им можно резать не только изоленту.",
		["bm_melee_selfie_info"] = "Как сказал Хокстон: \"Посмотри на этого гребаного олуха с селфи-палкой. Какой самовлюбленный. Держу пари, что он сильный. Знаешь, я должен отобрать это у него и дать ему по башке этой палкой. Сейчас верн~\"",
		["bm_melee_pugio_info"] = "Простой и эффективный в использовании. Независимо от того, перерезаете ли вы горло или освобождаете дельфинов из рыболовных сетей, это поможет выполнить работу на все сто.",
		["bm_melee_gator_info"] = "Говорят, человек может продержаться три недели без еды и три дня без воды, но во враждебной среде вы не продержитесь и трех часов без хорошего мачете под боком.",
		["bm_melee_scoutknife_info"] = "Не бойтесь использовать ржавый и изношенный нож. Нож всегда остается ножом - и некоторые говорят, что старый нож стареет так же, как хорошее вино (вероятно, никто никогда этого не говорил).",
		["bm_melee_shawn_info"] = "Вы знали, что стрижка овец считается спортом? Может быть, нам стоит изобрести новый вид спорта - стрижка полицейских?\nНет? Почему нет? Эх, ладно...",
		["bm_melee_stick_info"] = "Устали после долгого ограбления? Хотите выглядеть старым и мудрым? Может, разбить морду полицейскому? Пастушья трость может все.",
		["bm_melee_ballistic_info"] = "Джимми не из тех парней, которые думают, что меньше значит лучше. Поэтому он носит с собой двойной набор специальных ножей.\n\nНаносит #{skill_color}#двойной## урон после первого удара.",
		["bm_melee_tiger_info"] = "Изначально были разработаны для лазания по деревьям и стенам, но потом их стали использовать как полноценное оружие.\n\nНаносит #{skill_color}#двойной## урон после первого удара.",
		["bm_melee_whiskey_info"] = "Существует несколько правил и предписаний, которым должна соответствовать бутылка виски, чтобы называться шотландским виски. Наличие твердой бутылки не обязательно является одним из них, но это мало что значит для Бонни, которая считает пустую бутылку из-под \"Ривертаун Глен\" своим любимым оружием ближнего боя.",
		["bm_melee_road_info"] = "Цепь-кнут - любимое оружие Раста для ближнего боя, поскольку он поклонник олдскульных инструментов, которые могут причинить боль.\nСама цепь была куплена Растом в хозяйственном магазине.\nПомимо этого цепь издает свистящий звук, когда вы будете бить по лицу оппонента.",
		["bm_melee_shock_info"] = "\"Будь так любезен...\"",
		["bm_melee_brick_info"] = "Не ошибитесь - это не просто телефон. Это #{stat_maxed}#ХОТЛАЙН## #{skill_color}#8000##, пик общения в 80-х.\n\n- Привет, кто там?\n- Я позвонил, чтобы сказать...\n\n- Я ненавижу тебя.",
		["bm_melee_sword"] = "Карандаш",
		["bm_melee_sword_info"] = "\"Джон - человек целеустремленный, обязательный, волевой... Тебе это все знакомо очень мало. Я видел однажды как он убил троих в баре... #{important_1}#карандашом##.\nОбычным. #{important_1}#Карандашом##.\"",
		["bm_melee_oxide_info"] = "Инновационный дизайн позволяет создать надежное оружие ближнего боя. Оно должно уметь работать как мачете в районах с густой растительностью, но быть по габаритам как нож.\nЭто оружие может быть использовано летчиками, полевыми солдатами и всеми остальными, кому нужен хороший полевой нож.",
		["bm_melee_agave_info"] = "Жизнь головореза это не только про убийства - это еще про запугивание. То, что оставляет отпечаток внутри тех, кто становится свидетелем этого беспредела. Тут-то и вступает в игру мачете Сангреса.\n\nСангрес назвал свое мачете \"Эль Вердуго\" - подходящее имя для такого грозного оружия.",
		["bm_melee_ohwell_info"] = "Наряду с катаной, танто было основным оружием всех самураев.\n\nЭто принадлежало Кенто, хотя неизвестно, где он его приобрел.",
		["bm_melee_spoon_info"] = "Только ложечку, верно?",
		["bm_melee_aziz_info"] = "Алан, проснись.",
		["bm_melee_chac_info"] = "Войди в ритм с этим маракасом и встряхни им несколько черепов, буквально.",
		["bm_melee_sap_info"] = "Кожаная дубинка - оружие джентльмена.\n\nПростое похлопывание по голове, и ваш враг падает. Дюк владеет кожаной дубинкой с такой грацией и жестокостью, которые иногда переходят все границы и удары наносят больше повреждений, чем необходимо.\n\nТак что действуйте осторожно - или нет.",
		["bm_melee_hockey_info"] = "Красиво обработанный и покрашенный кусок дерева. Идеально подходит для того, чтобы забрасывать шайбу в сетку и выбивать нахрен зубы.",
		["bm_melee_meter_info"] = "Главное, чтобы ваша вторая половинка не спросила за насечки на линейке.",
		["bm_melee_catch_info"] = "Крюк - надежный инструмент, и, честно говоря, довольно примитивный. Необработанная деревянная ручка с прочным металлическим крюком - это все, что нужно.\n\nКрюк гарантированно вызовет много беспорядка. Его использование ограничено только вашим собственным извращенным воображением о том, как зацепить ваших врагов. Вонзать его своим противникам в рот или в их тела?",
		["bm_melee_watson_info"] = "Укусит, как комарик.\n\nСодержит раствор неизвестного происхождения, который наносит #{stats_positive}#120## урона ядом в течение #{skill_color}#4## секунд.",
		-- if anyone gets offended by this string for some reason, I'll explain: it's the "Parry this you filthy casual" meme adaptation, nothing more.
		["bm_melee_klara_info"] = "#{important_1}#\"Для мерзких казаулов.\"##\n\nЗдоровенный двуручный меч, хотя по размеру больше похоже на копье.\n\nПарирование противника наносит ему #{skill_color}#180## урона в ближнем бою. Навыки позволяют увеличить этот урон.",
		["bm_melee_twins"] = "Саи", --поправьте, если слово не склоняется вообше, я не гумманитарий.
		["bm_melee_twins_info"] = "Позволяет обезоружить врага с острым оружием за считанные секунды.\n\nПарирование противника наносит ему #{skill_color}#60## урона в ближнем бою. Навыки позволяют увеличить этот урон.",

			--КАСТОМНЫЕ оружия ближнего боя
			["bm_melee_revenant_heirloom"] = "Dead Man's Curve",
			["bm_melee_revenant_heirloom_info"] = "\"Это последнее, что ты увидишь, кожаный мешок\"",
			--это пиздец
			["bm_melee_megumins_staff"] = "Посох Мегумин",
			["bm_melee_megumins_staff_info"] = "Создает мощный #{stats_negative}#ВЗРЫВ##, когда полностью заряжен!\n#{stats_negative}#ВЗРЫВ## производится на любую поверхность или существо на расстоянии не более #{skill_color}#30## метров;\n#{stats_negative}#ВЗРЫВ## #{risk}#нельзя создать в воздухе.##\n\n#{important_1}#Скорость зарядки не зависит от навыков.##\nВо время зарядки у Вас затуманивается экран, тратится выносливость и постепенно уменьшается скорость передвижения.\nВы мгновенно падаете после создания #{stats_negative}#ВЗРЫВа##, ##при любых условиях.##",
			--славянский зажим яичек
			["bm_melee_cqc20_info"] = "#{risk}#ПОЛУЧАЙТЕ!##\n\nПолностью заряженные удары по противнику создают взрыв, нанося #{risk}#720## урона всем врагам в радиусе #{skill_color}#2##м.\n\n#{important_1}#Скорость зарядки не зависит от навыков.##",
			--я попаду в игру получше, если я этим задену себя?...
			["bm_melee_sakura_dork"] = "Палка Судьбоносного Грузовика",
			["bm_melee_sakura_dork_info"] = "Службы доставки и попаданцы будут завидовать вашим умениям обращаться с этой палкой!\n\nПолностью заряженный удар вызывает на помощь ##Грузовик-куна##.\n\n#{important_1}#Навыки, влияющие на скорость зарядки, не влияют на это оружие.##\n#{important_1}#Невозможно бегать во время атаки или зарядки этого оружия.##",
		["bm_menu_weapon_bayonet_header"] = "ХАР-КИ ОТ ОСНОВНОГО:",
		["bm_menu_weapon_bayonet_secondary_header"] = "ХАР-КИ ОТ ВТОРИЧНОГО:",
		["bm_menu_weapon_bayonet_damage"] = "\nДОП. УРОН: ##+",
		["bm_menu_weapon_bayonet_damage_base"] = "\n-БАЗОВЫЙ: ##",
		["bm_menu_weapon_bayonet_damage_skill"] = "\n-НАВЫКИ: ##+",
		["bm_menu_weapon_bayonet_range"] = "\nДОП. РАССТОЯНИЕ: ##+",

		

		

		--Menu Buttons--
		["bm_menu_btn_sell"] = "ПРОДАТЬ ОРУЖИЕ ($price)",
		["bm_menu_btn_buy_selected_weapon"] = "КУПИТЬ ОРУЖИЕ ($price)",
		
		--Для меню с характеристиками оружий
		["menu_seconds_suffix_short"] = "с",
		["menu_milliseconds_suffix_short"] = "мс",
		["menu_meters_suffix_short"] = "м",

		--Новые статы--
		["bm_menu_crit"] = "Шанс крита",
		["bm_menu_damage_shake"] = "Тряска",
		["bm_menu_deflection"] = "Устой-вость",
		["bm_menu_regen_time"] = "Регенерация",
		["bm_menu_swap_speed"] = "Ск. смены",
		["bm_menu_pickup"] = "Подбор",
		["bm_menu_ads_speed"] = "Прицеливание",
		["bm_menu_reload"] = "Перезарядка",
		["bm_menu_damage"] = "Урон", -- I gotta find out WHO KILLED MY DA- how to spoof the damage readout for melee ["bm_menu_damage"] = "Макс. урон",
		["bm_menu_standing_range"] = "Эффк. расстояние",
		["bm_menu_damage_min"] = "Мин. урон",
		["bm_menu_moving_range"] = "Макс. расстояние",		
		["bm_menu_dodge"] = "Уворот",
		

		["bm_menu_attack_speed"] = "Ск-сть атаки",
		["bm_menu_impact_delay"] = "Задержка",
		["bm_menu_cleave"] = "Прорубание",

		["bm_menu_stats_detection"] = "Нагрузка",
		["bm_menu_stats_min_detection"] = "Низкая нагрузка",
		["bm_menu_stats_max_detection"] = "Максимальная нагрузка",
		["bm_menu_stats_dash_limit"] = "Лимит рывка:", -- Что это вообще - кд на рывок? Дистанция рывка? надо проверить самому

		--Названия категорий аттачментов--
		["bm_menu_barrel_ext"] = "Насадка",
		["bm_menu_barrel_ext_plural"] = "Насадки",
		["bm_menu_foregrip"] = "Цевье",
		["bm_menu_foregrip_plural"] = "Цевье",
		["bm_menu_vertical_grip"] = "Рукоятка",
		["bm_menu_vertical_grip_plural"] = "Рукоятки",
		["bm_menu_bayonet"] = "Штык",
		["bm_menu_bayonet_plural"] = "Штыки",
		--Spoof types--
		["bm_menu_frame"] = "Рама",
		["bm_menu_whole_receiver"] = "Затвор",
		["bm_menu_shell_rack"] = "Патронташ",
		["bm_menu_nozzle"] = "Насадка",
		["bm_menu_fuel"] = "Баллон",
		["bm_menu_cylinder"] = "Барабан",
		["bm_menu_model"] = "Модель",
		["bm_menu_forebarrelgrip"] = "Ствол и рукоятка",
		["bm_menu_riser"] = "Рельс",
		["bm_menu_pump"] = "Помпа",

		["bm_menu_upotte_barrel"] = "Ствол",
		["bm_menu_upotte_foregrip"] = "Цевье",
		["bm_menu_upotte_stock"] = "Приклад",
		["bm_menu_upotte_grip"] = "Рукоятка",

		["bm_menu_ro_barrel"] = "Ствол",
		["bm_menu_ro_stock"] = "Приклад",
		["bm_menu_ro_modifier"] = "Модификаторы",
		["bm_menu_ro_charm"] = "Брелок",
		["bm_menu_ro_grip"] = "Рукоятка",

		--Категории пушек--
		["menu_pistol"] = "Пистолеты",
		["menu_pistol_single"] = "Пистолет",
			["menu_light_pis"] = "Легкие пистолеты",
			["menu_heavy_pis"] = "Тяжелые пистолеты",

		["menu_shotgun"] = "Дробовики",
		["menu_shotgun_single"] = "Дробовик",
			["menu_light_shot"] = "Авто. дробовики",
			["menu_heavy_shot"] = "Легкие дробовики",
			["menu_break_shot"] = "Тяжелые дробовики",

		["menu_smg"] = "Пулеметы",
		["menu_smg_single"] = "Пулемет",
		["menu_lmg"] = "Пулеметы",
		["menu_lmg_single"] = "Пулемет",
		["menu_minigun"] = "Миниганы",
		["menu_minigun_single"] = "Миниган",
			["menu_light_smg"] = "Легкие ПП",
			["menu_heavy_smg"] = "Тяжелые ПП",
			["menu_light_mg"] = "Легкие пулеметы",
			["menu_heavy_mg"] = "Тяжелые пулеметы",
			["menu_miniguns"] = "Миниганы",

		["menu_assault_rifle"] = "Винтовки",
		["menu_assault_rifle_single"] = "Винтовка",
		["menu_snp"] = "Винтовки",
		["menu_snp_single"] = "Винтовка",
			["menu_light_ar"] = "Легкие винтовки",
			["menu_heavy_ar"] = "Тяжелые винтовки",
			["menu_dmr_ar"] = "Марксманские винтовки",
			["menu_light_snp"] = "Легкие снайперские винтовки",
			["menu_heavy_snp"] = "Тяжелые снайперские винтовки",
			["menu_antim_snp"] = "Крупнокалиберные винтовки",

		["menu_wpn_special"] = "Особое",
			["menu_wpn_special_single"] = "Особое",

		["menu_flamethrower"] = "Огнеметы",
		["menu_flamethrower_single"] = "Огнемет",

		["menu_grenade_launcher"] = "Гранатометы",
		["menu_grenade_launcher_single"] = "Гранатомет",

		["menu_saw"] = "Пилы",
		["menu_saw_single"] = "Пила",

		["menu_bow"] = "Луки",
		["menu_bow_single"] = "Лук",
		["menu_crossbow"] = "Арбалеты",
		["menu_crossbow_single"] = "Арбалет",

		["menu_akimbo"] = "Парные+",

		["menu_unsupported"] = "Не поддерживается",

		["st_menu_value"] = "Стоимость:",

		["st_menu_skill_use"] = "ТИП НАВЫКА:",
		["st_wpn_akimbo"] = "Парн.+",
		["st_wpn_assault_rifle"] = "Винтовка",
		["st_wpn_snp"] = "Винтовка",
		["st_wpn_pistol"] = "Пистолет",
		["st_wpn_shotgun"] = "Дробовик",
		["st_wpn_smg"] = "Пулемет",
		["st_wpn_lmg"] = "Пулемет",
		["st_wpn_minigun"] = "Пулемет",
		["st_wpn_crossbow"] = "Лук",
		["st_wpn_bow"] = "Арбалет",
		["st_wpn_saw"] = "Пила",
		["st_wpn_grenade_launcher"] = "Гранатомет",
		["st_wpn_wpn_special"] = "Особое",
		["st_wpn_flamethrower"] = "Огнемет",

		["st_menu_firemode"] = "РЕЖИМ ОГНЯ:",
		["st_menu_firemode_semi"] = "ОДН",
		["st_menu_firemode_auto"] = "АВТ",
		["st_menu_firemode_burst"] = "ОЧР",
		["st_menu_firemode_volley"] = "ЗАЛП",
		["st_menu_firemode_burst_slamfire"] = "ТЕМПОВЫЙ",
		["st_menu_firemode_burst_fanning"] = "ФАННИНГ",
		["st_menu_firemode_burst_rapidfire"] = "СКОРОСТНОЙ",
		["st_menu_firemode_burst_autoburst"] = "АВТООЧЕРЕДЬ",

		["menu_reticle_dmc_eotech"] = "TECopt Full",
		["menu_reticle_dmc_eotech_moa"] = "TECopt MOA Dot",
		["menu_reticle_dmc_eotech_seggs"] = "TECopt Segmented",
		["menu_reticle_dmc_ebr_cqb"] = "Maelstrom EBR-CQB",
		["menu_reticle_dmc_trijicon_chevron"] = "Trigonom Chevron",
		["menu_reticle_dmc_ncstar"] = "Reconnaissance Cross",
		["menu_reticle_dmc_lua"] = "Powered by Lua",
		["menu_reticle_dmc_dot_4x4"] = "Small Dot",
		["menu_reticle_dmc_dot_2x2"] = "Tiny Dot",
		["menu_reticle_dmc_cross_holotherm"] = "SZ Holotherm",


		--Стринги для брони в меню раздевалки. НЕ ТРОЖЬ МОИ СТРИНГИ!!!
		["bm_menu_armor_pickup_1"] = "Подбор патронов: #{skill_color}#$armor_pickup## от нормального значения.",

		["bm_menu_append_milliseconds"] = " мс",
		["bm_menu_dodge_grace"] = "Увеличение длительности периода бессмертия при Увороте: #{skill_color}#$grace_bonus##\n\nПериод бессмертия - время, во время которого вы не можете получить урон или потерять Уворот.",
		["bm_menu_dodge_grace_cap"] = "Максимальное увеличение длительности периода бессмертия равно #{important_1}#$grace_bonus_cap##, потому что стоит ",
		["bm_menu_dodge_grace_jp_cap"] = "модификатор #{important_1}#Pro-Job##",
		["bm_menu_dodge_grace_both"] = " и ",
		["bm_menu_dodge_grace_diff_cap"] = "сложность #{risk}#$risk_level##",

		["bm_menu_dash_grace"] = "ПЕРИОД БЕССМЕРТИЯ ВО ВРЕМЯ РЫВКА: #{skill_color}#$dash_grace##",
		["bm_menu_dash_grace_dodge"] = "\n - ВМЕСТЕ С УВОРОТОМ: #{skill_color}#$dash_grace_dodge##",

		["bm_menu_armor_grinding_1"] = "Восстановление брони за раз: #{skill_color}#$passive_armor_regen##",
		["bm_menu_armor_grinding_2"] = "Восстановление брони за раз: #{skill_color}#$passive_armor_regen## \nВосстановление брони за нанесение урона: #{skill_color}#$active_armor_regen##",

		["bm_menu_armor_max_health_store_1"] = "Кколичество получаемого за убийство запасного здоровья: #{skill_color}#$health_stored##",
		["bm_menu_armor_max_health_store_2"] = "Количество получаемого за убийство запасного здоровья: #{skill_color}#$health_stored## \nВосстановление брони за убийство: #{skill_color}#$regen_bonus%##",
		
		["bm_menu_bonus"] = "Модификаторы",
		["steam_inventory_stat_boost"] = "Модификатор атрибутов",
		
		
		
		
		
		["bm_menu_custom_plural"] = "WEAPON ATTACHMENTS IN THE CUSTOM CATEGORY", --unused?--

		----Custom Weapon Mod Descriptions----

		--Is there a reason these have to be down here? If not, I'll move them up with the others (custom weapons in their own section dw)--

		--Triad Chi-Revolver [Custom]
		["bm_wp_wpn_fps_upg_triad_bullets_44normal_desc"] = "Why would you use outdated post-Collision ammunition with Chi-Revolvers? Why the fuck do dogs lick their balls?\nMin and max ammo pickup rate: 1.33x",
		["bm_wp_wpn_fps_upg_triad_bullets_44ap_desc"] = "Assblast your enemies through walls, armor, and shields with these rounds.\nEnables armor, shield, and wall piercing at the cost of damage.",
		["bm_wp_wpn_fps_upg_triad_bullets_44hollow_desc"] = "Chi-fussed hollow rounds stolen from a place of unknown origin. The only thing you need to know is that this shit KICKS hard and the fact that anything on the other end of the barrel is practically vaporized after the gun kicks. Good shit, ain't it?\nThis ammunition is much harder to find in ammo drops.\nEverything else lowered in favor of damage, and pickup rate.\nMin and max ammo pickup rate: 0.33x",

		--DECK-ARD [Custom]
		["bm_wp_wpn_fps_upg_deckard_ammo_damage_high_desc"] = "Shoot them so dead they'll die in hell.\nMassive damage at the cost of everything else.\nCapable of piercing through armor, walls and shields.\nThis ammunition is much harder to find in ammo drops.\nMin and max ammo pickup rate: 0.33x",
		["bm_wp_wpn_fps_upg_deckard_ammo_damage_med_desc"] = "Shoot them dead.\nThis ammunition is substantially easier to find in ammo drops.\nMin and max ammo pickup rate: 1.33x",

		--Unknown Weapon
		["bm_wp_wpn_fps_ass_tilt_a_fuerte"] = "7.62mm Conversion Kit",
		["bm_wp_wpn_fps_ass_tilt_a_fuerte_desc"] =  "Converts the weapon's caliber to 7.62mm, which slightly decreases fire rate and stability in favor of increased damage and accuracy.",

		--MK18 Specialist [Custom]
		["bm_wp_wpn_fps_ass_mk18s_a_weak_desc"] = "An ammunition type that mimics medium tier rifles. Lowers ammo count and stability in trade for higher damage and accuracy.",
		["bm_wp_wpn_fps_ass_mk18s_vg_magwell"] = "Magwell Grip",

		--Unknown Weapon
		["bm_wp_wpn_fps_pis_noodle_m_8"] = "Extended Magazine",
		["bm_wp_wpn_fps_pis_noodle_m_10"] = "Extend-o Magazine",

		--Jackal SMG(these are unused though)
		["bm_wp_wpn_fps_upg_schakal_m_atai_desc"] = "Converts the Jackal into the Mastiff, something of the younger sister in the Jackal family. Not as stable as the Coyote, and not as deadly as the Jackal, but atleast it fires rounds that can pierce both armor and walls.",

		--Unknown weapon
		["bm_wp_wpn_fps_upg_am_hollow_large_desc"] = "Open-tipped rounds that, thanks to physics, create larger and more painful wound cavities in their enemies. Although HP rounds are harder to find on enemies and have more recoil, they are thankfully more effective against the head and somewhat more accurate than normal rounds.",
		--Unknown Weapon
		["bm_menu_weirdmagthing"] = "Magwell Grip",

		--Gecko 7.62
		["bm_wp_wpn_fps_ass_galil_m_drum"] = "75 Round Drum Magazine",

		--Cavity 9mm
		["bm_wp_wpn_fps_smg_calico_body_full_desc"] = "Converts to medium pistol tier.\nMin and Max pickup rate: 0.8x",

		--DP-28 [Custom]
		["bm_wp_wpn_fps_lmg_dp28_tripod_top_desc"] = "A tripod with additional ammo mounted on its side.\nReduces movement speed by 20% when equipped.",

		--Arbiter
		["bm_wp_wpn_fps_gre_arbiter_o_smart_desc"] = "Experimental scope that provides airburst capabilites to the Arbiter.\nIncompatible with incendiary rounds.", --this weapon mod isn't vanilla though iirc--

		--Itachi [Custom]
		["bm_wp_wpn_fps_upg_bajur_m_pants"] = "NO",
		["bm_wp_wpn_fps_upg_bajur_fg_dmr_desc"] = "Replaces the upper receiver of the Itachi with a .50 Beowulf variant, making the weapon kick a hell of a lot harder, but increasing the size of bulletholes made on law enforcers ten-fold.\n Reduces all stats, except for accuracy and power.",
		
		--Duke Nukem' 1911
		["bm_w_duke1911_desc"] = "#{risk}#Встречай короля, детка!##",
		
		--AF2011
		["bm_af2011_sc_desc"] = "Если нужны парные пистолеты, но вам держать их неудобно - это #{risk}#двухствольное## чудо техники для вас.",
		["bm_wp_upg_af2011_a_uno_desc"] = "Позволяет стрелять из стволов поочередно.",
		
		--Nagant Revolver
		["bm_m1895_sc_desc"] = "Семизарядный револьвер прямиком из конца 19-ого века, который можно оснастить глушителем.#{risk}# Увы, но какой-то умник заменил барабан на стандартный.##\n\n#{skill_color}#Может пробивать броню, врагов, щитов и тонкие стены.##\n\nАльтернативный огонь выпускает боезапас с #{skill_color}#повышенной скоростью## за счет #{important_1}#отдачи, точности и невозможности прицеливания.##",

		--.50 Cal Deagle
		["bm_w_degfifty"] = "Дигл, но есть 50-калиберный нюанс",
		["menu_l_global_value_degfiftymod"] = "Какой-какой калибр???",
		
		--M6D
		["bm_w_m6d_desc"] = "Супероружие галагтического масштаба, способное поразить любую форму жизни на расстоянии 25 тысяч световых лет.",
		
		--BIG Chimano 88
		["menu_l_global_value_bigglockmod"] = "Вот он! Вот он, пистолет моей мечты! Здоровенный!",
		
		--FP6
		["bm_w_fpsix_desc"] = "Этот помповый дробовик был подобран с мертвого оперативника Мурок по прозвищу Гоуст.",
		
		--псп
		["menu_l_global_value_umd_launcher"] = "Предмет из набора SMOD!",
		["bm_w_umd_launcher_desc"] = "/give weapon_psp\n\nА, стоп, не та игра.",
		--испанский стыд гамбита
		["bm_w_toym16_sc_desc"] = "Больше не захочется жаловаться на пластиковые винтовки, когда в руках оказывается ЭТО. Зато патронов много.",
		["bm_w_toy1911_sc_desc"] = "Даже для страйкбола не подойдет. Удачи.",
		--дабстепгана нет, хоть с клавиаутурой побегать можно
		["bm_w_nckuro"] = "Диванный Воин",
		["bm_w_nckuro_desc"] = "Не стоит насмехаться над вашим напарником с этим изрыгателем #{risk}#самонаводящимися клавишами##.\nПервый в мире прославившийся диванный воин пролежал на печи 30 лет и 3 года.\nА второй в мире диванный воин вас пушками снабжает.",
		--Bipod
		["bm_sc_bipod_desc_pc"] = "Расставляются при нажатии #{skill_color}#$BTN_BIPOD##, если позволяет место. Нажмите клавишу снова, чтобы убрать.\n\nУменьшают отдачу на #{skill_color}#60%## и увеличивают расстоянии #{skill_color}#30%## во время использования.\n\n#{item_stage_2}#Дополнительные настройки для сошек можно найти в настройках Restoration Mod.##",
		["bm_sc_bipod_desc"] = "Расставляются при удержании #{skill_color}#$BTN_BIPOD##, если позволяет место. Удержите кнопку снова, чтобы убрать.\n\nУменьшают отдачу на #{skill_color}#60%## и увеличивают расстоянии #{skill_color}#30%## во время использования.\n\n#{item_stage_2}#Дополнительные настройки для сошек можно найти в настройках Restoration Mod.##",
		["hud_hint_bipod_moving"] = "Нельзя развернуть во время ходьбы",
		["hud_hint_bipod_slide"] = "Нельзя развернуть во время переката",
		["hud_hint_bipod_air"] = "Нельзя развернуть в воздухе",
		["hud_hint_bipod_lean"] = "Нельзя развернуть при наклоне",
		["hud_hint_bipod_midstance"] = "Нельзя развернуть, пока вы приседаете/встаете",
		--и рыбку сьесть и прицел? обойдешься!
		["hud_hint_fatty"] = "Вы перегружены и не можете прицелиться!",
		
		--Для разных шокеров--
		["bm_melee_funder_strike"] = "Шоковая дубинка",
		["bm_melee_funder_strike_info"] = "#{skill_color}#\"Подними эту банку.\"##\n\nВосстановленная дубинка, все еще пригодная для шоковых терапий.\n\n#{skill_color}#Электрезирует при попадании,## оглушая большинство врагов; для оглушения особых и элитных врагов необходим полностью заряженный удар.\n#{important_1}#Титановые Щиты, Титановые Тазеры, Титановые Бульдозеры и капитаны невосприимчивы к его оглушающему эффекту.##",
		["bm_melee_zeus_info"] = "Эти кастеты могут выглядеть неустойчивыми, но не волнуйтесь, его сделал какой-то подросток в интернете, так что безопасность гарантирована! Самодельное и экспериментальное электричество в потрясающе эффектном исполнении. \n\n#{skill_color}#Электрезирует при попадании,## оглушая большинство врагов; для оглушения особых и элитных врагов необходим полностью заряженный удар.\n#{important_1}#Титановые Щиты, Титановые Тазеры, Титановые Бульдозеры и капитаны невосприимчивы к его оглушающему эффекту.##",
		["bm_melee_taser_info"] = "Это то, чего вы так долго ждали - воплощение сладкой, электризующей мести этим самодовольным Тазерам. Самое время им познать мощь своего арсенала на себе!\n\n#{skill_color}#Электрезирует при попадании,## оглушая большинство врагов; для оглушения особых и элитных врагов необходим полностью заряженный удар.\n#{important_1}#Титановые Щиты, Титановые Тазеры, Титановые Бульдозеры и капитаны невосприимчивы к его оглушающему эффекту.##",
		
		--пабаджи или пуйдуй?
		["bm_melee_bonk_info"] = "Не для готовки...",
		["bm_melee_bonk2_info"] = "#{risk}#Выигрыш есть — можно и поесть!##\n\nИмеет #{skill_color}#10%## шанс нанести #{skill_color}#десятикратные## урон и нокдаун.",

		-- Renamed default weapons and mods + descriptions-- --move all these to their respective weapons--

	    ["bm_wp_pis_usp_b_match"] = "Затвор Фримена",
		["bm_wp_1911_m_big"] = "Коробчатый магазин",
		["bm_wp_usp_m_big"] = "Коробчатый магазин",
		["bm_wp_upg_ass_ak_b_zastava"] = "Длинный ствол",
		["bm_wp_upg_ass_m4_b_beowulf"] = "Ствол Вульфа",
		["bm_wp_p90_b_ninja"] = "Ниндзя-ствол",
		["bm_wp_par_b_short"] = "Укороченный ствол",

		["menu_es_rep_upgrade"] = "",	--???--

		["bm_w_x_shrew"] = "Барри и Пол",
		["bm_w_x_1911"] = "Мустанг и Салли",

		["bm_wp_mp5_fg_mp5sd"] = "Цевье агента",
		["bm_wp_hs2000_sl_long"] = "Элитный затвор",
		["bm_wp_vhs_b_sniper"] = "Гипер-ствол",
		["bm_w_r0991"] = "Пистолет AR-15 Varmint",
		["bm_wp_vhs_b_silenced"] = "Ствол 'Bad Dragan'",
		["bm_wp_wpn_fps_lmg_shuno_body_red"] = "Красный корпус",
		["bm_wp_g3_b_sniper"] = "Макро-ствол",
		["bm_wp_g3_b_short"] = "Микро-ствол",
		["bm_wp_g3_m_psg"] = "Магазин 'Präzision'",
		["bm_wp_upg_i_g3sg1"] = "Система 'Präzision'",
		["bm_wp_upg_i_g3sg1_desc"] = "Позволяет использовать мощные боеприпасы, которые #{skill_color}#полностью пробивают броню и щиты.## Некоторые части оружия заменены на более тяжелые, что в итоге #{important_1}#уменьшает скорострельность## и позволяет вести огонь только #{risk}#очередью##.",

		--VMP HK416c Fixed Stock
		["bm_wp_tecci_s_minicontra_alt"] = "Укрепленный приклад SG",

		["bm_w_beck_desc"] = "Самый популярный дробовик в криминальном мире вернулся в погоне за былой славой. Он использовался в оригинальной волне преступности 2011-го года и доказал свою надеждность в практически любой близкой конфронтации.",



		--Модификаторы-- 
		["bm_menu_bonus_concealment_p1"] = "Маленький бонус к Компактности и штраф к Стабильности",
		["bm_menu_bonus_concealment_p1_mod"] = "Маленький модификатор Компактности",
		["bm_menu_bonus_concealment_p2"] = "Большой бонус к Компактности и штраф к Стабильности",
		["bm_menu_bonus_concealment_p2_mod"] = "Большой модификатор Компактности",
		["bm_menu_bonus_concealment_p3"] = "Огромный бонус к Компактности и штраф к Стабильности",
		["bm_menu_bonus_concealment_p3_mod"] = "Огромный модификатор Компактности",
		["bm_menu_bonus_spread_p1"] = "Маленький бонус к Точности и штраф к Стабильности",
		["bm_menu_bonus_spread_p1_mod"] = "Маленький модификатор Точности",
		["bm_menu_bonus_spread_n1"] = "Огромный бонус к Стабильности и штраф к Точности",
		["bm_menu_bonus_recoil_p3_mod"] = "Огромный модификатор Стабильности",
		["bm_menu_bonus_recoil_p1"] = "Маленький бонус к Стабильности и штраф к Точности",
		["bm_menu_bonus_recoil_p1_mod"] = "Маленький модификатор Стабильности",
		["bm_menu_bonus_recoil_p2"] = "Большой бонус к Стабильности и штраф к Точности",
		["bm_wp_upg_bonus_team_exp_money_p3_desc"] = "+5% опыта для вас и вашей команды.",
		["bm_menu_spread"] = "Точность\n",
		["bm_menu_recoil"] = "Стабильность\n",
		["bm_menu_concealment"] = "Компактность\n",
		["bm_menu_bonus_spread_p2_mod"] = "Большой модификатор точности",
		["bm_menu_bonus_spread_p3_mod"] = "Огромный модификатор точности",
		["bm_menu_bonus_recoil_p2_mod"] = "Большой модификатор стабильности",
		["bm_wp_upg_bonus_team_money_exp_p1"] = "Денежный бонус",
		["bm_wp_upg_bonus_team_money_exp_p1_desc"] = "+5% к денежной награде для вас и команды.",

		["bm_wp_upg_i_singlefire_desc"] = "ОСТАВЛЯЕТ ТОЛЬКО #{risk}#ОДИНОЧНУЮ СТРЕЛЬБУ##.",
		["bm_wp_upg_i_autofire_desc"] = "ОСТАВЛЯЕТ ТОЛЬКО #{risk}#АВТОМАТИЧЕСКУЮ СТРЕЛЬБУ##.",

		["menu_akimbo_assault_rifle"] = "Парные винтовки",
		
		--Всякое бросаемое--
		["bm_grenade_copr_ability"] = "Ампула",
		["bm_grenade_damage_control"] = "Фляжка",
		["bm_concussion_desc"] = "Радиус: #{skill_color}#10 м## \nШанс подбора от коробки с патронами: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\nОглушает врагов на промежуток до #{skill_color}#4## секунд \nТочность врагов уменьшается на #{skill_color}#50%## на #{skill_color}#7## секунд \nНе прерывает действия #{important_1}#Титановых Щитов, Титановых Бульдозеров и Капитанов.## \n\nЭто сногсшибательная штучка поразит всех и даст вам лишние секунды чтобы их убить.",
		["bm_grenade_smoke_screen_grenade_desc"] = "Радиус: #{skill_color}#6 м## \nДлительность: #{skill_color}#12 секунд## \nДетонация: #{skill_color}#1 сек после падения на землю## \n \nИспользуйте, чтобы испариться в клубе дыма, через который врагам будет сложно попасть по вам.",
		["bm_grenade_frag_desc"] = "Урон: #{skill_color}#800## \nРадиус: #{skill_color}#5 м## \nДетонация: #{skill_color}#3 сек#{skill_color}# \nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n \nКлассическая осколочная граната. Не требует лишних слов.",
		["bm_dynamite_desc"] = "Урон: #{skill_color}#800## \nРадиус: #{skill_color}#4м## \nДетонация: #{skill_color}#3 сек##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\nНе отскакивает и не катится после приземления, но наносит меньше урона от взрыва, чем другая взрывчата.\n\nПридуман, чтобы взрывать камень. Вполне подходит, чтобы взрывать людей.",
		["bm_grenade_frag_com_desc"] = "Урон: #{skill_color}#800## \nРадиус: #{skill_color}#5 м## \nДетонация: #{skill_color}#3 сек##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\n\nОбновленная классическая граната, она придаст каждому взрыву стиль OVERKILL.",
		["bm_grenade_dada_com_desc"] = "Урон: #{skill_color}#800## \nРадиус: #{skill_color}#5 м## \nДетонация: #{skill_color}#3 сек##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n\nВнешний вид матрешки скрывает ее взрывоопасные внутренности. Дань Родине.",
		["bm_grenade_molotov_desc"] = "Урон (Огненная лужа): #{heat_warm_color}#1200 в течение 10 сек.## \nУрон (Огонь): #{heat_warm_color}#180 в течение 3 сек.## \nУрон (Взрыв): #{heat_warm_color}#30## \nРадиус (Взрыв): #{skill_color}#3 м##\nРадиус (Огненная лужа): #{skill_color}#3,75 м## \nДлительность (Огненная лужа): #{skill_color}#10 сек.## \nДетонирует при попадании\nОгненная лужа имеет #{skill_color}#50%## шанс поджечь врагов, заставляя остальных паниковать.\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\n\nБутылка с огнеопасной жидкостью и горящей тряпкой. Дешево, просто и крайне эффективно. Спалите все к чертям.",
		["bm_grenade_molotov_desc_short"] = "Урон (Огненная лужа): #{heat_warm_color}#1200 в течение 10 сек.## \nУрон (Огонь): #{heat_warm_color}#180 в течение 3 сек.## \nУрон (Взрыв): #{heat_warm_color}#30## \nРадиус (Взрыв): #{skill_color}#3 м##\nРадиус (Огненная лужа): #{skill_color}#3,75 м## \nДлительность (Огненная лужа): #{skill_color}#10 сек.## \nДетонирует при попадании\nОгненная лужа имеет #{skill_color}#50%## шанс поджечь врагов, заставляя остальных паниковать.\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##",
		["bm_grenade_fir_com_desc"] = "Урон (Огненная лужа): #{heat_warm_color}#1440 в течение 12 сек.## \nУрон (Взрыв): #{heat_warm_color}#120## \nРадиус (Взрыв): #{skill_color}#4,5 м##\nРадиус (Огненная лужа): #{skill_color}#3,75 м## \nДлительность (Огненная лужа): #{skill_color}#12 сек.## \nДетонация: #{skill_color}#2.5 сек.##\nОгненная лужа имеет #{skill_color}#50%## шанс поджечь врагов, заставляя остальных паниковать.\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\n\nСамоподжигающийся фосфорный контейнер. Идеален для отскакивания от стен за угол, к вашим противникам.",
		["bm_grenade_fir_com_desc_short"] = "Урон (Огненная лужа): #{heat_warm_color}#1440 в течение 12 сек.## \nУрон (Взрыв): #{heat_warm_color}#120## \nРадиус (Взрыв): #{skill_color}#4,5 м##\nРадиус (Огненная лужа): #{skill_color}#3,75 м## \nДлительность (Огненная лужа): #{skill_color}#12 сек.## \nДетонация: #{skill_color}#2.5 сек.##\nОгненная лужа имеет #{skill_color}#50%## шанс поджечь врагов, заставляя остальных паниковать.\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##",
		["bm_wpn_prj_ace_desc"] = "Урон: #{skill_color}#$damage## \nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n- #{skill_color}#Считается оружием ближнего боя.## \n\nМетательные игральные карты с лезвием. Убийственная колода.",
		["bm_wpn_prj_four_desc"] = "Урон (Попадание): #{skill_color}#$damage## \nУрон (Яд): #{stats_positive}#120 в течение 4 секунд## \n- #{skill_color}#Считается оружием ближнего боя только для прямых попаданий.## \n\n#{skill_color}#50%## шанс прервать врага каждые 0.5 секунд. \nНе прерывает действия #{important_1}#Щитов, Бульдозеров, Гренадеров и Капитанов.##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\n \nУ метательной звезды богатая история, полная крови и битв. Эти смазанные ядом звездочки несут угрозу всем, кто стоит у вас на пути.",
		["bm_wpn_prj_four_desc_short"] = "Урон (Попадание): #{skill_color}#$damage## \nУрон (Яд): #{stats_positive}#120 в течение 4 секунд## \n#{skill_color}#50%## шанс прервать врага каждые 0.5 секунд. \nНе прерывает действия #{important_1}#Щитов, Бульдозеров, Гренадеров и Капитанов.## \nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##",
		["bm_wpn_prj_target_desc"] = "Урон: #{skill_color}#$damage##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n- #{skill_color}#Считается оружием ближнего боя.## \n \nОтличный запасной план и надежная тактика для точного, бесшумного убийства.",
		["bm_wpn_prj_jav_desc"] = "Урон: #{skill_color}#$damage## \nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n- #{skill_color}#Считается оружием ближнего боя.## \n \nКопье - простое оружие, придуманное еще в доисторические времена. Простая палка с острым концом, которая испортит кому-нибудь день.",
		["bm_wpn_prj_hur_desc"] = "Урон: #{skill_color}#$damage## \nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n- #{skill_color}#Считается оружием ближнего боя.## \n \nГоворят, заточенный топор никогда не ошибается. Метательный заточенный топор уж тем более.",
		["bm_grenade_electric_desc"] = "Урон: #{skill_color}#400## \nРадиус: #{skill_color}#5 м## \nДетонация: #{skill_color}#3 сек## \nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\nНе прерывает действия #{important_1}#Щитов, Бульдозеров, Гренадеров и Капитанов.##\n\nВзрывы - это неплохо, но иногда хочется кого-нибудь поджарить. Эта милая высоковольтная штучка отлично подойдет.",
		["bm_grenade_poison_gas_grenade"] = "Граната Manticore-6",
		["bm_grenade_poison_gas_grenade_desc"] = "Урон: #{stats_positive}#300 за 10 сек## \nРадиус: #{skill_color}#8 м## \nДлительность: #{skill_color}#12 сек## \nДетонация: #{skill_color}#1 сек после падения на землю##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##\nВраги могут отравиться каждым облаком только один раз.\nНе прерывает действия #{important_1}#Щитов, Гренадеров, Бульдозеров и Капитанов.##\n\nЭто экспериментальное био-оружие выпускает облако ядовитого газа, которое влияет только на особые гены - у банды полный иммунитет. Жертвы почувствуют сильный кашель, головокружение и рвоту. Опасно для всех, кроме самых бронированных врагов.\n\nОружие военного преступника.",
		["bm_grenade_poison_gas_grenade_desc_short"] = "Урон: #{stats_positive}#300 за 10 сек## \nРадиус: #{skill_color}#8 м## \nДлительность: #{skill_color}#12 сек## \nДетонация: #{skill_color}#1 сек после падения на землю##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок##",
		["bm_grenade_sticky_grenade"] = "Граната 'Семтекс'",
		["bm_grenade_sticky_grenade_desc"] = "Урон: #{skill_color}#800## \nРадиус: #{skill_color}#4 м## \nДетонация: #{skill_color}#2.5 сек##\nШанс подбора: #{skill_color}#от $pickup_1 до $pickup_2 коробок## \n\nВзрывчатое вещество, которое прилипает к любым поверхностям, включая людей!",
		["bm_grenade_xmas_snowball"] = "Снежный ком",
		["bm_grenade_xmas_snowball_desc"] = "Урон: #{skill_color}#180## \nРадиус: #{skill_color}#1 м## \nДетонация: При попадании \nВремя восстановления: #{skill_color}#1 снежок раз в $regen##\n#{skill_color}#$regen_t## к восстановлению снежка за поднятную коробку с патронами \n\nОпустите их в воду, засуньте в морозильник и вот у вас смертоносное оружие. Легко.",


		["bm_wp_wpn_fps_upg_scar_m203_buckshot"] = "Снаряды 40MM Buckshot",
		["bm_wp_wpn_fps_upg_scar_m203_buckshot_desc"] = "Снаряд заряжен 6-ю тяжелыми дробинками.\n\nБоезапас: 15\nУрон: 360\nТочность: 40\nЭффективная дистанция: 9м\nМаксимальная дистанция: 18м",
		["bm_wp_wpn_fps_upg_scar_m203_flechette"] = "Снаряды 40MM Flechette",
		["bm_wp_wpn_fps_upg_scar_m203_flechette_desc"] = "Снаряд заряжен 12 маленькими дальнобойными дротиками.\n\nБоезапас: 20\nУрон: 240\nТочность: 50\nЭффективная дистанция: 11м\nМаксимальная дистанция: 22м",

		["bm_wp_wpn_fps_upg_g3m203_gre_buckshot"] = "Снаряды 40MM Buckshot",
		["bm_wp_wpn_fps_upg_g3m203_gre_buckshot_desc"] = "Снаряд заряжен 6-ю тяжелыми дробинками.\n\nБоезапас: 15\nУрон: 360\nТочность: 40\nЭффективная дистанция: 9м\nМаксимальная дистанция: 18м",
		["bm_wp_wpn_fps_upg_g3m203_gre_flechette"] = "Снаряды 40MM Flechette",
		["bm_wp_wpn_fps_upg_g3m203_gre_flechette_desc"] = "Снаряд заряжен 12 маленькими дальнобойными дротиками.\n\nБоезапас: 20\nУрон: 240\nТочность: 50\nЭффективная дистанция: 11м\nМаксимальная дистанция: 22м",
	})
end)
-- Названия оружий в зависимости от настройки
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Weapon_Names", function(loc)
	local weapon_names = restoration.Options:GetValue("OTHER/WepNames") or 1
		--[[
		WepNames Options
		1 = Имена оружия на кириллице
		2 = Имена оружия на латинице
		3 = Имено оружия и атачментов от DMC
		4 = Ванильные
	]]


		if weapon_names then
			if weapon_names == 2 then -- Латиница
				LocalizationManager:add_localized_strings({
		["bm_w_maxim9"] = "Magnus 9",
		["bm_w_x_maxim9"] = "Парные Magnus 9",
		["bm_w_stech"] = "Igor Automatik",
		["bm_w_x_stech"] = "Парные Igor Automatik",
		["bm_wp_pis_g26"] = "Chimano 26 Compact",
		["bm_w_jowi"] = "Парные Chimano 26 Compact",
		["bm_w_glock_18c"] = "Chimano 18C",
		["bm_w_x_g18c"] = "Парные Chimano 18C",
		["bm_w_czech"] = "CR 92",
		["bm_w_x_czech"] = "Парные CR 92",
		["bm_w_ppk"] = "Gruber Kurz",
		["bm_w_x_ppk"] = "Парные Gruber Kurz",
		["bm_w_pmm"] = "Strix",
		["bm_w_x_pmm"] = "Парные Strix",
		["bm_w_legacy"] = "M13",
		["bm_w_x_legacy"] = "Парные M13",
		["bm_w_glock_17"] = "Chimano 88",
		["bm_w_x_g17"] = "Парные Chimano 88",
		["bm_w_b92fs"] = "Bernetti 92",
		["bm_w_x_b92fs"] = "Парные Bernetti 92",
		["bm_w_pl14"] = "White Streak",
		["bm_w_x_pl14"] = "Парные White Streak",
		["bm_w_holt"] = "HOLT 9",
		["bm_w_x_holt"] = "Парные HOLT 9",
		["bm_w_fmg9"] = "Wasp DS-9",
		["bm_w_beer"] = "Bernetti 93R",
		["bm_w_packrat"] = "Contractor M30L",
		["bm_w_x_packrat"] = "Парные Contractor M30L",
		["bm_w_breech"] = "Parabellum-08",
		["bm_w_g22c"] = "Chimano Custom",
		["bm_w_x_g22c"] = "Парные Chimano Custom",
		["bm_w_p226"] = "Signature .40",
		["bm_w_hs2000"] = "LEO-40",
		["bm_w_lemming"] = "Acuto 5/7",
		["bm_w_sparrow"] = "Sparrow 941",
		["bm_w_x_sparrow"] = "Spike & Vicious",
		["bm_w_speen"] = "Ballerina 9mm",
		["bm_w_socom"] = "Anubis .45",
		["bm_w_x_socom"] = "Парные Anubis .45",
		["bm_w_colt_1911"] = "Crosskill Operator II",
		["bm_w_x_1911"] = "Mustang & Sally",
		["bm_w_m1911"] = "Crosskill A1",
		["bm_w_x_m1911"] = "Price & MacTavish",
		["bm_w_shrew"] = "Crosskill Guard",
		["bm_w_shrew_joshua"] = "A Light Shining in Darkness",
		["bm_w_x_shrew"] = "Barry & Paul",
		["bm_w_usp"] = "Interceptor-45",
		["bm_w_x_usp"] = "Парные Interceptor-45",
		["bm_w_type54"] = "CC-33",
		["bm_w_x_type54"] = "Парные CC-33",
		["bm_w_c96"] = "Broomstick",
		["bm_w_c96_dl44"] = "DL-44",
		["bm_wp_c96_nozzle"] = "Насадка BlasTech DL-44",
		["bm_w_sub2000"] = "Cavity .40",
		["bm_w_deagle"] = "Deagle",
		["bm_w_x_deagle"] = "Парные Deagle",
		["bm_w_korth"] = "Kahn .357",
		["bm_w_x_korth"] = "Парные Kahn .357",
		["bm_w_mateba"] = "Matever 9mm",
		["bm_w_x_2006m"] = "Парные Matever",
		["bm_w_model3"] = "Frenchman 87",
		["bm_w_x_model3"] = "Парные Frenchman 87",
		["bm_w_raging_bull"] = "Bronco .44",
		["bm_w_x_rage"] = "Парные Bronco .44",
		["bm_w_chinchilla"] = "Castigo .44",
		["bm_w_x_chinchilla"] = "Парные Castigo .44",
		["bm_w_rsh12"] = "RUS-12",
		["bm_w_shatters_fury"] = "Phoenix .500",
		["bm_w_peacemaker"] = "Peacemaker .45LC",
		["bm_w_hpb"] = "Hi-Power",
		["bm_w_p99"] = "Lakner G99",
		["bm_w_derringer"] = "Derringer",
		["bm_w_amt"] = "Automag .44",
		["bm_w_coltds"] = "Crosskill Investigator",
		["kfa_scope"] = "Прицел KFA-2 Smart-Link",
		["bm_w_px4"] = "Bernetti Hx4 Canaan",
		["bm_w_papa320"] = "M19",
		["bm_w_p90"] = "Project-90",
		["bm_w_x_p90"] = "Парные Project-90",
		["bm_w_mp7"] = "SpecOps-7",
		["bm_w_tec9"] = "T3K Urban",
		["bm_w_x_tec9"] = "Парные T3K Urban",
		["bm_w_sr2"] = "Heather-2M",
		["bm_w_x_sr2"] = "Парные Heather-2M",
		["bm_w_mp9"] = "CMP-9",
		["bm_w_pm9"] = "Miyaka 9 Special",
		["bm_w_baka"] = "Micro Uzi",
		["bm_w_x_baka"] = "Парные Micro Uzi",
		["bm_w_scorpion"] = "Cobra",
		["bm_w_x_scorpion"] = "Парные Cobra",
		["bm_w_coal"] = "Tatonka",
		["bm_w_vityaz"] = "AK Gen 21 Tactical",
		["bm_w_shepheard"] = "Signature PC9",
		["bm_w_mp5"] = "Compact-5",
		["bm_w_mp5sd"] = "Compact-5SD",
		["bm_w_mp5k"] = "Compact-5K",
		["bm_w_mp5k_pdw"] = "Compact-5K PDW",
		["bm_w_x_mp5"] = "Парные Compact-5",
		["bm_w_m45"] = "Swedish K",
		["bm_w_sterling"] = "Patchette L2A3",
		["bm_w_sterling_sd"] = "Patchette L34A1",
		["bm_w_sterling_pistol"] = "Patchette Mk. VII",
		["bm_w_sterling_e11"] = "E-11",
		["bm_wp_sterling_b_e11"] = "Ствол BlasTech E-11",
		["bm_w_uzi"] = "Uzi",
		["bm_w_m1928"] = "Chicago Typewriter",
		["bm_w_mac10"] = "Mark 10",
		["bm_w_x_mac10"] = "Парные Mark 10",
		["bm_w_erma"] = "MP 40",
		["bm_w_schakal"] = "Jackal",
		["bm_w_polymer"] = "Kross Vertex",
		["bm_w_alpha57_prim"] = "FSS Hurricane",
		["bm_w_smg45"] = "FT Striker .45",
		["bm_w_fang45"] = "Fang 45",
		["bm_w_crysis3_typhoon"] = "CRYNET Typhoon",
		["bm_w_m7caseless"] = "Misriah Armory M7",
		["bm_w_m7caseless_supp"] = "Misriah Armory M7S",
		["bm_w_x_m7caseless"] = "Парные M7",
		["bm_w_x_m7caseless_supp"] = "Парные M7S",
		["bm_w_tecci"] = "Bootlegger",
		["bm_w_m249"] = "KSP-90",
		["bm_w_rpk"] = "RPK",
		["bm_w_hk21"] = "Brenner-21",
		["bm_w_kacchainsaw"] = "Campbell 74",
		["bm_w_m60"] = "M60",
		["bm_w_par"] = "KSP-58B",
		["bm_w_mg42"] = "Buzzsaw-42",
		["bm_w_mg42_dlt19"] = "DLT-19",
		["bm_wp_mg42_b_vg38"] = "Ствол BlasTech DLT-19",
		["bm_w_hk51b"] = "Versteckt-51B",
		["bm_w_basset"] = "Grimm 12G",
		["bm_w_x_basset"] = "Brothers Grimm 12G",
		["bm_w_saiga"] = "IZHMA 12G",
		["bm_w_aa12"] = "Steakout 12G",
		["bm_w_spas12"] = "Predator 12G",
		["bm_w_benelli"] = "M1014 12G",
		["bm_w_ultima"] = "Argos III 12G",
		["bm_w_supernova"] = "Deimos 12G",
		["bm_w_striker"] = "Street Sweeper 12G",
		["bm_w_rota"] = "Goliath 12G",
		["bm_w_sko12"] = "VD-12G",
		["bm_w_x_sko12"] = "Парные VD-12G",
		["bm_w_m37"] = "GSPS 12G",
		["bm_w_serbu"] = "Locomotive 12G",
		["bm_w_m1897"] = "Repeater 1897 12G",
		["bm_w_m590"] = "Mosconi Tactical 12G",
		["bm_w_r870"] = "Reinfeld 880 12G",
		["bm_w_ksg"] = "Raven 12G",
		["bm_w_boot"] = "Breaker 10G",
		["bm_w_coach"] = "Claire S/S 12G",
		["bm_w_huntsman"] = "Mosconi S/S 12G",
		["bm_w_judge"] = "The Judge",
		["bm_w_x_judge"] = "Judge & Jury",
		["bm_w_b682"] = "Joceline O/U 12G",
		["bm_w_quadbarrel"] = "Doomstick",
		["bm_w_mp153"] = "Argos I",
		["bm_w_s552"] = "Commando 552",
		["bm_w_amcar"] = "AM-CAR",
		["bm_w_g36"] = "JP-36KV",
		["bm_w_g36_k"] = "JP-36K",
		["bm_w_g36_c"] = "JP-36C",
		["bm_w_g36_v"] = "JP-36V",
		["bm_w_g36_long"] = "JP-36",
		["bm_w_vhs"] = "Lion's Roar",
		["bm_w_olympic"] = "Para-23",
		["bm_w_x_olympic"] = "Парные Para-23",
		["bm_w_komodo"] = "Tempest-95",
		["bm_w_famas"] = "Clarion 5.56",
		["bm_w_osipr"] = "SABR",
		["bm_w_osipr_gl"] = "SABR - гранатомет",
		["bm_w_m4"] = "CAR-4",
		["bm_w_m4_mk12"] = "CAR-12 SPR",
		["bm_w_m4_lr300"] = "TR-300",
		["bm_wp_upg_fg_m4a1"] = "Em-Four Kit",
		["bm_w_ak5"] = "Ak 5",
		["bm_w_ak5b"] = "Ak 5B",
		["bm_w_ak5c"] = "Ak 5C",
		["bm_w_ak5_fnc"] = "VF Carabine",
		["bm_w_corgi"] = "Union 5.56",
		["bm_w_aug"] = "UAR A2",
		["bm_w_aug_a3"] = "UAR A3",
		["bm_w_aug_f90"] = "Raptor 90",
		["bm_w_ak12"] = "AK-17",
		["bm_w_ak74"] = "AK 5.45",
		["bm_w_hajk"] = "CR 805B",
		["bm_w_m16"] = "AMR-16",
		["bm_w_m16a1"] = "AMR-16A1",
		["bm_w_l85a2"] = "Queen's Wrath",
		["bm_w_akm"] = "AK 7.62",
		["bm_w_akm_gold"] = "Золотой AK 7.62",
		["bm_w_groza"] = "OB-14st Byk-1",
		["bm_w_tkb"] = "Rodion 3B",
		["bm_w_akmsu"] = "Krinkov",
		["bm_w_x_akmsu"] = "Парные Krinkov",
		["bm_w_tilt"] = "KVK-99",
		["bm_w_g36k"] = "JP36K",
		["bm_w_rk62"] = "Velmer",
		["bm_w_t9fastburst"] = "CARV.2",
		["bm_w_mcbravo"] = "Chimera",
		["bm_w_ar18"] = "CAR-18",
		["bm_w_contraband"] = "Bigger Friend 7.62",
		["bm_w_contraband_m16"] = "Little Friend 5.56",
		["bm_w_contraband_mpx"] = "OMNIA PC9 9mm",
		["bm_w_fal"] = "Falcon 58",
		["bm_w_fal_l1a1"] = "Falcon SLR",
		["bm_w_fal_sa58"] = "Falcon 58 OSW",
		["bm_w_fal_idf"] = "Falcon RMT",
		["bm_w_asval"] = "Valkyria",
		["bm_w_galil"] = "Gecko 7.62",
		["bm_w_galil_galatz"] = "Gekkota 7.62",
		["bm_w_galil_mar"] = "Micro Gecko 7.62",
		["bm_w_galil_556"] = "Gecko 5.56",
		["bm_w_galil_mar_556"] = "Micro Gecko 5.56",
		["bm_w_scar"] = "Eagle Heavy",
		["bm_w_scarl"] = "Eagle Light",
		["bm_w_scar_l"] = "Eagle Light",
		["bm_w_ching"] = "M1 Galant",
		["bm_w_m14"] = "M308",
		["bm_w_g3"] = "Gewehr-3",
		["bm_w_g3_sg1"] = "Gewehr-S1",
		["bm_w_g3_msg"] = "Gewehr-90",
		["bm_w_g3_psg"] = "Präzision Gewehr-1",
		["bm_w_g3_hk33"] = "SG-33",
		["bm_w_g3_hk33_fo3"] = "R91",
		["bm_w_shak12"] = "KS-12 Urban",
		["bm_wp_shak12_body_vks"] = "\"VISha\" Stock",
		["bm_w_hcar"] = "Akron HC",
		["bm_w_hcar_bar"] = "Akron HC",
		["bm_w_mcx_spear"] = "Signature M7",
		["bm_w_vss"] = "Viktoriya",
		["bm_w_g3hk79"] = "Gewehr-A3 w/ GL79",
		["bm_w_xr2"] = "XR-2",
		["bm_w_msr"] = "Rattlesnake",
		["bm_w_r700"] = "Reinfeld Model 700",
		["bm_w_qbu88"] = "Káng Arms X1",
		["bm_w_winchester1874"] = "Repeater 1874",
		["bm_w_tti"] = "Tecci Tactical .308",
		["bm_w_victor"] = "SA North Star",
		["bm_w_scout"] = "Pronghorn",
		["bm_w_wa2000"] = "Lebensauger .300",
		["bm_w_sbl"] = "Rangehitter Mk. 2", --It's not a Beretta gun so "Rangehitter" is the stand-in/fake name for the IRL manufacturer "Marlin"
		["bm_w_contender"] = "Aran G2",
		["bm_w_model70"] = "Platypus 70",
		["bm_w_siltstone"] = "Grom",
		["bm_w_mosin"] = "Nagant",
		["bm_w_desertfox"] = "Desertfox",
		["bm_w_r93"] = "R93",
		["bm_w_awp"] = "Amaroq 900",
		["bm_w_bessy"] = "Flintlock Freddy",
		["bm_w_m95"] = "Thanatos .50 BMG",
		["bm_w_sgs"] = "Guerilla 542",
		["bm_w_m107cq"] = "Mors .50 BMG",
		["bm_w_m200"] = "TF-141",
		["oracle_scope"] = "Oracle TechLink Scope",
	    ["bm_w_m1894"] = "Mare's Leg",
		["bm_w_moss464spx"] = "Mosconi SPX",
		["bm_w_winchester1894"] = "Repeater 1894",
		["bm_w_svd"] = "SV7",
		["bm_w_l115"] = "AIM 90M",
		["bm_wp_hmcar_hd_kit"] = "32bit 8K HD Kit",
		["bm_wp_avelyn"] = "Avelyn Kit",
		["bm_w_gre_m79"] = "GL-40",
		["bm_w_ms3gl"] = "Basilisk 3GL",
		["bm_w_m32"] = "Piglet",
		["bm_w_china"] = "China Puff",
		["bm_w_slap"] = "Compact 40mm",
		["bm_w_arbiter"] = "Arbiter",
		["bm_w_rpg7"] = "HRL-7",
		["bm_w_ray"] = "Commando 101 FLASH",
	--Кастомные оружия
		--Пистолеты
			--PK PSD9
			["bm_w_pkpsd9"] = "PK-PSD9",
			--K5 Pistol (Korean Arms Pack)
			["bm_w_k5"] = "K5",
			--AYY LMAO
			["bm_w_bf2042_ayylmao"] = "Laugo Alien",
			--Piercer 9mm
			["bm_w_rusglock"] = "Piercer",
			--Pinkie.380
			["bm_w_pinkie"] = "Pinkie .380",
			--CR 75 Czechmate
			["bm_w_axewscope"] = "CR 75 Czechmate",
			--High Standard HDM
			["bm_w_hshdm"] = "High Standard HDM",
			--Deagle K4
			["bm_w_limafive"] = "Deagle-K4",
			--S&W Model 500
			["bm_w_swhiskey"] = "S&W Model 500",
			--Bullkick 500
			["bm_w_bk500"] = "Bullkick 500",
			--CR Phantom II
			["bm_czshadow_sc_desc"] = "Вариация пистолета CR 92 без автоматического режима. Создано специально для спортивных состязаний, но разве стрельба по шлемам копов не является спортом?",
			--Javelin 10mm
			["bm_w_baller"] = "Crosskill Javelin",
			["bm_baller_sc_desc"] = "Модернизированный Crosskill, заряжженный 10×25 мм патронами вместо стандартных 11.43х23 мм.", -- в оригинале описания указано, что это подобие чанки кросскила с затвором "Крепкий охотник": и как вы мне прикажете переводить очередной кросскил?
			--Polar 9mm
			["bm_w_polar9_primary"] = "Crosskill Polar",
			["bm_w_polar9"] = "Crosskill Polar",
			["bm_w_x_polar9"] = "Парные Polar",
			["bm_polar9_desc"] = "Попытка модернизировать Crosskill под магазин с двойным стеком и боеприпас 9х19мм. Явный фаворит в спортивной стрельбе.",
			--Рэдфилд
			["bm_w_hipower"] = "Redfield GP-640b",
			["bm_w_x_hipower"] = "Парные Redfield GP-640b",
		--Дробовики
			--PD3 Origin-12
			["bm_w_or12"] = "ORIGIN-12",
			--FP6
			["bm_w_fpsix"] = "FP6",
			--ИТАК???
			["bm_w_stf12"] = "ITA12C",
			--Lunatic .410
			["bm_w_omni"] = "Lunatic .410",
			["bm_w_omni_desc"] = "Младший брат AMR-12. Даже с укороченным патроном .410 калибра ломает колени.\n",
			-- Candy Shotgun
			["bm_w_candy"] = "Candy 12",
			["bm_w_xmassg"] = "Gingerbread 12",
		--Винтовки
			["bm_w_kurisumasu"] = "R-4 Grenadier",
			["bm_xr2_sc_desc"] = "XR-2 - инструмент, подходящий для самых напряженных боев, который оснащен особым спусковым крючком, и имеет #{skill_color}#повышенную скорострельность при стрельбе очередями.##\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##",
			-- VALORANT Bulldog
		    ["bm_w_bulldog_desc"] = "Эта винтовка может стрелять очередями по 3 выстрела, и имеет встроенный прицел. По эффективности похожа на Tempest. Наверное.",
		--Особое
			["bm_w_umd_launcher"] = "UMD Привод",
		--м1991 детей
			["bm_w_toy1911"] = "Игрушечный M1911",
		--м16 детей
			["bm_w_toym16"] = "Игрушечный M16",
				})
		elseif weapon_names == 1 then -- Кириллица
			LocalizationManager:add_localized_strings({

		["bm_w_shatters_fury"] = "Феникс .500",
		["bm_w_osipr"] = "САБР",
		["bm_w_osipr_gl"] = "САБР - подствольник",
		["bm_w_maxim9"] = "Магнус 9",
		["bm_w_x_maxim9"] = "Парные Магнус 9",
		["bm_w_stech"] = "Стычкин Автоматический",
		["bm_w_x_stech"] = "Парные Стычкины",
		["bm_wp_pis_g26"] = "Чимано 26 Компакт",
		["bm_w_jowi"] = "Парные Чимано 26 Компакт",
		["bm_w_glock_18c"] = "Чимано 18C",
		["bm_w_x_g18c"] = "Парные Чимано 18C",
		["bm_w_czech"] = "Чешка 92",
		["bm_w_x_czech"] = "Парные Чешки 92",
		["bm_w_ppk"] = "Грубер Курц",
		["bm_w_x_ppk"] = "Парные Курцы",
		["bm_w_pmm"] = "Стрикс",
		["bm_w_x_pmm"] = "Парные Стрикс",
		["bm_w_legacy"] = "M13",
		["bm_w_x_legacy"] = "Парные M13",
		["bm_w_glock_17"] = "Чимано 88",
		["bm_w_x_g17"] = "Парные Чимано 88",
		["bm_w_b92fs"] = "Бернетти 92",
		["bm_w_x_b92fs"] = "Парные Бернетти 92",
		["bm_w_pl14"] = "Гусев",
		["bm_w_x_pl14"] = "Парные Гусевы",
		["bm_w_holt"] = "ХОЛТ",
		["bm_w_x_holt"] = "Парные ХОЛТ",
		["bm_w_fmg9"] = "Васп ДиЭс-9",
		["bm_w_beer"] = "Бернетти 93",
		["bm_w_packrat"] = "Контрактор M30Л",
		["bm_w_x_packrat"] = "Парные Контракторы",
		["bm_w_breech"] = "Парабеллум-08",
		["bm_w_x_breech"] = "Парные Парабеллумы",
		["bm_w_g22c"] = "Чимано Кастом",
		["bm_w_x_g22c"] = "Парные Чимано Кастом",
		["bm_w_p226"] = "Сигнатур 40",
		["bm_w_x_p226"] = "Парные Сигнатуры 40",
		["bm_w_hs2000"] = "ЛЕО-40",
		["bm_w_lemming"] = "Акьюто 5/7",
		["bm_w_sparrow"] = "Спэрроу 941",
		["bm_w_x_sparrow"] = "Биба и Боба",
		["bm_w_speen"] = "Балерина 9мм",
		["bm_w_socom"] = "Анубис .45",
		["bm_w_x_socom"] = "Парные Анубис 45",
		["bm_w_colt_1911"] = "Кросскилл Оператор II",
		["bm_w_x_1911"] = "Мустанг и Сэлли",
		["bm_w_m1911"] = "Кросскилл А1",
		["bm_w_x_m1911"] = "Прайс и МакТавиш",
		["bm_w_shrew"] = "Кросскилл Гард",
		["bm_w_shrew_joshua"] = "Свет, сияющий во тьме",
		["bm_w_x_shrew"] = "Барри и Пол",
		["bm_w_usp"] = "Интерсептор-45",
		["bm_w_x_usp"] = "Парные Интерспеторы-45",
		["bm_w_type54"] = "Токарь-33",
		["bm_w_x_type54"] = "Парные Токари-33",
		["bm_w_c96"] = "\"Метла\"",
		["bm_w_c96_dl44"] = "ДЛ-44",
		["bm_w_sub2000"] = "Кавити .40",
		["bm_w_deagle"] = "Дигл",
        ["bm_w_x_deagle"] = "Парные Диглы",
		["bm_w_korth"] = "Кан .357",
		["bm_w_x_korth"] = "Парные Кан .357",
		["bm_w_mateba"] = "Матевер 9мм",
		["bm_w_x_2006m"] = "Парные Матеверы",
		["bm_w_model3"] = "Френчман 87",
        ["bm_w_x_model3"] = "Парные Френчманы 87",
		["bm_w_raging_bull"] = "Бронко .44",
		["bm_w_x_rage"] = "Парные Бронко .44",
		["bm_w_chinchilla"] = "Кастиго .44",
        ["bm_w_x_chinchilla"] = "Парные Кастиго .44",
		["bm_w_rsh12"] = "РШУ-12",
		["bm_w_peacemaker"] = "Миротворец .45",
		--Кастомные пистолеты
			--ZiP 22
			["bm_w_zip22"] = "Зиппи 3000",
			--Px4
			["bm_w_px4"] = "Бернетти Канан",
			--Browning Hi-Power
			["bm_w_hpb"] = "Хай-Пауэр",
			--Walther P99
			["bm_w_p99"] = "Лакнер Г99",
			--Derringer
			["bm_w_derringer"] = "Деринжер",
			--Automag .44
			["bm_w_amt"] = "Автомаг .44",
			--Colt Detective
			["bm_w_coltds"] = "Кросскилл Детектив",
			--SIG P320
			["bm_w_papa320"] = "М19",
			["bm_w_x_papa320"] = "Парные М19",
			--PK PSD9
			["bm_w_pkpsd9"] = "ПК-ПСД9",
			--Auto-9
			["bm_w_rc_auto9"] = "Авто-9",
			--The Triad
			["bm_w_triad"] = "Триада",
			--K5 Pistol (Korean Arms Pack)
			["bm_w_k5"] = "К-Пятерка",
			--TTI STI 2011 Combat Master
			["bm_w_tti_2011"] = "Комбат Мастер",
			--AYY LMAO
			["bm_w_bf2042_ayylmao"] = "Лауго Элиен",
			--Polar 9mm
			["bm_w_polar9_primary"] = "Кросскилл Полар",
			["bm_w_polar9"] = "Кросскилл Полар",
			["bm_w_x_polar9"] = "Парные Полары",
			["bm_polar9_desc"] = "Попытка модернизировать Кросскилл под магазин с двойным стеком и боеприпас 9х19мм. Явный фаворит в спортивной стрельбе.",
			-- CZ 75B
			["bm_w_cz75b"] = "ЦЗ 75 Б",
			["bm_w_x_cz75b"] = "Парные ЦЗ 75 Б",
			--TTI Pit Viper
			["bm_w_tti_viper"] = "Пит Вайпер",
			-- Piercer 9mm
			["bm_w_rusglock"] = "Пирсер",
			--Magpul FMG-9
			["bm_w_fmgnine"] = "Магпул ФМГ-9",
			--Glock 19
			["bm_w_g19"] = "Глок 19",
			--Pinkie.380
			["bm_w_pinkie"] = "Пинки .380",
			--CR 75 Czechmate
			["bm_w_axewscope"] = "ЦР 75 Чехмейт",
			--MP-443 Grach
			["bm_w_mp443"] = "Грач",
			--CR Phantom II
			["bm_w_czshadow_sc"] = "ЦР Фантом II",
			["bm_w_x_czshadow_sc"] = "Парные Фантомы",
			["bm_czshadow_sc_desc"] = "Вариация пистолета ЦР 92 без автоматического режима. Создано специально для спортивных состязаний, но разве стрельба по шлемам копов не является спортом?",
			--обитель зла на смертном приговоре
			["bm_w_vp70"] = "ХК ВП70М",
			["bm_w_x_vp70"] = "Парные ВП70М",
			--High Standard HDM
			["bm_w_hshdm"] = "Хай Стандард ХДМ",
			["bm_w_x_hshdm"] = "Парные ХДМ",
			--ЗИ (НЕ ТО ЗИ!!!)
			["bm_w_pb"] = "ПБ",
			--SR1M
			["bm_w_sr1"] = "СР1М",
			["bm_w_x_sr1"] = "Парные СР1М",
			--AP Pistol (все вопросы к GTA V, "пистолет" я оставляю")
			["bm_w_appistol"] = "Бронебойный пистолет",
			--Predator Plasma Pistol (то же самое, AvP, все дела)
			["bm_w_hhpc"] = "Плазменный пистолет Хищника",
			--MR-96
			["bm_w_mr96"] = "МР-96",
			["bm_w_x_mr96"] = "Парные МР-96",
			--M712 Schnellfeuer
			["bm_w_m712"] = "Маузер M712 Шнельфайер",
			--Javelin 10mm
			["bm_w_baller"] = "Кросскилл Джавелин",
			["bm_baller_sc_desc"] = "Модернизированный Кросскилл, заряжженный 10×25 мм патронами вместо стандартных 11.43х23 мм.", -- в оригинале описания указано, что это подобие чанки кросскила с затвором "Крепкий охотник": и как вы мне прикажете переводить очередной кросскил?
			--AF2011
			["bm_w_af2011"] = "АФ2011",
			--HK45C
			["bm_w_hk45c"] = "ХК45Ц",
			["bm_w_x_hk45c"] = "Парные ХК45Ц",
			--Korth PRS
			["bm_w_korth_prs"] = "Корф ПРС",
			--S&W Model 642
			["bm_w_sw642"] = "Искорка 642",
			["bm_w_x_sw642"] = "Сигров и Андервуд", -- Last Man's Standing (1995)
			--Duke Nukem's M1911
			["bm_w_duke1911"] = "Позолоченный М1911 Дюка Нюкема",
			--Zenith
			["bm_w_zenith"] = "Зенит",
			--Chiappa Rhino - я 60 DS проходить не собираюсь
			["bm_w_rhino"] = "Чиаппа Рино 60ДС",
			--Deagle K4
			["bm_w_limafive"] = "Дигл-К4",
			--Mateba Model 6 Unica
			["bm_w_unica6"] = "Матевер Уника",
			--Deck-ARD
			["bm_w_deckard"] = "Дэк-АРД",
			--S&W Model 27
			["bm_w_sw27"] = "Страж 27",
			--M2019 Blaster
			["bm_w_lapd"] = "Бластер М2019",
			--Malorian Arms 3516
			["bm_w_malorian_3516"] = "МА 3516 'Сильверхенд'",
			--Nagant M1895
			["bm_w_m1895"] = "Нагант М1895",
			--Mars Automatic
			["bm_w_mars"] = "Марс Автоматик",
			--Night Hawk .50C
			["bm_w_cssdeagle"] = "Найт Хавк .50",
			--S&W Model 500
			["bm_w_swhiskey"] = "Брайсон",
			--Bullkick 500
			["bm_w_bk500"] = "Булкик 500",
			--.50 Cal Deagle
			["bm_w_degfifty"] = "Дигл, но есть 50-калиберный нюанс",
			-- Пистолет Макарова (будь проще)
			["bm_w_pm"] = "Макаров",
			["bm_w_x_pm"] = "Парные Макаровы",
			--Рэдфилд
			["bm_w_hipower"] = "Рэдфилд ГП-640б",
			["bm_w_x_hipower"] = "Парные Рэдфилды",
			--Sw 659
			["bm_w_sw659"] = "Кондор .659",
			["bm_w_x_sw659"] = "Пинк и Пурпл",
			--Walther p38
			["bm_w_p38"] = "Грубер П38",
			--Lahti
			["bm_w_l35"] = "Л-35 ''Лахти''",
			--NP762
			["bm_w_chinesium"] = "Норинко НП762",
			--FNP45T
			["bm_w_fnp45"] = "Р45Т",
			--SG45
			["bm_w_sg45"] = "СГ-45",
			["bm_w_x_sg45"] = "Парные СГ-45",
			["bm_sg45_desc"] = "Практически старший брат Контрактора.\nИ он очень практически стреляет .45 ACP.",
			--Degle
			["bm_w_degle"] = "Дэгл .50",
		["bm_w_p90"] = "Проджект-90",
		["bm_w_x_p90"] = "Парные Проджект-90",
		["bm_w_mp7"] = "СпекОпс-7",
		["bm_w_tec9"] = "ТЕК",
		["bm_w_x_tec9"] = "Парные ТЕК",
		["bm_w_sr2"] = "Пихта С-2",
		["bm_w_x_sr2"] = "Парные Пихты С-2",
		["bm_w_mp9"] = "КМП 9",
		["bm_w_pm9"] = "Мияка 9",
		["bm_w_baka"] = "Микро Узи",
		["bm_w_x_baka"] = "Парные Микро Узи",
		["bm_w_scorpion"] = "Кобра",
		["bm_w_x_scorpion"] = "Парные Кобры",
		["bm_w_coal"] = "Татонка",
		["bm_w_vityaz"] = "АК 21 Тактический",
		["bm_w_shepheard"] = "Сигнатур ПС9",
		["bm_w_x_shepheard"] = "Парные Сигнатурки",
		["bm_w_mp5"] = "Компакт-5",
		["bm_w_mp5sd"] = "Компакт-5СД",
		["bm_w_mp5k"] = "Компакт-5К",
		["bm_w_mp5k_pdw"] = "Компакт-5К ПДВ",
		["bm_w_x_mp5"] = "Парные Компакт-5",
		["bm_w_m45"] = "Карл M-45",
		["bm_w_sterling"] = "Патчетт Л2A3",
		["bm_w_sterling_sd"] = "Патчетт Л34А1",
		["bm_w_sterling_pistol"] = "Патчетт Мк. VII",
		["bm_w_sterling_e11"] = "Е-11",
		["bm_w_uzi"] = "Узи",
		["bm_w_x_uzi"] = "Парные Узи",
		["bm_w_m1928"] = "Чикагская машинка",
		["bm_w_mac10"] = "Марк 10",
		["bm_w_x_mac10"] = "Парные Марк 10",
		["bm_w_erma"] = "Шмайсер",
		["bm_w_schakal"] = "Шакал",
		["bm_w_polymer"] = "Кросс Вертекс",
		--Кастомные ПП
			--AR57
			["bm_w_alpha57_prim"] = "Ураган 5/7",
			--LWRC
			["bm_w_smg45"] = "Страйкер 45",
			--LWRC
			["bm_w_fang45"] = "Фанг 45",
			--Typhoon
			["bm_w_crysis3_typhoon"] = "КРАЙНЕТ Тайфун",
			--Glockson
			["bm_w_glockson"] = "Глоксон",
			--CBJ-MS
			["bm_w_cbjms"] = "Си-Би-Джей МС",
			["bm_w_lc10"] = "ЛЦ-10",
			--KSP 45
			["bm_w_ksp45"] = "КСП 45",
			--SBR .45
			["bm_ar45_sc"] = "СБР 45",
			["bm_x_ar45_sc"] = "Парные СБР",
			["bm_w_ar45_desc"] = "Пистолет-пулемет, созданный на платформе КАР-4 и принимаюший магазины от Стрика. Для экономных грабителей самое то.",
			--Tribune 32
			["bm_w_tribune32"] = "Трибун 32",
			["bm_w_x_tribune32"] = "Парные Трибуны",
			--Kedr
			["bm_w_kedr"] = "Кедр 91",
			["bm_w_x_kedr"] = "Парные Кедры",
			--Spectre M4
			["bm_w_spectre_m4"] = "М4 Спектр",
			["bm_w_x_spectre_m4"] = "Парные Спектры",
			--Einhander
			["bm_w_einhander"] = "Айнханда",
			--Jackal PDW
			["bm_w_geasy9"] = "Шакал ПДВ",
			--Steyr AUG
			["bm_w_aug9mm"] = "ЮАР А3 ИксЭс",
			--BO6 Grendel R31
			["bm_w_r31"] = "Танто 22",
			--Thompson
			["bm_w_tommy"] = "Томпсон",
			["bm_w_m7caseless"] = "Мисриа M7",
			["bm_w_m7caseless_desc"] = "Пистолет-пулемет стандарта ККОН под безгильзовые 5x23 мм.",
			["bm_w_m7caseless_supp"] = "Мисриа М7С",
			["bm_w_x_m7caseless"] = "Парные M7",
			["bm_w_x_m7caseless_supp"] = "Парные M7С",
			--SMG 32 Repmirand
		    ["bm_w_reprimand"] = "Взыскание",
            ["bm_w_reprimand_desc"] = "Тяжелый пистолет-пулемет, использующий крупнокалиберные боеприпасы. Невысокая скорострельность помогает справиться с сильной отдачей.\n",
		    ["menu_l_global_value_helldivers2te_mod"] = "Это предмет из Helldivers 2 - Блюстители Правды!",
			--StA-11 Submachine Gun
			["bm_w_sta11"] = "СтА-11",
	        ["bm_w_sta11_desc"] = "Пистолет-пулемет со шнековым магазином, который обеспечивает оружие увеличенным боезапасом, но при этом утяжеляет его.\nПроизведено ''Оружием Шталя''.\n",
			--XM 250
			["bm_w_sig_xm250"] = "Сигнатур МГ277",
			--PPS-43
			["bm_w_pps43"] = "Судаев",
			--APC9
			["bm_w_iso"] = "АПЦ-9",
			--KAC PDW
			["bm_w_pdw"] = "ПДВ ''Рыцарь''",
			--Grease Gun
			["bm_w_m3"] = "Масленка",
			["bm_w_x_m3"] = "Парные Масленки",
			["bm_w_peacekeepermk1"] = "Миротворец мк1",
		--Кастомные дробовики
			--PD3 Origin-12
			["bm_w_or12"] = "Ориджин-12",
			--MW2023 Origin-12
			["bm_w_haymaker"] = "Хеймейкер",
			--MW2022 Vepr
			["bm_w_vecho"] = "Вепрь",
			--MW2023 Riveter
			["bm_w_riveter"] = "Риветер",
			--Pursuivant
			["bm_w_bp12"] = "Последователь 12",
			--Predator 15A
			["bm_w_spas15"] = "Хищник 15А",
			--Dracarys Gen-12
			["bm_w_tti_dracarys"] = "Дракарис 12",
			--ASG-89
			["bm_w_uncle12"] = "АСГ-89",
			--FP6
			["bm_w_fpsix"] = "ФП6",
			--ИТАК???
			["bm_w_stf12"] = "ИТА12Ц",
			--Winchester 1912
			["bm_w_m1912"] = "Репитер 1912",
			--Mossberg 590A1
			["bm_w_mossberg590"] = "Москони 590А1",
			--TOZ-194
			["bm_w_toz194"] = "ТОЗ-194",
			--Да кто такая эта ваша Ребекка нафиг
			["bm_w_cp2077_guts"] = "Гатс",
			--BOSG 12.2
			["bm_w_dokkasho"] = "БОСГ 12.2",
			--TOZ-34
			["bm_w_toz34"] = "ТОЗ-34",
			--Abzats
			["bm_w_abzats"] = "Абзац 12",
			--Chiappa Triple Threat
			["bm_w_triple"] = "Чиаппа Триплтрит",
			--Lunatic .410
			["bm_w_omni"] = "Лунатик .410",
			["bm_w_omni_desc"] = "Младший брат АМР-12. Даже с укороченным патроном .410 калибра ломает колени.\n",
			--Widowmaker TX
			["bm_w_wmtx"] = "Овдовитель",
			--Fort-500
			["bm_w_f500"] = "Форт-500",
			--маленький дробовик компенсируется чем...
			["bm_w_littlest"] = "Спартанец СверхУкороченный",
			--Ashot
			["bm_w_ashot"] = "Ашот-12",		
			--TOZ-66
			["bm_w_toz66"] = "ТОЗ-66",
			["bm_w_x_toz66"] = "Парные ТОЗ-66",
			--FSA-12G
			["bm_w_fsa12"] = "ФСА-12G",
			--Candy Shotgun
			["bm_w_candy"] = "Леденец 12",
			--Gingerbread Shotgun
			["bm_w_xmassg"] = "Прянич 12",
		["bm_w_tecci"] = "Контрабандист",
		["bm_w_m249"] = "КСП 90",
		["bm_w_kacchainsaw"] = "Кэмпбелл 74",
		["bm_w_rpk"] = "РПК",
		["bm_w_hk21"] = "Бреннер 21",
		["bm_w_hcar"] = "Акрон",
		["bm_w_hcar_bar"] = "Акрон",
		["bm_w_m60"] = "M60",
		["bm_w_par"] = "КСП 58",
		["bm_w_mg42"] = "Косторез 42",
		["bm_w_mg42_dlt19"] = "ДЛТ-19",
		["bm_w_hk51b"] = "Ферштект-51",
		["bm_w_basset"] = "Гримм 12",
		["bm_w_x_basset"] = "Братья Гримм 12",
		["bm_w_saiga"] = "Ижма 12",
		["bm_w_aa12"] = "Стейкаут 12",
	    ["bm_w_spas12"] = "Хищник 12",
		["bm_w_benelli"] = "M1014",
		["bm_w_ultima"] = "Аргос 3",
		["bm_w_striker"] = "Чистильщик",
		["bm_w_rota"] = "Голиаф 12",
		["bm_w_sko12"] = "ВД 12",
		["bm_w_x_sko12"] = "Парные ВД 12",
		["bm_w_m37"] = "ДжиЭс 12",
		["bm_w_supernova"] = "Деймос",
		["bm_w_serbu"] = "Локомотив 12",
		["bm_w_m1897"] = "Репитер 1897",
		["bm_w_m590"] = "Москони 12 Тактический",
		["bm_w_r870"] = "Рейнфилд 880",
		["bm_w_ksg"] = "Рейвен 12",
		["bm_menu_sc_boot"] = "Брейкер 10",
		["bm_w_boot"] = "Брейкер 10",
		["bm_w_coach"] = "Клэр 12",
		["bm_w_huntsman"] = "Москони 12",
		["bm_w_judge"] = "Судья",
		["bm_w_x_judge"] = "Жока и Бока", --вините Клейтона.
		["bm_w_b682"] = "Джоселина 12",
		["bm_w_quadbarrel"] = "Думстик",
		["bm_w_mp153"] = "Аргос 1",
		["bm_w_s552"] = "Коммандо 552",
		["bm_w_amcar"] = "АМКАР",
		["bm_w_g36"] = "ДЖП 36КВ",
		["bm_w_g36_k"] = "ДЖП 36К",
		["bm_w_g36_c"] = "ДЖП 36С",
		["bm_w_g36_v"] = "ДЖП 36В",
		["bm_w_g36_long"] = "ДЖП 36",
		["bm_w_vhs"] = "Львиный оскал",
		["bm_w_olympic"] = "Пара 23",
		["bm_w_x_olympic"] = "Парные Пара 23",
		["bm_w_komodo"] = "Темпест 95",
		["bm_w_famas"] = "Клэрион 5.56",
		["bm_w_m4"] = "КАР-4",
		["bm_w_m4_mk12"] = "КАР-12 СПР",
		["bm_w_m4_lr300"] = "ТР-300",
		["bm_w_ak5"] = "АК 5",
		["bm_w_ak5b"] = "АК 5Б",
		["bm_w_ak5c"] = "АК 5С",
		["bm_w_ak5_fnc"] = "Карабин ВФ",
		["bm_w_corgi"] = "Юнион 5.56",
		["bm_w_aug"] = "ЮАР A2",
		["bm_w_aug_a3"] = "ЮАР А3",
		["bm_w_aug_f90"] = "Раптор 90",
		["bm_w_ak12"] = "АК 17",
		["bm_w_ak74"] = "АК 5.45",
		["bm_w_hajk"] = "КР 805",
		["bm_w_m16"] = "АМР 16",
		["bm_w_m16a1"] = "АМР-16А1",
		["bm_w_l85a2"] = "Ярость Королевы",
		["bm_w_akm"] = "АК 7.62",
		["bm_w_akm_gold"] = "Золотой АК 7.62",
		["bm_w_groza"] = "ОБ14 Бык 1",
		["bm_w_tkb"] = "Трехствольник Родионова",
		["bm_w_akmsu"] = "Кринков",
		["bm_w_x_akmsu"] = "Парные Кринковы",
		--Кастомные винтовки
			["bm_w_tilt"] = "КВК 99",
			["bm_w_g36k"] = "ДЖП 36K",
			["bm_w_scarl"] = "Игл Лайт",
			["bm_w_rk62"] = "Вельмер",
			["bm_w_mcbravo"] = "Химера",
			["bm_w_ar18"] = "КАР-18",
			["bm_w_pd3_qbz191"] = "Нортвест Б-9",
			["bm_w_t9fastburst"] = "КАРВ.2",
			["bm_w_t9fastburst_desc"] = "Помните, была такая странная винтовка, G11 звалась?\n\nНу так вот.",
			["bm_w_kurisumasu"] = "Р-4 Гренадер",
			["bm_w_fazertron"] = "Фазертрон",
			["bm_w_acwr"] = "Рейнфилд АКР М203",
			["bm_w_acwr2"] = "Рейнфилд АКР",
			["bm_w_holoar"] = "''Ураган''",
			["bm_w_akilo105_2022"] = "АК-105",
			["bm_w_fik22"] = "Сигнатур .22",
			["bm_w_stoner63a_rifle"] = "Стоунер 63А",
			["bm_w_ar2"] = "Импульсная Винтовка Альянса",
			--это пизда
			["bm_w_akm_nomag"] = "АК 7.62 раннего доступа",
			["bm_w_akm_nomag_desc"] = "Почему ранний доступ?\n«Пушка есть на продажу, магазины не завезли, а жрать надо сейчас»\n\nИзменится ли цена винтовки после выхода из раннего доступа?\n«Да, на сто тысяч баксов дороже будет»\n\nНеудачная первоапрельская шутка от Гейджа, которая зашла слишком далеко.",
			["bm_w_grayhound"] = "САЙ ГРИ",
			["bm_w_coyote"] = "АР-2 Койот",
			["bm_w_coyote_desc"] = "Вполне надежная винтовка с антикварным прицелом-мушкой.\n#{risk}#Стреляет зажигательными боеприпасами.##",
			["bm_w_coslo723"] = "ИксЭм-4",
			["bm_w_k2"] = "К-Двойка",
			["bm_w_acr_2012"] = "Игл СабРат",
			["bm_w_l403a1"] = "Воля Короля",
			["bm_w_l119a2"] = "Страж Короны",
			["bm_w_galilace"] = "Масада 23",
			--не подходит, но каламбур же - наберите AEK кириллицей и выйдет...
			["bm_w_aek971"] = "ФУЛ-971",
			["bm_w_a545"] = "ФУЛ-5 ''Баланс''",
			["bm_w_tkb0146"] = "Прото-146",
			["bm_w_ma40"] = "МА40",
			["bm_w_fakedefy"] = "Аколит 7.62с",
			["bm_w_akilo_2022"] = "АК103",
			["bm_w_malima"] = "Малима",
			["bm_w_ak556"] = "АК-56К",
			["bm_w_lvoac"] = "ЛВОА-Ц",
			--искал пушку, нашел только какую-то китайскую игру
			["bm_w_mikon"] = "Онмедзи 5.56",
			["bm_w_howa_type20"] = "Хова Тип 20",
			["bm_w_howa_type20_desc"] = "Новая штатная винтовка Сил самообороны Японии, в дизайне которой использованы элементы других современных винтовок.",
			["bm_w_howa"] = "Хова Тип 89",
			["bm_w_modl"] = "Модель Л",
			["bm_w_aku94"] = "АКУ-94",
			["bm_w_m2"] = "М2",
			--каламбур оригинального названия в том, что... ээээ... ганнатам Калды(и не только) эта вариация из 2023 не понравилась. Но я не ганнат, я похуист.
			["bm_w_stango44"] = "СТГ-44",
			["bm_w_bulldog"] = "Бульдог",
			-- VALORANT Bulldog
		    ["bm_w_bulldog_desc"] = "Эта винтовка может стрелять очередями по 3 выстрела, и имеет встроенный прицел. По эффективности похожа на Темпест. Наверное.",
			["bm_w_qbz95"] = "КьюБЗ-95",
		["bm_w_ching"] = "M1 Галант",
		["bm_w_m14"] = "M308",
		["bm_w_fal"] = "Фалкон 58",
		["bm_w_fal_l1a1"] = "Фалкон СЛР",
		["bm_w_fal_sa58"] = "Фалкон 58 ОСВ",
		["bm_w_fal_idf"] = "Фалкон РМТ",
		["bm_w_scar"] = "Игл Хэви",
		["bm_w_scar_l"] = "Игл Лайт",
		["bm_w_g3"] = "Гевер 3",
		["bm_w_g3_sg1"] = "Гевер-С1",
		["bm_w_g3_msg"] = "Гевер-90",
		["bm_w_g3_psg"] = "Präzision Гевер-1",
		["bm_w_g3_hk33"] = "СГ-33",
		["bm_w_g3_hk33_fo3"] = "Р91",
		["bm_w_contraband"] = "Большой дружок 7.62",
		["bm_w_contraband_m16"] = "Маленький дружок 5.56",
		["bm_w_contraband_mpx"] = "ОМНИА ПС9 9мм",
		["bm_w_asval"] = "Валькирия",
		["bm_w_galil"] = "Гекко 7.62",
		["bm_w_galil_galatz"] = "Геккота 7.62",
		["bm_w_galil_mar"] = "Микро Гекко 7.62",
		["bm_w_galil_556"] = "Гекко 5.56",
		["bm_w_galil_mar_556"] = "Микро Гекко 5.56",
		["bm_w_shak12"] = "КС 12",
		--Кастомные ДМР
			--MCX Spear
			["bm_w_mcx_spear"] = "Сигнатур M7",
			["bm_w_ngsierra"] = "Амикус 277",
			["bm_w_vss"] = "Виктория",
			["bm_w_g3hk79"] = "Гевер А3 с гранатометом",
			["bm_w_xr2"] = "Иксэр 2",
			["bm_xr2_sc_desc"] = "Иксэр-2 - инструмент, подходящий для самых напряженных боев, который оснащен особым спусковым крючком, и имеет #{skill_color}#повышенную скорострельность при стрельбе очередями.##\n\n#{skill_color}#Наносит 25% урона через броню и может пробивать врагов.##",
			["bm_w_sierra458"] = "Съерра .458",
			-- В ВК семьдесят восемь Коммандо, страшно!
			["bm_w_vk78_commando"] = "ВК78 Коммандо",
			--ОверВалькин дед
			["bm_w_owd_m1a"] = "СА А144",
			["bm_w_msecho"] = "ФТАК Рекон",
			["bm_w_fg42"] = "ФГ 42 Тип Ж",
			--Да, это набор для пушки выше. Пушка вышла еще до Winds of Change, к слову.
			["bm_w_fg42early"] = "ФГ 42 Тип Е",
			--Одного Пучкова миру было недостаточно.
			["bm_w_rmary2"] = "Гоблин МК2",
			["bm_w_m1918"] = "БАР",
			["bm_w_madsen_lar"] = "Мадсен ЛАР М62",
			["bm_w_skspug"] = "Вильгельм",
			["bm_w_enfieldl22"] = "Л-32",
			--а может ты?
			["bm_w_pdr"] = "ПДР",
			["bm_ak15u_sc"] = "АК-25У",
			["bm_ak15u_sc_desc"] = "Кустарный карабин на основе автомата АК-25 - варианта АК-17 под патрон 7.62х39.\n",
			["bm_w_fsbcustom"] = "Кочевник",
			["bm_w_plr16"] = "ПЛР-16",
			["bm_w_mdr_308"] = "МДР",
			["bm_w_soa"] = "СОА Подрывник",
			["bm_w_soa_desc"] = "Эффективность этой заряженной 7.62 патронами винтовки настолько высока, что для баланса Вселенной ее пришлось убить в хлам, чтобы она не стала новой ''Метой''.\nИли какие там словечки у геймеров, не знаю, олды на месте, как говорится.",
			--слар?? in ma resmed ru loc???
			["bm_w_l1a1"] = "Л1А1 СЛР",
			["bm_w_m1a1"] = "М1А1",
			["bm_w_sks"] = "СКС",
			["bm_w_sr3m"] = "СР-3М Вихрь",
			["bm_w_dd5"] = "ДДР5",
			["bm_w_br55"] = "МА БР55",
			["bm_w_t9british"] = "ИМ2",
			--NameError: name 'low_effort_joke_for_MAS-49' is not defined
			--		'I swear, Vavlo, if I hear this joke one more time...'
			["bm_w_mas49"] = "МАС-49",
		["bm_w_msr"] = "Раттлснейк",
		["bm_w_r700"] = "Рейнфилд Модель 700",
		["bm_w_qbu88"] = "Кэнг Икс 1",
		["bm_w_winchester1874"] = "Репитер 1874",
		["bm_w_tti"] = "Текки .308",
		["bm_w_victor"] = "Полярная звезда",
		["bm_w_scout"] = "Пронгхорн",
		["bm_w_awp"] = "Амарок 900",
		["bm_w_wa2000"] = "Лебензаугер .300",
		["bm_w_sbl"] = "Рейнджхитер Марк 2",
		["bm_w_contender"] = "Аран Джи 2",
		["bm_w_model70"] = "Платипус 70",
		["bm_w_siltstone"] = "Гром",
		["bm_w_mosin"] = "Нагант",
		["bm_w_desertfox"] = "Дезерт Фокс",
		["bm_w_r93"] = "Р93",
		["bm_w_bessy"] = "Флинтлок Фредди",
		["bm_w_m95"] = "Танатос .50",
--Кастомные снайперки
			--Guerilla
			["bm_w_sgs"] = "Партизан 553",
			["bm_w_m107cq"] = "Морс .50",
			["bm_w_m200"] = "ТФ 141",
			["bm_w_pd3_lynx"] = "ХЕТ-5 Ред Фокс",
			["bm_w_amr2"] = "Нортвест АМ-2",
			["bm_w_m1894"] = "Mare's Leg",
			["bm_w_sako_85"] = "Сако 85 Хантер",
			["bm_w_dl"] = "Де Лайла Коммандо",
			--ваше мнение об обрезании, Хьюстон?
			["bm_w_obrez"] = "Пистолет-обрез Мосина",
			["bm_w_musket"] = "Мушкет",
		["bm_w_moss464spx"] = "Москони ЭсПиЭкс",
		["bm_w_winchester1894"] = "Репитер 1894",
		["bm_w_svd"] = "СВ 7",
		["bm_w_l115"] = "АИМ 90",
		["bm_w_gre_m79"] = "ГЛ 40",
		["bm_w_m32"] = "Хрюндель",
		["bm_w_china"] = "Чайна Пафф",
		["bm_w_slap"] = "Компакт 40",
		["bm_w_arbiter"] = "Арбитр",
		["bm_w_rpg7"] = "РПГ",
		["bm_w_ray"] = "Коммандо 101",
		["bm_w_czevo"] = "Кобра Марк 4",
        ["bm_w_ppsh"] = "ШПП-42",
        ["bm_w_ks23"] = "Молот 24",
        ["bm_w_nova4"] = "Нова 4",
        ["bm_w_owlfbullpup"] = "Питбуль 5.56",
        ["bm_w_xeno"] = "Пульсовая винтовка M41A",
        ["bm_w_plasmaproto"] = "Прототип плазморужья",
        --["bm_w_mcx_spear"] = "Пейпервейт", - дупликат? откуда?
        ["bm_w_rsass"] = "Рейнджхиттер 11",
        ["bm_w_troglodyte"] = "АВМ-Ф",
        ["bm_w_as24"] = "А24 Уничтожитель",
        ["bm_w_raygun"] = "Лучемет",
        ["bm_w_fp45"] = "Фридом .45",
        ["bm_w_m6d"] = "Чиф 12.7",
        ["bm_w_jackhammer"] = "Отбойник 12",
        ["bm_w_hx25"] = "КФ-25",
		--псп
		["bm_w_umd_launcher"] = "УМД Привод",
		--м1991 детей
		["bm_w_toy1911"] = "Игрушечный М1911",
		--м16 детей
		["bm_w_toym16"] = "Игрушечный М16",
		--Ванилька мод пак - адаптация под рулок рестора
			["bm_w_amr12"] = "АМР-12",
			["bm_w_ak5s"] = "Автомат-5",
			["bm_w_x_ak5s"] = "Парные Автомат-5",
			["bm_w_sg416"] = "СГ 416",
			["bm_w_beck"] = "Рейнбек M1",
			["bm_w_car9"] = "АКАР-9",
			["bm_w_smolak"] = "Дракон 5.45",
			["bm_w_spike"] = "Спайкер 7.62",
			["bm_w_cold"] = "Кросскилл Протектор",
			["bm_w_x_cold"] = "Парные Кросскилл Протектор",
			["bm_w_x_smolak"] = "Парные Драконы 5.45",
			["bm_w_x_car9"] = "Парные АКАР-9",
			--["bm_w_sgs"] = "Партизан .308", - еще дупликат?
			["bm_w_lebman"] = "Вендетта .38",
			["bm_w_aknato"] = "Мамба 5.56",
			["bm_w_x_lebman"] = "Вендетта .38",
			["bm_w_bdgr"] = "Хорнет .300",
			["bm_w_minibeck"] = "Рейнбек Авто",
			["bm_w_bs23"] = "Молот 23",
		--Всякое для русека
		["bm_w_hailstorm"] = "Хейлшторм Марк 5",
		["bm_w_saw"] = "Пила ОВЕ9000",
		["bm_w_plainsrider"] = "Лук Плейнсрайдер",
		["bm_w_elastic"] = "Лук ДЕКА",
		["bm_w_flamethrower_mk2"] = "Огнемет Марк 1",
		["bm_w_cobray"] = "Пушка Джакета",
		["bm_w_m134"] = "Вулкан",
		--Милишки
		["bm_melee_kabar_tanto"] = "Нож УРСА",
		["bm_melee_alien_maul"] = "Альфа-Молот",
		["bm_melee_spoon"] = "Смехотворно огромная ложка",
		["bm_melee_spoon_gold"] = "Смехотворно золотая ложка",
		["bm_melee_shovel"] = "Лопата КЛАСС",
		["bm_melee_oxide"] = "Резкий",
		["bm_melee_chac"] = "Эль Ритмо",
		["bm_melee_agave"] = "Эль Вердуго",
		["bm_melee_kampfmesser"] = "Нож Кригер",
		["bm_melee_cs"] = "Бензопила Ламбер Лайт Л2",
		["bm_melee_brick"] = "Хотлайн 8000",
		["bm_melee_boxing_gloves"] = "Боксерские перчатки ОВЕРКИЛЛ",
		["bm_melee_sandsteel"] = "Катана Шинсакуто",
		["bm_melee_gerber"] = "Боевой нож Бергер",
		["bm_melee_rambo"] = "Боевой нож Траутман",
		})

		elseif weapon_names == 3 then --DMCWO перевод
			-- Нам это переводить не надо! Только если не объявится спец по оружиям с мазохисткими наклонностями, который захочет повозиться с реальными названиями пушек и их аттачментов.
		end
	end
end)

-- Советы при загрузке
Hooks:Add("LocalizationManagerPostInit", "SC_Localization_Skills", function(loc)
	LocalizationManager:add_localized_strings({
		--Restoration Gameplay Hints--
		["loading_gameplay_res_title"] = "Restoration - советы об игровом процессе",
		["loading_gameplay_res_1"] = "Клокеры издают сверчащий звук, когда готовятся атаковать. Используйте это для их обнаружения.",
		["loading_gameplay_res_2"] = "Клокеры больше не издают гудящий звук, когда сидят в засаде, а также скрежет при атаке.",
		["loading_gameplay_res_3"] = "Пистолеты идеально дополняют основное оружие с долгой скоростью переключения.",
		["loading_gameplay_res_4"] = "Тазеры теперь не перезаряжают ваше оружие.",
		["loading_gameplay_res_5"] = "Грабитель вдали от товарищей - идеальная цель для Клокеров.",
		["loading_gameplay_res_6"] = "Клокеры наносят урон напрямую здоровью, когда атакуют пинком. Этот урон можно уменьшить, используя Стойкость или навык 'Контрудар'.",
		["loading_gameplay_res_7"] = "Зеленые Бульдозеры наносят много урона и могут пробить даже самую тяжелую броню с одного выстрела.",
		["loading_gameplay_res_8"] = "Черные Бульдозеры (Бульдозеры с Сайгой) обладают высокой скорострельностью и большим магазином. Помимо этого они бегают быстрее всех дозеров и могут быть оглушены взрывом.",
		["loading_gameplay_res_9"] = "Дозеры с пулеметами/Скаллдозеры ведут огонь на поражение и не останавливаются, пока не отстреляют всю ленту. Они передвигаются так же медленно, как и Титановые Дозеры.",
		["loading_gameplay_res_10"] = "Дозеры с дробовиками Бенелли (Бенелли Дозеры) заменяют Дозеров с миниганами - у них и высокий урон, и высокая скорость стрельбы. Они совмещают опасность Зеленого и скорость Черного Дозеров.",
		["loading_gameplay_res_11"] = "Приоритет целей важен. Бульдозеру явно стоит уделить больше внимания, чем обычному спецназовцу.",
		["loading_gameplay_res_12"] = "На Смертном приговоре, Бульдозеры впадают в ярость, когда их стекло сломано, что увеличивает их урон на 10%.",
		["loading_gameplay_res_13"] = "Клокеры издают свой известный клич, если собираются произвести удар ногой в прыжке.",
		["loading_gameplay_res_14"] = "Удар ногой в прыжке от Клокеров закует вас в наручники вместо падения.",
		["loading_gameplay_res_15"] = "Светошумовые гранаты не могут быть сломаны на Смертном приговоре. Your opinion, my choice.",
		["loading_gameplay_res_16"] = "Атаки в ближнем бою можно парировать, если достать оружие ближнего боя. Навык 'Контрудар' также позволяет парировать Клокеров.",
		["loading_gameplay_res_17"] = "Атаки противников в ближнем бою гораздо более эффективны, чем раньше. Соблюдайте дистанцию.",
		["loading_gameplay_res_18"] = "Что гораздо эффективнее, чем бить врагов бейсбольной битой? Бить их по голове для дополнительного урона.",
		["loading_gameplay_res_19"] = "Снайперу требуется короткий промежуток времени, чтобы прицелиться, прежде чем он выстрелит. Обращайте внимание на лазер!",
		["loading_gameplay_res_20"] = "Клокеры также могут атаковать ногой ваших Джокеров.",
		["loading_gameplay_res_21"] = "Обычные противники обладают деталями на униформах, которые дадут понять, какое оружие они используют.",
		["loading_gameplay_res_22"] = "Противники с дробовиками очень опасны вблизи, но не вдалеке.",
		["loading_gameplay_res_23"] = "На высоких сложностях, противники стараются прятаться за Щитами.",
		["loading_gameplay_res_24"] = "На высоких сложностях, у противников появляются новые тактики.",
		["loading_gameplay_res_25"] = "'Смертный приговор' привносит много новых злобных фишек. Ожидайте худшего.",
		["loading_gameplay_res_26"] = "Pro Job - особо сложный режим, в котором у вас будет только одна попытка на прохождение. Остерегайтесь отряд Браво.",
		["loading_gameplay_res_27"] = "В Restoration Mod присутствуют разные фракции врагов, например, наемники Murkywater и полиция разных штатов.",
		["loading_gameplay_res_28"] = "На высоких сложностях, Клокеры бросают дымовую завесу при атаке.",
		["loading_gameplay_res_29"] = "У Тазеров и Гренадеров есть слабые места. Выстрелив по сумке на правом боку, вы можете оглушить владельца и тех, кому не повезло встать рядом.",
		--New Units Hints
	    ["loading_new_units_res_title"] = "Restoration - советы о новых противниках",
		["loading_new_units_res_1"] = "OMNIA ASU (агенты поддержки) усиливают урон товарищей при помощи желтых лазеров.",
		["loading_new_units_res_2"] = "LPF получает больше урона от оружия ближнего боя. Враги помечены фиолетовым цветом, когда их лечит LPF.",
		["loading_new_units_res_3"] = "Слабые противники получают дополнительное здоровье от LPF. В этом случае они помечаются фиолетовым цветом.",
		["loading_new_units_res_4"] = "Титановые Клокеры обладают продвинутой экипировкой, которая делает их практически невидимыми, но издает такие же звуки, как экипировка стандартных Клокеров.",
		["loading_new_units_res_5"] = "Титановые Дозеры предпочитают держать грабителей на расстоянии, чтобы выцелить их из своего Рельсотрона.",
		["loading_new_units_res_6"] = "Титановые Снайперы не имеют высокого урона и пробития брони, как у их стандартных  соратников, зато могут передвигаться и обладают высокой скоростью стрельбы.",
		["loading_new_units_res_7"] = "Вместо лазеров, Титановые Снайперы используют фиолетовые трассеры.",
		["loading_new_units_res_8"] = "Титановые щиты можно пробить только снайперской винтовкой Thanatos (и ее эквиваленты), пилой OVE9000 (с навыком 'Рвать и метать') и особыми бронебойными патронами у турелей. Однако, щит можно сбить, если вести по нему продолжительный огонь.",
		["loading_new_units_res_9"] = "Капитан Спринг и Титановые Дозеры всегда получают дополнительный урон в голову.",
		["loading_new_units_res_10"] = "Титановые Тазеры используют электрические боеприпасы, которые ненадолго замедляют вас. Экран засветится синим, если он выстрелит в вас.",
		["loading_new_units_res_11"] = "Копы-ветераны при смерти бросят слезоточивую гранату, если не убить их в голову.",
		["loading_new_units_res_12"] = "Копы-ветераны быстро передвигаются, из-за чего по ним трудно попасть.",
		["loading_new_units_res_13"] = "Титановый SWAT обладает броней, которая защищает их от холодного оружия.",
		["loading_new_units_res_14"] = "Титановый SWAT нельзя взять в заложники или переманить на свою сторону. ",
		["loading_new_units_res_15"] = "Титановый SWAT используют пулеметы и автоматические дробовики.",
		["loading_new_units_res_16"] = "Отряды Браво появляются только в режиме Pro Job, во время Точки невозврата. Это опасные противники, обладающие усиленными бронежилетами и более мощным оружием.",
		["loading_new_units_res_17"] = "Отряды Браво используют осколочные гранаты. Обращайте внимание на их уникальные звук и эффект.",
		["loading_new_units_res_18"] = "АКАН использует собственных Титановых юнитов - так называемая D-СЕРИЯ, разработанная корпорацией DRAK.",
		["loading_new_units_res_19"] = "Гренадер использует гранаты со слезоточивым газом, которые наносят продолжительный урон игрокам, стоящим в облаке. На 'Смертном приговоре' он вооружен более смертоносным паралитическим газом, который также уменьшает выносливость.",
		["loading_new_units_res_20"] = "Титановые щиты могут ослепить вас, используя свой щит. Следите за красными огнями и звуками, которые издают щиты во время подготовки к вспышке. Вы можете выстрелить в световую панель во время зарядки, чтобы оглушить противника.",
		--Captain Hints
		["loading_captains_res_title"] = "Restoration - советы о капитанах",
		["loading_captains_res_1"] = "Чтобы победить капитана Саммерса, нужно сначала обезвредить его команду, начиная с Дока. Саммерс будет неубиваем, пока вся его команда жива; остальные двое будут практически неуязвимы, пока жив Док.",
		["loading_captains_res_2"] = "Не жмитесь к Капитану Саммерсу, он быстро сожжет вас.",
		["loading_captains_res_3"] = "Капитан Спринг выдерживает много урона, но рано или поздно погибнет. Остерегайтесь его гранат и пользуйтесь его низкой скоростью.",
		["loading_captains_res_4"] = "Капитан Спринг периодически бросает кластерные осколочные гранаты. Не стойте возле него слишком долго.",
		["loading_captains_res_5"] = "Капитан Спринг может быть опасным, но это компенсируется его низкой скоростью и дальнобойностью.",
		["loading_captains_res_6"] = "Капитан Отем громко смеется во время своих атак.",
		["loading_captains_res_7"] = "В отличие от других капитанов, полиция не анонсирует появление капитана Отема, чтобы не испортить сюрприз.",
		["loading_captains_res_8"] = "Капитан Отем будет постепенно отключать ваше снаряжение, если дать ему оставаться незамеченным продолжительное время. Отключенное снаряжение помечено фиолетовым и будет восстановлено только после смерти Отема.",
		["loading_captains_res_9"] = "Вряд ли у вас получится победить капитана Отема в кулачном бою. Не стоит пробовать.",
		["loading_captains_res_10"] = "Капитан Винтерс практически неуязвим к взрывчатке и огню, обладает сильной защитой от пуль, но достаточно слаб в ближнем бою.",
		["loading_captains_res_11"] = "Щит Капитана Винтерса совершенно невозможно пробить, но вы можете попытаться выбить его из рук. Если будете вести продолжительный огонь по щиту, то Винтерс сбросит его и войдет в ярость.",
		["loading_captains_res_12"] = "Капитан Винтерс двигается по карте, постоянно подлечивая врагов.",
		["loading_captains_res_13"] = "Щит Капитана Винтерса также может ослепить вас. Но в отличие от титановых щитов, вы не cможете прервать зарядку его световой панели.",
		--Stealth Hints
	    ["loading_stealth_res_title"] = "Restoration - советы о стелсе",
		["loading_stealth_res_1"] = "Оператор посылает охранников на осмотр сломанных камер, поэтому камеры можно использовать как приманку.",
		["loading_stealth_res_2"] = "Если быстро убить охранника холодным оружием, то пейджер не сработает.",
		["loading_stealth_res_3"] = "Оператор может заметить убитых охранников и отправить замену.",
		["loading_stealth_res_4"] = "Охранники, не имеющие пейджеров, не увеличивают шкалу подозрения при смерти.",
		["loading_stealth_res_5"] = "Любое громкое оружие в стелсе имеет расстояние шума в 25 метров.",
		["loading_stealth_res_6"] = "Гражданские падают на землю, когда слышат стрельбу как при громком прохождении, так и стелсе.",
		["loading_stealth_res_7"] = "Турели заставляют лежать всех гражданских в достаточно высоком радиусе.",
		["loading_stealth_res_8"] = "Когда вы несете сумку, вас будут замечать с гораздо большей дистанции, а также гораздо быстрее, если вы стоите, бежите или прыгаете. Двигайтесь медленно и вприсядку.",
		["loading_stealth_res_9"] = "Вы можете брать до 4 Генераторов помех вместо 2 из ванильной игры, но их время действия сокращено в два раза.",
		["loading_stealth_res_10"] = "Оружие с глушителем не издает никакого шума в стелсе.",
		["loading_stealth_res_11"] = "Вы можете взять в заложники до 8 охранников.",
		["loading_stealth_res_12"] = "Стелс теперь прощает ошибки, позволяя перестраивать планы на лету.",
		["loading_stealth_res_13"] = "Охранники больше не погибают мгновенно от любого урона, если они не встревожены. Цельтесь в голову или используйте оружие ближнего боя с высоким уроном.",
		["loading_stealth_res_14"] = "Когда шкала подозрения заполнится полностью, у вас будет 60 секунд, прежде чем включится тревога.",
		["loading_stealth_res_15"] = "Чем выше шкала подозрения, тем быстрее вас замечают охранники. ",
		["loading_stealth_res_16"] = "Вы можете использовать больше мешков для трупов, чем в ванильной игре, и еще больше, если находитесь в одиночной игре.",
		["loading_stealth_res_17"] = "В одиночной игре у вас будет больше стяжек, чтобы компенсировать недостающих игроков. Их количество будет также увеличено от соответствующих навыков.",
		["loading_stealth_res_18"] = "Охранники, убитые из огнестрельного оружия, включат пейджер. Включение пейджеров не увеличит шкалу подозрения, если, конечно, их не игнорировать",
		["loading_stealth_res_19"] = "На высоких сложностях, оператор пейджеров не такой доверчивый. Использование последнего пейджера обозначается особой фразой от оператора.",
		["loading_stealth_res_20"] = "Ответ на пейджер после того, как лимит исчерпан, очень сильно увеличит шкалу подозрения, но это все равно лучше, чем сбросить или не отвечать вовсе.",
		["loading_stealth_res_21"] = "На высоких сложностях пейджеры требуют быстрой реакции и занимают больше времени на ответ.",
		--Equipment/Skill Hints
		["loading_equip_skills_res_title"] = "Restoration - советы о снаряжении и навыках",
		["loading_equip_skills_res_1"] = "Дробовики с низкой Точностью теряют эффективность на расстоянии, дробовики с высокой - теряют возможность поразить несколько целей. Экспериментируйте и выясняйте, что подходит именно вам!",
		["loading_equip_skills_res_2"] = "Пистолеты достаются быстрее всех остальных категорий оружия.",
		["loading_equip_skills_res_3"] = "Оружие в Restoration разделено на различные классы со своими плюсами и минусами. Оружие с большим уроном убивает врагов быстрее, но и опустошается так же быстро! ",
		["loading_equip_skills_res_4"] = "Оружие с высоким уроном, как правило, менее скрытно, если у него нет значительных минусов, таких как низкие Точность и Скорострельность. ",
		["loading_equip_skills_res_5"] = "Вульф прокачал Турели - теперь их можно ремонтировать прямо во время боя. Это занимает время, но зато процесс автоматический - вам нужно только запустить его.",
		["loading_equip_skills_res_6"] = "Если у вас открыты бронебойные патроны для Турелей, вы можете выбрать стандартный тип патронов в меню снаряжения. ",
		["loading_equip_skills_res_7"] = "Наборы перков предоставляют значительный бонус к урону, и многие из них обладают чрезвычайно нужными навыками лечения.",
		["loading_equip_skills_res_8"] = "Капо, Оружейник, Силовик, Аферист и Шулер - это простые и поэтому надежные наборы перков.",
		["loading_equip_skills_res_9"] = "Киллер (Hitman) был переработан в набор перков, который обладает низкой выживаемостью и надежностью, но взамен предоставляет возможность получить большое количество 'временного здоровья', чтобы пробиться через сложные ситуации.",
		["loading_equip_skills_res_10"] = "Капо (Crew Chief) - это командный набор перков, который предоставляет небольшие, но полезные бонусы для вас и ваших соратников, и еще больше бонусов, если вы берете заложников. Он хорошо сочетается с веткой Командира у Манипулятора.",
		["loading_equip_skills_res_11"] = "Шулер (Gambler) - это командный набор перков, который предоставляет немного здоровья вам и бонусные боеприпасы для ваших товарищей, когда вы подбираете патроны. Хорошо сочетается с навыками, которые дают дополнительные коробки патронов с врагов.",
		["loading_equip_skills_res_12"] = "Маньяк (Maniac) - это агрессивный и командный набор перков, который понижает повреждения по вам и вашим соратникам, если вы безостановочно наносите урон. Хорошо сочетается с билдами, в которых есть высокий урон и сопротивление урону.",
		["loading_equip_skills_res_13"] = "Карманный генератор помех Хакера (Hacker) предоставляет лечение и сдерживание толпы всей команде, но долго перезаряжается. Помимо этого, он эффективен в стелсе.",
		["loading_equip_skills_res_14"] = "Взломщик (Burglar) - колода для Уворота, которая награждает скрытность во время боя.",
		["loading_equip_skills_res_15"] = "Вор в законе (Kingpin) - гибкий набор перков. Инъектор можно использовать для самолечения, защиты от большого урона, или отвлечения противников от вашей команды.",
		["loading_equip_skills_res_16"] = "Тандем (Tag Team) - командный набор перков, который позволяет предоставить большое количество лечения конкретному соратнику, при условии, что вы вдвоем устраняете врагов без остановки.",
		["loading_equip_skills_res_17"] = "Бронебойные пули, пробившие щит, нанесут 50% урона.",
		["loading_equip_skills_res_18"] = "Револьверы Peacemaker и Phoenix .500 могут пробивать врагов, стены и щиты, как снайперские винтовки.",
		["loading_equip_skills_res_19"] = "Справа на экране может отображаться шкала синего цвета - это ваш показатель Уворота. Когда шкала подсвечивается, вы увернетесь от следующей пули. Для более подробного объяснения механики Уворота, используйте Гайд.",
		["loading_equip_skills_res_20"] = "Чем выше Компактность оружия, тем быстрее вы его достаете и убираете.",
		["loading_equip_skills_res_21"] = "Когда вы достаете Бензопилу или Казагуруму, они наносят урон противникам впереди вас.",
		["loading_equip_skills_res_22"] = "Нож-бабочка и Выкидной нож наносят огромный урон при атаке со спины.",
		["loading_equip_skills_res_23"] = "Ледоруб и Золотая лихорадка наносят дополнительный урон в голову, но обладают низкой скоростью атаки.",
		["loading_equip_skills_res_24"] = "Яд наносит небольшой урон, но вызывает рвоту, которая прерывает действия врагов.",
		["loading_equip_skills_res_25"] = "Оглушающие гранаты являются отличным инструментом отвлечения, даже против Бульдозеров.",
		["loading_equip_skills_res_26"] = "Прицеливание значительно увеличивает точность и уменьшает отдачу, даже у пулеметов.",
		["loading_equip_skills_res_27"] = "Гвоздомет - оружие ближнего боя с очень высокой дальнобойностью - он бьет гораздо дальше, чем любое другое оружие ближнего боя.",
		["loading_equip_skills_res_28"] = "Прокачивайте наборы перков, чтобы открыть Кейс с метательным оружием.",
		["loading_equip_skills_res_29"] = "Одна коробочка из Кейса с метательным оружием теперь полностью восстанавливает ваш запас метательного оружия.",
		["loading_equip_skills_res_30"] = "Берегите Пиковый навык Мотивация (Inspire Ace) для действительно опасной ситуации, ведь он очень долго перезаряжается и требует прямую видимость.",
		["loading_equip_skills_res_31"] = "Restoration Mod добавляет два дополнительных набора перков, которые предоставляют больше денег и опыта, но отключают перки. Испытайте себя ради увеличенных наград!",
		["loading_equip_skills_res_32"] = "Чтобы получить бонус к прицеливанию, требуется дождаться конца анимации прицеливания. Следите за характеристикой \"Прицеливание\", когда настраиваете оружие.",
		["loading_equip_skills_res_33"] = "Длинные стволы, крупные приклады и большие магазины имеют хорошие преимущества, но вредят скорости переключения, перезарядки, прицеливания и задержку после бега. Если слишком увлечетесь ими, оружие станет слишком медленным для использования.",
		["loading_equip_skills_res_34"] = "Скорость удара прикладом зависит от Компактности вашего оружия.",
		["loading_equip_skills_res_35"] = "Характеристика \"Прицеливание\" влияет на задержку после бега, на время которой вы не можете стрелять.",
		["loading_equip_skills_res_36"] = "Глушители уменьшают шанс того, что враги увернутся от вашей атаки. Учтите, что вместо уворота они откроют по вам огонь.",
		["loading_equip_skills_res_37"] = "Чем выше показатель увеличения у прицела, тем меньше будет отдача во время стрельбы в режиме прицеливания.",
		["loading_equip_skills_res_38"] = "Характеристика \"Прорубание\" у оружия ближнего боя показывает, как много врагов Вы можете зацепить во время удара.",
		["loading_equip_skills_res_39"] = "Оружия, стреляющие залпом (например, дробовики), отбросят большую часть противников при их поражении на близкой дистанции.",
		["loading_equip_skills_res_40"] = "Точность вашего оружия также влияет на горизонтальную отдачу.",
		["loading_equip_skills_res_41"] = "Стабильность вашего оружия также влияет на точность стрельбы от бедра.",
		["loading_equip_skills_res_42"] = "Байкер (Biker) был убит в начале 2026 года. Если вам нужен старый набор перков Байкера, тогда используйте Кровопийцу (Leech).",
		["loading_equip_skills_res_43"] = "Набор перков Байкера (Biker) был переделан, вознаграждая сплоченность вашей команды. Чем дольше вы с напарниками держитесь рядом, тем мощнее становятся выбранные вами эффекты набора перков.",
		["loading_equip_skills_res_44"] = "Набор перков Байкера (Biker) повышает уровни Единства как от вас, так и от других грабителей с тем же набором перков, также позволяя использовать все эффекты Байкера. Мир не настолько жесток, чтобы в нем не было места для двух и более Байкеров.",
		
		--Misc Hints
		["loading_misc_res_title"] = "Restoration - прочие подсказки",
		["loading_misc_res_1"] = "Попробуйте новые ограбления из Restoration! Вы можете найти их у заказчика 'Джекел', а также ограбление 'Наркопритон' у Влада.",
		["loading_misc_res_2"] = "У Restoration Mod есть гайд в Steam и на YouTube! В них содержится вся нужная информация о моде. Ссылка в главном меню.",
		["loading_misc_res_3"] = "У сообщества Restoration Mod есть Дискорд-канал! Присоединяйтесь для обсуждений, технической помощи и нахождения игроков. Ссылка в главном меню.",
		--Trivia Hints
		["loading_fluff_res_title"] = "Restoration - интересные факты",
		["loading_fluff_res_1"] = "OMNIA тратит капитал на восстановление неудачных военных проектов.",
		["loading_fluff_res_2"] = "Для LPF пиво наливают бесплатно.",
		["loading_fluff_res_3"] = "LPF и Титановый Снайпер - австралийцы.",
		["loading_fluff_res_4"] = "Нью-Йоркский Бронко Коп обожает пончики.",
		["loading_fluff_res_5"] = "Настоящее имя элитного ZEAL SWAT с UMP - Чад.",
		["loading_fluff_res_6"] = "Глаза Титановых Дозеров светятся благодаря генетической инженерии, экспериментам и боевым наркотикам.",
		["loading_fluff_res_7"] = "Капитан Спринг - не человек. Хотя говорят, что когда-то он им был.",
		-- KLEITON и Tom Blaine, простите, но уже не актуально :roflan_pominki:
		["loading_fluff_res_8"] = "В этой игре нет баланса. А в Restoration Mod - тем более.",
		["loading_fluff_res_9"] = "OMNIA разрабатывала двери, способные выдержать атаку динозавров.",
		["loading_fluff_res_10"] = "Гренадер раньше работал в центре дезинфекции.",
		["loading_fluff_res_11"] = "Вы никогда не видели Титанового Клокера.",
		["loading_fluff_res_12"] = "Omnia — музыкальная группа, сама определяющая свой стиль, как 'неокельтский языческий фолк', основана в Нидерландах и Бельгии. Неизвестно, есть ли у нее связь с организацией OMNIA.",
		["loading_fluff_res_13"] = "Джекел отказывается рассказывать, из-за какого события он покинул GenSec и начал работать на CrimeNet. Он был крайне им возмущен.",
		["loading_fluff_res_14"] = "ХАХАХАХА.",
		["loading_fluff_res_15"] = "Капитан Саммерс и его команда были бандой из четырех грабителей, прямо как банда Payday. Теперь они - нападающий отряд, работающий на OMNIA.",
		["loading_fluff_res_16"] = "По официальной версии, Капитан Саммерс и его команда погибли, когда на них обрушилась крыша банка во время ограбления. Это, конечно, утка.",
		["loading_fluff_res_17"] = "Капитан Отем тратит состояние на наручники. ",
		["loading_fluff_res_18"] = "Капитан Саммерс тратит состояние на газ, газ, газ.",
		["loading_fluff_res_19"] = "Капитан Спрингс тратит состояние на патроны и гранаты.",
		["loading_fluff_res_20"] = "Капитан Винтерс тратит состояние на щиты и изоленту.",
		["loading_fluff_res_21"] = "Дивизия Гренадеров тратит состояние на лечение химических ожогов из-за частых инцидентов с огнем по своим.",
		["loading_fluff_res_22"] = "Возможно вы встречались с Капитаном Саммерсом раньше. А возможно и нет.",
		["loading_fluff_res_23"] = "Мексиканская федеральная полиция имеет особый отряд по охоте на чупакабру.",
		["loading_fluff_res_24"] = "Капитаны не умирают, а отправляются под стражу.",
		["loading_fluff_res_25"] = "АКАН предложил 'быструю и жестокую расправу над картелями' по цене дешевле, чем OMNIA - поэтому мексиканская федеральная полиция пополнила состав Д-серией DRAK. На самом деле это уловка, чтобы подобраться ближе к операциям OMNIA в Мексике и США.",

	})
end)

-- Мутаторы
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Mutators", function(loc)
	LocalizationManager:add_localized_strings({
		["menu_mutators_achievement_disabled"] = "",
		["menu_mutators_category_holiday"] = "ПРАЗДНИКИ",
		["menu_mutators_category_old_event"] = "ИВЕНТЫ",
		["menu_mutators_category_crime_spree"] = "СЕРИЯ ОГРАБЛЕНИЙ",

		--Enemy Replacers
		["mutator_specials_override_boom"] = "Гренадеры",
		["mutator_specials_override_sniper"] = "Снайперы",

		["mutator_titandozers_desc"] = "Хэллоуинские эффекты",
		["mutator_titandozers_longdesc"] = "Безголовый Бульдозер сбежал из кошмаров Вульфа в реальность! Обычные Бульдозеры заменены на Безголовых, а также включены особые хэллоуинские эффекты.",

		["mutator_medidozer_longdesc"] = "Все обычные враги заменены на медиков, все специальные враги заменены на Бульдозеров.",
		["mutator_medicdozers"] = "Дозеры-медики",
		["mutator_medicdozers_desc"] = "Теперь появляются Дозеры-медики.",
		["mutator_medicdozers_longdesc"] = "Каждый раз, когда появляется Бульдозер, есть 50% шанс, что его заменит Бульдозер-медик.\n\nЕсли включен мутатор 'Бульдозеры с полуавтоматическими дробовиками', Бульдозеры-медики будут заменять Черныйх Бульдозеров с шансом 33.3%.",

		--Alternative arsenal
		["mutator_enemy_damage_longdesc"] = "Игроки будут получать больше или меньше урона от противников, чем обычно.",

		--Because of Training
		["mutator_enemy_health_longdesc"] = "Противники будут появляться с большим или меньшим кол-вом здоровья, чем обычно.",

		["mutator_notitans"] = "Сокращение бюджета",
		["mutator_notitans_desc"] = "Отключает Титановых юнитов.",
		["mutator_notitans_longdesc"] = "Любые появления Титановых юнитов отключены.",

		["mutator_onlytitans"] = "Повышение бюджета",
		["mutator_onlytitans_desc"] = "Титановые юниты заменяют всех обычных юнитов.",
		["mutator_onlytitans_longdesc"] = "Вместо обычных юнитов будут появляться их Титановые версии.",

		["mutator_mememanonly"] = "ХАХАХА, ОБМАНУЛ ВАС!",
		["mutator_mememanonly_desc"] = "СТРАДАЙ",
		["mutator_mememanonly_longdesc"] = "НЕУБЕЖАТЬНЕСПАСТИСЬПОМОГИТЕ\n\n ВНИМАНИЕ: Может вызвать вылет игры на некоторых картах.",

		["MutatorMoreDonutsPlus"] = "Больше пончиков+",
		["MutatorMoreDonutsPlus_desc"] = "Все обычные враги будут заменены на копов с револьвером Bronco, все особые враги будут заменены на LPF.",
		["MutatorMoreDonutsPlus_longdesc"] = "Все обычные враги будут заменены на копов с револьвером Bronco, все особые враги будут заменены на LPF.\n\nВНИМАНИЕ: Не стоит играть с этим отвратительным мутатором.",

		["MutatorJungleInferno"] = "Диско Инферно",
		["MutatorJungleInferno_desc"] = "Все враги теперь бегают с огнеметами.",
		["MutatorJungleInferno_longdesc"] = "Оружие всех противников заменяется на огнемет. Не работает для щитов и снайперов.",

		["mutator_minidozers"] = "Бульдозеры с полуавтоматическими дробовиками",
		["mutator_minidozers_desc"] = "Теперь появляются Бульдозеры с полуавтоматическими дробовиками.",
		["mutator_minidozers_longdesc"] = "Каждый раз, когда появляется Черный Бульдозер, есть 50% шанс того, что его заметит Бульдозер с M1014.\n\nЕсли включен мутатор 'Дозеры-медики', Бульдозеры с M1014 будут заменять Черных Бульдозеров с шансом 33.3%.",

		["mutator_fatroll"] = "Лютый троллинг",
		["mutator_fatroll_desc"] = "Грейс период (в с)",
		["mutator_fatroll_longdesc"] = "Задержка на получение урона для игроков и ботов теперь зависит от этого значения.",

		["mutator_overheal"] = "Эксперт сверхлечения",
		["menu_mutator_overheal_mult_override"] = "Множитель сверхлечения",
		["menu_mutator_overheal_mult_override_toggle"] = "Включить сверхлечение для капитанов",
		["mutator_overheal_desc"] = "LPF теперь может давать дополнительное здоровье почти всем противникам.",
		["mutator_overheal_longdesc"] = "LPF теперь может давать дополнительное здоровье всем противникам, кроме клокеров. \n\nПримечание:Мутатор не может перезаписать значение множителя для тех противников, множитель у которых выше, чем заданное Вами значение.",

		["mutator_asu_buff"] = "Мощь всех стволов",
		["menu_mutator_captain_asu_buff_toggle"] = "Включить усиления урона для капитанов",
		["mutator_asu_buff_desc"] = "ASU теперь может усиливать оружия особых противников.",
		["mutator_asu_buff_longdesc"] = "ASU теперь может усиливать оружия особых противников (кроме клокеров) и усиливает урон оружий как на сложности Смертный Приговор.",

		["mutator_bo_flashbang"] = "Your Opinion - My Choice",
		["menu_mutator_flashbang_cooking_time"] = "Время до срабатывания (в с)",
		["mutator_bo_flashbang_desc"] = "Светошумовые гранаты теперь нельзя сломать.",
		["mutator_bo_flashbang_longdesc"] = "Светошумовые гранаты теперь нельзя сломать.",

		["mutator_grenade_mayhem"] = "Тотальное побоище!",
		["menu_mutator_grenade_mayhem_usuals_toggle"] = "Гранаты для обычных и элитных врагов",
		["menu_mutator_grenade_mayhem_thugs_toggle"] = "Гранаты для бандитов",
		["menu_mutator_grenade_mayhem_specials_toggle"] = "Гранаты для особых врагов",
		["menu_mutator_grenade_mayhem_bosses_toggle"] = "Гранаты для боссов",
		["menu_mutator_grenade_mayhem_captains_toggle"] = "Гранаты для капитанов",
		--["menu_mutator_grenade_mayhem_sosa_cosplay_toggle"] = "Include Frag Underbarrels for Grenadiers",
		["mutator_grenade_mayhem_desc"] = "Позволяет всем противникам использовать осколочные гранаты.",
		["mutator_grenade_mayhem_longdesc"] = "Теперь осколочные гранаты доступны не только отрядам Браво.\n\nПримечание: Враги с огнеметами будут бросать молотовы; Клокеры будут использовать слезоточивый газ.",

		["mutator_captain_replace"] = "Вечная непогода",
		["menu_mutator_captain_replace_1"] = "Капитан (день 1)",
		["menu_mutator_captain_replace_2"] = "Капитан (день 2)",
		["menu_mutator_captain_replace_3"] = "Капитан (день 3)",
		["menu_mutator_captain_replace_no_captain_override"] = "Без изменений",
		["menu_mutator_captain_replace_captain_random"] = "Случайный",
		["menu_mutator_captain_replace_winter"] = "Винтерс",
		["menu_mutator_captain_replace_autumn"] = "Отем",
		["menu_mutator_captain_replace_spring"] = "Спринг",
		["menu_mutator_captain_replace_summer"] = "Саммерс",
		["menu_mutator_captain_replace_hvh"] = "АТБГШИЛ",
		["menu_mutator_winter_blacklist_toggle"] = "Исключить Винтерса из случайного выбора",
		["menu_mutator_spring_blacklist_toggle"] = "Исключить Спринга из случайного выбора",
		["menu_mutator_summer_blacklist_toggle"] = "Исключить Саммерса из случайного выбора",
		["menu_mutator_autumn_blacklist_toggle"] = "Исключить Отема из случайного выбора",
		["menu_mutator_hvh_blacklist_toggle"] = "Исключить АТБГШИЛ из случайного выбора",
		["mutator_captain_replace_desc"] = "Позволяет менять капитана, который может появиться на ограблении.",
		["mutator_captain_replace_longdesc"] = "Позволяет менять капитана, который может появиться на ограблении.\n\nПримечание: Мутатор не может заменить капитанов, которые приходят по скрипту. Исключение всех капитанов из случайного выбора приведет к использованию настройки \"Без изменений\".",

		["mutator_no_outlines"] = "Эксперт Реализм",
		["mutator_no_outlines_desc"] = "Почти все контуры отключены.",
		["mutator_no_outlines_longdesc"] = "Почти все контуры отключены. Также отключены ники над ботами/игроками.",
		["menu_mutator_no_outlines_enemies_toggle"] = "Выключить подсвечивающие контуры (кроме обводки для сопровождения цели)",
		["menu_mutator_no_outlines_deployables_toggle"] = "Выключить контуры снаряжения",
		["menu_mutator_no_outlines_ammo_pickups_toggle"] = "Выключить контуры для пачек с патронами и метательного",

		["mutator_spawn_mult"] = "Увеличенные отряды",
		["menu_mutator_enemy_spawn"] = "МНОЖИТЕЛЬ СПАУНОВ",
		["mutator_spawn_mult_desc"] = "Спауны врагов увеличены.",
		["mutator_spawn_mult_longdesc"] = "Во время штурмов будет спаунится больше врагов. Почувствуйте себя Джулсом!",

		["mutator_birthday"] = "Гелиевая вечеринка",
		["mutator_birthday_desc"] = "Убийство особых врагов спаунит шарики, которые дают бонусы.",
		["mutator_birthday_longdesc"] = "Восьмилетие PAYDAY:\n\nУбийство особых врагов заспаунит шарики, которые можно прострелить чтобы получить бонусы для всей команды. Некоторые враги спаунят шарики чаще. Можно активировать несколько бонусов сразу.",

		["mutator_CG22"] = "Криминальные колядки",
		["mutator_CG22_desc"] = "На некоторых ограблениях появится елка, которая дает подарки.",
		["mutator_CG22_longdesc"] = "Рождество 2022:\n\nНа некоторых ограблениях появляются елки, которые дают подарки. Подарки можно уничтожить и получить временные бонусы, или отдать Хайрудину для бонусного опыта, денег и монет Континеталь. При использовании подарков может появиться Бульдозер-Снеговик.",

		["mutator_thecandlesburnoutforyou"] = "Марафон перезарядок",
		["mutator_thecandlesburnoutforyou_desc"] = "Отключает автоперезарядку, когда в вашем оружии закончатся патроны в магазине.",
		["mutator_thecandlesburnoutforyou_longdesc"] = "Отключает автоперезарядку когда в вашем оружие закончатся патроны в магазине, требуется ручной ввод, как раньше больше не позажимать....",

		["mutator_letthesleepinggoddie"] = "Криворукий",
		["mutator_letthesleepinggoddie_desc"] = "Неполная перезарядка приводит к сбросу магазина.",
		["mutator_letthesleepinggoddie_longdesc"] = "Неполная перезарядка приводит к сбросу магазина.\n\nNote: Оружие, в котором сохраняются патроны во время перезарядки (перезарядка по одному патрону, перезарядки с удержанием магазина, и так далее.) а также перезарядка, вызванная навыками, не провоцирует действия мутатора.",
		["mutator_letthesleepinggoddie_no_effect"] = "Не провоцирует действие мутатора \"Криворукий\".",
		
		["mutator_no_ammo_drops"] = "Дефицит патронов",
		["menu_mutator_ammo_drop_chance"] = "Шанс выпадения патронов (в %)",
		["menu_mutator_ammo_drop_chance_ingame"] = "шанс выпадения патронов",
		["menu_mutator_no_ammo_drops"] = "Без выпадения патронов",
		["mutator_no_ammo_drops_desc"] = "Позволяет отключить коробки патронов с врагов, или изменить процент их выпадения.",
		["mutator_no_ammo_drops_longdesc"] = "Позволяет отключить коробки патронов с врагов, или изменить процент их выпадения.",

		["mutator_advancedtraining"] = "Современные тренировки",
		["mutator_advancedtraining_desc"] = "Враги имеют здоровье и наносят урон как на сложности 'Смертный Приговор'.",
		["mutator_advancedtraining_longdesc"] = "Враги имеют здоровье и наносят урон как на сложности 'Смертный Приговор' наряду с их способностями (из-за тренировок).",
		
		["menu_cg22_post_objective_1_desc"] = "Убить 200 врагов из любой снайперской винтовки.",
		["menu_cg22_post_objective_2_desc"] = "Убить 15 Клокеров из винтовки 'Полярная Звезда' на сложности 'Очень Сложно' или выше.",
		["menu_cg22_post_objective_3_desc"] = "Сделать 50 двойных убийств из винтовки 'Полярная Звезда' на любой сложности.",
		["menu_cg22_post_objective_4_desc"] = "Украсть 10 сумок и успешно сбежать на любой сложности.",
		["menu_cg22_post_objective_5_desc"] = "Убить 10 Бульдозеров на сложности 'OVERKILL' или выше.",
		["menu_cg22_post_objective_6_desc"] = "Украсть 25 сумок и успешно сбежать на любой сложности.",
		["menu_cg22_post_objective_7_desc"] = "Украсть 50 сумок и успешно сбежать на любой сложности.",
		["menu_cg22_post_objective_8_desc"] = "Убить 20 Бульдозеров на сложности 'OVERKILL' или выше.",
		["menu_cg22_post_objective_9_desc"] = "Украсть 75 сумок и успешно сбежать на любой сложности.",

		["mutator_piggybank"] = "Покорми свинью",
		["mutator_piggybank_desc"] = "Убийство врагов дает свинобаксы, которыми можно покормить золотую свинью.",
		["mutator_piggybank_longdesc"] = "Девятилетие PAYDAY:\n\nУбитые враги роняют свинобаксы. Свинобаксы - временные сумки, которыми можно кормить Золотую Свинку. Чем больше Свинка растет, тем больше бонусного денег и опыта вы получите в конце ограбления.",

		["mutator_piggyrevenge"] = "Плохие свинки",
		["mutator_piggyrevenge_desc"] = "Убийство врагов дает свинобаксы, которыми можно покормить золотую свинью.",
		["mutator_piggyrevenge_longdesc"] = "Десятилетие PAYDAY:\n\nУбитые враги роняют свинобаксы. Свинобаксы - временные сумки, которыми можно кормить Золотую Свинку. Когда вы кормите свинью, есть шанс того, что появится дозер-кабан с огнеметом. Чем больше Свинка растет, тем больше бонусного денег и опыта вы получите в конце ограбления.",

		["menu_pda10_post_objective_3_desc"] = "Пройдите 25 ограблений на любой сложности",
		["menu_pda10_post_objective_5_desc"] = "Убейте 50 врагов, используя снайперские винтовки",
		["menu_pda10_post_objective_2_desc"] = "Украдите 50 сумок",
		["menu_pda10_post_objective_6_desc"] = "Убейте 50 врагов, используя оружие ближнего боя",
		["menu_pda10_post_objective_1_desc"] = "Убейте 50 бульдозеров",
		["menu_pda10_post_objective_4_desc"] = "Соберите 50 посылок Гейджа",

		["mutator_bravos_only"] = "Профессиональный день",
		["mutator_bravos_only_desc"] = "Враги заменены на свои PONR-варианты.",
		["mutator_bravos_only_longdesc"] = "Враги заменены на варианты, которые появляются при Точке Невозврата (PONR) в режиме Pro-Job. Синий спецназ заменен на спецназ ФБР, а спецназ ФБР заменен на отряды Браво.\n\nЕсли выбранный метод замены - 'Случайная замена', то шанс замены врага будет увеличиваться после каждого штурма до заданного предела.\n\nЕсли выбранный метод - `Протокол ЧС`, то замена врагов начнется после того, как интенсивность штурма дойдет до заданной отметки.",
		["menu_bravo_replacement_choice"] = "Режим замены врагов",
		["menu_mutator_bravo_replacement_all"] = "Полная замена",
		["menu_mutator_bravo_replacement_random"] = "Случайная замена",
		["menu_mutator_bravo_replacement_slider"] = "Шанс замены (в %)",
		["menu_mutator_bravo_replacement_mode_13"] = "Протокол ЧС",
		["menu_mutator_bravo_replacement_increase_slider"] = "Увеличение шанса замены (в %)",
		["menu_mutator_bravo_replacement_max_slider"] = "Потолок увеличения шанса замены (в %)",
		["menu_mutator_bravo_replacement_increase_min_assaults_slider"] = "Кол-во штурмов для поднятия шанса замены",
		["menu_mutator_bravo_replacement_mode_13_slider"] = "Кол-во интенсивности для активации",


		["mutator_zombie_outbreak"] = "Ходячие мертвецы",
		["mutator_zombie_outbreak_desc"] = "Все враги заменены зомби",
		["mutator_zombie_outbreak_longdesc"] = "Мертвые восстали! Заменяет всех врагов на зомби-юнитов.",

		["mutator_faction_replace"] = "Faction Replacer",
		["mutator_faction_replace_desc"] = "Faction Replacer desc",
		["mutator_faction_replace_longdesc"] = "Faction Replacer longdesc",
		["menu_mutator_faction_replace"] = "Faction",
		["menu_mutator_faction_replace_america"] = "America",
		["menu_mutator_faction_replace_russia"] = "Russia",
		["menu_mutator_faction_replace_zombie"] = "Zombie",
		["menu_mutator_faction_replace_murkywater"] = "MurkyWater",
		["menu_mutator_faction_replace_federales"] = "Federales",
		["menu_mutator_faction_replace_nypd"] = "NYPD",
		["menu_mutator_faction_replace_lapd"] = "LAPD",	
		["faction_selector_choice"] = "Faction: ",

		["mutator_high_noon"] = "Red Dead: The Heist",
		["menu_mutator_high_noon"] = "Red Dead: The Heist",
		["mutator_high_noon_desc"] = "Wild West DC.",
		["mutator_high_noon_longdesc"] = "Howdy Cowboys! Prepare to fan your hammers in a thrilling heist of rustlers and deputies.\n\nNo Tactical Advantage Whatsoever: Can only use weapons from the age of Cowboys.",
		["bm_not_cowboy_sc"] = "CANNOT USE!!!",
		["bm_not_cowboy_sc_desc"] = "#{important_1}#Not Rootin' Tootin'!##",

		--мутаторы из кам сприи
		["mutator_cloakercuff"] = "Фокусник",
		["mutator_cloakercuff_desc"] = "Удары клокера в ближнем бою теперь заковывают Вас в наручники.",
		["mutator_cloakercuff_longdesc"] = "Удары клокера в ближнем бою теперь заковывают Вас в наручники.",

		["mutator_cloakerflashbang"] = "Ослепительный ниндзя",
		["mutator_cloakerflashbang_desc"] = "Клокеры могут выкинуть светошумовую гранату во время уворота.",
		["mutator_cloakerflashbang_longdesc"] = "Клокеры с шансом 50% могут выкинуть светошумовую гранату во время уворота.",

		["mutator_fartsmella"] = "Поставки с \"пестицидами\"",
		["mutator_fartsmella_desc"] = "Дымовые гранаты заменены на гранаты со слезоточивым газом.",
		["mutator_fartsmella_longdesc"] = "Дымовые гранаты заменены на гранаты со слезоточивым газом.\nНе работает на дымовые гранаты от мутатора \"Сделай мне больно\".",

		["mutator_kaboom"] = "Камикадзе",
		["mutator_kaboom_desc"] = "Гренадеры взрываются после смерти.",
		["mutator_kaboom_longdesc"] = "Гренадеры взрываются после смерти.",

		["mutator_fastresponse"] = "Оперативное реагирование",
		["mutator_fastresponse_desc"] = "Все полицейские штурмы теперь происходят с максимальной интенсивностью.",
		["mutator_fastresponse_longdesc"] = "Все полицейские штурмы теперь происходят с максимальной интенсивностью (сложность штурма начинается сразу с 1).",

		["mutator_fullautoinbuilding"] = "Бешеные стрелки",
		["mutator_fullautoinbuilding_desc"] = "Титановые снайперы и их эквиваленты теперь стреляют из своих винтовок в автоматическом режиме по игрокам, которые находятся близко к ним.",
		["mutator_fullautoinbuilding_longdesc"] = "Титановые снайперы и их эквиваленты теперь стреляют из своих винтовок в автоматическом режиме по игрокам, которые находятся на расстоянии не более 10 метров.",

		["mutator_crazytaser"] = "Шоковая терапия",
		["mutator_crazytaser_desc"] = "Тазеры теперь не имеют задержку перед применением удара электрошоком.",
		["mutator_crazytaser_longdesc"] = "Тазеры теперь не имеют задержку перед применением удара электрошоком.\n\nПримечание: Задержка для использования следующего удара шоком все еще есть.",

		["mutator_masterdodger"] = "Увернись от этого!",
		["mutator_masterdodger_desc"] = "Ветеран копы теперь уворачиваются от всех пуль.",
		["mutator_masterdodger_longdesc"] = "Ветеран копы теперь уворачиваются от всех пуль.",

		["mutator_quickscope360"] = "Орлиный глаз",
		["mutator_quickscope360_desc"] = "Снайперы теперь прицеливаются на 100% быстрее.",
		["mutator_quickscope360_longdesc"] = "Снайперы теперь прицеливаются на 100% быстрее.",

		["mutator_goldfarbdozers"] = "Двойные неприятности",
		["mutator_goldfarbdozers_desc"] = "Все бульдозеры теперь могут появиться парами.",
		["mutator_goldfarbdozers_longdesc"] = "Все бульдозеры теперь могут появиться парами. Не влияет на заскриптованных бульдозеров.",
		["menu_mutator_goldfarbdozers_always_pairs_toggle"] = "Всегда парами",
		["menu_mutator_goldfarbdozers_always_pairs"] = "Всегда",
		["menu_mutator_goldfarbdozers_sometimes_pairs"] = "Иногда",

		["mutator_spoocsquad"] = "Отряд ниндзя",
		["mutator_spoocsquad_desc"] = "Клокеры появляются группами.",
		["mutator_spoocsquad_longdesc"] = "Клокеры появляются группами.",

		["mutator_vanilla_police_call"] = "Посторонние на объекте",
		["mutator_vanilla_police_call_desc"] = "Возвращает обратно механики работы пейджеров, камер и звонков в полицию.",
		["mutator_vanilla_police_call_longdesc"] = "Возвращает обратно механики работы пейджеров, камер и звонков в полицию.",
	})
end)

-- Крайм (Кам) сприи ака Серия Ограблений
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Crime_Spree", function(loc)
	LocalizationManager:add_localized_strings({
	--Crime spree modifier changes
		["cn_crime_spree_brief"] = "Серия преступлений - режим, в котором вас предстоит сыграть бесконечную серию ограблений, идущих подряд. С каждым пройденным ограблением, ваши Ранг и Награда буду повышаться! Каждый 20-й и 26-й ранг вам предстоит выбрать модификатор, а каждые 100 рангов повысится уровень риска, что сделает последующие ограбления сложнее. После 600 ранга, задержка на получение урона будет уменьшаться, и среди обычных врагов начнут появляться отряды Браво.\n\n##При игре с друзьями, не забудьте убедиться, что они начали свою Серию преступлений, или они не смогут получать Ранги и Награды.##",
		["menu_cs_next_modifier_forced"] = "",
		["menu_cs_modifier_dozers"] = "Теперь на ограблениях может быть на одного Бульдозера больше.",
		["menu_cs_modifier_medics"] = "Теперь на ограблениях можеть быть на одного Медика больше.",
		["menu_cs_modifier_no_hurt"] = "Враги на 50% устойчивее к падению.",
		["menu_cs_modifier_dozer_immune"] = "Бульдозеры получают на 50% меньше урона от взрывчатки.",
		["menu_cs_modifier_bravos"] = "Враги получают дополнительный шанс 6.667% стать Браво-юнитами.",
		["menu_cs_modifier_grace"] = "Ваша задержка на получение урона уменьшена на 1/60 секунды.",
		["menu_cs_modifier_letstrygas"] = "Дымовые завесы заменены на слезоточивый газ.",
		["menu_cs_modifier_boomboom"] = "Гренадеры взрываются при смерти.",
		["menu_cs_modifier_friendlyfire"] = "Союзники теперь получают урон по своим.",
		["menu_cs_modifier_dodgethis"] = "Копы-ветераны теперь уворачиваются от всех пуль.",
		["menu_cs_modifier_sniper_aim"] = "Снайперы наводятся на 100% быстрее.",
		["menu_cs_modifier_health_damage_total"] = "",
		["menu_cs_modifier_heavies"] = "SWAT с легкими винтовками получают на 100% больший шанс стать лидером отряда + в каждом отряде может быть на одного лидера больше.",
		["menu_cs_modifier_heavy_sniper"] = "Титановые снайперы и снайперы Браво ведут автоматический огонь на близких расстояниях.",
		["menu_cs_modifier_dozer_medic"] = "Когда появляется Бульдозер, есть шанс, что его заменит Медикдозер. Медикдозер считается за Медика и Бульдозера одновременно.",
		["menu_cs_modifier_dozer_minigun"] = "Когда появляется Зеленый или Черный Бульдозер, есть шанс, что его заменит Бульдозер с М1014.",
		["menu_cs_modifier_shield_phalanx"] = "Все обычные Щиты получают дополнительный 15% шанс стать Титановыми щитами.",
		["menu_cs_modifier_taser_overcharge"] = "Тазерам теперь не нужно заряжать шокер перед выстрелом. Задержка между попытками остается.",
		["menu_cs_modifier_dozer_rage"] = "Когда визор Бульдозера уничтожен, он войдет в ярость, получая 10% к наносимому урону.",
		["menu_cs_modifier_medic_adrenaline"] = "Все Медики получают дополнительный 15% шанс стать OMNIA LPF или огнеметчиком DRAK, в зависимости от фракции.",
		["menu_cs_modifier_cloaker_arrest"] = "Атаки Клокеров в ближнем бою теперь заковывают игроков.",
		["menu_cs_modifier_cloaker_smoke"] = "Клокеры теперь имеют шанс 50% сбросить светошумовую гранату, когда уворачиваются от атак.",
		["menu_cs_modifier_cloaker_tear_gas"] = "Все агенты по спасению заложников получают дополнительный 15% шанс стать Титановыми агентами.",
		["menu_cs_modifier_dozer_lmg"] = "Когда появляется Зеленый или Черный Бульдозер, есть шанс, что его заменит Скаллдозер.",
		["menu_cs_modifier_10secondsresponsetime"] = "Полицейские штурмы сразу имеют максимальную интенсивность.",
		["menu_cs_modifier_dozerpairs"] = "Все бульдозеры теперь появляются парами.",
		["menu_cs_modifier_spoocsquad"] = "Клокеры стараются появляться группами.",
		
	})
end)

-- Навыки
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Skills", function(loc)
	LocalizationManager:add_localized_strings({

		--Переименовываем названия древ
		["st_menu_mastermind_single_shot"] = "Штурмовик",
		["st_menu_enforcer"] = "Боевик",
		["st_menu_enforce_shotgun"] = "Зачинщик",
		["st_menu_enforcer_armor"] = "Джаггернаут",
		["st_menu_enforcer_ammo"] = "Поддержка",
		["st_menu_technician_auto"] = "Боевой инженер",
		["st_menu_technician_breaching"] = "Перфоратор",
		["st_menu_technician_sentry"] = "Крепость",
		["st_menu_ghost_silencer"] = "Наемный убийца",
		["menu_st_points_total"] = "Вложено очков",
		["menu_st_points_unlock"] = "ОЧКОВ ДЛЯ ОТКРЫТИЯ",
	
	--[[   SKILLTREES   ]]--

		--[[   МАНИПУЛЯТОР   ]]--

			--[[   МЕДИК   ]]--
				--Combat Medic
				["menu_combat_medic_beta_sc"] = "Интерн",
				["menu_combat_medic_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете на #{skill_color}#$skill_value_b1## меньше урона во время поднятия напарника и в течение #{skill_color}#$skill_value_b2## секунд после.\n\n#{risk}#Эффект уменьшения урона работает только при прямом взаимодействии с упавшим.##\n\nПИКОВЫЙ: #{owned}#$pro##\nПоднятый напарник получит на #{skill_color}#$skill_value_p1## больше здоровья.",

				--Quick Fix
				["menu_tea_time_beta_sc"] = "Скорая помощь",
				["menu_tea_time_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУменьшает время установки Аптечек первой помощи и Медицинских сумок на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nНапарники, которые воспользовались вашими Аптечками первой помощи, будут получать на #{skill_color}#$skill_value_p1## меньше урона в течение #{skill_color}#$skill_value_p2## секунд.",

				--Pain Killers
				["menu_fast_learner_beta_sc"] = "Анальгин",
				["menu_fast_learner_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nНапарники, поднятые вами, получают на #{skill_color}#$skill_value_b1## меньше урона в течение #{skill_color}#$skill_value_b2## секунд.\n\nПИКОВЫЙ: #{owned}#$pro##\nУрон уменьшен еще на #{skill_color}#$skill_value_p1.##",

				--Uppers
				["menu_tea_cookies_beta_sc"] = "Колеса",
				["menu_tea_cookies_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь вы можете носить #{skill_color}#$skill_value_b1## Аптечек первой помощи.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь вы можете носить #{skill_color}#$skill_value_p1## Аптечек первой помощи.\n\nВаши установленные Аптечки первой помощи #{skill_color}#автоматически поднимут## вас или любого напарника, упавшего в радиусе #{skill_color}#5## метров от нее; перезарядка автоматического подъема длится #{important_1}#$skill_value_p2## секунд для каждого, кого подняли таким образом.\n\n#{risk}#Не работает, если игрок заранее использовал эффект навыка #{skill_color}#Лебединая песня##.##",

				--Combat Doctor
				["menu_medic_2x_beta_sc"] = "Военврач",
				["menu_medic_2x_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаши Медицинские сумки содержат дополнительные припасы, что позволяет использовать их еще #{skill_color}#$skill_value_b1## раз.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь вы можете носить #{skill_color}#$skill_value_p1## Медицинские сумки.",

				--Inspire
				["menu_inspire_beta_sc"] = "Мотивация",
				["menu_inspire_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы поднимаете напарников на #{skill_color}#$skill_value_b1## быстрее.\n\nКрик на них повысит их скорость перезарядки и передвижения на #{skill_color}#$skill_value_b2## в течение #{skill_color}#$skill_value_b3## секунд.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы можете поднять упавшего напарника #{skill_color}#в зоне прямой видимости## раз в #{important_1}#$skill_value_p1## секунд, крикнув на него на расстоянии до #{skill_color}#9## метров.",

			--[[   Командир   ]]--
				--Cable Guy
				["menu_triathlete_beta_sc"] = "Навязанная дружба",
				["menu_triathlete_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаш запас кабельных стяжек увеличен на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВаш запас кабельных стяжек увеличен еще на #{skill_color}#$skill_value_p1.##\n\nВаш шанс найти кабельные стяжки в пачках патронов увеличен до #{skill_color}#30%.##",

				--Clowns are Scary
				["menu_cable_guy_beta_sc"] = "Боязнь клоунов",
				["menu_cable_guy_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nГражданские остаются запуганными на #{skill_color}#$skill_value_b1## дольше.\n\nПИКОВЫЙ: #{owned}#$pro##\nУспешность и дальность вашего запугивания увеличены на #{skill_color}#$skill_value_p1.##",

				--Stockholm Syndrome
				["menu_joker_beta_sc"] = "Стокгольмский синдром",
				["menu_joker_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКогда вы упали, гражданские и завербованные заложники рядом #{skill_color}#поднимут вас, если вы их позовете##, и дадут вам пачку патронов.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы и ваша команда поглощаете #{skill_color}#$skill_value_p1## получаемого урона за каждого заложника; складывается до #{skill_color}#$skill_value_p2## раз.\n\n#{risk}#Эффекты от нескольких игроков не складываются.##",

				--Joker
				["menu_stockholm_syndrome_beta_sc"] = "Доминатор",
				["menu_stockholm_syndrome_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nПосле поднятия тревоги вы можете переманить #{skill_color}#1## обычного врага, который сдался, на вашу сторону; он считается заложником для навыков и обмена.\n\nВаш завербованный заложник получает на #{skill_color}#$skill_value_b1## меньше урона.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь вы можете иметь #{skill_color}#2## завербованных заложников одновременно.\n\nВаши завербованные заложники получают еще на #{skill_color}#$skill_value_p1## меньше урона.",

				--Partners in Crime
				["menu_control_freak_beta_sc"] = "Сообщник",
				["menu_control_freak_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаша скорость передвижения увеличена на #{skill_color}#$skill_value_b1## за каждого заложника; складывается до #{skill_color}#4## раз.\n\nПИКОВЫЙ: #{owned}#$pro##\nВаше здоровье увеличено на #{skill_color}#$skill_value_p1## за каждого заложника; складывается до #{skill_color}#4## раз.",

				--Hostage Taker
				["menu_black_marketeer_beta_sc"] = "Похититель",
				["menu_black_marketeer_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы восстанавливаете #{skill_color}#$skill_value_b1## здоровье каждые #{skill_color}#4## секунды за каждого заложника; складывается до #{skill_color}#4## раз.\n\nПИКОВЫЙ: #{owned}#$pro##\nРегенерация здоровья от этого навыка увеличена на #{skill_color}#$skill_value_p1##, когда у вас #{skill_color}#4 или более## заложников.\n\n#{skill_color}#Ваши гражданские заложники не будут убегать##, когда их освободят.\n\n#{important_1}#1## #{risk}#раз за ограбление##, вы #{skill_color}#можете провести обмен гражданского на себя## даже во время штурма, если вы попадете под стражу.",

			--[[   Штурмовик  ]]--
				--Leadership
				["menu_stable_shot_beta_sc"] = "Лидерство",
				["menu_stable_shot_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Пулеметы## получают #{skill_color}#$skill_value_b1## стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы и ваша команда получаете #{skill_color}#$skill_value_p1## стабильности для #{skill_color}#всего оружия##.\n\n#{risk}#Эффекты от нескольких игроков не складываются.##",

				--MG Handling
				["menu_scavenger_sc"] = "Рэмбо",
				["menu_scavenger_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУменьшает разброс #{skill_color}#Пулеметов## при стрельбе от бедра на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nДополнительно уменьшает разброс #{skill_color}#Пулеметов## при стрельбе от бедра на #{skill_color}#$skill_value_p1.##\n\nВы перезаряжаете #{skill_color}#Пулеметы## на #{skill_color}#$skill_value_p2## быстрее.",

				--MG Specialist
				["menu_sharpshooter_sc"] = "Пулеметчик",
				["menu_sharpshooter_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nШтраф к точности при движении уменьшен на #{skill_color}#$skill_value_b1## для #{skill_color}#Пулеметов##.\n\nШтраф к точности при движении зависит от стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Пулеметы## стреляют на #{skill_color}#$skill_value_p1## быстрее.\n\nКаждая #{skill_color}#5-я## пуля, выпущенная из #{skill_color}#Пулемета## без отпускания спускового крючка, не тратит патроны.",

				--Shock and Awe
				["menu_spotter_teamwork_beta_sc"] = "Перегрузка",
				["menu_spotter_teamwork_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nРазмер магазина #{skill_color}#Пулеметов## увеличен на #{skill_color}#$skill_value_b1.##\n\n#{risk}#Навык не применяется к пулеметам с регенерацией патронов.##\n\nПИКОВЫЙ: #{owned}#$pro##\nУвеличение размера магазина дополнительно повышается на #{skill_color}#$skill_value_p1.##",

				--Heavy Impact
				["menu_speedy_reload_sc"] = "Шок и трепет",
				["menu_speedy_reload_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Пулеметы## имеют #{skill_color}#$skill_value_b1## шанс сбить врагов с ног.\nЭтот шанс повышается до #{skill_color}#$skill_value_b2## при использовании сошек.\n\n#{risk}#Навык не действует на## #{important_1}#капитанов, бульдозеров, снайперов или щитов.##\n\nПИКОВЫЙ: #{owned}#$pro##\nИз #{skill_color}#Пулеметов## можно стрелять от бедра во время бега, и у них отсутствует задержка перед стрельбой после бега.\n\n#{item_stage_2}#Настройка для сохранения анимаций бега находится в оружейных опциях Restoration Mod.##\n\nВы получаете на #{skill_color}#$skill_value_p1## меньше урона в приседе.\nЭтот эффект повышается до #{skill_color}#$skill_value_p2## при использовании сошек.\n ",

				--Body Expertise
				["menu_body_expertise_beta_sc"] = "Свинцовый ад",
				["menu_body_expertise_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаши #{skill_color}#Пулеметы## наносят #{skill_color}#$skill_value_b1## урона сквозь броню.\n\nПИКОВЫЙ: #{owned}#$pro##\nУбийства с помощью #{skill_color}#Пулеметов## в #{risk}#полностью автоматическом## режиме дают стак увеличения урона на #{skill_color}#$skill_value_p2##; складывается до #{skill_color}#$skill_value_p3## раз.\nСтаки сбрасываются по одному каждые #{risk}#$skill_value_p1## секунд.",

		--[[   Боевик   ]]--

			--[[   Зачинщик   ]]--
				--Underdog--
				["menu_underdog_beta_sc"] = "Давление",
				["menu_underdog_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКогда #{skill_color}#3## или более врага находятся в #{skill_color}#18## метрах от вас, вы получаете #{skill_color}#$skill_value_b1## бонус к урону на #{skill_color}#$skill_value_b2## секунд.\n\nВаши #{skill_color}#Дробовики и Огнеметы## наносят на #{skill_color}#$skill_value_b3## больше урона по ломающимся объектам (броня Бульдозера, Титановые щиты и щит Капитана Винтерса).\n\n#{risk}#Бонус не влияет на гранатометы и ракетометы.##\n\nПИКОВЫЙ: #{owned}#$pro##\nКогда #{skill_color}#3## или более врага находятся в #{skill_color}#18## метрах от вас, вы также получаете на #{skill_color}#$skill_value_p1## меньше урона в течении #{skill_color}#$skill_value_p2## секунд.\n\nВаши #{skill_color}#Дробовики и Огнеметы## дополнительно наносят на #{skill_color}#$skill_value_p3## больше урона по ломающимся объектам.",

				--Shotgun CQB
				["menu_shotgun_cqb_beta_sc"] = "Гладкоствол",
				["menu_shotgun_cqb_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nСкорость прицеливания и возвращения в боевую стойку после бега при использовании #{skill_color}#Дробовиков и Огнеметов## теперь на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Дробовики и Огнеметы## перезаряжаются на #{skill_color}#$skill_value_p1## быстрее.",
				["menu_shotgun_cqb_per_pellet_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nСкорость прицеливания и возвращения в боевую стойку после бега при использовании #{skill_color}#Дробовиков и Огнеметов## теперь на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Дробовики и Огнеметы## перезаряжаются на #{skill_color}#$skill_value_p1## быстрее.",


				--Shotgun Impact
				["menu_shotgun_impact_beta_sc"] = "Ружьевой импульс",
				["menu_shotgun_impact_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Дробовики и Огнеметы## получают #{skill_color}#$skill_value_b1## стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Дробовики## получают #{skill_color}#3## дополнительные дробинки.\n\n#{risk}#Не работает на бронебойные и разрывные пули.##",
				["menu_shotgun_impact_per_pellet_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Дробовики и Огнеметы## получают #{skill_color}#$skill_value_b1## стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\nМинимальный урон #{skill_color}#Дробовиков## увеличен на #{skill_color}#25%.##\n\n#{risk}#Не работает на бронебойные и разрывные пули.##",

				--Pigeon Shooting
				["menu_far_away_beta_sc"] = "Охотник",
				["menu_far_away_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТочность и дальнобойность #{skill_color}#Дробовиков и Огнеметов## увеличена на #{skill_color}#$skill_value_b1## при прицеливании.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь каждая дробинка может пройти насквозь через #{skill_color}#1## врага и наносит #{skill_color}#$skill_value_p1## урона сквозь броню.\n\n#{risk}#Эффект складывается с бронебойностью## #{skill_color}#Дробовика## #{risk}#и другими схожими эффектами, вплоть до## #{skill_color}#100%.##",

				--Gung Ho
				["menu_close_by_beta_sc"] = "Беги и стреляй",
				["menu_close_by_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы можете стрелять из #{skill_color}#Дробовиков и Огнеметов## от бедра во время бега и не имеете задержки на стрельбу после бега.\n\n#{item_stage_2}#Настройка для сохранения анимаций бега находится в оружейных опциях Restoration Mod.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВаша скорострельность увеличена на #{skill_color}#$skill_value_p1## при стрельбе от бедра из #{skill_color}#Дробовиков и Огнеметов.##",

				--Overkill
				["menu_overkill_sc"] = "OVERKILL",
				["menu_overkill_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУбийство из #{skill_color}#Дробовика, Огнемета или Пилы OVE9000## на #{skill_color}#эффективном расстоянии## или #{skill_color}#в голову## увеличивает значение максимального урона на #{skill_color}#$skill_value_b1## на #{skill_color}#$skill_value_b2## секунды.\n\n#{risk}#Навык не сработает, если противник был убит## #{important_1}#взрывом или периодическим уроном.##\n\nПИКОВЫЙ: #{owned}#$pro##\nБонус к урону теперь работает на все оружие и действует #{skill_color}#$skill_value_p1## секунд. Навык должен быть активирован убийством из #{skill_color}#Дробовика, Огнемета или Пилы OVE9000.##\n\n#{risk}#Бонус не влияет на гранатометы и ракетометы.##\n\nВы убираете и достаете #{skill_color}#Дробовики, Огнеметы и Пилы## на #{skill_color}#$skill_value_p2## быстрее.\n ",

			--[[   ДЖАГГЕРНАУТ   ]]--
				--Stun Resistance--
				["menu_oppressor_beta_sc"] = "Стойкий",
				["menu_oppressor_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВражеские удары в ближнем бою отталкивают на #{skill_color}#$skill_value_b1## меньше за каждую единицу брони.\n\nПИКОВЫЙ: #{owned}#$pro##\nУменьшает ослепление от светошумовых гранат и эффект отталкивания от стрельбы по вам на #{skill_color}#$skill_value_p1.##",

				--Die Hard
				["menu_show_of_force_sc"] = "Крепкий орешек",
				["menu_show_of_force_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете #{skill_color}#$skill_value_b1## Устойчивости.\n\nУстойчивость уменьшает урон по вашему здоровью, до максимальных #{skill_color}#$deflection## и накладывается после всех остальных бонусов.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете еще #{skill_color}#$skill_value_p1## Устойчивости.",

				--Transporter
				["menu_pack_mule_beta_sc"] = "Перевозчик",
				["menu_transporter_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nЗа каждые #{skill_color}#10## очков брони штраф на передвижение с сумкой уменьшается на #{skill_color}#$skill_value_b1.##\n\nACE: #{owned}#$pro##\n\nШтраф к восстановлению выносливости при превышении максимального веса переносимых сумок уменьшен на #{skill_color}#$skill_value_p1## за каждые #{skill_color}#10## брони.\n\nМаксимальный вес переносимых сумок увеличен на #{skill_color}#$skill_value_p2.##\n\n#{risk}#Примечание: По умолчанию максимальный переносимый вес равняется 30. Штраф к передвижению при ношении сумок зависит от типов переносимых сумок.##",

				--More Blood to Bleed--
				["menu_iron_man_beta_sc"] = "Груда мышц",
				["menu_iron_man_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете на #{skill_color}#$skill_value_b1## больше здоровья.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете еще на #{skill_color}#$skill_value_p1## больше здоровья.",

				--Bullseye--
				["menu_prison_wife_beta_sc"] = "В яблочко",
				["menu_prison_wife_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nПопадания в голову восстанавливают #{skill_color}#$skill_value_b1## брони раз в #{important_1}#$skill_value_b2## секунд.\n\nУбийства в голову уменьшают перезарядку навыка на #{skill_color}#$skill_value_b3## секунды.\n\n\nПИКОВЫЙ: #{owned}#$pro##\nПопадания в голову восстанавливают еще #{skill_color}#$skill_value_p1## брони каждые #{important_1}#$skill_value_b2## секунд.\n\nУбийства в голову уменьшают перезарядку навыка еще на #{skill_color}#$skill_value_p2## секунды. $anarc_disable\n",

				--Iron Man
				["menu_juggernaut_beta_sc"] = "Железный человек",
				["menu_juggernaut_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nОткрывает возможность носить #{skill_color}#Улучшенный комбинированный тактический бронежилет.##\n\nОстальные типы брони восстанавливаются на #{skill_color}#$skill_value_b1## быстрее.\n\nПри ударе Щитов оружием ближнего боя, они отбрасываются от вашей силы.\n#{risk}#Не работает против## #{important_1}#Титановых Щитов## #{risk}#и## #{important_1}#Капитана Винтерса.##\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь #{skill_color}#Улучшенный комбинированный тактический бронежилет## получает #{skill_color}#$skill_value_p3## Устойчивости, позволяет передвигаться на #{skill_color}#$skill_value_p4## быстрее и восстановливается на #{skill_color}#$skill_value_p2## быстрее.\n\nВремя восстановления других типов брони дополнительно уменьшено на #{skill_color}#$skill_value_p1##.\n\nОгнестрельное оружие получает шанс отбросить Щиты. Шанс отбрасывания зависит от урона оружия. $anarc_disable",

			--[[   ПОДДЕРЖКА   ]]--
				--Scavenger
				["menu_scavenging_sc"] = "Мародер",
				["menu_scavenging_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУвеличивает расстояние подбора патронов на #{skill_color}#$skill_value_b1## и еще на #{skill_color}#$skill_value_b2## за каждые #{skill_color}#$skill_value_b3## единиц брони.\n\nПИКОВЫЙ: #{owned}#$pro##\nС каждого #{skill_color}#$skill_value_p1 - го## убитого противника выпадет дополнительная коробка патронов.",

				--Bulletstorm--
				--["menu_ammo_reservoir_beta_sc"] = "Свинцовый ливень",
				["menu_ammo_reservoir_beta_sc"] = "Смертный ливень",
				["menu_ammo_reservoir_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nСумки с патронами дают возможность не расходовать боезапас оружия до #{skill_color}#5## секунд после их использования.\n\nЧем больше патронов восстановлено, тем дольше будет эффект.\n\n#{risk}#Гранатометы, ракетометы, Пила OVER9000 и прочее взрывчатое оружие не получают эффекта.##\n\nПИКОВЫЙ: #{owned}#$pro##\nДлительность способности увеличена до #{skill_color}#15## секунд.",

				--Specialist Equipment formally Rip and Tear
				["menu_portable_saw_beta_sc"] = "Спецоборудование",
				["menu_portable_saw_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУвеличивает прочность #{skill_color}#Пилы OVE9000## на #{skill_color}#50%.##\n\nВы перезаряжаете оружие на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы перезаряжаете особые оружия (##пилы, арбалеты, луки, гранатометы и ракетометы##) на #{skill_color}#$skill_value_p1## быстрее.\n\nМинимальное количество патронов, подбираемое с коборок с патронами увеличено на #{skill_color}#$skill_value_p2.##",

				--Extra Lead
				["menu_ammo_2x_beta_sc"] = "Свинец оптом",
				["menu_ammo_2x_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nОбъем Сумки с патронами увеличен на #{skill_color}#$skill_value_b1##.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь можно ставить #{skill_color}#$skill_value_p1## Cумки с патронами вместо одной.",

				--Rip and Tear formally Carbon Blade
				["menu_carbon_blade_beta_sc"] = "Рвать и метать",
				["menu_carbon_blade_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Пила OVE9000## теперь распиливает щиты.\n\nВсе оружие наносит #{skill_color}#$skill_value_b1## урона сквозь броню.\n\n#{risk}#Эффект складывается с бронебойностью вашего оружия, вплоть до ## #{skill_color}#100%.##\n\nПИКОВЫЙ: #{owned}#$pro##\nУбийства #{skill_color}#пилой, арбалетами, луками, гранатометами и ракетометами## имеют #{skill_color}#$skill_value_p1## шанс посеять панику среди врагов на расстоянии #{skill_color}#$skill_value_p2## метров.\n\n#{risk}#Паника заставляет врагов испытывать неконтролируемый страх на короткий промежуток времени.##\n\nРазмер магазина для #{skill_color}#всех оружий, кроме особых## увеличен на #{skill_color}#$skill_value_p3.##\n\n#{risk}#Увеличение размера магазинов не работает для оружия с регенерацией патронов.##\n ",

				--Fully Loaded--
				["menu_bandoliers_beta_sc"] = "Вооружен до зубов",
				["menu_bandoliers_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы подбираете на #{skill_color}#$skill_value_p1## больше патронов из коробок.\n\nВы носите на #{skill_color}#$skill_value_b2## больше метательного оружия.\n\n#{risk}#Навык не работает с метательным оружием, которое восставливается самостоятельно.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВаш общий запас патронов увеличен на #{skill_color}#$skill_value_b1.##\n\nНеобходимое количество собранных пачек патронов для получения метательного оружия уменьшено на #{skill_color}#$skill_value_p2##.\n\n#{risk}#Навык не работает с метательным оружием, которое восставливается самостоятельно.##\n ",

		--[[   TECHNICIAN   ]]--

			--[[   FORTRESS SUBTREE   ]]--
				--Logistician
				["menu_defense_up_beta_sc"] = "Логист",
				["menu_defense_up_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВсе виды взаимодействия со снаряжением на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь вы взаимодействуете со всем снаряжением дополнительно на #{skill_color}#$skill_value_p1## быстрее.\nВаши члены команды взаимодействуют и ставят снаряжение на #{skill_color}#$skill_value_p2## быстрее.\n\n#{risk}#Примечание: Командные навыки не складываются, если несколько игроков имеют этот навык.##",

				--Nerves of Steel--
				["menu_fast_fire_beta_sc"] = "Стальные нервы",
				["menu_fast_fire_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете возможность #{skill_color}#прицеливаться после падения.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете на #{skill_color}#$skill_value_p1## меньше урона во время любого взаимодействия.",

				--Engineering
				["menu_eco_sentry_beta_sc"] = "Инженер",
				["menu_eco_sentry_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаши Турели получают на #{skill_color}#$skill_value_b1## больше здоровья.\n\nПИКОВЫЙ: #{owned}#$pro##\nВаши Турели получают еще на #{skill_color}#$skill_value_p1## больше здоровья.",

				--Jack of all Trades
				["menu_jack_of_all_trades_beta_sc"] = "Мастер на все руки",
				["menu_jack_of_all_trades_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаши Арсенальные сумки востанавливают дополнительно #{skill_color}#$skill_value_b1## патронов за раз.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь вы можете взять #{skill_color}#2## Арсенальные сумки.\n\n#{skill_color}#Вы можете носить с собой второе оборудование.## Нажмите клавишу #{skill_color}#$BTN_CHANGE_EQ## чтобы переключиться на другое оборудование.\n\nВторое оборудование содержит на #{important_1}#50%## меньше использований, минимум - #{skill_color}#1.##",

				--Sentry Tower Defense--
				["menu_tower_defense_beta_sc"] = "Круговая оборона",
				["menu_tower_defense_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь можно переключать тип патронов в Турелях на бронебойные, которые уменьшают их скорострельность на #{skill_color}#75%##, тратят на #{important_1}#300%## больше патронов, наносят на #{skill_color}#300%## больше урона и позволяют им пробивать врагов и щиты.\n\nТурели теперь стоят #{skill_color}#25%## вашего боезапаса.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы можете носить с собой #{skill_color}#$skill_value_p1## Турели.\n\nВаши Турели получают #{skill_color}#фронтальный бронебойный щит.##",

				--Bulletproof--
				["menu_iron_man_sc"] = "Пуленепробиваемый",
				-- "Blocks the excess damage of Snipers, Titan Dozers, fire and explosives" - does it actually blocks fire? Isn't that a thing by default?
				["menu_iron_man_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nПока у вас есть броня, ее будет невозможно прошить, блокируя урон по здоровью от атак Снайпера, Титанового Дозера и взрывов.\n\n#{risk}#Навык не работает против атак Клокеров и Тазеров, а также нанесения урона самому себе.##\n\nПИКОВЫЙ: #{owned}#$pro##\nПока ваша броня заполнена хотя бы на #{skill_color}#$skill_value_p5##, получаемый урон уменьшается на #{skill_color}#$skill_value_p1## от вашей максимальной брони.\n\nКогда ваша броня ломается, к вашему следующему периоду бессмертия добавится #{skill_color}#$skill_value_p3## секунд за каждые #{skill_color}#$skill_value_p4## брони.",

			--[[   Перфоратор   ]]--
				--Silent Drilling--
				["menu_hardware_expert_beta_sc"] = "Бесшумная дрель",
				["menu_hardware_expert_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаши дрели и пилы #{skill_color}#теперь бесшумны##. Гражданским и охранникам нужно увидеть дрель или пилу, чтобы поднять тревогу.\n\nВы чините дрели и пилы на #{skill_color}#$skill_value_p1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы чините дрели и пилы на #{skill_color}#$skill_value_p2## быстрее.",

				--Demoman
				["menu_trip_mine_expert_beta_sc"] = "Подрывник",
				["menu_combat_engineering_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь можно ставить до #{skill_color}#6## Кумулятивных зарядов.\n\nВы ставите Кумулятивные заряды и Мины на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь можно ставить до #{skill_color}#8## Кумулятивных зарядов.\n\nРадиус взрыва ваших Мин увеличен на #{skill_color}#$skill_value_p1.##",

				--Drill Sawgeant
				["menu_drill_expert_beta_sc"] = "Бурный взлом",
				["menu_drill_expert_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nЭффективность вашей дрели и пилы увеличена на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nЭффективность вашей дрели и пилы увеличена еще на #{skill_color}#$skill_value_p1.##",

				--Fire Trap--
				--["menu_more_fire_power_sc"] = "Зажигательная ловушка",
				["menu_more_fire_power_sc"] = "Минер",
				["menu_more_fire_power_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь можно носить #{skill_color}#$skill_value_p1## Мин.\n\nВаши Мины оставляют на месте взрыва огненную лужу в течение #{skill_color}#10## секунд в радиусе #{skill_color}#7.5## метров.\n\nОгонь не наносит урона вам и команде.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь можно носить #{skill_color}#$skill_value_p2## Мин.\n\nВаши Мины наносят на #{skill_color}#50%## больше урона.",

				--Expert Hardware
				["menu_kick_starter_beta_sc"] = "Техэксперт",
				["menu_kick_starter_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВаши дрели и пилы получают #{skill_color}#$skill_value_b1## шанс на автоматическую починку.\n\nПИКОВЫЙ: #{owned}#$pro##\nВаши дрели и пилы получают еще #{skill_color}#$skill_value_p1## к шансу на автоматическую починку.\n\nВраги, которые пытаются сломать вашу дрель, имеют #{skill_color}#$skill_value_p2## шанс получить электроразряд, останавливая их попытку.",

				--Kickstarter
				["menu_fire_trap_beta_sc"] = "С толкача",
				["menu_fire_trap_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете возможность чинить дрель или пилу ударом холодного оружия.\n\nУ вас #{skill_color}#1## попытка на каждую поломку с шансом #{skill_color}#75%.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы #{skill_color}#больше не убираете оружие при взаимодействии.##\n\nВы можете оглядываться, приседать, двигаться, целиться и использовать оружие, пока держите кнопку и остаетесь в зоне взаимодействия.",

			--[[   COMBAT ENGINEER SUBTREE   ]]--
				--Sharpshooter--
				["menu_discipline_sc"] = "Крепкий хват",
				["menu_discipline_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Винтовки## получают #{skill_color}#$skill_value_b1## стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\nУбийства в голову из #{skill_color}#Винтовок## в режиме #{risk}#одиночной стрельбы## или #{risk}#очередями## в течение #{skill_color}#$skill_value_p2## секунд увеличивают вашу скорострельность на #{skill_color}#$skill_value_p1##, а из #{skill_color}#Винтовок## в #{risk}#автоматическом режиме## стрельбы - только на #{skill_color}#$skill_value_p3.##",

				--Rifleman
				["menu_rifleman_sc"] = "Пехотинец",
				["menu_rifleman_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nПока вы стоите на месте, #{skill_color}#Винтовки## получают на #{skill_color}#$skill_value_b1## больше точности и урона на расстоянии во время прицеливания.\n\n#{skill_color}#Винтовки## получают еще #{skill_color}#$skill_value_b2## стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Винтовки## получают еще на #{skill_color}#$skill_value_p1## больше точности и урона на расстоянии во время прицеливания, даже если вы в движении.\n\n#{skill_color}#Винтовки## теперь наносят #{skill_color}#$skill_value_p2## урона сквозь броню.\n\n#{risk}#Эффект не складывается с бронебойностью вашей ## #{skill_color}#Винтовки.##",

				--Kilmer--
				["menu_heavy_impact_beta_sc"] = "Килмер",
				["menu_heavy_impact_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Винтовки## перезаряжаются на #{skill_color}#$skill_value_b2## быстрее.\nШтраф на точность во время передвижения для #{skill_color}#Винтовок## уменьшен на #{skill_color}#$skill_value_b1##.\n\nШтраф на точность во время передвижения зависит от стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Винтовки## перезаряжаются на #{skill_color}#$skill_value_p1## быстрее.\n\nСкорость прицеливания и задержка стрельбы после бега из #{skill_color}#Винтовок## на #{skill_color}#$skill_value_p2## быстрее.",

				--Ammo Efficiency--
				--["menu_single_shot_ammo_return_sc"] = "Эффективный расход",
				["menu_single_shot_ammo_return_sc"] = "Практичность",
				["menu_single_shot_ammo_return_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#$skill_value_b1## убийства в голову из #{skill_color}#Винтовок## в течение #{skill_color}#$skill_value_b2## секунд восстановят #{skill_color}#$skill_value_b4## от вашего подбора патронов (минимум #{skill_color}#1## патрон).\n\nПИКОВЫЙ: #{owned}#$pro##\nНавык теперь срабатывает после #{skill_color}#$skill_value_p1## убийств в голову в течение #{skill_color}#$skill_value_p2## секунд. #{skill_color}#Патроны возвращаются прямо в магазин.##",

				--Aggressive Reload
				--["menu_engineering_beta_sc"] = "Агрессивная перезарядка",
				["menu_engineering_beta_sc"] = "Проактивность",
				["menu_engineering_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУбийства в голову из #{skill_color}#Винтовок## увеличивают скорость перезарядки и прицеливания на #{skill_color}#$skill_value_b1## в течение #{skill_color}#$skill_value_b2## секунд.\n\nПИКОВЫЙ: #{owned}#$pro##\nБонус к скорости перезарядки увеличен до #{skill_color}#$skill_value_p1## и может быть получен при убийстве не в голову.",

				--Mind Blown, formerly Explosive Headshot--
				["menu_kilmer_sc"] = "Рикошет",
				["menu_kilmer_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nПопадания в голову из #{skill_color}#Винтовок## наносят #{skill_color}#$skill_value_b1## урона ближайшему врагу в радиусе #{skill_color}#$skill_value_b2## метров; срабатывает раз в #{important_1}#$skill_value_b5## секунды.\n\nЕсли ваша #{skill_color}#винтовка## находится в режиме #{risk}#одиночной стрельбы## или #{risk}#очереди##, за каждые #{skill_color}#$skill_value_b3## метров от цели эффект перебрасывается еще до #{skill_color}#$skill_value_b4## раз.\n\nПИКОВЫЙ: #{owned}#$pro##\nРадиус навыка увеличен на #{skill_color}#$skill_value_p1## метр.\nПопадания в голову из #{skill_color}#Винтовок## в режиме #{risk}#одиночной стрельбы## или #{risk}#очереди## #{skill_color}#не теряют урон на расстоянии##, и за каждые #{skill_color}#$skill_value_b3## метров от врага эффект наносит дополнительные #{skill_color}#$skill_value_p2## урона; вплоть до #{skill_color}#$skill_value_p3## урона.",
		--[[   GHOST   ]]--

			--[[   SHINOBI SUBTREE   ]]--
				--Alert--
				["menu_jail_workout_sc"] = "Меченный",
				["menu_jail_workout_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВраги остаются помеченными на #{skill_color}#100%## дольше.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь можно #{skill_color}#автоматически помечать## охранников, особых и титановых врагов в #{skill_color}#40## метрах от вас с помощью прицеливания.\n\n#{risk}#Охранники помечаются только до поднятия тревоги.##",

				--Sixth Sense--
				["menu_chameleon_beta_sc"] = "Шестое чувство",
				["menu_chameleon_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы #{skill_color}#автоматически помечаете## всех врагов в радиусе #{skill_color}#10## метров, если стоите на месте в течение #{skill_color}#3.5## секунд.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете #{skill_color}#доступ ко всем инсайдерским активам.##",

				--ECM Overdrive--
				["menu_cleaner_beta_sc"] = "Электровзлом",
				["menu_cleaner_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nГенератор помех теперь #{skill_color}#может открывать некоторые электронные двери.##\n\nПИКОВЫЙ: #{owned}#$pro##\nДлительность генератора помех увеличена на #{skill_color}#25%,## #{risk}#пока вы не под стражей.##\n\n##Пейджеры теперь удерживаются помехами.##",

				--Nimble--
				["menu_second_chances_beta_sc"] = "Шустрые пальцы",
				["menu_second_chances_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь можно #{skill_color}#бесшумно взламывать сейфы вручную.##\n\nВы взаимодействуете со всеми компьютерами, камерами и генераторами помех на #{skill_color}#30%## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы взламываете все замки на #{skill_color}#50%## быстрее.\n\nВы взаимодействуете со всеми компьютерами, камерами и генераторами помех еще на #{skill_color}#50%## быстрее.",

				--ECM Specialist--
				["menu_ecm_booster_beta_sc"] = "Диверсант",
				["menu_ecm_booster_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь можно носить #{skill_color}#3## Генератора помех.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь можно носить #{skill_color}#4## Генератора помех.",

				--Spotter--
				["menu_ecm_2x_beta_sc"] = "Шестерка",
				["menu_ecm_2x_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВраги, отмеченные вами, получают на #{skill_color}#$skill_value_b1## больше урона на расстоянии дальше #{risk}#$skill_value_b2## метров.\n\nПИКОВЫЙ: #{owned}#$pro##\nВраги, отмеченные вами, получают на #{skill_color}#$skill_value_p1## больше урона с любого расстояния, от любого оружия.",

			--[[   ARTFUL DODGER SUBTREE   ]]--
				--Duck and Cover--
				["menu_sprinter_beta_sc"] = "Пригнись и укройся",
				["menu_sprinter_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВыносливость восстанавливается на #{skill_color}#$skill_value_b1## раньше и на #{skill_color}#$skill_value_b2## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nВаша полоска Уворота заполняется на #{skill_color}#$skill_value_p1## за каждую секунду в приседе.\n\nВы двигаетесь на #{skill_color}#$skill_value_p2## быстрее в приседе.",

				--Evasion--
				["menu_awareness_beta_sc"] = "Атлет",
				["menu_awareness_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы двигаетесь на #{skill_color}#$skill_value_b1## быстрее.\n\nУрон от падений с высоты уменьшен на #{skill_color}#$skill_value_b2.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы можете #{skill_color}#перезаряжаться во время бега.##\n\n#{item_stage_2}#Чтобы отменять перезарядку при помощи кнопки бега, включите соответствующую опцию в настройках Restoration Mod.##",

				--Deep Pockets--
				["menu_thick_skin_beta_sc"] = "Широкие карманы",
				["menu_thick_skin_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУвеличивает компактность оружия ближнего боя на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nУвеличивает компактность баллистических жилетов на #{skill_color}#$skill_value_p1##, а всей остальной брони на #{skill_color}#$skill_value_p2.##",

				--Moving Target--
				["menu_dire_need_beta_sc"] = "Неуловимый",
				["menu_dire_need_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы двигаетесь на #{skill_color}#$skill_value_b1## быстрее за каждые #{skill_color}#$skill_value_b2## очка нагрузки ниже #{skill_color}#$skill_value_b3##, до максимальных #{skill_color}#$skill_value_b4## скорости.\n\n Ваша полоска Уворота заполняется на #{skill_color}#$skill_value_p6## от вашего значения Уворота каждую секунду, проведенную на зиплайнах.\n\nВы передвигаетесь на #{skill_color}#$skill_value_b5## быстрее при прицеливании.\n#{risk}#Скорость передвижения в прицеливании не может превышать вашу максимальную.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы двигаетесь на #{skill_color}#$skill_value_p1## быстрее за каждое #{skill_color}#$skill_value_p2## очко нагрузки ниже #{skill_color}#$skill_value_p3##, до максимальных #{skill_color}#$skill_value_p4## скорости.\n\nВаш Уворот заполняется на #{skill_color}#$skill_value_p5## за каждую секунду бега (в два раза меньше, если нет выносливости).\n\nТеперь вы можете стрелять от бедра во время бега и не имеете задержки на стрельбу после бега.\n\n#{item_stage_2}#Настройка для сохранения анимаций бега находится в оружейных опциях Restoration Mod.##",

				--Shockproof
				["menu_insulation_beta_sc"] = "Заземленный",
				["menu_insulation_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nШоковая атака Тазера больше #{skill_color}#не заставляет вас стрелять## и имеет #{skill_color}#15%## шанс отскочить от вас, оглушая Тазера.\n\n#{risk}#Не отменяет штрафов на точность и урон во время шоковой атаки.##\n\nОтталкивание от попаданий по вам уменьшено на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВзаимодействие с вражеским Тазером в течение #{skill_color}#$skill_value_p1## секунд после шоковой атаки производит контратаку, нанося #{skill_color}#$skill_value_p2## урона его здоровью.\n\nЗамедление и его длительность от атак Титановых Тазеров уменьшено на #{skill_color}#50%.##\n ",

				--Sneaky Bastard--
				["menu_jail_diet_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете #{skill_color}#$skill_value_b1## Уворота за каждые #{risk}#$skill_value_b2## очка нагрузки ниже #{risk}#$skill_value_b3## до максимальных #{skill_color}#$skill_value_b4## Уворота.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете #{skill_color}#$skill_value_b1## Уворота за каждое #{risk}#$skill_value_p1## очко нагрузки ниже #{risk}#$skill_value_b3## до максимальных #{skill_color}#$skill_value_b4## Уворота.\n\nКогда ваша броня ломается, следующий Уворот #{skill_color}#восстанавливает вашу броню в количестве, равное вашему Увороту##, и #{skill_color}#$skill_value_p2## вашего здоровья. \nЭто может произойти только раз в #{important_1}#$skill_value_p3## секунд; пока ваша броня сломана, каждый Уворот сокращает время на #{skill_color}#$skill_value_p4## секунды.",

			--[[   SILENT KILLER SUBTREE   ]]--
				--Second Wind
				["menu_scavenger_beta_sc"] = "Второе дыхание",
				["menu_scavenger_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКогда ваша броня ломается, ваша скорость увеличивается на #{skill_color}#$skill_value_b1## на #{skill_color}#$skill_value_b2## секунды.\n\nПИКОВЫЙ: #{owned}#$pro##\nКогда ваша броня полностью сломана, первый выстрел оглушит противника.\n\nЭтот эффект остается на #{skill_color}#$skill_value_p1## секунды после регенерации брони.",

				--Optical Illusions--
				["menu_optic_illusions_sc"] = "Иллюзионист",
				["menu_optic_illusions_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы достаете и прячете оружие на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nКомпактность всего оружия увеличена на #{skill_color}#$skill_value_p1.##",

				--The Professional--
				["menu_silence_expert_beta_sc"] = "Профессионал",
				["menu_silence_expert_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы прицеливаетесь на #{skill_color}#$skill_value_b1## быстрее, а ваша задержка после бега уменьшена на #{skill_color}#$skill_value_b1##.\n\nПИКОВЫЙ: #{owned}#$pro##\nУбийство особых и титановых врагов огнестрельным оружием предоставляет дополнительную пачку патронов.",

				--Unseen Strike, formally Dire Need--
				["menu_backstab_beta_sc"] = "Удар исподтишка",
				["menu_backstab_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nЕсли вы не получаете урон в течение #{skill_color}#$skill_value_b1## секунд, то вы получите #{skill_color}#$skill_value_b2## шанс критического попадания. Бонус пропадает спустя #{skill_color}#$skill_value_b3## секунд после получения урона.\n\nКритические попадания наносят на #{skill_color}#100%## больше урона.\n#{risk}#Попадания от взрывов и периодическего урона## #{important_1}#не могут быть критическими.##\n\nПИКОВЫЙ: #{owned}#$pro##\nКритический шанс теперь остается на #{skill_color}#$skill_value_p1## секунды после получения урона.",

				--Cleaner--
				["menu_hitman_beta_sc"] = "Чистильщик",
				["menu_hitman_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы наносите на #{skill_color}#$skill_value_b1## больше урона по особым и элитным врагам.\n\n#{risk}#Не действует на ракетометы и гранатометы.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы наносите на #{skill_color}#$skill_value_p1## больше урона особым и элитным врагам.\n\nУбийство врага в голову заполнит вашу полоску Уворота на #{skill_color}#$skill_value_p2##; убийство сзади заполнят ее на #{skill_color}#$skill_value_p3##; этот эффект складывается с убийством в голову.\n\n#{risk}#Убийства при помощи## #{important_1}#взрывов, огня и периодическего урона## #{risk}#не считаются.##",

				--Low Blow--
				["menu_unseen_strike_beta_sc"] = "Подлый прием",
				["menu_unseen_strike_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете #{skill_color}#$skill_value_b1## шанс критического попадания за каждые #{skill_color}#$skill_value_b2## очка нагрузки ниже #{skill_color}#$skill_value_b3##, до максимального шанса #{skill_color}#$skill_value_b4.##\n\nКритические попадания наносят на #{skill_color}#100%## больше урона.\n#{risk}#Попадания от взрывов и периодическего урона## #{important_1}#не могут быть критическими.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете #{skill_color}#$skill_value_p1## шанс критического попадания за каждое #{skill_color}#$skill_value_p2## очко нагрузки ниже #{skill_color}#$skill_value_p3##, до максимального шанса #{skill_color}#$skill_value_p4.##\n\nВаш шанс критического попадания увеличивается на #{skill_color}#$skill_value_p5## при атаках сзади.",

		--[[   FUGITIVE   ]]--

			--[[   GUNSLINGER SUBTREE   ]]--
				--Equilibrium--
				["menu_equilibrium_beta_sc"] = "Эквилибриум",
				["menu_equilibrium_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nСтабильность #{skill_color}#пистолетов## для вас и вашей команды увеличена на #{skill_color}#$skill_value_b1.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы достаете и прячете #{skill_color}#пистолеты## на #{skill_color}#$skill_value_p1## быстрее.",

				--Gun Nut--
				["menu_dance_instructor_sc"] = "Мелкий калибр",
				["menu_dance_instructor_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУменьшает разлет пуль при стрельбе от бедра из #{skill_color}#пистолетов## на #{skill_color}#$skill_value_b1.##\nВы достаете и прячете #{skill_color}#Парные## оружия на #{skill_color}#$skill_value_p2## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Пистолеты## стреляют на #{skill_color}#$skill_value_p1## быстрее.\n\n#{skill_color}#Пистолеты## наносят #{skill_color}#$skill_value_p2## урона через броню, а #{skill_color}#Парные## оружия - #{skill_color}#$skill_value_p3## урона.\n\n#{risk}#Эффект складывается с бронебойностью вашего оружия, вплоть до## #{skill_color}#100%.##",

				--Over Pressurized/Gunfighter--
				["menu_gun_fighter_sc"] = "Ковбой",
				["menu_gun_fighter_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\n#{skill_color}#Пистолеты## перезаряжаются на #{skill_color}#$skill_value_b1## быстрее.\n\nШтраф к точности при стрельбе во время движения уменьшен на #{skill_color}#$skill_value_b2## для пистолетов.\n\nУменьшение штрафа на точность зависит от стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\n#{skill_color}#Пистолеты## перезаряжаются еще на #{skill_color}#$skill_value_p1## быстрее.\n\nШтраф к точности при стрельбе во время движения дополнительно уменьшен на #{skill_color}#$skill_value_p2##",

				--Akimbo--
				["menu_akimbo_skill_sc"] = "Акимбо",
				["menu_akimbo_skill_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nТеперь вы можете стрелять от бедра во время бега и не имеете задержки на стрельбу после бега, пока используете #{skill_color}#пистолеты## и #{skill_color}#парные пистолеты##.\n\n#{item_stage_2}#Настройка для сохранения анимаций бега находится в оружейных опциях Restoration Mod.##\n\n#{skill_color}#Парное оружие## получает #{skill_color}#$skill_value_b1## стабильности.\n\nПИКОВЫЙ: #{owned}#$pro##\nТеперь вы можете стрелять от бедра во время бега и не имеете задержки на стрельбу после бега, используя #{skill_color}#любое парное## оружие.\n\n#{skill_color}#Парное оружие## получает #{skill_color}#$skill_value_p1## точности.",

				--Desperado--
				["menu_expert_handling_sc"] = "Отчаянный",
				["menu_expert_handling_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКаждое убийство в голову из #{skill_color}#пистолета## дает #{skill_color}#$skill_value_b1## бонус к точности и урону на растоянии на #{skill_color}#$skill_value_b2## секунды. Этот эффект накладывается до #{skill_color}#$skill_value_b3## раз, а длительность обновляется при каждом выстреле в голову.\n\n#{skill_color}#Пистолеты## получают #{skill_color}#$skill_value_b4## точности во время прицеливания.\n\nПИКОВЫЙ: #{owned}#$pro##\nУвеличивает длительность бонуса к точности и урона на растоянии до #{skill_color}#$skill_value_p1## секунд.\n\nМаксимальное расстояние поражения для #{skill_color}#Пистолетов## во время прицеливания увеличено на #{skill_color}#$skill_value_p2##.",

				--Trigger Happy--
				["menu_trigger_happy_beta_sc"] = "Музыкант",
				["menu_trigger_happy_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКаждый выстрел в голову из #{skill_color}#пистолета## дает дополнительные #{skill_color}#$skill_value_b1## урона на #{skill_color}#$skill_value_b2## секунды. Этот эффект накладывается до #{skill_color}#$skill_value_b3## раз, а длительность обновляется при каждом выстреле в голову.\n\nПИКОВЫЙ: #{owned}#$pro##\nУвеличивает длительность бонуса к урону до #{skill_color}#$skill_value_p1## секунд. Эффект теперь накладывается еще #{skill_color}#$skill_value_p2## раз.",

			--[[   REVENANT SUBTREE   ]]--
				--Running From Death--
				["menu_nine_lives_beta_sc"] = "Бегущий от смерти",
				["menu_nine_lives_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы передвигаетесь на #{skill_color}#$skill_value_b1## быстрее в течение #{skill_color}#$skill_value_b2## секунд после того, как вы встали.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете на #{skill_color}#$skill_value_p1## меньше урона на #{skill_color}#$skill_value_p2## секунд после того, как вы встали.\n\nВаше оружие автоматически перезаряжается после того, как вы встали.",

				--Undying--
				["menu_running_from_death_beta_sc"] = "Неумирающий",
				["menu_running_from_death_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете на #{skill_color}#$skill_value_b1## больше здоровья при падении.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы получаете еще #{skill_color}#$skill_value_p1## здоровья при падении.\n\nВы можете использовать основное оружие при падении.",

				--What Doesn't Kill You Only Makes You Stronger--
				["menu_what_doesnt_kill_beta_sc"] = "Что не убивает",
				["menu_what_doesnt_kill_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nПолучаемый урон уменьшается на #{skill_color}#$skill_value_b1## очко за каждое падение, которое приближает вас к аресту. \n\nПИКОВЫЙ: #{owned}#$pro##\nПолучаемый урон всегда уменьшается на #{skill_color}#$skill_value_p1## очка.",

				--Swan Song
				["menu_perseverance_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКогда ваше здоровье опускается до #{important_1}#0##, вы можете сражаться еще #{skill_color}#$skill_value_b1## секунды с #{important_1}#60%## штрафом к скорости передвижения.\n\n#{risk}#Вы гарантированно упадете по истечении времени.##\n\nПИКОВЫЙ: #{owned}#$pro##\nВы можете сражаться еще на #{skill_color}#$skill_value_p1## секунд дольше.",

				--Haunt--
				["menu_haunt_sc"] = "Пугало",
				["menu_haunt_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nУбийство врага, находящихся на расстоянии ближе #{skill_color}#18## метров имеет #{skill_color}#$skill_value_b1## шанс посеять панику на #{skill_color}#12## метров вокруг Вас за каждое падение, которое приближает вас к аресту.\n\n#{risk}#Паника заставляет врагов испытывать неконтролируемый страх на короткий промежуток времени.##\n\nПИКОВЫЙ: #{owned}#$pro##\nШанс паники всегда увеличен на #{skill_color}#$skill_value_p1##.",

				--Messiah--
				["menu_pistol_beta_messiah_sc"] = "Мессия",
				["menu_pistol_beta_messiah_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКогда вы упадете, убийство врага позволит вам встать самостоятельно. У вас есть только #{skill_color}#1## шанс сделать это, который восстановится при выходе из под ареста.\n\nВы можете упасть еще #{skill_color}#1## раз прежде чем попадете под арест.\n\nПИКОВЫЙ: #{owned}#$pro##\nМессию теперь можно использовать сколько угодно раз, но с задержкой в #{skill_color}#120## секунд. Убийства во время падения уменьшают задержку на #{skill_color}#10## секунд.",

			--[[   BRAWLER SUBTREE   ]]--
				--Martial Arts--
				["menu_martial_arts_beta_sc"] = "Боевые искусства",
				["menu_martial_arts_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы получаете на #{skill_color}#$skill_value_b1## меньше урона от всех атак в ближнем бою (из-за тренировок).\n\nПИКОВЫЙ: #{owned}#$pro##\nНокдаун холодного оружия увеличен на #{skill_color}#$skill_value_p1## (из-за тренировок).\n\n#{risk}#Нокдаун определяет, с каким шансом вы оглушите врага, а также сколько урона вы наносите броне Бульдозера, титановым щитам и щиту Капитана Винтерса.##",

				--Counter-Strike--
				["menu_drop_soap_beta_sc"] = "Контр-удар",
				["menu_drop_soap_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы можете парировать прыжки Клокеров холодным оружием. Это столкнет их на землю.\n\nВы получаете на #{skill_color}#$skill_value_b1## меньше урона от ударов Клокеров и атак Тазеров.\n\nПИКОВЫЙ: #{owned}#$pro##\n\nТеперь вы можете парировать все особые атаки Клокеров и атаки щитов при помощи холодного оружия.\n#{risk}#Не работает против Титановых Щитов и Капитана Винтерса.##\n\nДальнобойный урон по вам уменьшен на #{skill_color}#$skill_value_p1## когда вы достаете оружие ближнего боя.\n\nВы получаете еще на #{skill_color}#$skill_value_p2## меньше урона от ударов Клокеров и атак Тазеров.\n ",

				--Pumping Iron--
				["menu_steroids_beta_sc"] = "Накачанный",
				["menu_steroids_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nВы атакуете и замахиваетесь оружием ближнего боя на #{skill_color}#$skill_value_b1## быстрее.\n\nПИКОВЫЙ: #{owned}#$pro##\nВы атакуете и замахиваетесь оружием ближнего боя еще на #{skill_color}#$skill_value_p1## быстрее.",

				--Bloodthirst--
				["menu_bloodthirst_sc"] = "Кровожадность",
				["menu_bloodthirst_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nКогда вы убиваете врага в #{skill_color}#ближнем бою##, вы получаете #{skill_color}#$skill_value_b1## бонус к скорости перезарядки и передвижения на #{skill_color}#$skill_value_b2## секунд.\n\nПИКОВЫЙ: #{owned}#$pro##\nКаждое убийство увеличивает урон следующей атаки в ближнем бою на #{skill_color}#25%##, до максимальных #{skill_color}#100%.##\n\nЭтот эффект обнуляется, когда вы наносите удар в ближнем бою.",

				--Frenzy--
				["menu_wolverine_beta_sc"] = "Неистовый",
				["menu_wolverine_beta_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nЧем больше у вас здоровья, тем меньше вы восстанавливаете здоровья, до #{important_1}#$skill_value_b2##.\n\nЧем меньше у вас здоровья, тем больше у вас устойчивости, до #{skill_color}#$skill_value_b1##.\n\nУстойчивость уменьшает урон по вашему здоровью, до максимальных #{skill_color}#$deflection## и накладывается после всех остальных бонусов.\n\nПИКОВЫЙ: #{owned}#$pro##\nЛечение уменьшается до #{important_1}#$skill_value_b2##, а устойчивость увеличивается до #{skill_color}#$skill_value_p1.##",

				--Berserker--
				["menu_frenzy_sc"] = "Берсерк",
				["menu_frenzy_desc_sc"] = "БАЗОВЫЙ: #{owned}#$basic##\nЧем меньше у вас здоровья, тем больше урона вы наносите.\n\nКогда ваше здоровье ниже #{skill_color}#100%##, вы будете наносить до #{skill_color}#$skill_value_b1## дополнительного урона пилой и оружием ближнего боя.\n\nПИКОВЫЙ: #{owned}#$pro##\nЧем меньше у вас здоровья, тем больше урона вы наносите.\n\nКогда ваше здоровье ниже #{skill_color}#100%##, вы будете наносить до #{skill_color}#$skill_value_p1## дополнительного урона огнестрельным оружием.\n\n#{risk}#Не работает с гранатометами и ракетометами.##"

	})
end)

-- Перки
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_Perk_Decks", function(loc)
	LocalizationManager:add_localized_strings({
		["menu_st_category_all"] = "Все перки",
		["menu_st_category_offensive"] = "Нападение",
		["menu_st_category_defensive"] = "Защита",
		["menu_st_category_supportive"] = "Поддержка",
		["menu_st_category_favorites"] = "Избранные",
		["menu_specialization_tier"] = "Карта",
		["menu_specialization_key_but_deck"] = "Разблокировать",
		["menu_specialization_key_favorite"] = "В избранное",
		["menu_st_category_activated"] = "Включаемые",
		["menu_st_category_challenge"] = "Пустые",
		["menu_st_category_mod"] = "Моды",

		--Общие перки
		["menu_deckall_2_desc_sc"] = "Увеличивает урон в голову на #{skill_color}#$perk_value_1##\n\nВы наносите на #{skill_color}#$perk_value_2## больше урона.\n#{risk}#Урон не увеличивается для## #{important_1}#метательного оружия, гранатометов и ракетных установок.##",
		["menu_deckall_4_desc_sc"] = "Вы получаете #{skill_color}#$perk_value_1## к скорости.\n\nПри ношении брони штраф к вашей скорости становится на #{skill_color}#$perk_value_1## меньше.\n\nВы получаете на #{skill_color}#$perk_value_3## больше опыта при выполнении ограблений.\n\n#{risk}#Без модификатора## #{important_1}#Pro Job,## вы перезаряжаете свое оружие на #{skill_color}#$perk_value_4## быстрее. \n\nВы наносите на #{skill_color}#$perk_value_5## больше урона. \n#{risk}#Урон не увеличивается для## #{important_1}#метательного оружия, гранатометов и ракетных установок.##",
		["menu_deckall_6_desc_sc"] = "Открывает #{skill_color}#Кейс с метательным оружием## в качестве оборудования. Кейс с метательным оружием используется, чтобы восполнить запас метательного оружия во время ограбления.\n\n#{risk}#Без модификатора## #{important_1}#Pro Job,## вы подбираете на #{skill_color}#$perk_value_1## больше патронов; этот эффект удваивается в одиночном режиме Crime.Net. \n\nВы наносите на #{skill_color}#$perk_value_2## больше урона. \n#{risk}#Урон не увеличивается для## #{important_1}#метательного оружия, гранатометов и ракетных установок.##",
		["menu_deckall_8_desc_sc"] = "Увеличивает скорость взаимодействия с сумкой с медикаментами на #{skill_color}#$perk_value_1.##\n\nВы наносите на #{skill_color}#$perk_value_2## больше урона. \n#{risk}#Урон не увеличивается для## #{important_1}#метательного оружия, гранатометов и ракетных установок.##",
		--Аферист
		["menu_deck6_1"] = "Пойманный",
		["menu_deck6_3"] = "Выживший",
		["menu_deck6_5"] = "Буян",	
		["menu_deck6_7"] = "Стрелок",		
		["menu_deck6_9"] = "Беглец",
		
		["menu_deck6_1_desc_sc"] = "Когда вы находитесь в #{skill_color}#$perk_value_1## метрах от 3-х и более врагов, вы получаете на #{skill_color}#$perk_value_2## меньше урона.",
		["menu_deck6_3_desc_sc"] = "Убийство врага восстанавливает #{skill_color}#$perk_value_1## брони.\n\nЭто может происходить только раз в #{important_1}#$perk_value_2## секунд, но каждое убийство сокращает время на #{skill_color}#$perk_value_3## секунд, а убийство холодным оружием - еще на #{skill_color}#$perk_value_4## секунды.\n\nЕсли убийство сокращает время полностью, бонусы активируются и задержка начнется сначала.",
		["menu_deck6_5_desc_sc"] = "Убийство врага оружием ближнего боя восстанавливает #{skill_color}#$perk_value_1## здоровья и #{skill_color}#$perk_value_3## выносливости.\n\n#{important_1}#Эффект активируется вместе с картой## Выживший.\n\nВы носите на #{skill_color}#$perk_value_2## мешок для тел больше.",
		["menu_deck6_7_desc_sc"] = "Убийство врага, находящегося в менее чем #{skill_color}#$perk_value_1## метров от вас, восстанавливает #{skill_color}#$perk_value_2## брони, а убийство холодным оружием - в два раза больше брони.\n\n#{important_1}#Эффект активируется вместе с картой## Выживший.\n\nВы получаете еще #{skill_color}#$perk_value_3## Уворота.",
		["menu_deck6_9_desc_sc"] = "Убийство врага, находящегося в менее чем #{skill_color}#$perk_value_1## метров от вас, имеет #{skill_color}#$perk_value_2## шанс посеять панику среди врагов в радиусе #{skill_color}#$perk_value_3## метров от Вас, а убийство холодным оружием повышает этот шанс в два раза.\n\nПаника заставляет врагов испытывать неконтролируемый страх на короткий промежуток времени.\n\n#{important_1}#Эффект активируется вместе с картой## Выживший.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Точно не Шпион!
		["menu_deck4_1_desc_sc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.\n\nВы меняете оружие на #{skill_color}#$perk_value_2## быстрее.",
		["menu_deck4_3_desc_sc"] = "Вы получаете еще #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck4_5_desc_sc"] = "Ваша полоска Уворота будет заполнена на #{skill_color}#$perk_value_1## после того, как вы встали.\n\nВы зацикливаете камеры на #{skill_color}#$perk_value_2## секунд дольше.",
		["menu_deck4_7_desc_sc"] = "Вы получаете еще #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck4_9_desc_sc"] = "Уворот от атаки восстанавливает #{skill_color}#$perk_value_1## очко здоровья каждую секунду в течение #{skill_color}#$perk_value_2## секунд. Этот эффект может складываться, но бонус потеряется, если вы получите урон по здоровью.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Киллер
		["menu_deck5_1_sc"] = "Ган-фу",
		["menu_deck5_3_sc"] = "Тренированный убийца",
		["menu_deck5_5_sc"] = "Убийство карандашом",
		["menu_deck5_7_sc"] = "Эксперт",

		--он убил карандаш... человеком.
		["menu_deck5_1_desc_sc"] = "Убийство врагов огнестрельным оружием добавляет #{skill_color}#$perk_value_1## ##запасного здоровья##. Вы можете получить до #{skill_color}#$perk_value_2## запасного здоровья.\n\nУбийство врагов оружием ближнего боя превращает запасное здоровье во ##временное здоровье##, которое утекает со скоростью #{skill_color}#$perk_value_3## единиц в секунду.\n\nВременное здоровье может превышать ваше максимальное здоровье, но вы не можете иметь больше #{skill_color}#$perk_value_4## временного здоровья за раз.",
		["menu_deck5_3_desc_sc"] = "Ваша полоска уворота заполняется на #{skill_color}#$perk_value_1## при восстановлении брони.\n\nВы получаете ##5## Уворота.",
		["menu_deck5_5_desc_sc"] = "Вы можете получить на #{skill_color}#$perk_value_1## больше запасного здоровья.\n\nВы носите на #{skill_color}#$perk_value_2## мешок для тел больше.",
		["menu_deck5_7_desc_sc"] = "Вы получаете #{skill_color}#$perk_value_1## временного здоровья после того, как вы встали.\n\nВы получаете еще #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck5_9_desc_sc"] = "Пока у вас есть временное здоровье, вы получаете #{skill_color}#$perk_value_1## Устойчивости и передвигаетесь на #{skill_color}#$perk_value_2## быстрее.\n\nУстойчивость уменьшает урон по вашему здоровью, до максимальных #{skill_color}#$perk_value_3## и накладывается после всех остальных бонусов.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Силовик
		["menu_deck2_1_desc_sc"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck2_3_desc_sc"] = "Ваше здоровье увеличено еще на #{skill_color}#$perk_value_1##.\n\nВаш уворот увеличен на #{skill_color}#$perk_value_2## очков.",
		["menu_deck2_5_desc_sc"] = "Ваше здоровье увеличено еще на #{skill_color}#$perk_value_1##.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_2## быстрее.",
		["menu_deck2_7_desc_sc"] = "Каждый выстрел из вашего оружия имеет #{skill_color}#$perk_value_1## шанс посеять панику среди врагов.\n\nПаника заставляет врагов испытывать неконтролируемый страх на короткий промежуток времени.\n\nВаш уворот увеличен еще на #{skill_color}#$perk_value_2## очков.",
		["menu_deck2_9_desc_sc"] = "Ваше здоровье увеличено еще на #{skill_color}#$perk_value_1##.\n\nВы получаете на #{skill_color}#$perk_value_2## больше здоровья после того, как вы встали.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Капо
		["menu_deck1_3_desc_sc"] = "Выносливость для вас и вашей команды увеличена на #{skill_color}#$perk_value_1##.\n\nРасстояние ваших криков увеличено на #{skill_color}#$perk_value_2##.\n\nКомандные бонусы не складываются.\n\nВаш уворот увеличен на #{skill_color}#$perk_value_3## очков.",
		["menu_deck1_5_desc_sc"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.\n\nЗдоровье вашей команды увеличено на #{skill_color}#$perk_value_2##.\n\nКомандные бонусы не складываются.\n\nВы отвечаете на пейджеры на #{skill_color}#$perk_value_3## быстрее.",
		["menu_deck1_7_desc_sc"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.\n\nВаш уворот увеличен еще на #{skill_color}#$perk_value_2## очков.",
		["menu_deck1_9_desc_sc"] = "Каждый заложник увеличивает здоровье на #{skill_color}#$perk_value_1## и выносливость на #{skill_color}#$perk_value_2## для вас и вашей команды, до #{skill_color}#$perk_value_3## заложников.\n\nКомандные бонусы не складываются.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Оружейник
		["menu_deck3_1"] = "Стандартные пластины",
		["menu_deck3_1_desc_sc"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.\n\nБаллистические бронежилеты получают на #{skill_color}#$perk_value_2## больше брони.",
		["menu_deck3_3"] = "Адаптивные пластины",
		["menu_deck3_3_desc_sc"] = "Ваша броня увеличена еще на #{skill_color}#$perk_value_1##.\n\nВы получаете #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck3_5"] = "Щитовые пластины",
		["menu_deck3_5_desc_sc"] = "Ваша броня увеличена еще на #{skill_color}#$perk_value_1##.\n\nВы получаете еще #{skill_color}#$perk_value_3## Уворота, если на вас надет баллистический бронежилет.\n\nВы получаете возможность ставить #{skill_color}#$perk_value_2## сумки с мешками для трупов.",
		["menu_deck3_7"] = "Запасные пластины",
		["menu_deck3_7_desc_sc"] = "Ваша броня восстанавливается быстрее на #{skill_color}#$perk_value_1.##\n\nВы получаете еще#{skill_color}#$perk_value_2## Уворота, если на вас надет баллистический бронежилет.",
		["menu_deck3_9"] = "Текучие пластины",
		["menu_deck3_9_desc_sc"] = "Ваша броня восстанавливается еще быстрее  на #{skill_color}#$perk_value_1.##\n\nБаллистические бронежилеты получают на #{skill_color}#$perk_value_2## больше брони.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Взлом JOAPY
		["menu_deck7_1_desc_sc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.\n\nВаша полоска Уворота заполняется на #{skill_color}#$perk_value_2## за каждую секунду в приседе.",
		["menu_deck7_3_desc_sc"] = "Вы получаете еще #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck7_5_desc_sc"] = "Ваша полоска Уворота заполняется еще на #{skill_color}#$perk_value_1## за каждую секунду в приседе.\n\nВы двигаетесь на #{skill_color}#$perk_value_2## быстрее в приседе.",
		["menu_deck7_7_desc_sc"] = "Вы получаете еще #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck7_9_desc_sc"] = "Ваша броня восстанавливается быстрее на #{skill_color}#$perk_value_1##.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Джекпот!
		["menu_deck10_1_desc_sc"] = "Коробки с патронами также дают медикаменты, которые восстанавливают от #{skill_color}#$perk_value_1## до #{skill_color}#$perk_value_2## здоровья.\n\nЭффект происходит раз в #{skill_color}#$perk_value_3## секунд, но каждая подобранная коробка патронов уменьшает эту задержку на #{skill_color}#$perk_value_4##-#{skill_color}#$perk_value_5## секунды.",
		["menu_deck10_3_desc_sc"] = "Когда вы подбираете патроны, ваша команда дополнительно получает #{skill_color}#$perk_value_1## патронов.\n\nВы получаете #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck10_5_desc_sc"] = "Коробки с патронами теперь восстанавливают от #{skill_color}#$perk_value_1## до #{skill_color}#$perk_value_2## очков здоровья.\n\nКаждый раз, когда вы лечитесь от подбора, ваша полоска уворота получает до #{skill_color}#$perk_value_3## от вашего Уворота.\n\nВы отвечаете на пейджеры на #{skill_color}#$perk_value_4## быстрее.",
		["menu_deck10_7_desc_sc"] = "Когда вы лечитесь при помощи коробок с патронами, ваша команда также лечится на #{skill_color}#$perk_value_1## от количества полученного здоровья.\n\nВы получаете еще #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck10_9_desc_sc"] = "Коробки с патронами теперь восстанавливают от #{skill_color}#$perk_value_1## до #{skill_color}#$perk_value_2## очков здоровья.\n\nКогда вы лечитесь при помощи коробок с патронами, вы получаете #{skill_color}#$perk_value_3## брони.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		["menu_deck10_7"] = "Сомнительная медицина",
		["menu_deck10_9"] = "Народная медицина",

		--Интервент
		["menu_deck8_1_desc_sc"] = "Когда вы находитесь в #{skill_color}#$perk_value_1## метрах от врага, вы получаете на #{skill_color}#$perk_value_2## меньше урона.",
		["menu_deck8_3_desc_sc"] = "Когда вы находитесь в #{skill_color}#$perk_value_1## метрах от врага, вы получаете еще на #{skill_color}#$perk_value_2## меньше урона.\n\nВы получаете #{skill_color}#$perk_value_3## Уворота.",
		["menu_deck8_5_desc_sc"] = "Когда вы находитесь в #{skill_color}#$perk_value_1## метрах от врага, вы получаете еще на #{skill_color}#$perk_value_2## меньше урона.\n\nКаждый успешный удар оружием ближнего боя дает #{skill_color}#$perk_value_3## бонус к урону оружия ближнего боя на #{skill_color}#$perk_value_4## секунд, который может складываться до #{skill_color}#$perk_value_5## раз. Эффект обнуляется при промахе.\n\nВы зацикливаете камеры на #{skill_color}#$perk_value_6## секунд дольше.",
		["menu_deck8_7_desc_sc"] = "Каждый успешный удар оружием ближнего боя дает еще #{skill_color}#$perk_value_1## урона оружию ближнего боя на #{skill_color}#$perk_value_2## секунд.\n\nВы получаете еще #{skill_color}#$perk_value_3## Уворота.",
		["menu_deck8_9_desc_sc"] = "Каждый успешный удар оружием ближнего боя восстанавливает #{skill_color}#$perk_value_1## очко здоровья каждую секунду в течение #{skill_color}#$perk_value_2## секунд, этот эффект может складываться до #{skill_color}#$perk_value_3## раз.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Джон Хотлайн Майями
		["menu_deck9_1_sc"] = "Без разговоров",
		["menu_deck9_1_desc_sc"] = "Вы получаете #{skill_color}#Комбометр##.\nУбийства в ближнем бою  заполняют Комбометр на #{important_1}#$perk_value_1## Комбо; максимальное значение Комбометра - #{important_1}#$perk_value_2##. За убийство элитных и специальных юнитов вы получаете в #{skill_color}#3## раза больше Комбо, а за Бульдозеров и Капитанов - в #{skill_color}#6## раз.\n\nВаш Комбометр истощается на #{important_1}#$perk_value_3## Комбо каждые #{risk}#$perk_value_4## секунд.\nВы теряете #{important_1}#$perk_value_5## Комбо, когда получаете урон по здоровью; это не может происходить чаще, чем раз в #{risk}#$perk_value_6## секунду.\nВы теряете #{important_1}#$perk_value_7## Комбо после падения.\n\nВы получаете на #{skill_color}#$perk_value_9## урона меньше за каждые #{important_1}#$perk_value_8## Комбо до максимальных #{skill_color}#$perk_value_10##.",
		["menu_deck9_3"] = "Напряженность",		
		["menu_deck9_3_desc_sc"] = "Нелетальные удары оружием ближнего боя и убийства из огнестрельного оружия обновляют Комбометр.\n\nВы двигаетесь на #{skill_color}#$perk_value_2## быстрее за каждые #{risk}#$perk_value_1## Комбо до максимальных #{skill_color}#$perk_value_3##.\n\nВы получаете #{skill_color}#$perk_value_4## уворота.",
		["menu_deck9_5"] = "Прямое Попадание",				
		["menu_deck9_5_desc_sc"] = "Убийства оружием ближнего боя восстанавливают #{skill_color}#$perk_value_1## выносливости.\n\nУбийства оружием ближнего боя восстанавливают #{skill_color}#$perk_value_3## здоровья за каждые #{risk}#$perk_value_2## очков вашего Комбо до максимальных #{skill_color}#$perk_value_4## здоровья.\n\nВы носите #{skill_color}#$perk_value_5## дополнительный мешок для трупов.",
		["menu_deck9_7"] = "Передозировка",			
		["menu_deck9_7_desc_sc"] = "За каждые #{risk}#$perk_value_2## брони вы получаете на #{skill_color}#$perk_value_1## Комбо больше за убийство, а интервал между потерями Комбо за получение урона по здоровью увеличивается на #{skill_color}#$perk_value_8## секунд.\n\nУбийства заполняют вашу полоску уворота на #{skill_color}#$perk_value_4## в зависимости от его общего количества за каждые #{risk}#$perk_value_3## Комбо до максимальных #{skill_color}#$perk_value_5## уворота.\nУбийства в ближнем бою увеличивают этот эффект на #{skill_color}#$perk_value_7.##\n\nВы получаете еще #{skill_color}#$perk_value_6## Уворота.",
		["menu_deck9_9"] = "В Открытую",			
		["menu_deck9_9_desc_sc"] = "Теперь ваш Комбометр истощается на #{skill_color}#$perk_value_1## Комбо за раз.\n\nУбийства прямым уроном имеют #{skill_color}#$perk_value_3## шанс посеять панику среди врагов в #{skill_color}#$perk_value_4## метрах за каждые #{risk}#$perk_value_2## Комбо до максимальных #{skill_color}#$perk_value_5##.\nУбийства в ближнем бою увеличивают этот эффект на #{skill_color}#$perk_value_6.##.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на #{skill_color}#10%.##",

		["menu_deck9_richard"] = "Ричард",
		["menu_deck9_richard_desc_sc"] = "#{important_1}#Ты любишь причинять боль людям?## \n\nНикакого эффекта.",
		["menu_deck9_tony"] = "Тони",
		["menu_deck9_tony_desc_sc"] = "#{risk}#Кулаки ярости## \n\nВаши #{skill_color}#Кулаки## наносят на #{skill_color}#$perk_value_1## больше урона, но #{risk}#Капитаны и боссы## получают на #{important_1}#$perk_value_9## меньше урона от них.\nЭффекты карт #{risk}#Передозировка## и #{risk}#В Открытую## за убийство уменьшены на #{important_1}#33%.## \nМаксимальное значение Комбометра уменьшено на #{important_1}#$perk_value_6## Комбо. Ваш Комбометр теперь истощается на #{important_1}#$perk_value_7## секунды быстрее.\nВы дополнительно теряете #{important_1}#$perk_value_5## Комбо когда получаете урон по здоровью. \nВаш общий боезапас урезан на #{important_1}#$perk_value_2##, а подбор - на #{important_1}#$perk_value_3##.\n ",		
		["menu_deck9_aubrey"] = "Обри",
		["menu_deck9_aubrey_desc_sc"] = "#{risk}#Весь мир - театр, а люди в нем - актеры.## \n\nУбийства любым оружием, кроме ближнего боя, теперь заполняют Комбометр на #{skill_color}#$perk_value_1## Комбо.\n\n#{risk}#Убийства любым оружием прямым уроном, кроме ближнего боя, теперь добавляют только## #{skill_color}#$perk_value_2## #{risk}#секунды к истощению Комбометра,## #{important_1}#убийства взрывчаткой и периодическим уроном больше не обновляют Комбометр.##",
		["menu_deck9_rufus"] = "Руфус",
		["menu_deck9_rufus_desc_sc"] = "#{risk}#Выдержи одну пулю## \n\nТеперь за каждые #{risk}#$perk_value_2## Комбо получаемый урон уменьшается на #{skill_color}#$perk_value_1## до максимальных #{skill_color}#$perk_value_3## очков.\n\nВы теряете дополнительные #{important_1}#$perk_value_4## Комбо когда получаете урон по здоровью.",
		["menu_deck9_zack"] = "Зак",
		["menu_deck9_zack_desc_sc"] = "#{risk}#Продолжительное Комбо## \n\nВаш Комбометр теперь истощается на #{skill_color}#$perk_value_1## секунды дольше, но на #{important_1}#$perk_value_2## Комбо больше за раз.",
		["menu_deck9_rick"] = "Рик",
		["menu_deck9_rick_desc_sc"] = "#{risk}#Точные... удары?!## \n\nУбийства в ближнем бою теперь дают на #{skill_color}#$perk_value_1## Комбо больше, но максимальное значение Комбометра уменьшено на #{important_1}#$perk_value_2## Комбо.",
		["menu_deck9_brandon"] = "Брэндон",
		["menu_deck9_brandon_desc_sc"] = "#{risk}#Ходи быстрее## \n\nТеперь вы двигаетесь на #{skill_color}#$perk_value_1## быстрее за каждые #{risk}#$perk_value_2## Комбо до максимальных #{skill_color}#$perk_value_3## скорости.\n\nВаш Комбометр теперь истощается на #{important_1}#$perk_value_4## секунду быстрее.",
		["menu_deck9_earl"] = "Эрл",
		["menu_deck9_earl_desc_sc"] = "#{risk}#Выдержи две пули## \n\n#{skill_color}#Теперь вы не теряете Комбо когда получаете урон по здоровью.##\n\n#{risk}#Лечение от карты## #{skill_color}#Прямое попадание## #{risk}#было уменьшено на 50%##.\n\n#{important_1}#Когда вы упадете, вы потеряете все накопленные Комбо.##",
		["menu_deck9_tonyr"] = "Месть Тони",
		["menu_deck9_tonyr_desc_sc"] = "#{risk}#чувак ванильный пейдей 2 отстой, я бля ненавижу эту игру## \n\nВаши #{skill_color}#Кастеты 350к## наносят #{skill_color}#$perk_value_1## больше урона, но #{risk}#Капитаны и боссы## получают на #{important_1}#$perk_value_9## меньше урона от них.\nЭффекты карт #{risk}#Передозировка## и #{risk}#В Открытую## за убийство уменьшены на #{important_1}#33%.## \nМаксимальное значение Комбометра уменьшено на #{important_1}#$perk_value_6.## \nВаш Комбометр теперь истощается на #{important_1}#$perk_value_7## секунд быстрее.\nВы дополнительно теряете #{important_1}#$perk_value_5## Комбо когда получаете урон по здоровью. \nВаш общий боезапас урезан на #{important_1}#$perk_value_2##, а подбор - на #{important_1}#$perk_value_3##\n ", 
		["menu_deck9_mark"] = "Марк",
		["menu_deck9_mark_desc_sc"] = "#{risk}#акимбо узи## \n\n#{risk}#Эффект карты## #{skill_color}#Передозировка##, #{risk}#дающий Уворот за убийства, заменен на новый##:\n\nВаша броня восстанавливается на #{skill_color}#$perk_value_2## быстрее за каждые #{risk}#$perk_value_1## Комбо до максимальных #{skill_color}#$perk_value_3.##\n\nТеперь вы #{important_1}#не получаете## #{risk}#скорость передвижения от навыка## Напряженность #{risk}#и выносливость от навыка ##Прямое попадание.",
		["menu_deck9_swan"] = "Алекс и Эш",
		["menu_deck9_swan_desc_sc"] = "#{risk}#Бензопила и пушки.## \n\nУбийства, совершенные оружием ближнего боя и огнестрелом поочередно дают #{skill_color}#$perk_value_1## Комбо. \n\n#{risk}#Последовательные убийства одним и тем же способом только обновят Комбометр.##",
		["menu_deck9_corey"] = "Кори",
		["menu_deck9_corey_desc_sc"] = "#{risk}#кувырки## \n\nВаши убийства теперь заполняют полоску Уворота на #{skill_color}#$perk_value_1## от вашего максимального Уворота за каждые #{risk}#$perk_value_2## Комбо до максимальных #{skill_color}#$perk_value_3.## Убийства в ближнем бою  увеличивают этот эффект на #{skill_color}#$perk_value_5.##\nВы дополнительное теряете #{important_1}#$perk_value_4## Комбо когда получаете урон по здоровью. \n#{important_1}#Убийства из гранатометов или периодическим уроном не заполняют полоску Уворота.##",


		--Нападающий
		["menu_deck11_1_desc_sc"] = "Нанесение урона врагу восстанавливает #{skill_color}#$perk_value_1## здоровья каждую секунду в течение #{skill_color}#$perk_value_2## секунд.\n\nЭтот эффект складывается до #{skill_color}#$perk_value_3## раз, но не чаще чем раз в #{skill_color}#$perk_value_4## секунд и только при ношении ##Противоосколочного жилета##. Ваши турели и периодический урон (огонь или яд) не вызывают этот эффект.\n\nВы теряете #{skill_color}#$perk_value_5## брони при ношении Противоосколочного жилета.\n\nКомпактность Противоосколочного жилета увеличена на #{skill_color}#$perk_value_6##.",
		["menu_deck11_3_desc_sc"] = "Эффект теперь восстанавливает на #{skill_color}#$perk_value_1## здоровье больше каждую секунду.",
		["menu_deck11_5_desc_sc"] = "Эффект теперь длится еще #{skill_color}#$perk_value_1## секунды.\n\nВы получаете возможность ставить #{skill_color}#$perk_value_2## кейса с мешками для трупов.",
		["menu_deck11_7_desc_sc"] = "Эффект теперь восстанавливает на #{skill_color}#$perk_value_1## здоровье больше каждую секунду.",
		["menu_deck11_9_desc_sc"] = "Каждое срабатывание эффекта теперь увеличивает скорость передвижения на #{skill_color}#$perk_value_1##.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Экс-президент
		["menu_deck13_1_desc_sc"] = "Когда у вас полная броня, вы получаете ##запасное здоровье## за каждого убитого врага, максимум до #{skill_color}#$perk_value_1##.\n\nКогда ваша броня восстанавливается после полной потери, ваше запасное здоровье превращается в настоящее.\n\nПолучаемое за убийство количество запасного здоровья зависит от вашей брони - тяжелая броня получает меньше, чем легкая.",
		["menu_deck13_3_desc_sc"] = "Увеличивает количество запасного здоровья за убийства на #{skill_color}#$perk_value_1##.\n\nВы получаете #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck13_5_desc_sc"] = "Вы можете накапливать на #{skill_color}#$perk_value_1## больше запасного здоровья.\n\nГражданские, напуганные вами и вашей бандой, остаются напуганными на #{skill_color}#$perk_value_2## дольше.",
		["menu_deck13_7_desc_sc"] = "Увеличивает количество запасного здоровья за убийства на #{skill_color}#$perk_value_1##.\n\nВы получаете еще #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck13_9_desc_sc"] = "Убийство врага ускоряет восстановление брони, в зависимости от надетой брони. Тяжелая броня получает меньший бонус, чем легкая. Этот бонус обнуляется при каждом восстановлении брони.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--THIS IS WAR BABY
		["menu_deck14_1_desc_sc"] = "Наносимый вами урон переводится в ##Истерию##. Максимальное количество Истерии - #{skill_color}#$perk_value_1##.\n\n##Истерия##\nВы поглощаете #{skill_color}#$perk_value_2## получаемого урона за каждые #{skill_color}#$perk_value_3## Истерии. Количество Истерии уменьшается на #{skill_color}#$perk_value_4## каждые #{skill_color}#$perk_value_5## секунд.",
		["menu_deck14_3_desc_sc"] = "Члены вашей команды получают бонус за Истерию.\n\nИстерия от разных членов команды не складывается - только Истерия с наивысшим значением поглощения урона имеет эффект.\n\nВы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck14_5_desc_sc"] = "Истерия теперь уменьшается на #{skill_color}#$perk_value_1## каждые #{skill_color}#$perk_value_2## секунд.\n\nГражданские, напуганные вами и вашей бандой, остаются напуганными на #{skill_color}#$perk_value_3## дольше.",
		["menu_deck14_7_desc_sc"] = "Получаемый урон теперь поглощается еще на #{skill_color}#$perk_value_1## очко за каждые #{skill_color}#$perk_value_2## Истерии.\n\nВы получаете еще #{skill_color}#$perk_value_3## Уворота.",
		["menu_deck14_9_desc_sc"] = "Истерия теперь на #{skill_color}#$perk_value_1## эффективнее для вас.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--ДСПД НОУ АИ НОУ ДАУНС НОУ ДЖОКЕРС НОУ УИЛЛ ТУ ЛИВ
		["menu_st_spec_15"] = "Анархист",
		["menu_deck15_1_desc_sc"] = "Вместо полного восстановления брони вне боя, Анархист периодически восстанавливает часть брони. Чем тяжелее ваш бронежилет, тем больше брони восстанавливается за раз, но тем реже это происходит.\n\nНавыки, увеличивающие скорость восстановления брони, отключены при использовании этого набора.",
		["menu_deck15_3_desc_sc"] = "#{skill_color}#$perk_value_1## вашего здоровья переводится в #{skill_color}#$perk_value_2## брони.",
		["menu_deck15_5_desc_sc"] = "#{skill_color}#$perk_value_1## вашего здоровья переводится в #{skill_color}#$perk_value_2## брони.\n\nГражданские, напуганные вами и вашей бандой, остаются напуганными на #{skill_color}#$perk_value_3## дольше.",
		["menu_deck15_7_desc_sc"] = "#{skill_color}#$perk_value_1## вашего здоровья переводится в #{skill_color}#$perk_value_2## брони.",
		["menu_deck15_9_desc_sc"] = "Нанесение урона восстановит вам часть брони - это может произойти только раз в #{skill_color}#$perk_value_1## секунд. Тяжелые бронежилеты восстанавливают больше брони.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		["menu_anarc_disable"] = "#{important_1}#(Этот эффект не работает для набора перков Анархист)##",

		--Лицо со Шрамом
		["menu_deck17_1_desc_sc"] = "Теперь вы можете использовать #{skill_color}#Инъектор##. Переключение на другой набор перков сделает Инъектор недоступным. Инъектор занимает слот метательного оружия.\n\nВо время ограбления нажмите кнопку метательного оружия, чтобы использовать его. Во время использования Инъектора, вы будете вылечены на #{skill_color}#$perk_value_1## от любого полученного урона или успешного Уворота в течение #{skill_color}#$perk_value_2## секунд.\n\n#{risk}#Количество восстанавливаемого здоровья во время Уворота не может превысить значение вашей максимальной брони.##\n\nИнъектор можно использовать раз в #{skill_color}#$perk_value_3## секунд, но каждое убийство уменьшит задержку на #{skill_color}#$perk_value_4## секунду.",
		["menu_deck17_3_desc_sc"] = "Ваша скорость увеличена на #{skill_color}#$perk_value_1## пока действует Инъектор.\n\nВы получаете #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck17_5_desc_sc"] = "Теперь вы будете вылечены на #{skill_color}#$perk_value_1## от любого полученного урона или успешного Уворота (пока у вас есть броня) в течение #{skill_color}#$perk_value_2## секунд после использования Инъектора.\n\nПока действует Инъектор, враги будут держать вас в приоритете.",
		["menu_deck17_7_desc_sc"] = "Количество восстанавливаемого Инъектором здоровья увеличено на #{skill_color}#$perk_value_1## если у вас меньше #{skill_color}#$perk_value_2## здоровья.\n\nВы получаете еще #{skill_color}#$perk_value_3## Уворота.",
		["menu_deck17_9_desc_sc"] = "Пока у вас полное здоровье, Инъектор восстановится на #{skill_color}#$perk_value_2## секунды быстрее за каждые #{skill_color}#$perk_value_1## здоровья, полученные во время действия Инъектора.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Дымовуха из бичпакета
		["menu_st_spec_18"] = "Сикарио",
		["menu_deck18_1_desc_sc"] = "Теперь вы можете использовать #{skill_color}#Дымовую шашку##. Переключение на другой набор перков сделает Дымовую шашку недоступным. Дымовая шашка занимает слот метательного оружия.\n\nПри броске, Дымовая шашка создает завесу на #{skill_color}#$perk_value_1## секунд. Внутри завесы вы и ваша команда восстанавливаете броню на #{skill_color}#$perk_value_2## быстрее, а значение Уворота повышается до #{skill_color}#$perk_value_3##, если оно ниже. Любые противники, стоящие в дымовой завесе, получает штраф #{skill_color}#$perk_value_4## к точности.\n\nДымовую завесу можно использовать раз в #{skill_color}#$perk_value_5## секунд, но убийство врага сокращает эту задержку на #{skill_color}#$perk_value_6## секунды.\n\nВы получаете #{skill_color}#$perk_value_7## Уворота.",
		["menu_deck18_3_desc_sc"] = "Вы получаете еще #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck18_5_desc_sc"] = "Уворот от атаки сократит задержку дымовой завесы на #{skill_color}#$perk_value_1## секунду.\n\nВы носите на #{skill_color}#$perk_value_2## мешок для тел больше.",
		["menu_deck18_7_desc_sc"] = "Вы получаете еще #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck18_9_desc_sc"] = "Полоска Уворота будет заполняться на #{skill_color}#$perk_value_1## каждую секунду, пока вы находитесь внутри дымовой завесы.\n\nПолоска Уворота напарников будет заполняться на ##$perk_value_2## каждую секунду.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Стоик не про алкоголизм, но что нам стоит взять механику Монаха из Варкрафта и добавить в наш шутер
		["menu_deck19_1_desc_sc"] = "Теперь вы можете использовать #{skill_color}#Фляжку##. Переключение на другой набор перков сделает Фляжку недоступным. Фляжка занимает слот метательного оружия.\n\n#{skill_color}#$perk_value_1## полученного урона по здоровью превращается во ##временное здоровье##, которые убывает в течении #{skill_color}#$perk_value_2## секунд.\n\nВы можете нажать на кнопку метательного оружия, чтобы использовать Фляжку и обнулить временное здоровье, #{skill_color}#$perk_value_3## от которого превращается в настоящее здоровье. Фляжку можно использовать раз в #{skill_color}#$perk_value_4## секунд.\n\n#{skill_color}#$perk_value_5## вашей брони переводятся в #{skill_color}#$perk_value_6## здоровья.\n\nПока ваша броня сломана, ваше период неуязвимости уменьшен на #{important_1}#$perk_value_7##.\n#{risk}# Это не влияет на естественное убывание временного здоровья и увороты.##",
		["menu_deck19_3_desc_sc"] = "Задержка Фляжки сокращается на #{skill_color}#$perk_value_1## секунды за каждого убитого врага.",
		["menu_deck19_5_desc_sc"] = "Если вы не получаете урон в течение #{skill_color}#$perk_value_1## секунд, все текущее временное здоровье становится настоящим.\n\nВы отвечаете на пейджеры на #{skill_color}#$perk_value_2## быстрее.",
		["menu_deck19_7_desc_sc"] = "Когда у вас меньше #{skill_color}#$perk_value_1## здоровья, задержка Фляжки сокращается на #{skill_color}#$perk_value_2## секунды за каждого убитого врага.",
		["menu_deck19_9_desc_sc"] = "Вы получаете на #{skill_color}#$perk_value_1## больше здоровья после того, как вы встали.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Минздрав предупреждает: все убивает без предупреждения
		["menu_st_spec_20"] = "Тандем",
		["menu_deck20_1_desc_sc"] = "Теперь вы можете использовать ##Парилку.## Переключение на другой набор перков сделает Парилку недоступным. Парилка занимает слот метательного оружия.\n\nЧтобы активировать Парилку, вам нужно смотреть на союзника на расстоянии не более #{skill_color}#$perk_value_1## метров и нажать на кнопку метательного оружия, чтобы отметить его. Между вами и союзником не должно быть препятствий или стен.\n\nКаждый противник, убитый вами или выбранным союзником, восстановит #{skill_color}#$perk_value_2## здоровья вам и #{skill_color}#$perk_value_3## здоровья союзнику.\n\nПарилка длится #{skill_color}#$perk_value_4## секунд и восстанавливается #{skill_color}#$perk_value_5## секунд.",
		["menu_deck20_3_desc_sc"] = "Каждый убитый вами или выбранным союзником враг продлевает действие Парилки на #{skill_color}#$perk_value_1## секунды.\n\nЭтот эффект уменьшается на #{skill_color}#$perk_value_2## секунды с каждым убийством.",
		["menu_deck20_5_desc_sc"] = "Каждый убитый вами или выбранным союзником враг уменьшает получаемый урон на #{skill_color}#$perk_value_1## очков, до максимальных #{skill_color}#$perk_value_2##, пока Парилка не станет снова доступна для использования.\n\nВы зацикливаете камеры на #{skill_color}#$perk_value_3## секунд дольше.",
		["menu_deck20_7_desc_sc"] = "Лечение от Парилки увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck20_9_desc_sc"] = "Каждый враг, убитый вами, сокращает задержку Парилки на #{skill_color}#$perk_value_1## секунды.\n\nКаждый враг, убитый выбранным союзником, сокращает задержку Парилки на #{skill_color}#$perk_value_2## секунды, пока она действует.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Байкер
		["menu_deck16_1_desc_sc"] = "Вы получаете #{skill_color}#Единство##. Каждый напарник в близости от вас протяженностью #{skill_color}#$perk_value_1## метров повышает уровень Единства.\nКаждый уровень Единства имеет #{skill_color}#$perk_value_2## стаков; чем больше разница между текущим и максимальным количеством стаков Единства, тем быстрее стаки будут набираться или спадать.\nЧлены вашей команды теряют #{important_1}#$perk_value_3## стак Единства за каждые полученные #{skill_color}#$perk_value_4## урона (эффект #{skill_color}#удваивается## при получении урона по здоровью).\n\nЭффекты Единства зависят от выбранных карт в этом наборе перков.\n\n#{risk}#Если несколько Байкеров находятся вместе, то для набора стаков считается только максимальный уровень Единства, скорость накопления стаков остается прежним, а эффекты одинаковых карт набора перков не складываются.##",
		["menu_deck16_1_short_sc"] = "Вы и члены вашей команды получаете Единство. Единство повышается, когда ваши напарники находятся рядом, и понижается при получении урона и отсутствии напарников поблизости. Единство дает бонусы в зависимости от выбранных карт.",
		["menu_deck16_1_1_sc"] = "Держа колонну",
		["menu_deck16_1_1_desc_sc"] = "За каждые #{skill_color}#8## стаков Единства члены команды лечатся на #{skill_color}#$perk_value_1## эффективнее.",
		["menu_deck16_1_2_sc"] = "Каждая пуля на счету",
		["menu_deck16_1_2_desc_sc"] = "За каждые #{skill_color}#8## стаков Единства члены команды подбирают на #{skill_color}#$perk_value_1## больше патронов из коробок.",

		["menu_deck16_3_desc_sc"] = "Эффекты всех карт для вас всегда мощнее на #{skill_color}#$perk_value_1## стаков Единства.\n\nВаш уворот увеличен на #{skill_color}#$perk_value_2## очков.",
		["menu_deck16_3_1_sc"] = "Встав колом",
		["menu_deck16_3_1_desc_sc"] = "Вы получаете на #{skill_color}#$perk_value_1## больше стаков Единства, когда вы находитесь рядом с напарниками.\nВы теряете на #{important_1}#$perk_value_2## больше стаков Единства при падении и отсутствии напарников рядом.",
		["menu_deck16_3_2_sc"] = "Вваливая своим путем",
		["menu_deck16_3_2_desc_sc"] = "Вы получаете на #{skill_color}#$perk_value_1## меньше стаков Единства, когда вы находитесь рядом с напарниками.\nВы теряете на #{important_1}#$perk_value_2## меньше стаков Единства при падении и отсутствии напарников рядом.",
		["menu_deck16_3_3_sc"] = "Езда по старинке",
		["menu_deck16_3_3_desc_sc"] = "Никакого эффекта.",

		["menu_deck16_5_desc_sc"] = "Вы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_1## быстрее.",
		["menu_deck16_5_1_sc"] = "Переобувка",
		["menu_deck16_5_1_desc_sc"] = "За каждые #{skill_color}#8## стаков Единства члены команды передвигаются на #{skill_color}#$perk_value_1## быстрее.",
		["menu_deck16_5_2_sc"] = "Тюних магазинов",
		["menu_deck16_5_2_desc_sc"] = "За каждые #{skill_color}#8## стаков Единства члены команды перезаряжают оружия на #{skill_color}#$perk_value_1## быстрее.",

		["menu_deck16_7_desc_sc"] = "Ваш уворот увеличен еще на #{skill_color}#$perk_value_1## очков.",
		["menu_deck16_7_1_sc"] = "Встал с колен",
		["menu_deck16_7_1_desc_sc"] = "Вы получаете #{skill_color}#$perk_value_1## стаков Единства после того, как вы встали.",
		["menu_deck16_7_2_sc"] = "Пусть их шапки летят",
		["menu_deck16_7_2_desc_sc"] = "Вы и члены вашей команды рядом получают #{skill_color}#$perk_value_1## стак Единства за каждое убийство.\nЭффект складывается при наличии другого Байкера в команде с этой же картой.\n\n#{risk}#Стаки Единства, полученные с помощью этой карты, не могут превысить их максимально возможное количество.##",
		["menu_deck16_7_2_short_sc"] = "Вы и члены вашей команды рядом получают #{skill_color}#$perk_value_1## стак Единства за каждое убийство.",

		["menu_deck16_9_desc_sc"] = "Члены вашей команды получают в #{skill_color}#два раза больше## стаков Единства.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",
		["menu_deck16_9_1_sc"] = "Заложить поворот",
		["menu_deck16_9_1_desc_sc"] = "Члены вашей команды теперь теряют стаки Единства за каждые полученные #{skill_color}#$perk_value_1## урона.\nЗа каждые 8 стаков Единства члены команды получают #{skill_color}#$perk_value_2## здоровья каждые #{important_1}#$perk_value_3## секунд.",
		["menu_deck16_9_2_sc"] = "Льем горючку",
		["menu_deck16_9_2_desc_sc"] = "За каждые 8 стаков Единства члены вашей команды восстанавливают броню на #{skill_color}#$perk_value_1## быстрее.\nЗа каждые 8 стаков Единства члены команды получают #{skill_color}#$perk_value_2## брони.\n\n#{risk}#Этот эффект учитывается первым при подсчете итогового значения брони.##",
		["menu_deck16_9_2_short_sc"] = "За каждые 8 стаков Единства члены вашей команды восстанавливают броню на #{skill_color}#$perk_value_1## быстрее.\nЗа каждые 8 стаков Единства члены команды получают #{skill_color}#$perk_value_2## брони.",
		["menu_deck16_9_3_sc"] = "Дальнобой",
		["menu_deck16_9_3_desc_sc"] = "За каждые 8 стаков Единства члены вашей команды восстанавливают выносливость на #{skill_color}#$perk_value_1## быстрее.\nДополнительный эффект от карты 'Дорожный Капитан' теперь мощнее на #{skill_color}#$perk_value_2.##",
		["menu_deck16_9_4_sc"] = "Мототоксикоз",
		["menu_deck16_9_4_desc_sc"] = "Члены вашей команды получают #{skill_color}#$perk_value_1## стаков Единства за каждое #{skill_color}#$perk_value_2##-ое убийство.\nУ каждого напарника свой счетчик убийств.\n\n#{risk}#Стаки Единства, полученные с помощью этой карты, могут превысить их максимально возможное количество.##",
		["menu_deck16_9_4_short_sc"] = "Члены вашей команды получают #{skill_color}#$perk_value_1## стаков Единства за каждое #{skill_color}#$perk_value_2##-ое убийство.",

		--Джон Якудза
		["menu_deck12_1_desc_sc"] = "Чем меньше у вас здоровья, тем быстрее будет восстанавливаться полоска Уворота, до максимальных #{skill_color}#$perk_value_1## Уворота каждую секунду.\n\nВы получаете #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck12_3_desc_sc"] = "Чем меньше у вас здоровья, тем больше вы будете получать Уворота при убийстве врага, до максимальных #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck12_5_desc_sc"] = "Чем меньше у вас здоровья, тем меньше урона вы получаете, до максимальных #{skill_color}#$perk_value_1##.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_2## быстрее.",
		["menu_deck12_7_desc_sc"] = "Чем меньше у вас здоровья, тем больше вы будете получать Уворота при убийстве врага оружием ближнего боя или метательным оружием (кроме гранат), до максимальных #{skill_color}#$perk_value_1## Уворота.\n\nВы получаете еще #{skill_color}#$perk_value_4## Уворота.",
		["menu_deck12_9_desc_sc"] = "Максимальное количество устойчивости увеличено до #{skill_color}#$perk_value_1.##\n\nОдин раз за падение, если у вас закончится здоровье, вы выживите с ##1## здоровьем и восстановите #{skill_color}#$perk_value_2## брони.\n\nДанный перк не работает на удары Клокеров и шок Тазеров.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		["menu_yakuza_deflection_add"] = "(с бонусом от Якудзы)",

		--Хакер
		["menu_deck21_1_desc_sc"] = "Теперь вы можете использовать #{skill_color}#Карманный генератор помех## (сокр. #{skill_color}#КГП##). Переключение на другой набор перков сделает КГП недоступным. КГП занимает слот метательного оружия.\n\nВо время ограбления нажмите кнопку метательного оружия, чтобы активировать его.\n\nАктивация КГП до тревоги отключит всю электронику и пейджеры на #{skill_color}#$perk_value_1## секунд.\n\nАктивация КГП после тревоги будет оглушать врагов в радиусе #{skill_color}#$perk_value_2## метров. Первые помехи имеют #{skill_color}#$perk_value_3## шанс оглушить врага, затем каждые #{skill_color}#$perk_value_4## секунды помех имеют #{skill_color}#$perk_value_5## шанс на оглушение.\n\nКГП восстанавливается #{skill_color}#$perk_value_6## секунд, но каждое убийство сократит задержку на #{skill_color}#$perk_value_7## секунды.",
		["menu_deck21_3_desc_sc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck21_5_desc_sc"] = "Пока работает КГП, убийство врага  восстановит #{skill_color}#$perk_value_1## здоровья.",
		["menu_deck21_7_desc_sc"] = "Ваша броня восстанавливается быстрее на #{skill_color}#$perk_value_1##.\n\nВы получаете еще #{skill_color}#$perk_value_2## Уворота.",
		["menu_deck21_9_desc_sc"] = "Союзники восстановят #{skill_color}#$perk_value_1## здоровья, если убьют врага пока работает КГП.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Кровосися
		["menu_deck22_1_desc_sc"] = "Теперь вы можете использовать #{skill_color}#Ампулу##. Переключение на другой набор перков сделает Ампулу недоступным. Ампула занимает слот метательного оружия.\n\nНажмите кнопку метательного оружия, чтобы активировать Ампулу. Она восстановит #{skill_color}#$perk_value_1## вашего здоровья и #{important_1}#лишит вас Уворота и брони## на #{skill_color}#$perk_value_2## секунд. После окончания действия Ампулы вы восстанавливаете броню в том же количестве, в котором вы потеряли.\n#{risk}#Навыки, которые восстанавливают броню неестественным способом, продолжают работать во время действия Ампулы и влияют на итоговую броню по его окончании.##\n\nПока Ампула действует, ваше здоровье разделено на сегменты: каждый сегмент равен #{skill_color}#$perk_value_3## здоровья, и любой полученный урон снимет один сегмент. Убийство #{risk}#$perk_value_4## врагов восстановит один сегмент и заблокирует получаемый урон на #{skill_color}#$perk_value_5## секунду.\nАмпула восстанавливается #{skill_color}#$perk_value_6## секунд.\n\nПока Ампула не активна, когда вы или ваша команда убивают врага, вы восстанавливаете #{skill_color}#$perk_value_7## здоровья. Это может произойти только раз в #{skill_color}#$perk_value_8## секунд.\n ",
		["menu_deck22_3_desc_sc"] = "Пока действует Ампула, любое получение урона восстановит #{skill_color}#$perk_value_1## здоровья вашим союзникам.\n\nВы восставливаете #{skill_color}#$perk_value_2## брони каждые #{skill_color}#$perk_value_3## секунды.\n\nВы получаете #{skill_color}#$perk_value_4## Уворота.",
		["menu_deck22_5_desc_sc"] = "Длительность Ампулы увеличена до #{skill_color}#$perk_value_1## секунд.\n\nУбийство врага уменьшает задержку Ампулы на #{skill_color}#$perk_value_2## секунду.\n\nПока Ампула не активна, каждые недостающие #{skill_color}#$perk_value_3## брони уменьшают задержку эффекта получения брони за убийство на #{skill_color}#$perk_value_4## секунд.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_5## быстрее.",
		["menu_deck22_7_desc_sc"] = "Теперь ваше здоровье разделено на сегменты по #{skill_color}#$perk_value_1## во время действия Ампулы.\nТеперь убийство #{important_1}#$perk_value_2## врагов во время действия Ампулы восстанавливают #{skill_color}#$perk_value_3## сегментов здоровья.\n\nТеперь вы восставливаете #{skill_color}#$perk_value_4## брони каждые #{skill_color}#$perk_value_5## секунд.\n\nУбийство врага оружием ближнего боя активирует следующее восстановление брони на #{skill_color}#$perk_value_6## секунд быстрее.\n\nВы получаете еще #{skill_color}#$perk_value_7## Уворота.",
		["menu_deck22_9_desc_sc"] = "Теперь можно активировать Ампулу когда вы лежите. Это временно поднимет вас до конца действия Ампулы и добавит #{skill_color}#$perk_value_1## секунд к времени восстановления Ампулы.\n\nТеперь получение урона вылечит товарищей на #{skill_color}#$perk_value_2##.\n\nПока Ампула не активна, каждые недостающие #{skill_color}#$perk_value_3## брони увеличивают количество получаемого здоровья за убийства на #{skill_color}#$perk_value_4##.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		--Подражатель
		["menu_st_spec_23"] = "Подражатель",
		["menu_st_spec_23_desc"] = "Подражатель - уникальный человек, обладающий фотографической памятью и молниеносными рефлексами. Вечное ожидание опасности сделало вас настолько ловким, что вы можете уворачиваться и даже отражать пули противника. Вы изучали своих товарищей и теперь можете имитировать их способности и формировать свой собственный уникальный стиль из них. И если кто-то скажет, что вы просто воришка, ответьте, что подражание - высшая форма похвалы.",
		["menu_deck23_1"] = "Тактическая перезарядка",
		["menu_deck23_3"] = "Головная боль",
		["menu_deck23_5"] = "Твоя пуля?",
		["menu_deck23_7"] = "Секунда славы",
		["menu_deck23_9"] = "Мимикрия",
		["menu_deck23_9_desc"] = "Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",

		["menu_deck23_1_desc"] = "Убийство #{skill_color}#$perk_value_1## врагов перезарядит ваше спрятанное оружие.\n\nУбийства считаются отдельно для каждого оружия, счетчик обнуляется только при срабатывании эффекта.\n\nВы меняете оружие на #{skill_color}#$perk_value_2## быстрее.",
		["menu_deck23_1_short"] = "Убийство #{skill_color}#$perk_value_1## врагов перезарядит ваше спрятанное оружие.\n\nВы переключаете оружие на #{skill_color}#$perk_value_2## быстрее.",
		["menu_deck23_1_1_desc"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_1_1_short"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_1_2_desc"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_1_2_short"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_1_3_desc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_1_3_short"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_1_4_desc"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_1_4_short"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_1_1"] = "Живчик",
		["menu_deck23_1_2"] = "Крепыш",
		["menu_deck23_1_3"] = "Ловкач",
		["menu_deck23_bonus_speed"] = "Проныра",

		["menu_deck23_3_desc"] = "Каждый выстрел в голову восстанавливает #{skill_color}#$perk_value_1## здоровья.\n\nЭто может произойти не чаще чем раз в #{skill_color}#$perk_value_2## секунд или при срабатывании навыка #{skill_color}#\"В яблочко\"##.",
		["menu_deck23_3_short"] = "Каждый выстрел в голову восстанавливает #{skill_color}#$perk_value_1## здоровья.\n\nЭто может произойти не чаще чем раз в #{skill_color}#$perk_value_2## секунд или при срабатывании навыка #{skill_color}#\"В яблочко\"##.",
		["menu_deck23_3_1_desc"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_3_1_short"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_3_2_desc"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_3_2_short"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_3_3_desc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_3_3_short"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_3_4_desc"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_3_4_short"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_3_1"] = "Живчик",
		["menu_deck23_3_2"] = "Крепыш",
		["menu_deck23_3_3"] = "Ловкач",

		["menu_deck23_5_desc"] = "Пули, от которых вы увернулись, отлетят во врагов.\n\nПули, которые ломают вашу броню, отлетят обратно во врага и нанесут на #{skill_color}#$perk_value_1## больше урона.\n\nРикошеты от брони происходят не чаще чем раз в #{skill_color}#$perk_value_2## секунд.",
		["menu_deck23_5_short"] = "Пули, от которых вы увернулись, отлетят во врагов.\n\nПули, которые ломают вашу броню, отлетят обратно во врага и нанесут на #{skill_color}#$perk_value_1## больше урона.\n\nРикошеты от брони происходят не чаще чем раз в #{skill_color}#$perk_value_2## секунд.",
		["menu_deck23_5_1_desc"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_5_1_short"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_5_2_desc"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_5_2_short"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_5_3_desc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_5_3_short"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_5_4_desc"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_5_4_short"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_5_1"] = "Живчик",
		["menu_deck23_5_2"] = "Крепыш",
		["menu_deck23_5_3"] = "Ловкач",

		["menu_deck23_7_desc"] = "Когда ваше здоровье опускается ниже #{skill_color}#$perk_value_1##, вы получите иммунитет к урону на #{skill_color}#$perk_value_2## секунды.\n\nЭто может произойти не чаще чем раз в #{skill_color}#$perk_value_3## секунд.",
		["menu_deck23_7_short"] = "Когда ваше здоровье опускается ниже #{skill_color}#$perk_value_1##, вы получите иммунитет к урону на #{skill_color}#$perk_value_2## секунды.\n\nЭто может произойти не чаще чем раз в #{skill_color}#$perk_value_3## секунд.",
		["menu_deck23_7_1_desc"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_7_1_short"] = "Ваше здоровье увеличено на #{skill_color}#$perk_value_1##.",
		["menu_deck23_7_2_desc"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_7_2_short"] = "Ваша броня увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_7_3_desc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_7_3_short"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.",
		["menu_deck23_7_4_desc"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_7_4_short"] = "Скорость в приседе и с сумкой увеличена на #{skill_color}#$perk_value_1##.",
		["menu_deck23_7_1"] = "Живчик",
		["menu_deck23_7_2"] = "Крепыш",
		["menu_deck23_7_3"] = "Ловкач",
		--Последняя карта
			--Crew Chief
			["menu_deck1_mrwi_desc"] = "Выносливость для вас и вашей команды увеличена на #{skill_color}#$perk_value_1##.\n\nРасстояние ваших криков увеличено на #{skill_color}#$perk_value_2##.\n\nКомандные бонусы не складываются.\n\nВы отвечаете на пейджеры на #{skill_color}#$perk_value_3## быстрее.",
			--Muscle
			["menu_deck2_mrwi_desc"] = "Каждый выстрел из вашего оружия имеет #{skill_color}#$perk_value_1## шанс посеять панику среди врагов.\n\nПаника заставляет врагов испытывать неконтролируемый страх на короткий промежуток времени.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_2## быстрее.",
			--Armorer
			["menu_deck3_mrwi_desc"] = "Ваша броня восстанавливается на #{skill_color}#$perk_value_1## быстрее.\n\nВы можете ставить #{skill_color}#$perk_value_2## кейса с мешками для тел.",
			--Rogue
			["menu_deck4_mrwi_desc"] = "Вы получаете #{skill_color}#$perk_value_1## Уворота.\n\nВы меняете оружие на #{skill_color}#$perk_value_2## быстрее.\n\nВы зацикливаете камеры на #{skill_color}#$perk_value_3## секунд дольше.",
			--Hitman
			["menu_deck5_mrwi_desc"] = "Убийство врагов огнестрельным оружием добавляет #{skill_color}#$perk_value_1## #{skill_color}#запасного здоровья##. Вы можете получить до #{skill_color}#$perk_value_2## запасного здоровья.\n\nУбийство врага оружием ближнего боя превращает запасное здоровье во #{skill_color}#временное здоровье##, которое утекает со скоростью #{skill_color}#$perk_value_3## единиц в секунду.\n\nВременное здоровье может превышать ваше максимальное здоровье, но вы не можете иметь больше #{skill_color}#$perk_value_4## временного здоровья за раз.\n\nВы носите на #{skill_color}#$perk_value_5## мешок для тел больше.",
			--Crook
			["menu_deck6_mrwi_desc"] = "Убийство врага восстанавливает #{skill_color}#$perk_value_1## брони.\n\nЭто может происходить только раз в #{important_1}#$perk_value_2## секунд, но каждое убийство сокращает время на #{skill_color}#$perk_value_3## секунд, а убийство холодным оружием - еще на #{skill_color}#$perk_value_4## секунды.\n\nЕсли убийство сокращает время полностью, бонусы активируются и задержка начнется сначала.\n\nВы взламываете замки на #{skill_color}#$perk_value_5## секунды быстрее.",
			--Burglar
			["menu_deck7_mrwi_desc"] = "Ваш Уворот увеличен на #{skill_color}#$perk_value_1## очков.\n\nВаша полоска Уворота заполняется еще на #{skill_color}#$perk_value_2## за каждую секунду в приседе.\n\nВы двигаетесь на #{skill_color}#$perk_value_3## быстрее в приседе.",
			--Infiltrator
			["menu_deck8_mrwi_desc"] = "Когда вы находитесь в #{skill_color}#$perk_value_1## метрах от врага, вы получаете на #{skill_color}#$perk_value_2## меньше урона.\n\nКаждый удар в ближнем бою увеличивает урон холодного оружия на #{skill_color}#$perk_value_3##, этот эффект действует #{skill_color}#$perk_value_4## секунд и складывается до #{skill_color}#$perk_value_5## раз. Эффект обнуляется при промахе.\n\nВы зацикливаете камеры на #{skill_color}#$perk_value_6## секунд дольше.",
			--Sociopath
			["menu_deck9_mrwi_desc"] = "Вы получаете ##Комбометр##.\nУбийства в ближнем бою заполняют Комбометр на #{skill_color}#$perk_value_1## Комбо; максимальное значение Комбометра - #{skill_color}#$perk_value_2## .\n\nВаш Комбометр истощается на #{important_1}#$perk_value_3## Комбо каждые #{risk}#$perk_value_4## секунд.\nВы теряете #{important_1}#$perk_value_5## Комбо когда получаете урон по здоровью; это не может происходить чаще чем в #{skill_color}#$perk_value_6## секунды.\nВы теряете #{important_1}#$perk_value_7## Комбо когда падаете.\n\nВы получаете на #{skill_color}#$perk_value_9## очков урона меньше за каждые #{risk}#$perk_value_8## Комбо до максимальных #{skill_color}#$perk_value_10## очков.\n\nВы двигаетесь на #{skill_color}#$perk_value_14## быстрее за каждые #{risk}#$perk_value_13## Комбо до максимальных #{skill_color}#$perk_value_15## скорости.\nУбийства оружием ближнего боя восстанавливают #{skill_color}#$perk_value_11## вашей выносливости.\n\nВы носите #{skill_color}#$perk_value_12## дополнительный мешок для трупов.",
			--Gambler
			["menu_deck10_mrwi_desc"] = "Патроны, которые вы подбираете, лечат членов команды от #{skill_color}#$perk_value_1 до $perk_value_2## здоровья.\n\nЛечение имеет задержку в #{skill_color}#$perk_value_3## секунд, но каждая подобранная коробочка патронов сокращает эту задержку на #{skill_color}#$perk_value_4 - $perk_value_5## секунды.\n\nКогда вы подбираете патроны, ваша команда дополнительно получает #{skill_color}#$perk_value_6## патронов.\n\nВы отвечаете на пейджеры на #{skill_color}#$perk_value_7## быстрее.",
			--Grinder
			["menu_deck11_mrwi_desc"] = "Нанесение урона врагу восстанавливает #{skill_color}#$perk_value_1## здоровья каждую секунду в течение #{skill_color}#$perk_value_2## секунд.\n\nЭтот эффект складывается до #{skill_color}#$perk_value_3## раз, но не чаще чем раз в #{skill_color}#$perk_value_4## секунд и только при ношении ##Противоосколочного жилета##. Турели и периодический урон (огонь или яд) не вызывают этот эффект.\n\nВы теряете #{skill_color}#$perk_value_5## брони при ношении Противоосколочного жилета.\n\nКомпактность Противоосколочного жилета увеличена на #{skill_color}#$perk_value_6##.\n\nВы получаете возможность ставить #{skill_color}#$perk_value_7## кейса с мешками для трупов.",
			--Yakuza
			["menu_deck12_mrwi_desc"] = "Чем меньше у вас здоровья, тем больше вы будете получать Уворота при убийстве врага. Когда у вас меньше ##100%## здоровья, вы получите до #{skill_color}#$perk_value_1## Уворота при убийстве врага.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_2## быстрее.",
			--Ex-Pres
			["menu_deck13_mrwi_desc"] = "Когда у вас полная броня, вы получаете ##запасное здоровье## за каждого убитого врага, максимум до #{skill_color}#$perk_value_1##.\n\nКогда ваша броня восстанавливается после полной потери, ваше запасное здоровье превращается в настоящее.\n\n Получаемое за убйство количество запасного здоровья зависит от вашей брони - тяжелая броня получает меньше, чем легкая.\n\nГражданские, напуганные вами и вашей бандой, остаются напуганными на #{skill_color}#$perk_value_2## дольше.",
			--Maniac
			["menu_deck14_mrwi_desc"] = "Наносимый вами урон переводится в ##Истерию##. Максимальное количество Истерии - #{skill_color}#$perk_value_1##.\n\n##Истерия##\nВы и ваша команда поглощаете #{skill_color}#$perk_value_2## полученного урона за каждые #{skill_color}#$perk_value_3## очков Истерии. Истерия уменьшается на #{skill_color}#$perk_value_4## каждые #{skill_color}#$perk_value_5## секунд.\n\nГражданские, напуганные вами и вашей бандой, остаются напуганными на #{skill_color}#$perk_value_6## дольше.",
			--Anarchist
			["menu_deck15_mrwi_desc"] = "Вместо восстановления брони вне боя, вы периодически восстанавливаете броню с частотой ##8## очков брони в секунду. Чем тяжелее бронежилет, тем больше восстанавливется брони за раз, но тем реже это происходит.\n\nНавыки, увеличивающие скорость восстановления брони, отключены при использовании этого набора.\n\nГражданские, напуганные вами и вашей бандой, остаются напуганными на #{skill_color}#$perk_value_1## дольше.",
			--Biker
			["menu_deck16_mrwi_desc"] = "Вы и члены вашей команды получаете #{skill_color}#Единство##. Ваши напарники в радиусе #{skill_color}#$perk_value_1## метров от вас повышают уровень Единства.\nКаждый уровень Единства имеет #{skill_color}#$perk_value_2## стаков; чем больше разница между текущим и максимальным количеством стаков Единства, тем быстрее стаки будут набираться или спадать.\nЧлены вашей команды теряют #{important_1}#$perk_value_3## стак Единства за каждые полученные #{skill_color}#$perk_value_4## урона (эффект #{skill_color}#удваивается## при получении урона по здоровью).\nЧлены команды передвигаются на #{skill_color}#$perk_value_5## быстрее за каждые #{skill_color}#8## стаков Единства.\n\n#{risk}#Если несколько Байкеров находятся вместе, то для набора стаков считается только максимальный уровень Единства, скорость накопления стаков остается прежним, а эффекты одинаковых карт не складываются.##\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_6## быстрее.",
			--Kingpin
			["menu_deck17_mrwi_desc"] = "Теперь вы можете использовать #{skill_color}#Инъектор##.\n\nВо время использования Инъектора, вы будете вылечены на #{skill_color}#$perk_value_1## от любого полученного урона или успешного Уворота в течение #{skill_color}#$perk_value_2## секунд.\n\n#{risk}#Количество восстанавливаемого здоровья во время Уворота не может превысить значение вашей максимальной брони.##\n\nВаша скорость увеличена на #{skill_color}#$perk_value_3## пока действует Инъектор.\n\nИнъектор можно использовать раз в #{skill_color}#$perk_value_4## секунд, но каждое убийство уменьшит задержку на #{skill_color}#$perk_value_5## секунду.",
			--Sicario
			["menu_deck18_mrwi_desc"] = "Теперь вы можете использовать #{skill_color}#Дымовую шашку##.\n\nПри броске, дымовая шашка создает завесу на #{skill_color}#$perk_value_1## секунд. Внутри завесы вы и ваша команда восстанавливаете броню на #{skill_color}#$perk_value_2## быстрее, а значение Уворота повышается до #{skill_color}#$perk_value_3##, если оно ниже. Любые противники, стоящие в завесе, получат штраф #{skill_color}#$perk_value_4## к точности.\n\nДымовую шашку можно использовать раз в #{skill_color}#$perk_value_5## секунд, но убийство врага сокращает эту задержку на #{skill_color}#$perk_value_6## секунды.\n\nВаш Уворот увеличен на #{skill_color}#$perk_value_7## очков.\n\nВы носите на #{skill_color}#$perk_value_8## мешок для тел больше.",
			--Stoic
			["menu_deck19_mrwi_desc"] = "Теперь вы можете использовать #{skill_color}#Фляжку##.\n\n#{skill_color}#$perk_value_1## получаемого урона по здоровью станет #{skill_color}#временным здоровьем##, которая будет убывать в течение #{skill_color}#$perk_value_2## секунд.\n\nВы можете нажать на кнопку метательного оружия, чтобы использовать Фляжку и обнулить временное здоровье, #{skill_color}#$perk_value_3## от которого превращается в настоящее здоровье. Фляжку можно использовать раз в #{skill_color}#$perk_value_4## секунд.\n\n#{skill_color}#$perk_value_5## вашей брони переводится в #{skill_color}#$perk_value_6## здоровья.\n\nПока ваша броня сломана, ваш период неуязвимости уменьшен на #{important_1}#$perk_value_8## милисекунд.\n#{risk}#Это не влияет на естественное убывание временного здоровья и Увороты.##\n\nВы отвечаете на пейджеры на #{skill_color}#$perk_value_7## быстрее.",
			--Tag Team
			["menu_deck20_mrwi_desc"] = "Теперь вы можете использовать #{skill_color}#Парилку##.\n\nЧтобы активировать Парилку, вам нужно смотреть на союзника на расстоянии не более #{skill_color}#$perk_value_1## метров и нажать на кнопку метательного оружия, чтобы отметить его. Между вами и союзником не должно быть препятствий или стен.\n\nКаждый противник, убитый вами или выбранным союзником, восстановит #{skill_color}#$perk_value_2## здоровья вам и #{skill_color}#$perk_value_3## здоровья союзнику.\n\nПарилка длится #{skill_color}#$perk_value_4## секунд и восстанавливается #{skill_color}#$perk_value_5## секунд.\n\nВы зацикливаете камеры на #{skill_color}#$perk_value_6## секунд дольше.",
			--Hacker
			["menu_deck21_mrwi_desc"] = "Теперь вы можете использовать #{skill_color}#Карманный генератор помех##(Сокр. ##КГП##).\n\nВо время ограбления нажмите кнопку метательного оружия, чтобы активировать его.\n\nАктивация КГП до тревоги отключит всю электронику и пейджеры на #{skill_color}#$perk_value_1## секунд.\n\nАктивация КГП после тревоги будет оглушать врагов в радиусе #{skill_color}#$perk_value_2## метров. Первые помехи имеют #{skill_color}#$perk_value_3## шанс оглушить врага, затем каждые #{skill_color}#$perk_value_4## секунды помех имеют #{skill_color}#$perk_value_5## шанс на оглушение.\n\nКГП восстанавливается #{skill_color}#$perk_value_6## секунд, но каждое убийство сократит задержку на #{skill_color}#$perk_value_7## секунды.",
			--Leech
			["menu_deck22_mrwi_desc"] = "Теперь вы можете использовать #{skill_color}#Ампулу##.\n\nНажмите кнопку метательного оружия, чтобы активировать Ампулу. Она восстановит #{skill_color}#$perk_value_1## вашего здоровья и лишит вас брони на время своего действия.\n\nПока Ампула действует, ваше здоровье разделено на сегменты по #{skill_color}#$perk_value_3##, и любой полученный урон снимет один сегмент. Убийство #{skill_color}#$perk_value_4## врагов восстановит один сегмент и заблокирует получаемый урон на #{skill_color}#$perk_value_5## секунду.\n\nАмпула действует #{skill_color}#$perk_value_2## секунд и восстанавливается #{skill_color}#$perk_value_6## секунд.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_7## быстрее.",

		--Мета наборы--
		["menu_st_spec_0"] = "Перерожденный",
		["menu_st_spec_0_desc"] = "Говорят, люди рождаются без каких-либо заложенных идей, мыслей и убеждений - они приобретаются исключительно из опыта. Для кого-то это усложняет жизнь, кто-то видит в этом возможности. Перерожденный - это грабитель, удача которого раскрывается не сразу. Его судьба полна как больших рисков, так и больших наград.",
		["menu_st_spec_0_desc_short"] = "Говорят, люди рождаются без каких-либо заложенных идей, мыслей и убеждений - они приобретаются исключительно из опыта. Для кого-то это усложняет жизнь, кто-то видит в этом возможности. Перерожденный - это грабитель, удача которого раскрывается не сразу. Его судьба полна как больших рисков, так и больших наград.",
		["menu_deck0_1"] = "Свой человек",
		["menu_deck0_1_desc"] = "Предметы на черном рынке и активы стоят на ##30%## меньше.",
		["menu_deck0_2"] = "Черный дилер",
		["menu_deck0_2_desc"] = "Предметы на черном рынке и активы стоят еще на ##30%## меньше.",
		["menu_deck0_3"] = "Мертвые президенты",
		["menu_deck0_3_desc"] = "Подбираемая добыча дает на ##15%## больше денег.",
		["menu_deck0_4"] = "День ветерана",
		["menu_deck0_4_desc"] = "Подбираемая добыча дает еще на ##30%## больше денег.",
		["menu_deck0_5"] = "Нуболюб",
		["menu_deck0_5_desc"] = "Вы получаете на ##45%## больше опыта.",
		["menu_deck0_6"] = "Способный ученик",
		["menu_deck0_6_desc"] = "Вы получаете на ##45%## больше опыта.",
		["menu_deck0_7"] = "Мистер Профессор Фантастик",
		["menu_deck0_7_desc"] = "Вы получаете на ##45%## больше опыта.",
		["menu_deck0_8"] = "Четырехлистный клевер",
		["menu_deck0_8_desc"] = "Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##10%.##",
		["menu_deck0_9"] = "Талисман удачи",
		["menu_deck0_9_desc"] = "Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##20%.##",

		["menu_st_spec_00"] = "Прирожденный",
		["menu_st_spec_00_desc"] = "Некоторые считают, что все необходимые навыки уже есть с рождения. Некоторые люди - прирожденные грабители: им не нужно тратить ресурсы на навыки. Возможно, их убеждения - просто упрямство. Действительно ли стоит отказываться приобретать новые навыки?",
		["menu_st_spec_00_desc_short"] = "Некоторые считают, что все необходимые навыки уже есть с рождения. Некоторые люди - прирожденные грабители: им не нужно тратить ресурсы на навыки. Возможно, их убеждения - просто упрямство. Действительно ли стоит отказываться приобретать новые навыки?",
		["menu_deck00_9_desc"] = "Шанс получения предмета высокого качества после прохождения ограбления увеличен на ##20%.##",

		["rpd_menu_button"] = "Обнулить перк",
		["rpd_menu_dialog_title"] = "Вы уверены?",
		["rpd_menu_dialog_text"] = "Если вы обнулите перк '$perk_deck_name', вы получите $points_to_refund очков.",

		--для Lobby Player Info
		["menu_st_spec_24"] = "Перерожденный",
		["menu_st_spec_25"] = "Прирожденный",
		--МОДОВЫЕ ПЕРКИ
			--OFFYERROCKER'S MERCENARY PERK DECK
	["menu_deck_kmerc_title"] = "Наемник",
	["menu_deck_kmerc_desc"] = "Профессиональный Наемник прошел сотни тренировок, чтобы убивать и не быть убитым. Даже в самых жарких перестрелках, Наемник найдет дух, настойчивость и силу прорываться вперед. Выживание - правило номер один; ведь когда все кончится, оплату заберут лишь живые.",
	["menu_deck_kmerc_1"] = "Покрытый шрамами",
	["menu_deck_kmerc_1_desc_sc"] = "Вы получаете меньше урона по здоровью. Чем выше получаемый урон, тем сильнее данный эффект.\n\nВы получаете на ##5%## больше здоровья.",
	["menu_deck_kmerc_3"] = "Чрезмерная сила",
	["menu_deck_kmerc_3_desc_sc"] = "Вы получаете ##1%## бонус к скорости перезарядки и ##2%## бонус к скорости смены оружия за каждые ##4## единицы брони.\n\nВы получаете на ##5%## больше брони.",
	["menu_deck_kmerc_5"] = "Отстранись",
	["menu_deck_kmerc_5_desc_sc"] = "Когда вам наносят смертельный удар, вы выживаете с ##1## здоровьем и получаете ##2## секунды неуязвимости. Во время неуязвимости вы не можете бежать.\nЭтот эффект не может повториться, пока вы не вылечитесь до 100% здоровья.\n\nВы получаете на ##5%## больше здоровья.",
	["menu_deck_kmerc_7"] = "Лечебный слой",
	["menu_deck_kmerc_7_desc_sc"] = "Если в течение ##2## секунд у вас все еще есть броня, вы восстанавливаете здоровье, равное ##1%## вашей брони каждые ##5## секунд, пока ваша броня не будет сломана.",
	["menu_deck_kmerc_9"] = "Сильная сторона",
	["menu_deck_kmerc_9_desc_sc"] = "Когда вы получаете урон, который оставит вас с меньше чем ##30%## здоровья, вы восстанавливаете броню на ##50%## от полученного урона.\nЭффект имеет задержку в ##1## секунду и не может сработать одновременно с неуязвимостью от карты ##Отстранись##.",

			--OFFYERROCKER'S LIBERATOR PERK DECK
	["bm_tachi"] = "Инъектор жизни Таки-2Б",
	["bm_tachi_desc"] = "В этих инъекторах содержатся сильные лекасртва и микроскопические роботы. При инъекции, эти роботы попадают в организм и быстро восстанавливают поврежденные ткани. Данный вариант инъектора так же содержит адреналин для ускорения действия роботов.",
	["menu_deck_liberator_title"] = "Либератор",
	["menu_deck_liberator_desc"] = "Либератор уже долгое время занимается восстановлением государственного и корпоративного имущества - в основном, цифровых документов. Отсутствие боевого опыта означает, что Либератору иногда приходится останавливаться и брать передышку, прежде чем возвращаться к борьбе со всякими тиранами, захватившими власть.",
	["menu_deck_liberator_1"] = "Любой ценой",
	["menu_deck_liberator_1_desc_sc"] = "Открывает ##Инъектор жизни##. Использование Инъектора сразу восстановит ##15## выносливости, а также будет восстанавливать ##0.5## здоровья каждую секунду в течение ##4## секунд, или пока игрок не получит урон.\nИнъектор жизни обладает ##1## использованием с задержкой в ##30## секунд. Каждое убийство уменьшит задержку на ##1## секунду.",
	["menu_deck_liberator_3"] = "На опережение",
	["menu_deck_liberator_3_desc_sc"] = "Регенерация здоровья от Инъектора теперь длится на ##2## секунды дольше.\n\nЕсли регенерация здоровья отменилась, вы получите ##10%## сопротивления урону на остаток времени.",
	["menu_deck_liberator_5"] = "Теоретические знания",
	["menu_deck_liberator_5_desc_sc"] = "Использование Инъектора теперь восстанавливает на ##15## выносливости больше, а его регенерация увеличена на ##0.5##.\n\nВаш Уворот увеличен на ##5## очков.",
	["menu_deck_liberator_7"] = "Проблемная личность",
	["menu_deck_liberator_7_desc_sc"] = "Ваше здоровье увеличено на ##10%##.\n\nРегенерация здоровья от Инъектора теперь длится на ##2## секунды дольше.",
	["menu_deck_liberator_9"] = "Внезапная сила",
	["menu_deck_liberator_9_desc_sc"] = "Инъектор теперь восстанавливает дополнительную ##единицу## здоровья каждую секунду.",

	})
end)


-- ПасхалОчки
Hooks:Add("LocalizationManagerPostInit", "ResMod_Ruloc_EasterEggs", function(loc)

if not easterless then
	local twirl = math.rand(1)
	local shalashaska = 0.06
	if Month == "4" and Day == "1" then
		shalashaska = 1
	end
	if twirl <= shalashaska then
		LocalizationManager:add_localized_strings({
			["bm_w_peacemaker"] = "Revolver Ocelot",
			["bm_w_peacemaker_desc"] = "Revolver Ocelot",
			["bm_ap_weapon_peacemaker_sc_desc"] = "Revolver Ocelot",
			["bm_wp_peacemaker_barrel_long"] = "Revolver Ocelot",
			["bm_wp_peacemaker_barrel_short"] = "Revolver Ocelot",
			["bm_wp_peacemaker_handle_bling"] = "Revolver Ocelot",
			["bm_wp_peacemaker_rifle_stock"] = "Revolver Ocelot",
			["bm_menu_ro_barrel"] = "Revolver Ocelot",
			["bm_menu_ro_stock"] = "Revolver Ocelot",
			["bm_menu_ro_modifier"] = "Revolver Ocelot",
			["bm_menu_ro_charm"] = "Revolver Ocelot",
			["bm_menu_ro_grip"] = "Revolver Ocelot",

			["bm_m134_sc_desc"] = "CRYPTIC METAPHOR...",
			["bm_wp_upg_suppressor_boss"] = "\"CRAB BATTLE!!!\"\n\n#{skill_color}#Заглушает## оружие и #{risk}#уменьшает шанс того, что противники увернутся от вашего огня.####"
		})
	end

	 local stalker = math.rand(1)
	 local anekdot = 0.02
	 if Month == "4" and Day == "1" then
		anekdot = 1
	 end
	 if stalker <= anekdot then
		 LocalizationManager:add_localized_strings({
			-- Иди своей дорогой, сталкер
			["bm_w_striker"] = "Отбойник", -- Ну в параше не прям Protecta используется, но визуально похоже
			["bm_w_groza"] = "Гром С-14",
			  ["bm_groza_sc_desc_pc"] = "Автоматно-гранатометный комплекс — очень удачный в условиях Зоны вариант штурмовой винтовки: компактный, надежный, и в то же время универсальный и мощный. «Гром» очень любят военные сталкеры.\n\nНажмите #{skill_color}#$BTN_BIPOD## чтобы переключиться на подствольный гранатомет.",
			["bm_w_asval"] = "СА «ЛАВИНА»",
			  ["bm_asval_sc_desc"] = "Создан на базе бесшумной снайперской винтовки «Винторез», от которой отличается складным прикладом, возможностью вести огонь очередями, а также более емким магазином. Изначально предназначался для применения спецподразделениями в условиях атаки, требующей бесшумной и беспламенной стрельбы.\n\nОбладает #{skill_color}#встроенным глушителем##, #{skill_color}#наносит 25% урона через броню и может пробивать врагов.##",
			["bm_w_corgi"] = "ФТ-200М",
			["bm_w_g36"] = "ГП37",
			  ["bm_g36_sc_desc"] = "Штурмовая винтовка немецкого производства, представляющая собой первоклассный образец современного оружия — легкого, надежного и эргономичного.",
			["bm_w_p99"] = "Волкер-П9м",
			["bm_w_usp"] = "УДП «Компакт»",
			  ["bm_usp_sc_desc"] = "Солидный ствол. Немецкое качество и надежность. Компактное оружие ближнего боя. Пользуется особой популярностью среди ветеранов Зоны.",
			["bm_w_mp5"] = "Гадюка-5",
			  ["bm_mp5_sc_desc"] = "Одно из самых лучших в классе пистолетов-пулеметов оружие. В течение последних десятилетий XX века был принят на вооружение спецподразделений армии и полиции во многих странах мира. С началом постепенной его замены более современными моделями стал часто появляться на черном рынке, откуда массово попал и в Зону.",
			["bm_w_l85a2"] = "ИЛ86",
			  ["bm_l85a2_sc_desc"] = "После того, как в армии Соединенного Королевства эта винтовка была заменена на более современную, она в большом количестве всплыла на черном рынке, а затем и в Зоне. Главными достоинствами данного оружия являются штатный 4-кратный оптический прицел и высокая точность первого выстрела. При стрельбе очередями точность боя резко падает, а основные механизмы демонстрируют недостаточную надежность.",
			["bm_w_spas12"] = "СПСА-14",
			  ["bm_spas12_sc_desc"] = "Гладкоствольное ружье СПСА-14 было разработано в конце 1970-х в качестве универсального боевого оружия для полиции и штурмовых подразделений армии. Данное оружие отличают высокая надежность и гибкость применения; с другой стороны, оно довольно массивно, сложно в устройстве и дорого. Пожалуй, лучшего ствола для ближнего боя в Зоне не найти.",
			["bm_w_colt_1911"] = "Кора-919",
			  ["bm_1911_sc_desc"] = "Классический «Кольт», с честью прошедший все вооруженные конфликты XX века и уверенно вошедший в новое столетие. Невысокая емкость магазина в определенной степени компенсируется использованием мощного патрона.",
			["bm_w_m32"] = "Бульдог-6", -- да я знаю, что Бульдог-6 основан на РГ-6
			  ["bm_m32_sc_desc"] = "Гранатомет револьверного типа. Иногда просто незаменим, в частности при очистке больших площадей от мутантов, нападении на охраняемые стационарные объекты, в бою с особо живучими тварями.",
			["bm_w_b92fs"] = "Марта",
			  ["bm_b92fs_sc_desc"] = "Пистолеты этой серии имеют во всем мире репутацию надежного, хотя и несколько громоздкого оружия, и состоят на вооружении армейских и полицейских формирований многих стран. Не менее популярны и у преступников благодаря мощному патрону и емкому магазину. Как правило, в Зону попадают не самые новые модели.",
			["bm_w_ppk"] = "ПМм",
			["bm_w_x_ppk"] = "Парные ПМм",
			  ["bm_ppk_sc_desc"] = "Наиболее распространенный в Зоне пистолет — наследие советской эпохи. Достаточно надежен и дешев, но отличается невысокой емкостью магазина при недостаточной мощности и неудовлетворительной кучности патрона. Основное оружие сталкера-новичка.",
			["bm_w_rpg7"] = "РПГ-7у",
			["bm_w_siltstone"] = "СВДм-2",
			  ["bm_siltstone_sc_desc"] = "Широко использовалась во всех боевых операциях, проводившихся советской армией с начала 1960-х. Зарекомендовала себя как исключительно надежное и удобное в обращении оружие.\n\n#{skill_color}#Может пробивать броню, врагов, щиты и тонкие стены.##",
			["bm_w_p226"] = "СИП-т М200",
			  ["bm_p226_sc_desc"] = "Модель, разработанная еще в 1975 году, но до сих пор популярная во всем мире. Магазин недостаточно емкий, зато механизм надежен, как швейцарские часы; вторым плюсом является использование мощного патрона.",
			["bm_w_hpb"] = "ХПСС-1м",
			["bm_w_b682"] = "Охотничье ружье",
			  ["bm_b682_sc_desc"] = "Широко распространенное охотничье ружье-«вертикалка» — благодаря достаточной точности и хорошему останавливающему действию — обеспечивает более надежную защиту от мутантов, чем пистолет. Очень дешево и доступно в сравнении с большинством видов оружия, поэтому активно применяется новичками и бандитами как на окраинах, так и в Центре Зоны.",
			["bm_w_deagle"] = "Черный ястреб",
			  ["bm_deagle_sc_desc"] = "Настоящая «карманная пушка» — большая, тяжелая и обладающая чрезвычайно высокой убойной силой. Из-за цены и габаритов особого распространения в Зоне не получила.\n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
			["bm_w_ak74"] = "АКМ-74/2",
			  ["bm_ak74_sc_desc"] = "Автомат складной, образца 1974 года под патрон 5,45 × 39. Представляет собой простое и надежное оружие, хотя дешевизна в производстве несколько сказалась на удобстве использования и точности боя. В Зоне это основное оружие военных, сталкеров и многих одиночек.",
			["bm_w_akmsu"] = "АКМ-74/2У",
			  ["bm_akmsu_sc_desc"] = "По своим габаритам и массе близок к пистолетам-пулеметам, однако устройство механизма почти полностью идентично АКМ-74/2. Малые габариты оружия позволяют успешно использовать его в условиях городской застройки и в стесненных условиях, а пробивающее действие пули довольно велико.",


			-- типо мемные
			["bm_w_saiga"] = "Сайга",
			  ["bm_saiga_sc_desc"] = " - Баффните #{stats_positive}#сайгу!## \n - Ты как #{stats_negative}#ижму## назвал?",
			["bm_w_m4"] = "Кар-карыч",
			["bm_w_ak12"] = "Калак-12",
			  ["bm_flint_sc_desc"] = "С затворной задержкой как у М-16. #{skill_color}#Умеет стрелять очередями по 2## и обладает кризисом личности.",
			["bm_w_p90"] = "Петух",
			["bm_w_sko12"] = "WD 40",
			["bm_w_x_akmsu"] = "KALAWIKI",
			  ["bm_x_akmsu_sc_desc"] = "После взятия иных в руки - у Вас резко появилось желание писать транслитом и поедать сумки с патронами, предварительно кинув под нее коктейль Молотова.",
			["bm_w_ching"] = "\"Золотой\" Галант",
			  ["bm_galant_sc_desc"] = "Тот самый легендарный Галант прямиком из игры #{important_1}#RAID: WW2##\n\n#{skill_color}#Наносит 50% урона через броню и может пробивать врагов и тонкие стены.##",
			["bm_w_m60"] = "Свинка Пеппа",
			["bm_w_x_deagle"] = "Лупа и Пупа",
			  ["bm_x_deagle_sc_desc"] = "Все перепутали... \n\n#{skill_color}#Наносит 50% урона через броню и пробивает врагов.##",
			["bm_w_saw"] = "Болгарка",
			  ["bm_ap_saw_sc_desc"] = "Легендарный инструмент в узких кругах Crime.Net, благодаря которому было распилено не один десяток голов гражданских.\n\n#{skill_color}#Прорезает броню.##",
			["bm_w_x_basset"] = "Акимбо Грибы",
			--Кастомные каламбуры
			["bm_w_ar47"] = "Дочка Калаша и ЭМки",
			  ["bm_w_ar47_desc"] = "Я не могу понять все твои тупые вопросы:\n«Зачем? Почему?» — а я че, Бог?\n\nЯ ебу что ли?",
			["bm_w_sr1"] = "Срам",
			["bm_w_x_sr1"] = "Стыд и Срам",
			--в память о ебнутом деде с анонсов пушек от маквшей
			["bm_w_hailstorm_2006m"] = "Метал Петух 3",
			["bm_w_korth"] = "Каха",
			["bm_w_kacchainsaw"] = "Огнемет с надствольным пилометом",
			["bm_w_contender"] = "АРА ТЫ ЧОООО",
			["bm_w_tkb"] = "Трихерник",
			["bm_w_scout"] = "Пронхорни",
		})
	 end
	 
	
	 local butt = math.rand(1)
	 local sex = 0.01
	 if Month == "4" and Day == "1" then
		sex = 1
	 end
	 if butt <= sex then
		 LocalizationManager:add_localized_strings({
			["menu_st_spec_23"] = "Полурак-полухуй",
			["menu_st_spec_23_desc"] = "Полурак-полухуй - уникальный уеба, обладающий ничем и всем сразу одновременно. Вечное нахождение под кроватью сделало вас, и вы там застряли надолго - зато ловить пули не нужно. Вы изучали своих патлатых товарищей пять секунд, но вам и так ясно, что лучше их посадить в кастоди и самому нагибать, взяв их навыки. Главное, не придумывать механики игры, которых нет - это высшая форма долбоебизма.",

			["menu_difficulty_sm_wish"] = "Ванильный ДС",
			["menu_risk_sm_wish"] = "Чувак. Ты думал что-то здесь будет? О, нет. От тебя ваниллой воняет, даже отсюда чувствую. Выходи, выходи с хаиста и иди нахуй. Друг крутой, а ты лоханулся."
		 })
	 end
	 -- Ради этого мне пришлось сдвинуть пасхалочки в самый низ.
	 local dragon = math.rand(1)
	 local kiwami = 0.01
	 if Month == "12" and Day == "8" then
		kiwami = 1
	 end
	 if dragon <= kiwami then
		LocalizationManager:add_localized_strings({
		["menu_deck12_1"] = "Подобный Кои",
		["menu_deck12_3"] = "Подобный Гадюке",
		["menu_deck12_5"] = "Подобный Тигру",
		["menu_deck12_7"] = "Подобный Дракону",
		["menu_deck12_9"] = "Подобный Хання",
		["menu_deck12_1_desc_sc"] = "Чем меньше у вас здоровья, тем быстрее будет восстанавливаться полоска Уворота, до максимальных #{skill_color}#$perk_value_1## Уворота каждую секунду.\n\nВы получаете #{skill_color}#$perk_value_2## Уворота.\n\n#{important_1}#Среди Якудза татуировки (Иредзуми) являются 'удостоверением' c глубоким подтекстом.\nТе, кто носят на себе карпа кои, отличаются силой и храбростью, и рано или поздно им суждено превзойти почитаемого им дракона, чтобы стать онным.\n\nДо сих пор ходят легенды о двух подобных Кои (с подозрительно схожими голосами). Один из них потерял все и отступился от Кодекса ради того, чтобы стать сильнее и преодолеть Врата Дракона... Но после поражения в бою с Драконом он решил похоронить себя с 10 миллиардами йен, дабы спасти всех.\n\nКакая глупая смерть.##",
		["menu_deck12_3_desc_sc"] = "Чем меньше у вас здоровья, тем больше вы будете получать Уворота при убийстве врага, до максимальных #{skill_color}#$perk_value_1## Уворота.\n\n#{important_1}#Среди Якудза татуировки (Иредзуми) являются 'удостоверением' c глубоким подтекстом.\nТе, кто носят на себе Гадюку, отличаются мудростью и долгом защиты священных мест. Те, кто причинят боль подобным Гадюке, будут прокляты.\n\nВ Окинаве ходят легенды об одном подобном Гадюке. Пускай мало кто его помнит в лицо, он был идеалистичнен и наивен, но предан своему городу.\nЕсли бы не история с планируемой реконструкцией острова в военную базу (или в курорт???), он бы не был прославен своими приключениями с одним из подобных Дракону, но - может быть - он бы остался жив... Если бы за его спиной стоял сценарист, готовый к ретконам.##",
		["menu_deck12_5_desc_sc"] = "Чем меньше у вас здоровья, тем меньше урона вы получаете, до максимальных #{skill_color}#$perk_value_1##.\n\nВы используете сумки для тел и взаимодействуете с гражданскими на #{skill_color}#$perk_value_2## быстрее.\n\n#{important_1}#Среди Якудза татуировки (Иредзуми) являются 'удостоверением' c глубоким подтекстом.\nТе, кто носят на себе Тигра, отличаются пылкостью и грубой силой, которая может потягаться с силой дракона.\n\nМного подобных Тигру известно в криминальной среде Японии, но один из таких прославился еще в 1985 году, убив 18 главных членов противоборствуещего клана из шести револьверов и получив пожизненный срок с ожидающей смертной казнью.\n\n\n\nПравда, пули в револьверах были резиновые. Да и убил их совершенно другой человек.\nНо об этом все узнали только 25 лет спустя...##",
		["menu_deck12_7_desc_sc"] = "Чем меньше у вас здоровья, тем больше вы будете получать Уворота при убийстве врага оружием ближнего боя, до максимальных #{skill_color}#$perk_value_1## Уворота, а также период бессмертия следующего Уворота будет увеличен, до максимальных #{skill_color}#$perk_value_2##, не превышая порог в #{skill_color}#$perk_value_3 мс##.\n\nВы получаете еще на #{skill_color}#$perk_value_4## Уворота.\n\n#{important_1}#Среди Якудза татуировки (Иредзуми) являются 'удостоверением' c глубоким подтекстом.\nТе, кто носят на себе дракона, отличаются необычайной силой и мудростью.\nМножество подобных Дракону достигали успехов, но даже в легендах место найдется только одному из них. Самый известный подобный Дракону дважды с шумом был выгнан из своей семьи и даже сумел стать на день Четвертым председателем своего клана, чем связал свою жизнь с криминалом настолько, что ему пришлось инсценировать свою смерть ради родных ему людей.\n\nИ то этому помешала какая-то виртуальная ютуберша.##",
		["menu_deck12_9_desc_sc"] = "Максимальное количество устойчивости увеличено до #{skill_color}#$perk_value_1.##\n\nОдин раз за падение, если у вас закончится здоровье, вы выживите с #{skill_color}#1## здоровьем и восстановите #{skill_color}#$perk_value_2## брони.\n\nДанный перк не работает на удары Клокеров и шок Тазеров.\n\nБонус полной колоды: Шанс получения предмета высокого качества после прохождения ограбления увеличен на 10%.\n\n#{important_1}#Среди Якудза татуировки (Иредзуми) являются 'удостоверением' c глубоким подтекстом, но мало кто осмелится носить на себе Хання - вселяющую страх маску демона.\nВпрочем, один из подобных Хання прочно записал себя в легенды как «Бешенный пес» - образ, вдохновленный прицнипу «получать больше удовольствия и жить безумнее, чем кто-либо».\nИронично, что этот подобный прожил дольше всех. И пускай он может где-то безпамятно лежать на пляже лицом вниз, мирные жители Кабуки-те вряд ли забудут его голос.##\n\n«Йо... #{risk}#Кирю-чан!!!##»",
		["menu_yakuza_deflection_add"] = "(будучи Подобным)"
		})
		end
	end
end)
