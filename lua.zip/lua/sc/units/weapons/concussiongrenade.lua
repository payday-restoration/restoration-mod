ConcussionGrenade._PLAYER_FLASH_RANGE = 1000
