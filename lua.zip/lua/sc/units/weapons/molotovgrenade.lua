function MolotovGrenade:bullet_hit()
end