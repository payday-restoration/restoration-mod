MutatorEnemyDamage.reductions = {money = 0, exp = 0}
MutatorEnemyDamage.disables_achievements = false