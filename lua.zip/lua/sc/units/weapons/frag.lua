function FragGrenade:bullet_hit()
--yay
end