if SC and SC._data.sc_ai_toggle or restoration and restoration.Options:GetValue("SC/SC") then

	ConcussionGrenade._PLAYER_FLASH_RANGE = 1000
	
end