if restoration.Options:GetValue("HUD/UI/Loadouts") then
ChatGui.PRESETS.default = {
	left = 0,
	bottom = 120,
	layer = 20
}
ChatGui.PRESETS.lobby = {
	left = 0,
	bottom = 50,
	layer = 20
}
end

